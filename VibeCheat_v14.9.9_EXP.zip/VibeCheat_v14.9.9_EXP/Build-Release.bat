@echo off
setlocal
cd /d "%~dp0"

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo Visual Studio Installer / vswhere was not found.
  echo Open VibeMenu.sln manually and build Release x64.
  pause
  exit /b 1
)

for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe`) do set "MSBUILD=%%i"
if not defined MSBUILD (
  echo MSBuild was not found. Install Desktop development with C++.
  pause
  exit /b 1
)

"%MSBUILD%" "%~dp0VibeMenu.sln" /m /p:Configuration=Release /p:Platform=x64
if errorlevel 1 (
  echo.
  echo BUILD FAILED
  pause
  exit /b 1
)

echo.
echo BUILD OK
echo Single DLL: %~dp0bin\RemakeESP.dll
pause
