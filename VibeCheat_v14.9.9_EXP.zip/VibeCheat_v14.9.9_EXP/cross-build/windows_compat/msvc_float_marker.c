/* MSVC COFF floating-point usage marker for the native core. */
int _fltused = 0;
