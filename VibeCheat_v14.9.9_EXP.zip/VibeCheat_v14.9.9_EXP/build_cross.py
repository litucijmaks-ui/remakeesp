"""Optional Zig cross-build of the complete Windows x64 DLL from source.
The Visual Studio project remains the primary Windows build entry point.
"""
from pathlib import Path
import subprocess, os, shutil, xml.etree.ElementTree as E, sys
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).resolve().parent
zig=os.environ.get('VIBE_ZIG') or shutil.which('zig')
if not zig:raise SystemExit('Set VIBE_ZIG to a Zig executable, or put Zig in PATH.')
zig=str(Path(zig).resolve());build=root/'cross-build';build.mkdir(exist_ok=True)
compat=build/'windows_compat';compat.mkdir(exist_ok=True)
(compat/'Windows.h').write_text('#pragma once\n#include_next <windows.h>\n')
(compat/'msvc_float_marker.c').write_text('/* MSVC COFF floating-point usage marker for the native core. */\nint _fltused = 0;\n')
env=os.environ.copy();env['PATH']=str(Path(zig).parent)+os.pathsep+env.get('PATH','')
env['VIBE_CORE_TARGET']='x86_64-windows-gnu'
subprocess.run([sys.executable,str(root/'source/esp/build_single_obj.py')],cwd=root,env=env,check=True)
tree=E.parse(root/'VibeSingleDLL.vcxproj');ns={'m':'http://schemas.microsoft.com/developer/msbuild/2003'}
sources=[n.attrib['Include'].replace('\\','/') for n in tree.findall('.//m:ClCompile',ns) if 'Include' in n.attrib]
# The supplied imconfig selects stb_truetype and the UI only uses FreeType flag
# constants. Keep the selected rasterizer; no MSVC FreeType ABI is linked here.
config=(root/'imgui_menu/vendor/imgui/imconfig.h').read_text()
if any(line.strip().startswith('#define IMGUI_ENABLE_FREETYPE') for line in config.splitlines()):raise SystemExit('This cross-build expects the supplied stb_truetype configuration.')
sources=[s for s in sources if not s.endswith('/imgui_freetype.cpp')]
includes=['imgui_menu/src','imgui_menu/src/ui','imgui_menu/src/vibe','imgui_menu/vendor/imgui','imgui_menu/vendor/imgui/backends','imgui_menu/vendor/freetype/include']
common=['-target','x86_64-windows-gnu','-O2','-DNDEBUG','-DNOMINMAX','-DVIBE_INTERNAL_DLL_UI=1','-fms-extensions','-fno-autolink','-Wno-error=date-time','-I'+str(compat)]+['-I'+str(root/i) for i in includes]
def compile_one(source):
    obj=build/(Path(source).stem+'.obj')
    language=['c++','-std=c++20'] if Path(source).suffix in ('.cpp','.cxx') else ['cc','-std=c11']
    result=subprocess.run([zig,*language,*common,'-c',str(root/source),'-o',str(obj)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (build/(Path(source).stem+'.log')).write_text(result.stdout,encoding='utf-8')
    if result.returncode:raise RuntimeError(source+'\n'+result.stdout[-12000:])
    print('Compiled '+source,flush=True);return str(obj)
with ThreadPoolExecutor(max_workers=3) as pool:objects=list(pool.map(compile_one,sources))
objects.append(compile_one('cross-build/windows_compat/msvc_float_marker.c'))
out=root/'bin'/'RemakeESP.dll';out.parent.mkdir(exist_ok=True)
libraries=['d3d11','d3dcompiler_47','dxgi','dwmapi','shell32','user32','gdi32','kernel32','ole32','windowscodecs','dbghelp','uuid','winmm']
subprocess.run([zig,'c++','-target','x86_64-windows-gnu','-shared','-O2',*objects,str(root/'source/esp/native-build-single/esp.c.obj'),str(root/'VibeSingle.def'),*['-l'+x for x in libraries],'-o',str(out)],cwd=root,check=True)
print(out)
