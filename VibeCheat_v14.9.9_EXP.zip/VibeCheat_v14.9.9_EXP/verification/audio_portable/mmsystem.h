#pragma once
#include "windows.h"
using HWAVEOUT=void*;using MMRESULT=unsigned;
#define WHDR_DONE 1u
#define WHDR_PREPARED 2u
#define WHDR_INQUEUE 16u
#define WAVE_FORMAT_PCM 1u
#define WAVE_MAPPER 0xffffffffu
#define CALLBACK_NULL 0u
struct WAVEFORMATEX{std::uint16_t wFormatTag,nChannels;DWORD nSamplesPerSec,nAvgBytesPerSec;std::uint16_t nBlockAlign,wBitsPerSample,cbSize;};
struct WAVEHDR{LPSTR lpData;DWORD dwBufferLength,dwBytesRecorded;DWORD_PTR dwUser;DWORD dwFlags,dwLoops;WAVEHDR* lpNext;DWORD_PTR reserved;};
MMRESULT waveOutOpen(HWAVEOUT*,UINT,const WAVEFORMATEX*,DWORD_PTR,DWORD_PTR,DWORD);
MMRESULT waveOutPrepareHeader(HWAVEOUT,WAVEHDR*,UINT);MMRESULT waveOutUnprepareHeader(HWAVEOUT,WAVEHDR*,UINT);
MMRESULT waveOutWrite(HWAVEOUT,WAVEHDR*,UINT);MMRESULT waveOutReset(HWAVEOUT);MMRESULT waveOutClose(HWAVEOUT);
