#pragma once
#include <cstdint>
#include <cstddef>
#define WINAPI
#define INFINITE 0xffffffffu
using DWORD=std::uint32_t;using UINT=unsigned;using BOOL=int;using ULONGLONG=std::uint64_t;using HANDLE=void*;using LPSTR=char*;using DWORD_PTR=std::uintptr_t;
using THREADPROC=DWORD(*)(void*);
ULONGLONG GetTickCount64();DWORD GetLastError();void Sleep(DWORD);
HANDLE CreateThread(void*,std::size_t,THREADPROC,void*,DWORD,DWORD*);
DWORD WaitForSingleObject(HANDLE,DWORD);BOOL CloseHandle(HANDLE);
