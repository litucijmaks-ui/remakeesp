// VIBE IL2CPP runtime metadata export
// RVA is relative to GameAssembly.dll; unavailable native pointers are null.
// Names/signatures are preserved as metadata; this reference listing may not compile.

// Image: Assembly-"Game\Рус.dl l

// Namespace: Space Line | Declaring type:  | Flags: 0x1
class Класс"\
{
    static System.Collections.Generic.List<System.String> value  "\; // Offset: 0x18, Flags: 0x10
    // RVA: 0x1234 | Token: 0x6000001 | Flags: 0x10 | Impl: 0x7
    static System.Collections.Generic.List<System.String> Fire"\(System.Collections.Generic.List<System.String> arg  );
    // RVA: unavailable | Token: 0x6000001 | Flags: 0x10 | Impl: 0x7
    static System.Collections.Generic.List<System.String> NoPointer();
}

// Image: Empty.dll
