from pathlib import Path
import argparse, struct, json, hashlib, re
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

parser=argparse.ArgumentParser()
parser.add_argument('binary');parser.add_argument('metadata');parser.add_argument('output')
parser.add_argument('--owner', action='append', default=[], help='Additional exact class names to disassemble')
parser.add_argument('--lookup-rva',action='append',default=[],type=lambda x:int(x,0))
args=parser.parse_args(); out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
data=Path(args.metadata).read_bytes();raw=Path(args.binary).read_bytes()
assert struct.unpack_from('<II',data)==(0xFAB11BAF,107)
names='stringLiteral stringLiteralData string events properties methods parameterDefaultValues fieldDefaultValues fieldAndParameterDefaultValueData fieldMarshaledSizes parameters fields genericParameters genericParameterConstraints genericContainers nestedTypes interfaces vtableMethods interfaceOffsets typeDefinitions typeInlineArrays images assemblies fieldRefs referencedAssemblies attributeData attributeDataRange unresolvedVirtualCallParameterTypes unresolvedVirtualCallParameterRanges windowsRuntimeTypeNames windowsRuntimeStrings exportedTypeDefinitions'.split()
sections={n:struct.unpack_from('<iii',data,8+i*12) for i,n in enumerate(names)}
for o,size,count in sections.values():assert o>=0 and size>=0 and count>=0 and o+size<=len(data)
assert sections['typeDefinitions'][1]==63*sections['typeDefinitions'][2]
assert sections['methods'][1]==30*sections['methods'][2]
assert sections['parameters'][1]==10*sections['parameters'][2]
assert sections['images'][1]==36*sections['images'][2]
strings=data[sections['string'][0]:sum(sections['string'][:2])]
def ui(p,n=4):return int.from_bytes(data[p:p+n],'little')
def st(i):
    assert 0<=i<len(strings)
    end=strings.find(b'\0',i);assert end>=i
    return strings[i:end].decode('utf-8')
types=[]
for i in range(sections['typeDefinitions'][2]):
    p=sections['typeDefinitions'][0]+i*63
    types.append(dict(name=st(ui(p)),namespace=st(ui(p+4)),byval_type=ui(p+8,2),first_field=ui(p+20,2),field_count=ui(p+43,2),first_method=ui(p+22),method_count=ui(p+39,2),image=None))
type_names={t['byval_type']:t['namespace']+'.'+t['name'] for t in types}
images=[]
for i in range(sections['images'][2]):
    p=sections['images'][0]+i*36;name=st(ui(p));start=ui(p+8,2);count=ui(p+10)
    assert start+count<=len(types)
    image=dict(name=name,start=start,count=count,method_count=0)
    for t in types[start:start+count]:t['image']=name;image['method_count']+=t['method_count']
    images.append(image)
methods=[]
for i in range(sections['methods'][2]):
    p=sections['methods'][0]+i*30;owner=ui(p+4,2);assert owner<len(types)
    t=types[owner];count=ui(p+28,2);first=ui(p+12);params=[]
    assert count==0 or first+count<=sections['parameters'][2]
    for j in range(first,first+count):
        q=sections['parameters'][0]+j*10;params.append(dict(name=st(ui(q)),type_index=ui(q+8,2)))
    methods.append(dict(index=i,name=st(ui(p)),owner=t['name'],namespace=t['namespace'],image=t['image'],token=ui(p+18),return_type_index=ui(p+6,2),flags=ui(p+22,2),parameters=params,rva=None))
    methods[-1]['return_type']=type_names.get(methods[-1]['return_type_index'])
    for param in params:param['type_name']=type_names.get(param['type_index'])
pe=pefile.PE(data=raw,fast_load=True);base=pe.OPTIONAL_HEADER.ImageBase
def offset(va):return pe.get_offset_from_rva(va-base)
module_matches={}
for image in images:
    needle=image['name'].encode()+b'\0';pos=raw.find(needle)
    if pos<0:continue
    va=base+pe.get_rva_from_offset(pos);pattern=struct.pack('<Q',va);candidates=[];p=0
    while True:
        p=raw.find(pattern,p)
        if p<0:break
        if p+24<=len(raw):
            count,table=struct.unpack_from('<QQ',raw,p+8)
            if count==image['method_count'] and count>0 and base<table<base+pe.OPTIONAL_HEADER.SizeOfImage:
                try:
                    start=offset(table)
                    assert start+count*8<=len(raw)
                    pointers=struct.unpack_from('<'+'Q'*count,raw,start)
                    assert all(v==0 or base<=v<base+pe.OPTIONAL_HEADER.SizeOfImage for v in pointers)
                    candidates.append(pointers)
                except (AssertionError,pefile.PEFormatError):pass
        p+=1
    if len(candidates)==1:module_matches[image['name']]=candidates[0]
assert 'Assembly-CSharp.dll' in module_matches,'Native Assembly-CSharp method count differs from this metadata; refusing a guessed token/RVA map'
rva_names={}
for m in methods:
    pointers=module_matches.get(m['image']);rid=m['token']&0xffffff
    if pointers and 0<rid<=len(pointers) and pointers[rid-1]:
        m['rva']=pointers[rid-1]-base;rva_names.setdefault(m['rva'],[]).append(m['owner']+'.'+m['name'])
shoot=next(m for m in methods if m['owner']=='HeldWeaponLogic' and m['name']=='CmdShootWeapon')
param_types=[p['type_index'] for p in shoot['parameters']]
selected=[m for m in methods if m['owner']=='HeldWeaponLogic' and (m['name'] in ['CmdShootWeapon','CmdHitPlayer','ServerOnPlayerHit'] or m['name'].startswith('UserCode_Cmd') and [p['type_index'] for p in m['parameters']]==param_types)]
selected += [m for m in methods if m['owner']=='ClientAntiCheatBootstrap' and m['name'] in ['Update','Awake','TriggerViolation','ɚƠѐĸƛӲ']]
selected += [m for m in methods if m['owner']=='AntiCheatMonitor' and m['name'] in ['OnNext','FixedUpdate','GetDetector','GetPunisher','get_ThreatLevel']]
selected += [m for m in methods if (m['owner'] in args.owner or m['rva'] in args.lookup_rva) and m not in selected]
field_inventory=[]
for t in types:
    if t['name'] in args.owner:
        fields=[]
        for i in range(t['first_field'],t['first_field']+t['field_count']):
            assert 0<=i<sections['fields'][2]
            p=sections['fields'][0]+i*10
            fields.append(dict(index=i,name=st(ui(p)),type_index=ui(p+4,2),type_name=type_names.get(ui(p+4,2))))
        field_inventory.append(dict(owner=t['name'],namespace=t['namespace'],fields=fields))
(out/'field-inventory.json').write_text(json.dumps(field_inventory,ensure_ascii=False,indent=2)+'\n')
(out/'type-inventory.json').write_text(json.dumps(types,ensure_ascii=False,indent=2)+'\n')
md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
starts=sorted(rva_names)
for m in selected:
    rva=m['rva']
    if rva is None:continue
    later=next((p for p in starts if p>rva),rva+20000);length=min(later-rva,20000)
    code=raw[offset(base+rva):offset(base+rva)+length];lines=[];calls=[]
    for ins in md.disasm(code,base+rva):
        suffix=''
        if ins.mnemonic in ['call','jmp'] and len(ins.operands)==1 and ins.operands[0].type==2:
            target=ins.operands[0].imm-base;names_at=rva_names.get(target,[])
            suffix=' ; '+' | '.join(names_at) if names_at else ''
            calls.append(dict(rva=hex(target),names=names_at))
        lines.append(f'{ins.address-base:08x} {ins.mnemonic:8} {ins.op_str}{suffix}')
    m['calls']=calls;m['disassembly_bytes']=length
    (out/(str(m['index'])+'-'+m['owner']+'.txt')).write_text('\n'.join(lines)+'\n')
report=dict(binary_name=Path(args.binary).name,binary_sha256=hashlib.sha256(raw).hexdigest(),metadata_sha256=hashlib.sha256(data).hexdigest(),metadata_version=107,assembly_method_count=len(module_matches['Assembly-CSharp.dll']),matched_modules=len(module_matches),mapped_methods=sum(m['rva'] is not None for m in methods),methods=selected,scope='Static method-table mapping and disassembly of supplied client binary; live server and damage acceptance not tested')
(out/'reverse-map.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['binary_sha256','assembly_method_count','matched_modules','mapped_methods']},ensure_ascii=False))
for m in selected:print(m['index'],m['owner'],m['name'],hex(m['rva']) if m['rva'] is not None else None,'bytes',m.get('disassembly_bytes'))
