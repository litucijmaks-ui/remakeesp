@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-CoreObject.ps1"
exit /b %errorlevel%
