$ErrorActionPreference = 'Stop'
$sourceRoot = Join-Path $PSScriptRoot 'source'
$manifestPath = Join-Path $sourceRoot 'esp/native-build-single/core-manifest.json'
$objectPath = Join-Path $sourceRoot 'esp/native-build-single/esp.c.obj'
if ((Test-Path -LiteralPath $manifestPath) -and (Test-Path -LiteralPath $objectPath)) {
    $coreManifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $coreMatches = ((Get-FileHash -LiteralPath $objectPath -Algorithm SHA256).Hash.ToLowerInvariant() -eq $coreManifest.object_sha256)
    foreach ($coreFile in $coreManifest.sources.PSObject.Properties) {
        $corePath = Join-Path $sourceRoot $coreFile.Name
        if (!(Test-Path -LiteralPath $corePath) -or ((Get-FileHash -LiteralPath $corePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $coreFile.Value)) { $coreMatches = $false; break }
    }
    if ($coreMatches) { Write-Output 'Verified included core COFF and source hashes'; exit 0 }
}
$bundledPython = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$builder = Join-Path $PSScriptRoot 'source/esp/build_single_obj.py'
if (Test-Path -LiteralPath $bundledPython) { & $bundledPython $builder }
elseif (Get-Command py -ErrorAction SilentlyContinue) { & py -3 $builder }
else { & python $builder }
exit $LASTEXITCODE
