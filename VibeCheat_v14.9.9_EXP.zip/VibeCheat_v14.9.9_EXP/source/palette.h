/* HSV palette: two cached CPU rasters, no per-pixel GDI objects or timers. */
#define PALETTE_W 208
#define PALETTE_H 112
typedef struct {DWORD size;int32_t width,height;uint16_t planes,bits;DWORD compression,image_size;int32_t xppm,yppm;DWORD used,important;} PaletteBitmapInfo;
static DWORD palette_pixels[PALETTE_W*PALETTE_H],palette_hue_pixels[PALETTE_W*12];
static int palette_hue,palette_sat,palette_value,palette_raster_hue=-1,palette_drag=-1;
static DWORD palette_seen_color;
static DWORD *palette_seen_target;
static BOOL palette_hue_ready;
static DWORD palette_rgb(int hue,int saturation,int value){
 int sector=hue/256,fraction=hue%256,p=value*(255-saturation)/255,q=value*(255-saturation*fraction/255)/255,t=value*(255-saturation*(255-fraction)/255)/255;
 switch(sector%6){case 0:return RGB(value,t,p);case 1:return RGB(q,value,p);case 2:return RGB(p,value,t);case 3:return RGB(p,q,value);case 4:return RGB(t,p,value);default:return RGB(value,p,q);}
}
static void palette_sync(void){
 DWORD *target=selected_color(),color=*target;if(palette_seen_target==target&&palette_seen_color==color)return;
 int r=color&255,g=(color>>8)&255,b=(color>>16)&255,max=r>g?r:g,min=r<g?r:g;if(b>max)max=b;if(b<min)min=b;
 int delta=max-min;palette_value=max;palette_sat=max?delta*255/max:0;
 if(delta){int hue=max==r?(g-b)*256/delta:max==g?512+(b-r)*256/delta:1024+(r-g)*256/delta;while(hue<0)hue+=1536;palette_hue=hue%1536;}
 else if(palette_seen_target!=target)palette_hue=0;
 palette_seen_target=target;palette_seen_color=color;
}
static DWORD palette_dib(DWORD color){return ((color&255u)<<16)|(color&0xff00u)|((color>>16)&255u);}
static int palette_top(void){return page==6?268:250;}
static int palette_hue_top(void){return palette_top()+127;}
static int palette_hit(int x,int y){if(x<180||x>=180+PALETTE_W)return -1;int top=palette_top();if(y>=top&&y<top+PALETTE_H)return 0;if(y>=top+127&&y<top+139)return 1;return -1;}
static BOOL palette_set(int part,int x,int y){
 palette_sync();if(x<180)x=180;if(x>180+PALETTE_W-1)x=180+PALETTE_W-1;
 if(part==1)palette_hue=(x-180)*1535/(PALETTE_W-1);
 else{int top=palette_top();if(y<top)y=top;if(y>top+PALETTE_H-1)y=top+PALETTE_H-1;palette_sat=(x-180)*255/(PALETTE_W-1);palette_value=255-(y-top)*255/(PALETTE_H-1);}
 DWORD color=palette_rgb(palette_hue,palette_sat,palette_value);BOOL changed=color!=*selected_color();*selected_color()=color;palette_seen_target=selected_color();palette_seen_color=color;return changed;
}
static void palette_blit(HDC dc,int x,int y,int height,const DWORD *pixels){
 PaletteBitmapInfo info={sizeof(info),PALETTE_W,-height,1,32,0,(DWORD)(PALETTE_W*height*4),0,0,0,0};
 SetDIBitsToDevice(dc,x,y-draw_scroll,PALETTE_W,(DWORD)height,0,0,0,(UINT)height,pixels,&info,0);
}
static void palette_paint(HDC dc){
 palette_sync();
 if(palette_raster_hue!=palette_hue){for(int y=0;y<PALETTE_H;++y)for(int x=0;x<PALETTE_W;++x)palette_pixels[y*PALETTE_W+x]=palette_dib(palette_rgb(palette_hue,x*255/(PALETTE_W-1),255-y*255/(PALETTE_H-1)));palette_raster_hue=palette_hue;}
 if(!palette_hue_ready){for(int y=0;y<12;++y)for(int x=0;x<PALETTE_W;++x)palette_hue_pixels[y*PALETTE_W+x]=palette_dib(palette_rgb(x*1535/(PALETTE_W-1),255,255));palette_hue_ready=1;}
 int top=palette_top(),x=180+palette_sat*(PALETTE_W-1)/255,y=top+(255-palette_value)*(PALETTE_H-1)/255;
 palette_blit(dc,180,top,PALETTE_H,palette_pixels);palette_blit(dc,180,palette_hue_top(),12,palette_hue_pixels);
 HGDIOBJ p=SelectObject(dc,accent_pen),b=SelectObject(dc,GetStockObject(5));Ellipse(dc,x-4,y-4-draw_scroll,x+5,y+5-draw_scroll);
 int hx=180+palette_hue*(PALETTE_W-1)/1535;Rectangle(dc,hx-2,palette_hue_top()-2-draw_scroll,hx+3,palette_hue_top()+14-draw_scroll);SelectObject(dc,p);SelectObject(dc,b);
}
