#ifndef VIBE_SETTINGS_H
#define VIBE_SETTINGS_H
/* A complete, checksummed record shared by the standalone menu and ESP. */
#define SETTINGS_MAGIC 0x48505345u
#define SETTINGS_V14_8_MAGIC 0x47505345u
#define SETTINGS_V14_7_MAGIC 0x46505345u
#define SETTINGS_V14_4_MAGIC 0x45505345u
#define SETTINGS_V14_MAGIC 0x44505345u
#define SETTINGS_V12_MAGIC 0x43505345u
#define SETTINGS_V10_MAGIC 0x41505345u
#define SETTINGS_V9_MAGIC 0x39505345u
#define SETTINGS_LEGACY_MAGIC 0x33505345u
#define MENU_WINDOW_CLASS "VibeRemakeMenu12"
#define MENU_CLOSE_MESSAGE 0x8353u
#define MENU_CLOSE_COOKIE 0x45535034u
#define RANGE_LIMIT_M 1500u
#define RANGE_DEFAULT_M 500u
#define PROFILE_AUTO 0u
#define PROFILE_SMOOTH 1u
#define PROFILE_ECO 2u
#define AIM_FOV_LIMIT 600u
#define AIM_FOV_DEFAULT 160u
#define AIM_BIND_DEFAULT 2u
#define AIM_POINT_HEAD 0u
#define AIM_POINT_BODY 1u
#define AIM_POINT_LEGS 2u
#define AIM_MODE_CAMERA 0u
#define AIM_MODE_SILENT 1u
#define AIM_MODE_AIMKILL 2u
#define SETTINGS_REMOVED_AIM_MODE 3u
#define FARM_MODE_AUTO 0u
#define FARM_SEARCH_LIMIT_M 1000u
#define VISUAL_TIME 1u
#define VISUAL_SKY_COLOR 2u
#define VISUAL_HANDS 4u
#define VISUAL_FOG 8u
#define HANDS_DISTANCE_LIMIT_CM 100u
#define ESP_COLOR_BOX 0u
#define ESP_COLOR_NAME 1u
#define ESP_COLOR_LINE 2u
#define ESP_COLOR_SKELETON 3u
#define ESP_COLOR_HP 4u
#define ESP_COLOR_DISTANCE 5u
#define ESP_COLOR_FOV 6u
#define ESP_COLOR_COUNT 7u
/* farm_mode and farm_reserve_percent retain their positions for old records. */
typedef struct {DWORD magic,flags,min_m,max_m,profile,aim_flags,aim_fov,aim_key,aim_point,aim_sharpness,aim_mode,farm_flags,farm_mode,farm_range_cm,farm_interval_ms,move_flags,speed_percent,farm_search_m,farm_reserve_percent,speed_key,noclip_key,rapid_flags,rapid_percent,visual_flags,sky_minutes,sky_color,hands_distance_cm,esp_colors[ESP_COLOR_COUNT],esp_width,fog_color,medkit_threshold,medkit_slots,medkit_delay_ms,magic_cooldown_ms,combat_flags,fastkill_damage,balloon_max_m,check;} ESPSettings;
static inline BOOL settings_key_valid(DWORD key){return key>0&&key<255&&key!=27&&key!=0x23&&key!=0x2d&&key!=0x12&&key!=0xa4&&key!=0xa5;}
static inline DWORD settings_old_checksum(const ESPSettings *s){return 0x56494245u^s->magic^s->flags^(s->min_m*31u)^(s->max_m*131u)^(s->profile*17u)^(s->aim_flags*193u)^(s->aim_fov*251u)^(s->aim_key*397u)^(s->aim_point*503u)^(s->aim_sharpness*719u)^(s->aim_mode*823u)^(s->farm_flags*947u)^(s->farm_mode*1031u)^(s->farm_range_cm*1151u)^(s->farm_interval_ms*1223u)^(s->move_flags*1381u)^(s->speed_percent*1459u)^(s->farm_search_m*1543u)^(s->farm_reserve_percent*1657u);}
static inline DWORD settings_v14_4_checksum(const ESPSettings *s){return settings_old_checksum(s)^(s->speed_key*1783u)^(s->noclip_key*1861u)^(s->rapid_flags*1973u)^(s->rapid_percent*2081u);}
static inline DWORD settings_v14_8_checksum(const ESPSettings *s){DWORD check=settings_v14_4_checksum(s)^(s->visual_flags*2203u)^(s->sky_minutes*2333u)^(s->sky_color*2441u)^(s->hands_distance_cm*2557u)^(s->esp_width*2683u)^(s->fog_color*3691u)^(s->medkit_threshold*3821u);for(unsigned i=0;i<ESP_COLOR_COUNT;++i)check^=s->esp_colors[i]*(2801u+i*122u);return check;}
static inline DWORD settings_checksum(const ESPSettings *s){return settings_v14_8_checksum(s)^(s->medkit_slots*3943u)^(s->medkit_delay_ms*4051u)^(s->magic_cooldown_ms*4177u)^(s->combat_flags*4297u)^(s->fastkill_damage*4409u)^(s->balloon_max_m*4507u);}
static inline DWORD settings_color_default(unsigned i){const DWORD colors[ESP_COLOR_COUNT]={RGB(0,255,120),RGB(248,248,252),RGB(0,255,120),RGB(0,255,120),RGB(0,255,120),RGB(248,248,252),RGB(225,225,232)};return i<ESP_COLOR_COUNT?colors[i]:0;}
static inline void settings_reset_colors(ESPSettings *s){for(unsigned i=0;i<ESP_COLOR_COUNT;++i)s->esp_colors[i]=settings_color_default(i);s->esp_width=2;}
static inline void settings_normalize(ESPSettings *s){s->farm_mode=FARM_MODE_AUTO;s->farm_flags&=223u;s->combat_flags&=13u;if(s->aim_mode==SETTINGS_REMOVED_AIM_MODE){s->aim_mode=AIM_MODE_SILENT;s->aim_flags|=4u;}}
static inline void settings_default(ESPSettings *s){*s=(ESPSettings){.magic=SETTINGS_MAGIC,.flags=30,.max_m=RANGE_DEFAULT_M,.profile=PROFILE_AUTO,.aim_flags=2,.aim_fov=AIM_FOV_DEFAULT,.aim_key=AIM_BIND_DEFAULT,.aim_point=AIM_POINT_HEAD,.aim_sharpness=35,.aim_mode=AIM_MODE_CAMERA,.farm_flags=30,.farm_mode=FARM_MODE_AUTO,.farm_range_cm=300,.farm_interval_ms=500,.speed_percent=100,.farm_search_m=60,.farm_reserve_percent=15,.rapid_percent=200,.sky_minutes=720,.sky_color=RGB(83,130,190),.hands_distance_cm=20,.fog_color=RGB(160,170,180),.medkit_threshold=60,.medkit_slots=255,.medkit_delay_ms=1500,.magic_cooldown_ms=500,.fastkill_damage=250,.balloon_max_m=RANGE_DEFAULT_M};settings_reset_colors(s);s->check=settings_checksum(s);}
static inline BOOL settings_decode(ESPSettings *out,const void *data,DWORD count){
 if(count==8){const DWORD *old=data;if(old[0]!=SETTINGS_LEGACY_MAGIC)return 0;settings_default(out);out->flags=old[1]&63u;out->check=settings_checksum(out);return 1;}
 if(count==24){
  const DWORD *old=data;DWORD check=0x56494245u^old[0]^old[1]^(old[2]*31u)^(old[3]*131u)^(old[4]*17u);
  if(old[0]!=SETTINGS_V9_MAGIC||old[1]>63||old[2]>old[3]||old[3]>RANGE_LIMIT_M||old[4]>PROFILE_ECO||old[5]!=check)return 0;
  settings_default(out);out->flags=old[1];out->min_m=0;out->max_m=old[3];out->profile=old[4];out->check=settings_checksum(out);return 1;
 }
 if(count==44){
  const DWORD *old=data;DWORD check=0x56494245u^old[0]^old[1]^(old[2]*31u)^(old[3]*131u)^(old[4]*17u)^(old[5]*193u)^(old[6]*251u)^(old[7]*397u)^(old[8]*503u)^(old[9]*719u);
  if(old[0]!=SETTINGS_V10_MAGIC||old[1]>63||old[2]>old[3]||old[3]>RANGE_LIMIT_M||old[4]>PROFILE_ECO||old[5]>3||old[6]>AIM_FOV_LIMIT||!settings_key_valid(old[7])||old[8]>AIM_POINT_LEGS||old[9]<1||old[9]>100||old[10]!=check)return 0;
  settings_default(out);out->flags=old[1];out->min_m=0;out->max_m=old[3];out->profile=old[4];out->aim_flags=old[5];out->aim_fov=old[6];out->aim_key=old[7];out->aim_point=old[8];out->aim_sharpness=old[9];out->check=settings_checksum(out);return 1;
 }
 if(count==72||count==80||count==96){
  const DWORD *old=data;ESPSettings migrated;settings_default(&migrated);
  DWORD *dest=(DWORD*)&migrated;for(int i=0;i<(count==72?17:count==80?19:23);++i)dest[i]=old[i];
  DWORD old_check=settings_old_checksum(&migrated);
  if(count==72){old_check^=(migrated.farm_search_m*1543u)^(migrated.farm_reserve_percent*1657u);if(old[0]!=SETTINGS_V12_MAGIC||old[17]!=old_check||old[11]>7||old[15]>3)return 0;migrated.farm_flags=(migrated.farm_flags&6u)|24u;}
  else if(count==80){if(old[0]!=SETTINGS_V14_MAGIC||old[19]!=old_check||old[11]>255||old[12]>1)return 0;}
  else if(old[0]!=SETTINGS_V14_4_MAGIC||old[23]!=settings_v14_4_checksum(&migrated))return 0;
  migrated.magic=SETTINGS_MAGIC;migrated.min_m=0;settings_normalize(&migrated);
  migrated.check=settings_checksum(&migrated);return settings_decode(out,&migrated,sizeof(migrated));
 }
 if(count==144){const DWORD *old=data;ESPSettings migrated;settings_default(&migrated);DWORD *dest=(DWORD*)&migrated;for(unsigned i=0;i<35;++i)dest[i]=old[i];DWORD legacy=settings_v14_8_checksum(&migrated)^(migrated.fog_color*3691u)^(migrated.medkit_threshold*3821u);if(old[0]!=SETTINGS_V14_7_MAGIC||old[35]!=legacy||migrated.visual_flags>7||migrated.rapid_flags>1)return 0;migrated.magic=SETTINGS_MAGIC;migrated.check=settings_checksum(&migrated);return settings_decode(out,&migrated,sizeof(migrated));}
 if(count==152){const DWORD *old=data;ESPSettings migrated;settings_default(&migrated);DWORD *dest=(DWORD*)&migrated;for(unsigned i=0;i<37;++i)dest[i]=old[i];if(old[0]!=SETTINGS_V14_8_MAGIC||old[37]!=settings_v14_8_checksum(&migrated))return 0;migrated.magic=SETTINGS_MAGIC;migrated.check=settings_checksum(&migrated);return settings_decode(out,&migrated,sizeof(migrated));}
 if(count==172){const DWORD *old=data;ESPSettings migrated;settings_default(&migrated);DWORD *dest=(DWORD*)&migrated;for(unsigned i=0;i<42;++i)dest[i]=old[i];if(old[0]!=SETTINGS_MAGIC||old[42]!=(settings_checksum(&migrated)^(migrated.balloon_max_m*4507u)))return 0;migrated.check=settings_checksum(&migrated);return settings_decode(out,&migrated,sizeof(migrated));}
 if(count!=sizeof(ESPSettings))return 0;
 const ESPSettings *s=data;
 if(s->medkit_slots>255||s->medkit_delay_ms<100||s->medkit_delay_ms>10000||s->magic_cooldown_ms<150||s->magic_cooldown_ms>5000||s->combat_flags>15||s->fastkill_damage<1||s->fastkill_damage>500||s->visual_flags>15||s->fog_color>0xffffffu||s->medkit_threshold<1||s->medkit_threshold>99||s->sky_minutes>1440||s->sky_color>0xffffffu||s->hands_distance_cm>HANDS_DISTANCE_LIMIT_CM||s->esp_width<1||s->esp_width>4)return 0;
 for(unsigned i=0;i<ESP_COLOR_COUNT;++i)if(s->esp_colors[i]>0xffffffu)return 0;
 if(s->magic!=SETTINGS_MAGIC||s->flags>2047||s->min_m!=0||s->max_m>RANGE_LIMIT_M||s->profile>PROFILE_ECO||s->aim_flags>7||s->aim_fov>AIM_FOV_LIMIT||!settings_key_valid(s->aim_key)||s->aim_point>AIM_POINT_LEGS||s->aim_sharpness<1||s->aim_sharpness>100||s->aim_mode>SETTINGS_REMOVED_AIM_MODE||s->farm_flags>255||s->farm_mode!=FARM_MODE_AUTO||s->farm_range_cm<50||s->farm_range_cm>800||s->farm_interval_ms<20||s->farm_interval_ms>2000||s->move_flags>7||s->speed_percent<100||s->speed_percent>300||s->farm_search_m<5||s->farm_search_m>FARM_SEARCH_LIMIT_M||s->farm_reserve_percent<5||s->farm_reserve_percent>50||(s->speed_key&&!settings_key_valid(s->speed_key))||(s->noclip_key&&!settings_key_valid(s->noclip_key))||(s->speed_key&&(s->speed_key==s->noclip_key||s->speed_key==s->aim_key))||(s->noclip_key&&s->noclip_key==s->aim_key)||s->rapid_flags>63||s->rapid_percent<100||s->rapid_percent>300||s->balloon_max_m>2500u||s->check!=settings_checksum(s))return 0;
 *out=*s;settings_normalize(out);out->check=settings_checksum(out);return 1;
}
static inline BOOL settings_load(const char *path,ESPSettings *out){
 HANDLE f=CreateFileA(path,0x80000000u,7,0,3,0x80,0);if(f==INVALID_HANDLE)return 0;
 ESPSettings data={0};DWORD got=0;BOOL ok=ReadFile(f,&data,sizeof(data),&got,0);CloseHandle(f);
 return ok&&settings_decode(out,&data,got);
}
static inline BOOL settings_save(const char *path,ESPSettings *s){
 char temporary[1100];size_t n=slen(path);if(n+5>=sizeof(temporary))return 0;
 copystr(temporary,path,sizeof(temporary));copystr(temporary+n,".tmp",sizeof(temporary)-n);
 s->magic=SETTINGS_MAGIC;settings_normalize(s);s->check=settings_checksum(s);
 HANDLE f=CreateFileA(temporary,0x40000000u,0,0,2,0x80,0);if(f==INVALID_HANDLE)return 0;
 DWORD wrote=0;BOOL ok=WriteFile(f,s,sizeof(*s),&wrote,0);CloseHandle(f);
 if(!ok||wrote!=sizeof(*s)){DeleteFileA(temporary);return 0;}
 if(!MoveFileExA(temporary,path,9)){DeleteFileA(temporary);return 0;}
 return 1;
}
static inline BOOL settings_load_w(const WCHAR *path,ESPSettings *out){
 HANDLE f=CreateFileW(path,0x80000000u,7,0,3,0x80,0);if(f==INVALID_HANDLE)return 0;
 ESPSettings data={0};DWORD got=0;BOOL ok=ReadFile(f,&data,sizeof(data),&got,0);CloseHandle(f);return ok&&settings_decode(out,&data,got);
}
static inline BOOL settings_save_w(const WCHAR *path,ESPSettings *s){
 WCHAR temporary[1100];size_t n=wlen(path);if(n+5>=sizeof(temporary)/sizeof(*temporary))return 0;
 wcopy(temporary,path,1100);wascii(temporary+n,".tmp",1100-n);s->magic=SETTINGS_MAGIC;settings_normalize(s);s->check=settings_checksum(s);
 HANDLE f=CreateFileW(temporary,0x40000000u,0,0,2,0x80,0);if(f==INVALID_HANDLE)return 0;
 DWORD wrote=0;BOOL ok=WriteFile(f,s,sizeof(*s),&wrote,0);CloseHandle(f);
 if(!ok||wrote!=sizeof(*s)){DeleteFileW(temporary);return 0;}
 if(!MoveFileExW(temporary,path,9)){DeleteFileW(temporary);return 0;}return 1;
}
#endif
