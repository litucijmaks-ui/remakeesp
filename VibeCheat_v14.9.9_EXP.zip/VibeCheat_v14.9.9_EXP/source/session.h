#ifndef VIBE_SESSION_H
#define VIBE_SESSION_H
#define SESSION_QUIT_MESSAGE 0x8354u
#define SESSION_COOKIE 0x56494231u
#define SESSION_PID_PROPERTY "Vibe.GamePID.12"
#define SESSION_REQUEST_PREFIX "Local\\VibeRemake12.Open."
#define SESSION_READY_PREFIX "Local\\VibeRemake12.Ready."
static inline int session_number(char *out,DWORD value){char digits[12];int n=0,k=0;do{digits[k++]=(char)('0'+value%10u);value/=10u;}while(value);while(k)out[n++]=digits[--k];out[n]=0;return n;}
static inline void session_event_name(char *out,const char *prefix,DWORD pid){copystr(out,prefix,96);session_number(out+slen(out),pid);}
static inline BOOL session_directory(HMODULE module,WCHAR *path,DWORD cap){
 DWORD n=GetModuleFileNameW(module,path,cap);if(!n||n>=cap-32)return 0;
 while(n&&path[n-1]!='\\'&&path[n-1]!='/')--n;
 if(!n)return 0;
 path[n]=0;return 1;
}
static inline BOOL session_sibling(const WCHAR *directory,const char *name,WCHAR *out,size_t cap){
 size_t n=wlen(directory),k=slen(name);if(n+k+1>cap)return 0;wcopy(out,directory,cap);wascii(out+n,name,cap-n);return 1;
}
static inline BOOL session_menu_command(const WCHAR *exe,DWORD pid,WCHAR *out,size_t cap){
 size_t n=wlen(exe);if(n+40>=cap)return 0;
 out[0]='"';wcopy(out+1,exe,cap-1);out[n+1]='"';wascii(out+n+2," --game-pid ",cap-n-2);
 char digits[12];session_number(digits,pid);wascii(out+wlen(out),digits,cap-wlen(out));return 1;
}
static inline DWORD session_command_pid(const WCHAR *s){
 if(!s)return 0;
 while(*s==' ')++s;
 if(*s=='"'){++s;while(*s&&*s!='"')++s;if(*s)++s;}else while(*s&&*s!=' ')++s;
 while(*s){while(*s==' ')++s;const char *flag="--game-pid";const WCHAR *p=s;while(*flag&&*p==(unsigned char)*flag){++p;++flag;}
  if(!*flag&&*p==' '){while(*p==' ')++p;DWORD pid=0;BOOL digits=0;while(*p>='0'&&*p<='9'){DWORD d=(DWORD)(*p++-'0');if(pid>(UINT32_MAX-d)/10u)return 0;pid=pid*10u+d;digits=1;}return digits&&(!*p||*p==' ')?pid:0;}
  while(*s&&*s!=' ')++s;
 }
 return 0;
}
static inline DWORD session_find_game(void){
 HANDLE snap=CreateToolhelp32Snapshot(2,0);if(snap==INVALID_HANDLE)return 0;
 PROCESSENTRY32 entry;zeromem(&entry,sizeof(entry));entry.dwSize=sizeof(entry);DWORD pid=0;unsigned count=0;
 if(Process32First(snap,&entry))do{if(iequal(entry.szExeFile,"Remake Survival.exe")||iequal(entry.szExeFile,"RemakeSurvival.exe")){pid=entry.th32ProcessID;++count;}}while(Process32Next(snap,&entry));
 CloseHandle(snap);return count==1?pid:0;
}
static inline void session_close_legacy_menus(void){
 const char *classes[]={"VibeRemakeMenu9","VibeRemakeMenu10"};
 for(int i=0;i<2;++i){HWND old=FindWindowA(classes[i],"VIBE CHEAT");if(old){DWORD pid=0,tid=GetWindowThreadProcessId(old,&pid);if(tid&&pid!=GetCurrentProcessId())PostThreadMessageA(tid,0x12,0,0);}}
}
static inline BOOL session_signal_open(DWORD pid){
 char name[96];session_event_name(name,SESSION_REQUEST_PREFIX,pid);HANDLE event=OpenEventA(2,0,name);if(!event)return 0;
 AllowSetForegroundWindow(pid);BOOL ok=SetEvent(event);CloseHandle(event);return ok;
}
#endif
