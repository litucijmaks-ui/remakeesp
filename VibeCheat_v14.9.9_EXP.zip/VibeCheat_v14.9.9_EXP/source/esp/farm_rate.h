#pragma once
#include <stdint.h>
static inline uint32_t farm_rate_interval(float rate){
 if(!(rate>=0.5f))rate=0.5f;if(rate>50.f)rate=50.f;
 uint32_t delay=(uint32_t)(1000.f/rate+0.5f);return delay<20?20:delay>2000?2000:delay;
}
static inline float farm_rate_from_interval(uint32_t delay){
 if(delay<20)delay=20;if(delay>2000)delay=2000;return 1000.f/(float)delay;
}
static inline uint32_t farm_work_interval(uint32_t delay){return delay<20?20:delay>100?100:delay;}
