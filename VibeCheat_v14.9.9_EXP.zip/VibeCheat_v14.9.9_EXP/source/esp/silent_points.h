/* The selector and physical hit probe use the same current aim points. */
static unsigned silent_candidate_points(Obj player,Obj primary,const Vec3 *origin,Vec3 points[8]){
 Vec3 center,extents={.07f,.09f,.07f};BOOL require_head=aim_point==AIM_POINT_HEAD;
 /* A render bone can leave FOV while the current physics head remains inside. */
 BOOL geometry=require_head&&shot_head_geometry(player,&center,&extents);
 if(!geometry&&(!alive(primary)||!position_value(primary,&center)))return 0;
 if(!finite_number(center.x)||!finite_number(center.y)||!finite_number(center.z))return 0;
 for(unsigned i=0;i<8;i++)points[i]=center;
 if(!require_head)return 1;
 float dx=origin->x-center.x,dz=origin->z-center.z,length=__builtin_sqrtf(dx*dx+dz*dz);
 float nx=length>.0001f?dx/length:0,nz=length>.0001f?dz/length:1;
 points[1].y+=extents.y*.55f;
 points[2].x+=nz*extents.x*.65f;points[2].z-=nx*extents.z*.65f;
 points[3].x-=nz*extents.x*.65f;points[3].z+=nx*extents.z*.65f;
 points[4].y-=extents.y*.55f;
 points[5].x+=nx*extents.x*.5f;points[5].z+=nz*extents.z*.5f;
 points[6]=points[2];points[6].y+=extents.y*.4f;
 points[7]=points[3];points[7].y-=extents.y*.4f;return 8;
}
