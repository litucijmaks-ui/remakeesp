/* A Unity rendering event carries an immutable camera-frame snapshot to the
   graphics thread. It contains no Unity calls and no gameplay operations. */
static _Atomic(Method) game_marker_method;
static _Atomic BOOL game_markers_enabled;
static atomic_flag game_frame_lock=ATOMIC_FLAG_INIT;
static Frame game_render_frame;
static uint64_t game_render_stamp_us;
static _Atomic uint64_t game_marker_frames,game_marker_drops;
#define GAME_FRAME_SLOTS 4
static struct {Frame frame;_Atomic unsigned pending;int32_t token;} game_frame_queue[GAME_FRAME_SLOTS];
static unsigned game_frame_cursor;
static BOOL invoke_checked(Method,Obj,void **,Obj *);
static void logline(const char *);
static void ABI game_render_event(int32_t token){
 unsigned index=(unsigned)token&(GAME_FRAME_SLOTS-1u);
 if(!atomic_load_explicit(&game_frame_queue[index].pending,memory_order_acquire)||game_frame_queue[index].token!=token)return;
 if(!atomic_flag_test_and_set_explicit(&game_frame_lock,memory_order_acquire)){
  game_render_frame=game_frame_queue[index].frame;game_render_stamp_us=clock_us();++game_marker_frames;
  atomic_flag_clear_explicit(&game_frame_lock,memory_order_release);
 }else ++game_marker_drops;
 atomic_store_explicit(&game_frame_queue[index].pending,0,memory_order_release);
}
static void queue_game_render_frame(void){
 if(!game_markers_enabled||!game_marker_method||native_faulted)return;
 unsigned index=GAME_FRAME_SLOTS;
 for(unsigned n=0;n<GAME_FRAME_SLOTS;++n){unsigned slot=(game_frame_cursor+n)&(GAME_FRAME_SLOTS-1u);if(!atomic_load_explicit(&game_frame_queue[slot].pending,memory_order_acquire)){index=slot;break;}}
 if(index==GAME_FRAME_SLOTS){++game_marker_drops;return;}
 if(atomic_flag_test_and_set_explicit(&frame_lock,memory_order_acquire)){++game_marker_drops;return;}
 game_frame_queue[index].frame=shared_frame;atomic_flag_clear_explicit(&frame_lock,memory_order_release);
 int32_t token=(int32_t)((game_frame_queue[index].frame.serial&0x0fffffffu)<<2)|(int32_t)index;game_frame_queue[index].token=token;
 atomic_store_explicit(&game_frame_queue[index].pending,1,memory_order_release);game_frame_cursor=(index+1u)&(GAME_FRAME_SLOTS-1u);
 uintptr_t callback=(uintptr_t)game_render_event;void *args[]={&callback,&token};Obj ignored;
 if(!invoke_checked(game_marker_method,0,args,&ignored)){atomic_store_explicit(&game_frame_queue[index].pending,0,memory_order_release);game_markers_enabled=0;logline("Game render marker disabled: GL.IssuePluginEvent failed");}
}
