/* Bind to metadata objects, never dereference an old raw instance offset.
   Names below cover the two supplied desktop builds. A uniquely typed
   reference field remains resolvable if only its obfuscated name changes.
   Camera float slots must match a reviewed alias, type and layout. */
static void compatibility_missing(const char *label){logline("Compatibility missing or ambiguous:");logline(label);}
static BOOL compatible_field_type(void *field,void *expected,size_t offset){
 return field&&expected&&!(field_get_flags(field)&0x10u)&&class_from_type(field_get_type(field))==expected&&(offset==SIZE_MAX||field_get_offset(field)==offset);
}
static void *compatible_field(void *owner,void *expected,const char *current,const char *legacy,BOOL unique,size_t offset,const char *label){
 if(!owner||!expected){compatibility_missing(label);return 0;}
 void *field=class_get_field_from_name(owner,current);
 if(compatible_field_type(field,expected,offset))return field;
 field=class_get_field_from_name(owner,legacy);
 if(compatible_field_type(field,expected,offset))return field;
 if(unique){
  void *iterator=0,*match=0;unsigned count=0;
  while(count++<512&&(field=class_get_fields(owner,&iterator))){
   if(!compatible_field_type(field,expected,offset))continue;
   if(match){compatibility_missing(label);return 0;}match=field;
  }
  if(count<=512&&match){logline("Compatibility: unique typed reference used");logline(label);return match;}
 }
 compatibility_missing(label);return 0;
}
static BOOL compatible_signature(Method candidate,void *const *parameters,uint32_t count){
 if(!candidate||method_get_param_count(candidate)!=count||(method_get_flags(candidate,0)&0x10u)||class_from_type(method_get_return_type(candidate))!=klass("System","Void"))return 0;
 for(uint32_t i=0;i<count;++i)if(!parameters[i]||class_from_type(method_get_param(candidate,i))!=parameters[i])return 0;
 return 1;
}
static BOOL compatible_method(Method m,void *returns,void *const *parameters,uint32_t count,BOOL is_static){
 if(!m||!returns||method_get_param_count(m)!=count||!!(method_get_flags(m,0)&0x10u)!=!!is_static||class_from_type(method_get_return_type(m))!=returns)return 0;
 for(uint32_t i=0;i<count;++i)if(parameters&&(!parameters[i]||class_from_type(method_get_param(m,i))!=parameters[i]))return 0;
 return 1;
}
