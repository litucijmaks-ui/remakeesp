/* Death loot is a Backpack network object, independent of PlayerStatus. */
static Obj backpack_type;
static GCHandle backpack_array_root;
static uint64_t backpack_next_scan;
static uint32_t backpack_cursor,backpack_kept_count;
static Obj backpack_kept[96];
static _Atomic uint64_t backpack_scan_count;
static void backpack_release(void){
 if(backpack_array_root)gchandle_free(backpack_array_root);backpack_array_root=0;
 backpack_next_scan=0;backpack_cursor=backpack_kept_count=0;
}
static void backpack_sample(Obj camera,const Vec3 *origin,uint64_t now,BOOL discover){
 if(!(menu_options&128u)){backpack_release();return;}
 if(!backpack_type||!alive(camera)||!origin)return;
 if(discover&&(!backpack_array_root||now>=backpack_next_scan)){
  int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={backpack_type,&no},*unsorted[]={backpack_type,&inactive,&sort};
  Obj a=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);
  GCHandle root=a?gchandle_new(a,0):0;backpack_next_scan=now+1250;++backpack_scan_count;
  if(root){if(backpack_array_root)gchandle_free(backpack_array_root);backpack_array_root=root;backpack_kept_count=0;}
 }
 Obj a=backpack_array_root?gchandle_get_target(backpack_array_root):0;if(!a)return;
 uint32_t count=array_length(a),header=array_object_header_size();if(count>8192||header<24||header>128)return;
 for(unsigned n=0;n<count&&n<128;n++){
  if(backpack_cursor>=count)backpack_cursor=0;Obj bag=((Obj*)((unsigned char*)a+header))[backpack_cursor++];if(!alive(bag))continue;
  Vec3 p;if(!world_position(bag,&p))continue;float x=p.x-origin->x,y=p.y-origin->y,z=p.z-origin->z;
  if(!finite_number(x)||!finite_number(y)||!finite_number(z)||x*x+y*y+z*z>(float)range_max_m*range_max_m)continue;
  unsigned i=0;for(;i<backpack_kept_count;i++)if(backpack_kept[i]==bag)break;
  if(i==backpack_kept_count&&backpack_kept_count<96)backpack_kept[backpack_kept_count++]=bag;
 }
 unsigned kept=0;
 for(unsigned i=0;i<backpack_kept_count;i++){
  Obj bag=backpack_kept[i];if(!alive(bag))continue;backpack_kept[kept++]=bag;
  if(world_marker_count>=32)continue;Vec3 p,screen;if(!world_position(bag,&p))continue;
  float x=p.x-origin->x,y=p.y-origin->y,z=p.z-origin->z,square=x*x+y*y+z*z;
  if(!finite_number(square)||square>(float)range_max_m*range_max_m||!project_value(camera,&p,&screen))continue;
  VibeWorldMarker marker;if(!world_marker_project(&screen,source_width,source_height,&marker))continue;
  marker.distance=__builtin_sqrtf(square);marker.edge|=2u;world_markers[world_marker_count++]=marker;
 }
 backpack_kept_count=kept;
}
