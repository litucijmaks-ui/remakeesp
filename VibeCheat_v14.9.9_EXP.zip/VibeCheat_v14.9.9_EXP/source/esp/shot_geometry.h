/* Fresh bounds from the game's actual head collider. No velocity extrapolation
   is sent to a hitscan RPC: every accepted point has a current physics hit. */
typedef struct {Vec3 center,extents;} ShotBounds;
static Method shot_collider_bounds;
static void *shot_parts_field,*shot_part_collider_field,*shot_part_class;
typedef struct {Obj key;GCHandle box,head;uint64_t seen;} ShotColliderCache;
static ShotColliderCache shot_colliders[16];
static void shot_cache_release(ShotColliderCache *c){
 if(c->box)gchandle_free(c->box);if(c->head)gchandle_free(c->head);*c=(ShotColliderCache){0};
}
static void shot_geometry_release(void){
 for(unsigned i=0;i<16;i++)shot_cache_release(&shot_colliders[i]);
}
static void resolve_shot_geometry(void){
 shot_geometry_release();shot_collider_bounds=0;shot_parts_field=shot_part_collider_field=0;
 void *hitbox=klass("OxideOld.Player","PlayerHitbox"),*collider=klass("UnityEngine","Collider"),*bounds=klass("UnityEngine","Bounds");
 shot_part_class=klass("OxideOld.Player","HitCollider");
 uint32_t alignment=0;
 if(bounds&&class_value_size(bounds,&alignment)==(int32_t)sizeof(ShotBounds))shot_collider_bounds=physics_named_method(collider,"get_bounds",bounds,0,0,0);
 void *parts=hitbox?class_get_field_from_name(hitbox,"hitColliders"):0;
 if(shot_part_class&&parts&&!(field_get_flags(parts)&0x10u)&&class_get_element_class(class_from_type(field_get_type(parts)))==shot_part_class)shot_parts_field=parts;
 shot_part_collider_field=compatible_field(shot_part_class,collider,"collider","collider",0,SIZE_MAX,"Head collider reference");
 logline(shot_collider_bounds&&shot_parts_field&&shot_part_collider_field?"Fresh head collider bounds resolved":"Head bounds unavailable; strict head bone probes retained");
}
static BOOL shot_head_geometry(Obj player,Vec3 *center,Vec3 *extents){
 if(!shot_collider_bounds||!shot_parts_field||!shot_part_collider_field)return 0;
 ShotColliderCache *slot=0,*oldest=&shot_colliders[0];
 for(unsigned i=0;i<16;i++){ShotColliderCache *c=&shot_colliders[i];if(c->key==player){slot=c;break;}if(!c->key&&!slot)slot=c;if(c->seen<oldest->seen)oldest=c;}
 if(!slot)slot=oldest;if(slot->key!=player){shot_cache_release(slot);slot->key=player;}slot->seen=GetTickCount64();
 Obj box=slot->box?gchandle_get_target(slot->box):0;
 if(!alive(box)||invoke(hitbox_status,box,0)!=player){
  shot_cache_release(slot);slot->key=player;slot->seen=GetTickCount64();
  unsigned char inactive=1;void *args[]={hitbox_type,&inactive};box=invoke(component_children,player,args);
  if(!alive(box)||invoke(hitbox_status,box,0)!=player)return 0;
  slot->box=gchandle_new(box,0);if(!slot->box)return 0;
 }
 Obj head=slot->head?gchandle_get_target(slot->head):0;
 if(!alive(head)){
  if(slot->head)gchandle_free(slot->head);slot->head=0;
  Obj array=0;field_get_value(box,shot_parts_field,&array);if(!array)return 0;
  uint32_t count=array_length(array),header=array_object_header_size();if(count>64||header<24||header>128)return 0;
  Obj *parts=(Obj*)((unsigned char*)array+header);
  for(uint32_t i=0;i<count;++i){
   Obj part=parts[i];if(!part||object_get_class(part)!=shot_part_class)continue;
   Obj candidate=0;field_get_value(part,shot_part_collider_field,&candidate);if(!alive(candidate))continue;
   unsigned char flag=0;void *args[]={candidate,&flag};Obj result=invoke(hitbox_multiplier,box,args);
   void *value=result?object_unbox(result):0;float mult=value?*(float*)value:0;
   if(flag&&finite_number(mult)&&mult>0&&mult<=10){head=candidate;slot->head=gchandle_new(head,0);break;}
  }
 }
 if(!alive(head)||!slot->head)return 0;
 Obj result=invoke(shot_collider_bounds,head,0);ShotBounds *b=result?object_unbox(result):0;if(!b)return 0;
 if(!finite_number(b->center.x)||!finite_number(b->center.y)||!finite_number(b->center.z)||
    !finite_number(b->extents.x)||!finite_number(b->extents.y)||!finite_number(b->extents.z)||
    b->extents.x<0||b->extents.y<0||b->extents.z<0||b->extents.x>1||b->extents.y>1||b->extents.z>1)return 0;
 *center=b->center;*extents=b->extents;return 1;
}
