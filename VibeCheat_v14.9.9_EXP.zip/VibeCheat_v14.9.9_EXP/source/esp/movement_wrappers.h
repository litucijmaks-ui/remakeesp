/* New movement API accepts reviewed 12-byte encrypted value types. A float
   or one-byte bool must never be passed/read as an Obfuscated value. */
typedef struct {uint32_t key,value,canary;} MovementWrappedValue;
_Static_assert(sizeof(MovementWrappedValue)==12,"Reviewed movement value layout");
static Method movement_float_ctor,movement_bool_ctor,movement_bool_read;
static BOOL movement_wrapped,movement_primitive;
extern DWORD ABI VibeInvokeMovementValue(DWORD,void *,void *,void *,Method,DWORD *,uintptr_t *);
static BOOL movement_value_method(Method m,uint32_t rva,const unsigned char *prefix,size_t size){
 return m&&aimkill_entry_matches(m,rva,prefix,(unsigned)size);
}
static void resolve_movement_wrappers(void *movement){
 void *single=klass("System","Single"),*boolean=klass("System","Boolean"),*nothing=klass("System","Void");
 void *wrapped_float=klass("OxideOld.AntiCheat","ObfuscatedFloat"),*wrapped_bool=klass("OxideOld.AntiCheat","ObfuscatedBool");
 void *fargs[]={single},*bargs[]={boolean},*fsargs[]={wrapped_float},*bsargs[]={wrapped_bool};
 movement_wrapped=movement_primitive=0;movement_float_ctor=movement_bool_ctor=movement_bool_read=0;
 for(unsigned i=0;i<3;++i)if(!compatible_field_type(speed_fields[i],single,SIZE_MAX))speed_available=0;
 BOOL primitive=compatible_field_type(sprint_field,boolean,SIZE_MAX)&&compatible_method(sprint_setter,nothing,bargs,1,0);
 for(unsigned i=0;i<3;++i)primitive=primitive&&compatible_method(speed_setters[i],nothing,fargs,1,0);
 movement_primitive=primitive;if(primitive)return;
 uint32_t alignment=0;
 if(!class_value_size||!wrapped_float||!wrapped_bool||class_value_size(wrapped_float,&alignment)!=12||class_value_size(wrapped_bool,&alignment)!=12){speed_available=0;return;}
 movement_float_ctor=method(wrapped_float,".ctor",1);movement_bool_ctor=method(wrapped_bool,".ctor",1);movement_bool_read=method(wrapped_bool,PC_METHOD_obfBoolRead,0);
 BOOL valid=compatible_signature(movement_float_ctor,fargs,1)&&compatible_signature(movement_bool_ctor,bargs,1)&&compatible_method(movement_bool_read,boolean,0,0,0)&&compatible_field_type(sprint_field,wrapped_bool,PC_OFFSET_sprint)&&compatible_method(sprint_setter,nothing,bsargs,1,0);
 for(unsigned i=0;i<3;++i)valid=valid&&compatible_method(speed_setters[i],nothing,fsargs,1,0);
 valid=valid&&movement_value_method(movement_float_ctor,PC_RVA_obfFloatCtor,pc_prefix_obfFloatCtor,sizeof(pc_prefix_obfFloatCtor))&&movement_value_method(movement_bool_ctor,PC_RVA_obfBoolCtor,pc_prefix_obfBoolCtor,sizeof(pc_prefix_obfBoolCtor))&&movement_value_method(movement_bool_read,PC_RVA_obfBoolRead,pc_prefix_obfBoolRead,sizeof(pc_prefix_obfBoolRead));
 valid=valid&&movement_value_method(speed_setters[0],PC_RVA_walkSetter,pc_prefix_walkSetter,sizeof(pc_prefix_walkSetter))&&movement_value_method(speed_setters[1],PC_RVA_runSetter,pc_prefix_runSetter,sizeof(pc_prefix_runSetter))&&movement_value_method(speed_setters[2],PC_RVA_crouchSetter,pc_prefix_crouchSetter,sizeof(pc_prefix_crouchSetter))&&movement_value_method(sprint_setter,PC_RVA_sprintSetter,pc_prefix_sprintSetter,sizeof(pc_prefix_sprintSetter));
 movement_wrapped=valid;speed_available=speed_available&&valid;
 logline(valid?"Movement: reviewed 12-byte ObfuscatedFloat/Bool API ready":"Movement paused: encrypted setter signature/layout unsupported");
 (void)movement;
}
static BOOL movement_value_call(DWORD operation,Method method,MovementWrappedValue *value,void *primitive){
 if(!movement_wrapped||!method||!value||!primitive||native_faulted)return 0;
 DWORD code=0;uintptr_t address=0;
 if(VibeInvokeMovementValue(operation,*(void *const*)method,value,primitive,method,&code,&address))return 1;
 native_faulted=1;ready=0;logline("Movement encrypted value native fault; calls paused");log_number("Native exception code=",code);log_number("Native exception address=",address);return 0;
}
static BOOL movement_set_wrapped(Method setter,Method ctor,Obj controller,void *primitive){
 if(!movement_wrapped||!setter||!ctor||!controller||!primitive)return 0;
 MovementWrappedValue wrapped={0};Obj ignored=0;
 if(!movement_value_call(ctor==movement_float_ctor?0u:1u,ctor,&wrapped,primitive))return 0;
 void *args[]={&wrapped};return invoke_checked(setter,controller,args,&ignored);
}
static BOOL movement_set_sprint(Obj controller,unsigned char value){
 if(movement_wrapped)return movement_set_wrapped(sprint_setter,movement_bool_ctor,controller,&value);
 if(!movement_primitive)return 0;void *args[]={&value};Obj ignored=0;return invoke_checked(sprint_setter,controller,args,&ignored);
}
static BOOL movement_read_sprint(Obj controller,unsigned char *out){
 *out=0;
 if(!sprint_field)return 0;
 if(!movement_wrapped){if(!movement_primitive)return 0;field_get_value(controller,sprint_field,out);return 1;}
 MovementWrappedValue wrapped={0};field_get_value(controller,sprint_field,&wrapped);
 return movement_value_call(2u,movement_bool_read,&wrapped,out);
}
static BOOL movement_sprint_snapshot(Obj controller,uint32_t out[3]){
 out[0]=out[1]=out[2]=0;if(!sprint_field)return 0;
 if(movement_wrapped){field_get_value(controller,sprint_field,out);return 1;}
 if(!movement_primitive)return 0;unsigned char value=0;field_get_value(controller,sprint_field,&value);out[0]=value;return 1;
}
static BOOL movement_sprint_owned(Obj controller,const uint32_t applied[3]){
 uint32_t current[3];return movement_sprint_snapshot(controller,current)&&current[0]==applied[0]&&current[1]==applied[1]&&current[2]==applied[2];
}
