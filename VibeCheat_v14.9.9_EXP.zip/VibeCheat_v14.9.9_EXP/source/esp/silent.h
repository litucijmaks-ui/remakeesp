/* Typed Win64 shot proxy: MinHook decodes the original prologue.
   Redirected Vector3 values use private stack storage; caller data is preserved. */
typedef void (ABI *ShootFunction)(Obj,Obj,Vec3 *,Vec3 *,unsigned char,float,unsigned char,Vec3 *,Vec3 *,Method);
static ShootFunction shoot_original;
extern DWORD ABI VibeCreateNativeHook(void *,void *,void **);
static unsigned char *shoot_entry;
static _Atomic BOOL silent_available;
static _Atomic BOOL silent_installed;
static BOOL shot_hook_available;
static GCHandle silent_player_root,silent_identity_root,silent_weapon_root,silent_bone_root,silent_camera_root;
static BOOL third_shot_origin(Obj,Vec3 *);
static BOOL silent_refresh_shot_target(Obj,const Vec3 *,Vec3 *);
static _Atomic DWORD game_thread_id;
static uint64_t silent_sample_us;
static _Atomic uint64_t silent_shots;
static _Atomic uint64_t aimkill_shots;
static void silent_clear(void){
 shot_geometry_release();
 silent_sample_us=0;
 GCHandle *roots[]={&silent_player_root,&silent_identity_root,&silent_weapon_root,&silent_bone_root,&silent_camera_root};
 for(unsigned i=0;i<5;++i){if(*roots[i])gchandle_free(*roots[i]);*roots[i]=0;}
}
static _Atomic uint64_t silent_attempts,silent_stale,silent_blocked,silent_fallback_shots;
static BOOL silent_hit_point(Obj player,Obj camera,const Vec3 *world,const Vec3 *origin,int32_t mask,BOOL require_head,PhysicsHit *hit,Vec3 *direction,unsigned char *head,float *multiplier){
 Vec3 screen;
 if(!finite_number(world->x)||!finite_number(world->y)||!finite_number(world->z))return 0;
 Vec3 d={world->x-origin->x,world->y-origin->y,world->z-origin->z};float square=d.x*d.x+d.y*d.y+d.z*d.z;
 if(!finite_number(square)||square<=0.0001f||square>(float)range_max_m*range_max_m||!project_value(camera,world,&screen)||screen.z<=0)return 0;
 float x=screen.x-source_width*0.5f,y=screen.y-source_height*0.5f;
 if(!finite_number(x)||!finite_number(y)||x*x+y*y>(float)aim_fov_px*aim_fov_px)return 0;
 float length=__builtin_sqrtf(square);d.x/=length;d.y/=length;d.z/=length;
 BOOL found=0;
 if(!trace_ray(origin,&d,length+0.15f,mask,2,hit,&found)||!found)return 0;
 Obj collider=invoke(hit_collider,hit,0);unsigned char inactive=0;void *parent_args[]={hitbox_type,&inactive};
 Obj hitbox=alive(collider)?invoke(component_parent,collider,parent_args):0;
 if(!alive(hitbox)||invoke(hitbox_status,hitbox,0)!=player)return 0;
 unsigned char is_head=0;void *mult_args[]={collider,&is_head};Obj mult=invoke(hitbox_multiplier,hitbox,mult_args);float damage=mult?*(float*)object_unbox(mult):0;
 if(require_head&&!is_head)return 0;
 if(!finite_number(hit->point.x)||!finite_number(hit->point.y)||!finite_number(hit->point.z)||!finite_number(hit->normal.x)||!finite_number(hit->normal.y)||!finite_number(hit->normal.z)||!finite_number(damage)||damage<=0||damage>10)return 0;
 *head=is_head;*multiplier=damage;*direction=d;return 1;
}
#include "silent_points.h"
static BOOL selected_shot_probe(Obj weapon,Obj player,Obj camera,Obj primary,const Vec3 *origin,PhysicsHit *hit,Vec3 *direction,unsigned char *head,float *damage,BOOL *fallback){
 if(fallback)*fallback=0;
 int32_t mask=0;field_get_value(weapon,weapon_mask_field,&mask);
 unsigned limit=performance_profile==PROFILE_ECO?6u:9u,tries=0;
 BOOL require_head=aim_point==AIM_POINT_HEAD;Vec3 center,points[8];unsigned count=silent_candidate_points(player,primary,origin,points);
 if(!count)return 0;
 for(unsigned i=0;i<count&&tries<limit;++i){++tries;
  if(silent_hit_point(player,camera,&points[i],origin,mask,require_head,hit,direction,head,damage)){if(fallback)*fallback=i!=0;return 1;}
 }
 uint32_t allowed=aim_joint_mask(aim_point);
 for(int j=0;j<JOINT_COUNT&&tries<limit;++j)if(allowed&(1u<<j)){
  Obj alternate=skeleton_joint_transform(player,j);if(!alive(alternate)||alternate==primary||!position_value(alternate,&center))continue;++tries;
  if(silent_hit_point(player,camera,&center,origin,mask,require_head,hit,direction,head,damage)){if(fallback)*fallback=1;return 1;}
 }
 return 0;
}
static void ABI shoot_proxy(Obj weapon,Obj target,Vec3 *point,Vec3 *normal,unsigned char head,float multiplier,unsigned char real,Vec3 *direction,Vec3 *origin,Method info){
 Vec3 redirected_point,redirected_normal,redirected_direction,redirected_origin;
 if(!native_faulted&&silent_available&&GetCurrentThreadId()==game_thread_id&&running&&!stop_requested&&focused&&!menu_open&&!cursor_wanted&&(aim_options&1)&&(aim_mode==AIM_MODE_SILENT||aim_mode==AIM_MODE_AIMKILL)&&GetAsyncKeyState((int32_t)aim_bind)<0){
  uint64_t now=clock_us();++silent_attempts;
  if(!origin||!finite_number(origin->x)||!finite_number(origin->y)||!finite_number(origin->z)){++silent_stale;}
  else if(!silent_refresh_shot_target(weapon,origin,&redirected_origin)){++silent_stale;}
  else if((now=clock_us())<silent_sample_us||now-silent_sample_us>120000){++silent_stale;}
  else if(point&&normal&&direction&&origin&&finite_number(origin->x)&&finite_number(origin->y)&&finite_number(origin->z)&&gchandle_get_target(silent_weapon_root)==weapon){
   Obj player=gchandle_get_target(silent_player_root),identity=gchandle_get_target(silent_identity_root),camera=gchandle_get_target(silent_camera_root);unsigned char dead=1;
   if(alive(player)&&alive(identity))field_get_value(player,dead_field,&dead);
   Obj lock=invoke(cursor_get_lock,0,0);
   if(!dead&&lock&&*(int32_t*)object_unbox(lock)==1&&alive(camera)&&invoke(net_identity,player,0)==identity){
    Obj primary=gchandle_get_target(silent_bone_root);PhysicsHit hit;unsigned char actual_head;float damage;
    BOOL fallback=0;
    const Vec3 *probe_origin=&redirected_origin;
    BOOL redirected=selected_shot_probe(weapon,player,camera,primary,probe_origin,&hit,&redirected_direction,&actual_head,&damage,&fallback);
    if(redirected){redirected_point=hit.point;redirected_normal=hit.normal;point=&redirected_point;normal=&redirected_normal;direction=&redirected_direction;if(probe_origin==&redirected_origin)origin=&redirected_origin;target=identity;head=actual_head;multiplier=damage;real=1;++silent_shots;if(fallback)++silent_fallback_shots;if(aim_mode==AIM_MODE_AIMKILL)++aimkill_shots;}
    else ++silent_blocked;
   }
  }
 }
 shoot_original(weapon,target,point,normal,head,multiplier,real,direction,origin,info);
}
static BOOL silent_resolve(Method shoot){
 unsigned char *previous=shoot_entry;silent_available=0;shot_hook_available=0;
 if(silent_installed&&(!shoot||*(void *const*)shoot!=previous)){
  logline("Shot method changed: active trampoline kept pass-through; new DLL required");return 0;
 }
 if(!silent_installed)shoot_entry=0;
 if(!shoot){logline("Silent unavailable: CmdShootWeapon method/signature missing");return 0;}
 HMODULE module=GetModuleHandleA("GameAssembly.dll");if(!module)return 0;
 const unsigned char *base=module;uint32_t pe=*(const uint32_t*)(base+60);
 if(pe>4096||*(const uint32_t*)(base+pe)!=0x4550)return 0;
 uint32_t size=*(const uint32_t*)(base+pe+24+56);
 /* MethodInfo's first member was independently checked in this runtime. */
 unsigned char *entry=*(unsigned char *const*)shoot;
 if((uintptr_t)entry<(uintptr_t)base||(uintptr_t)entry+17>=(uintptr_t)base+size)return 0;
 if(!silent_installed){
  if(PC_RVA_shoot>=size||sizeof(pc_prefix_shoot)>size-PC_RVA_shoot||entry!=base+PC_RVA_shoot){logline("Silent paused: supplied update shot RVA differs");return 0;}
  for(unsigned i=0;i<sizeof(pc_prefix_shoot);++i)if(entry[i]!=pc_prefix_shoot[i]){logline("Silent paused: supplied update shot instruction bytes differ");return 0;}
 }

 shoot_entry=entry;shot_hook_available=1;
 silent_available=net_identity&&weapon_field&&dead_field&&physics_ray&&hit_collider&&component_parent&&hitbox_type&&hitbox_status&&hitbox_multiplier&&weapon_mask_field;
 return silent_available;
}
static __attribute__((noinline)) BOOL silent_install(void){
 if(silent_installed)return shot_hook_available;
 if(!shot_hook_available||!shoot_entry)return 0;
 DWORD error=VibeCreateNativeHook(shoot_entry,shoot_proxy,(void**)&shoot_original);
 if(error){silent_available=0;shot_hook_available=0;log_number("Shot native hook status=",error);return 0;}
 silent_installed=1;logline("Shot wrapper: decoded MinHook trampoline installed (Silent / native Aimkill)");return 1;
}
static void silent_remove(void){silent_clear();/* Hook remains pass-through across END/resume; never free a live trampoline. */}
static BOOL silent_set_root(GCHandle *root,Obj object){
 if(*root&&gchandle_get_target(*root)==object)return 1;
 if(*root)gchandle_free(*root);*root=gchandle_new(object,0);return *root!=0;
}
static void silent_select(Obj local,Obj camera,const AimSelection *selection){
 Obj bone=skeleton_joint_transform(selection->player,selection->joint_index);
 Vec3 head,extents;BOOL collider_head=selection->player&&aim_point==AIM_POINT_HEAD&&shot_head_geometry(selection->player,&head,&extents);
 if(!selection->player||(!alive(bone)&&!collider_head)||!alive(camera)||!silent_install()){silent_clear();return;}
 Obj weapon=0;field_get_value(local,weapon_field,&weapon);Obj identity=invoke(net_identity,selection->player,0);
 if(!alive(weapon)||!alive(identity)){silent_clear();return;}
 if(!alive(bone)){if(silent_bone_root)gchandle_free(silent_bone_root);silent_bone_root=0;}
 if(!silent_set_root(&silent_player_root,selection->player)||!silent_set_root(&silent_identity_root,identity)||!silent_set_root(&silent_weapon_root,weapon)||(alive(bone)&&!silent_set_root(&silent_bone_root,bone))||!silent_set_root(&silent_camera_root,camera)){silent_clear();return;}
 silent_sample_us=clock_us();aim_target_key=selection->player;
}
