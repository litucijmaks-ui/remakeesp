/* Client timing is an experiment. Native HvH uses the game's existing
   permission and RapidFire property, without changing the server mode. */
static void *rapid_cooldown_field,*rapid_ammo_field,*rapid_cost_field,*rapid_mag_field,*rapid_kind_field;
static Method rapid_native_permission,rapid_native_get,rapid_native_set;
static _Atomic BOOL rapid_available;
static _Atomic(const char *) rapid_state="Rapid fire disabled";
static GCHandle rapid_item_root;
static float rapid_base,rapid_applied;
static BOOL rapid_native_written;
static unsigned char rapid_native_base;
static void resolve_rapid(void *weapon,void *item){
 rapid_cooldown_field=compatible_field(item,klass("System","Single"),"fireCooldown","fireCooldown",0,SIZE_MAX,"Rapid fire cooldown");
 rapid_ammo_field=compatible_field(item,item,"ammoType","ammoType",0,SIZE_MAX,"Rapid fire ammo item");
 rapid_cost_field=compatible_field(item,klass("System","Int32"),"ammoPerShot","ammoPerShot",0,SIZE_MAX,"Rapid fire ammo cost");
 rapid_mag_field=compatible_field(weapon,klass("System","Int32"),"currentAmmoInMag","currentAmmoInMag",0,SIZE_MAX,"Rapid fire magazine");
 rapid_kind_field=compatible_field(item,klass("","ƖɅĨȡϪЀ"),"itemType","itemType",0,0x38u,"Rapid fire firearm category");
 void *owner=klass("","΢ɉ͝ŋЁƫ"),*boolean=klass("System","Boolean");void *set_args[]={boolean};
 rapid_native_permission=method(owner,PC_METHOD_nativeRapidAllowed,0);rapid_native_get=method(owner,"get_RapidFire",0);rapid_native_set=method(owner,"set_RapidFire",1);
 static const unsigned char permission[]={0x48,0x83,0xec,0x28,0x80,0x3d,0x7d,0x72,0xfa,0x01,0x00,0x75,0x18,0x48,0x8d,0x0d};
 static const unsigned char getter[]={0x48,0x83,0xec,0x28,0x80,0x3d,0xdc,0x63,0xfa,0x01,0x00,0x75,0x18,0x48,0x8d,0x0d};
 static const unsigned char setter[]={0x40,0x53,0x48,0x83,0xec,0x20,0x80,0x3d,0xc2,0x6f,0xfa,0x01,0x00,0x0f,0xb6,0xd9};
 if(!compatible_method(rapid_native_permission,boolean,0,0,1)||!aimkill_entry_matches(rapid_native_permission,PC_RVA_nativeRapidAllowed,pc_prefix_nativeRapidAllowed,sizeof(pc_prefix_nativeRapidAllowed)))rapid_native_permission=0;
 if(!compatible_method(rapid_native_get,boolean,0,0,1)||!aimkill_entry_matches(rapid_native_get,PC_RVA_nativeRapidGet,pc_prefix_nativeRapidGet,sizeof(pc_prefix_nativeRapidGet)))rapid_native_get=0;
 if(!compatible_method(rapid_native_set,klass("System","Void"),set_args,1,1)||!aimkill_entry_matches(rapid_native_set,PC_RVA_nativeRapidSet,pc_prefix_nativeRapidSet,sizeof(pc_prefix_nativeRapidSet)))rapid_native_set=0;
 rapid_available=field_set_value&&weapon_field&&item_field&&rapid_cooldown_field&&rapid_ammo_field&&rapid_cost_field&&rapid_mag_field&&rapid_kind_field;
 logline(rapid_available?"Rapid fire restored: compatible client cooldown resolved":"Rapid fire unavailable: compatible firearm fields missing");
 log_number("Rapid fire native HvH bindings ready=",rapid_native_permission&&rapid_native_get&&rapid_native_set);
}
static BOOL rapid_read_bool(Method method,unsigned char *out){
 Obj value=0;if(!method||!invoke_checked(method,0,0,&value)||!value)return 0;
 void *data=object_unbox(value);if(!data)return 0;*out=*(unsigned char*)data;return 1;
}
static void rapid_release_timer(void){
 if(!rapid_item_root)return;Obj item=gchandle_get_target(rapid_item_root);
 if(alive(item)){float current=0;field_get_value(item,rapid_cooldown_field,&current);if(finite_number(current)&&__builtin_fabsf(current-rapid_applied)<0.00001f)field_set_value(item,rapid_cooldown_field,&rapid_base);}
 gchandle_free(rapid_item_root);rapid_item_root=0;
}
static void rapid_release_native(void){
 if(!rapid_native_written)return;
 unsigned char current=0;if(rapid_read_bool(rapid_native_get,&current)&&current==1){void *args[]={&rapid_native_base};Obj ignored;invoke_checked(rapid_native_set,0,args,&ignored);}
 rapid_native_written=0;
}
static void rapid_release(void){rapid_release_timer();rapid_release_native();}
static float rapid_effective_cooldown(float original){
 if(!rapid_native_written)return original;
 float value=original*.25f;return value<.08f?value:.08f;
}
static __attribute__((noinline)) void rapid_tick(Obj local,BOOL active){
 if(!active||!(rapid_options&1u)||!rapid_available){rapid_release();rapid_state=!(rapid_options&1u)?"Rapid fire disabled":!rapid_available?"Rapid fire unavailable":"Rapid fire paused";return;}
 Obj weapon=0,item=0,ammo=0;int32_t cost=0,mag=0,kind=0;
 if(alive(local))field_get_value(local,weapon_field,&weapon);
 if(alive(weapon))field_get_value(weapon,item_field,&item);
 if(alive(item)){field_get_value(item,rapid_ammo_field,&ammo);field_get_value(item,rapid_cost_field,&cost);field_get_value(item,rapid_kind_field,&kind);field_get_value(weapon,rapid_mag_field,&mag);}
 if((kind!=2&&kind!=13)||!ammo||cost<1||cost>32||mag<cost){rapid_release();rapid_state="Rapid fire: equip a loaded firearm";return;}
 if(custom_rapid_mode==1){
  rapid_release_timer();unsigned char allowed=0,current=0;
  if(!rapid_read_bool(rapid_native_permission,&allowed)||!allowed||!rapid_native_get||!rapid_native_set){rapid_release_native();rapid_state="Rapid fire: native HvH permission unavailable";return;}
  if(!rapid_native_written){
   if(!rapid_read_bool(rapid_native_get,&current)){rapid_state="Rapid fire: native property unavailable";return;}
   rapid_native_base=current;unsigned char enabled=1;void *args[]={&enabled};Obj ignored;
   if(!invoke_checked(rapid_native_set,0,args,&ignored)){rapid_state="Rapid fire: native activation failed";return;}
   rapid_native_written=1;
  }
  rapid_state="Rapid fire: native HvH mode active";return;
 }
 rapid_release_native();
 if(rapid_item_root&&gchandle_get_target(rapid_item_root)!=item)rapid_release_timer();
 float current=0;field_get_value(item,rapid_cooldown_field,&current);
 if(!finite_number(current)||current<=0||current>30){rapid_release_timer();rapid_state="Rapid fire: invalid client cooldown";return;}
 if(!rapid_item_root){rapid_base=rapid_applied=current;rapid_item_root=gchandle_new(item,0);if(!rapid_item_root)return;}
 else if(__builtin_fabsf(current-rapid_applied)>0.00001f)rapid_base=current;
 float factor=(float)rapid_percent*.01f;if(factor<1)factor=1;if(factor>3)factor=3;
 float desired=rapid_base/factor;if(desired<.035f)desired=.035f;if(desired>rapid_base)desired=rapid_base;
 if(__builtin_fabsf(current-desired)>0.00001f)field_set_value(item,rapid_cooldown_field,&desired);
 rapid_applied=desired;rapid_state="Rapid fire: client timing active; server rate unconfirmed";
}
