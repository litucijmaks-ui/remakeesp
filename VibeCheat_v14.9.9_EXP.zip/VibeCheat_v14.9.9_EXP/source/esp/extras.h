/* Optional dump-backed client controls. Networked vitals and magazines remain
   server-owned; a successful local write is not a server confirmation. */
typedef struct {GCHandle root;void *field;DWORD base,last;BOOL written;} ExtraWrite;
static ExtraWrite extra_writes[8];
static void *extra_god,*extra_mag_size;
#include "recoil.h"

static void *med_slot_item;
static void *med_player_inventory,*med_local_hotbar;
static Method med_max_health;
static void *med_inventory_instance,*med_slots,*med_health,*med_food,*med_water;
static Method med_get_item,med_get_amount,med_consume,med_use_consumable;
static void *med_definition,*med_data_name,*med_data_short_name,*med_data_components,*med_component_items,*med_component_size;
static void *med_component_health,*med_component_food,*med_component_water,*med_consumable_class;
static uint64_t med_next_diagnostic;
static uint64_t med_next_attempt,med_pending_until;
static float med_health_before;
static _Atomic(const char*) med_state="Auto medkit disabled";
static void *med_weapon_inventory,*med_hotbar_slots,*med_hotbar_instance;
static void *med_belt_slots,*med_backpack_slots,*med_main_slots;
static void *med_belt_field,*med_backpack_field,*med_container_items;
static Method med_get_component;
static Obj med_held_weapon_type;
static Obj med_hotbar_type;
static void extra_restore(ExtraWrite *w){
 if(w->root){Obj target=gchandle_get_target(w->root);if(alive(target)&&w->written){DWORD current=0;field_get_value(target,w->field,&current);if(current==w->last)field_set_value(target,w->field,&w->base);}gchandle_free(w->root);}
 *w=(ExtraWrite){0};
}
static void extra_write(unsigned slot,Obj target,void *field,DWORD value,BOOL byte){
 ExtraWrite *w=&extra_writes[slot];
 if(!field||!alive(target)){extra_restore(w);return;}
 if(w->root&&gchandle_get_target(w->root)!=target)extra_restore(w);
 DWORD current=0;field_get_value(target,field,&current);
 if(!w->root){w->root=gchandle_new(target,0);if(!w->root)return;w->field=field;w->base=current;}
 /* bool getters write one byte into the zeroed DWORD above. */
 if(current!=value){field_set_value(target,field,&value);w->last=byte?(value&255u):value;w->written=1;}
}
static void combat_release(void);
static void extras_release(void){combat_release();recoil_release();for(unsigned i=0;i<8;++i)extra_restore(&extra_writes[i]);med_next_attempt=med_pending_until=0;}
static void resolve_combat(void *,void *);
static void resolve_extras(void *weapon,void *item){
 void *boolean=klass("System","Boolean"),*single=klass("System","Single"),*integer=klass("System","Int32"),*nothing=klass("System","Void");
 extra_god=compatible_field(player_class,boolean,"godMode","godMode",0,SIZE_MAX,"Client god mode");
 resolve_recoil(weapon);resolve_combat(weapon,item);
 extra_mag_size=compatible_field(item,integer,"magazineSize","magazineSize",0,SIZE_MAX,"Magazine capacity");


 /* Global update: exact medkit owners */
 void *inventory=klass("","InventoryManager"),*hotbar=klass("OxideOld.Player","HotbarManager"),*slot=klass("","InventorySlot");
 med_player_inventory=compatible_field(player_class,inventory,PC_FIELD_playerInventory,PC_FIELD_playerInventory,0,PC_OFFSET_playerInventory,"Local player inventory");
 med_local_hotbar=compatible_field(player_class,hotbar,PC_FIELD_hotbar,PC_FIELD_hotbar,0,PC_OFFSET_hotbar,"Local player hotbar");
 med_hotbar_slots=hotbar?class_get_field_from_name(hotbar,"slots"):0;
 if(med_hotbar_slots&&((field_get_flags(med_hotbar_slots)&16u)||field_get_offset(med_hotbar_slots)!=PC_OFFSET_slots||!class_get_element_class||class_get_element_class(class_from_type(field_get_type(med_hotbar_slots)))!=klass("","HotbarSlot")))med_hotbar_slots=0;
 med_weapon_inventory=compatible_field(weapon,inventory,PC_FIELD_weaponInventory,PC_FIELD_weaponInventory,0,PC_OFFSET_weaponInventory,"Held weapon inventory");
 med_health=compatible_field(item,integer,"healthRestore","healthRestore",0,PC_OFFSET_healthRestore,"Medical HP");
 med_food=compatible_field(item,integer,"foodRestore","foodRestore",0,PC_OFFSET_foodRestore,"Medical food");
 med_water=compatible_field(item,integer,"waterRestore","waterRestore",0,PC_OFFSET_waterRestore,"Medical water");
 med_get_item=method(slot,PC_METHOD_slotItem,0);med_get_amount=method(slot,PC_METHOD_slotAmount,0);
 if(!compatible_method(med_get_item,item,0,0,0))med_get_item=0;
 if(!compatible_method(med_get_amount,integer,0,0,0))med_get_amount=0;
 void *params[]={klass("System","String"),klass("Mirror","NetworkConnectionToClient")};
 med_use_consumable=method(weapon,PC_METHOD_useConsumable,2);med_consume=method(inventory,PC_METHOD_consumeItem,2);
 if(!compatible_method(med_use_consumable,nothing,params,2,0))med_use_consumable=0;
 if(!compatible_method(med_consume,nothing,params,2,0))med_consume=0;
 med_max_health=method(player_class,"GetMaxHealth",0);if(!compatible_method(med_max_health,single,0,0,0))med_max_health=0;
 logline(med_local_hotbar&&med_get_item&&(med_use_consumable||med_consume)?"Exact auto medkit bindings ready":"Exact auto medkit bindings unavailable");
}
#include "medkit_names.h"
static BOOL med_name_match(Obj name){return name&&med_text_match(string_chars(name),string_length(name));}
static void med_log_name(Obj name){if(!name){logline("<missing itemName>");return;}char text[600];int count=string_length(name);const WCHAR *chars=string_chars(name);if(!chars)return;if(count>128)count=128;int bytes=WideCharToMultiByte(65001,0,chars,count,text,599,0,0);if(bytes>0){text[bytes]=0;logline(text);}}
static BOOL med_definition_values(Obj item,int32_t *health,int32_t *food,int32_t *water,BOOL *name_match){
 if(!med_definition)return 0;Obj data=0,name=0;field_get_value(item,med_definition,&data);if(!data)return 0;
 if(med_data_name){field_get_value(data,med_data_name,&name);if(med_name_match(name))*name_match=1;}
 if(med_data_short_name){field_get_value(data,med_data_short_name,&name);if(med_name_match(name))*name_match=1;}
 if(!med_data_components||!med_component_items||!med_component_size||!med_component_health||!med_component_food||!med_component_water||!object_get_class)return 0;
 Obj list=0,array=0;int32_t count=0;field_get_value(data,med_data_components,&list);if(!list)return 0;
 field_get_value(list,med_component_size,&count);field_get_value(list,med_component_items,&array);if(!array||count<=0||count>64)return 0;
 uint32_t length=array_length(array),header=array_object_header_size();if((uint32_t)count>length||header<24||header>128)return 0;
 for(int32_t i=0;i<count;++i){Obj component=((Obj*)((unsigned char*)array+header))[i];if(!component||object_get_class(component)!=med_consumable_class)continue;
  field_get_value(component,med_component_health,health);field_get_value(component,med_component_food,food);field_get_value(component,med_component_water,water);return 1;
 }return 0;
}

static void medkit_tick(Obj local,float health){
 uint64_t now=GetTickCount64();if(!finite_number(health)||health<=0){med_state="Auto medkit: no live HP";return;}
 if(med_pending_until){
  if(health>med_health_before+.5f){med_pending_until=0;med_state="Auto medkit: HP increase confirmed";}
  else if(now>=med_pending_until){med_pending_until=0;med_state="Auto medkit: request not confirmed by HP";}
  else return;
 }
 float maximum=100.f;Obj boxed=med_max_health?invoke(med_max_health,local,0):0;
 if(boxed){float max=*(float*)object_unbox(boxed);if(finite_number(max)&&max>0&&max<100000)maximum=max;}
 if(health*100.f/maximum>=(float)medkit_threshold||now<med_next_attempt)return;
 med_next_attempt=now+medkit_delay_ms;
 if(!medkit_slots||!med_local_hotbar||!med_hotbar_slots||!med_get_item||!item_name_field){med_state="Auto medkit: hotbar binding unavailable";return;}
 Obj hotbar=0,weapon=0,inventory=0;
 field_get_value(local,med_local_hotbar,&hotbar);if(weapon_field)field_get_value(local,weapon_field,&weapon);
 if(med_player_inventory)field_get_value(local,med_player_inventory,&inventory);
 if(!alive(inventory)&&alive(weapon)&&med_weapon_inventory)field_get_value(weapon,med_weapon_inventory,&inventory);
 if(!alive(hotbar)){med_state="Auto medkit: local hotbar unavailable";return;}
 Obj array=0;field_get_value(hotbar,med_hotbar_slots,&array);GCHandle root=array?gchandle_new(array,0):0;if(!root)return;
 array=gchandle_get_target(root);uint32_t count=array_length(array),header=array_object_header_size();
 if(count>128||header<24||header>128){gchandle_free(root);med_state="Auto medkit: slot array differs";return;}
 BOOL sent=0;
 for(unsigned i=0;i<count&&i<8&&!native_faulted;++i){
  if(!(medkit_slots&(1u<<i)))continue;array=gchandle_get_target(root);Obj slot=((Obj*)((unsigned char*)array+header))[i];if(!alive(slot))continue;
  Obj amount=med_get_amount?invoke(med_get_amount,slot,0):0;if(amount&&*(int32_t*)object_unbox(amount)<=0)continue;
  Obj item=invoke(med_get_item,slot,0);if(!alive(item))continue;Obj name=0;field_get_value(item,item_name_field,&name);if(!name)continue;
  int32_t hp=0,food=0,water=0;if(med_health)field_get_value(item,med_health,&hp);if(med_food)field_get_value(item,med_food,&food);if(med_water)field_get_value(item,med_water,&water);
  if(!med_name_match(name)&&!(hp>0&&food<=0&&water<=0))continue;
  Obj ignored=0;void *args[]={name,0};const char *previous=invoke_context;invoke_context="Auto medkit: exact consume command";
  if(med_use_consumable&&alive(weapon))sent=invoke_checked(med_use_consumable,weapon,args,&ignored);
  if(!sent&&!native_faulted&&med_consume&&alive(inventory))sent=invoke_checked(med_consume,inventory,args,&ignored);
  invoke_context=previous;
  if(sent){med_health_before=health;med_pending_until=now+(medkit_delay_ms>1500?medkit_delay_ms:1500);med_state="Auto medkit: request sent; waiting for HP";break;}
 }
 gchandle_free(root);if(!sent)med_state="Auto medkit: no usable medicine in selected hotbar slots";
}
#include "combat.h"
static void extras_tick(Obj local,BOOL active,float health){
 if(!active||!field_set_value){extras_release();med_state=(rapid_options&4)?"Auto medkit paused: menu/focus/player gate":"Auto medkit disabled";return;}
 DWORD flags=rapid_options;combat_tick(local,active);if(native_faulted)return;

 
 recoil_tick(local,active);
 
 if(flags&4)medkit_tick(local,health);else {med_next_attempt=med_pending_until=0;med_state="Auto medkit disabled";}

}

static BOOL extras_have_roots(void){for(unsigned i=0;i<8;++i)if(extra_writes[i].root)return 1;return combat_identity_root||combat_tool_root||unbreak_slot_root||reload_timing_root;}
