/* Local automatic rebinding. A future incompatible binary still requires a
   reviewed release; no offsets, download endpoint or signature are guessed. */
static void request_compatibility_check(void){compatibility_requested=1;compatibility_status="Compatibility recheck requested";}
static uintptr_t compatibility_image_base;
static uint32_t compatibility_image_stamp,compatibility_image_size;
static BOOL compatibility_image_changed(void){
 const unsigned char *base=GetModuleHandleA("GameAssembly.dll");if(!base)return 0;
 uint32_t pe=*(const uint32_t*)(base+60);if(pe>4096||*(const uint32_t*)(base+pe)!=0x4550)return 0;
 uint32_t stamp=*(const uint32_t*)(base+pe+8),size=*(const uint32_t*)(base+pe+80);
 BOOL changed=compatibility_image_base&&((uintptr_t)base!=compatibility_image_base||stamp!=compatibility_image_stamp||size!=compatibility_image_size);
 compatibility_image_base=(uintptr_t)base;compatibility_image_stamp=stamp;compatibility_image_size=size;return changed;
}
static BOOL compatibility_version(char *out,size_t limit){
 if(!compatibility_version_method){void *app=klass("UnityEngine","Application");Method m=method(app,"get_version",0);if(m&&method_get_param_count(m)==0&&(method_get_flags(m,0)&0x10u)&&class_from_type(method_get_return_type(m))==klass("System","String"))compatibility_version_method=m;}
 if(!compatibility_version_method)return 0;
 Obj value=invoke(compatibility_version_method,0,0);if(!value)return 0;int count=string_length(value);const WCHAR *s=string_chars(value);if(!s||count<1)return 0;
 size_t n=(size_t)count;if(n>=limit)n=limit-1;for(size_t i=0;i<n;++i)out[i]=s[i]>=32&&s[i]<127?(char)s[i]:'?';out[n]=0;return 1;
}
typedef struct {char data[4096];size_t used;} CompatibilityReport;
static void compatibility_report_text(CompatibilityReport *r,const char *s){while(*s&&r->used<sizeof(r->data)-1)r->data[r->used++]=*s++;r->data[r->used]=0;}
static void compatibility_report_number(CompatibilityReport *r,uint64_t value){char digits[24];int n=0;do{digits[n++]=(char)('0'+value%10);value/=10;}while(value);while(n){char text[2]={digits[--n],0};compatibility_report_text(r,text);}}
static void compatibility_report_field(CompatibilityReport *r,const char *name,void *field){compatibility_report_text(r,name);compatibility_report_text(r,": ");if(field){compatibility_report_text(r,"bound; current metadata offset=");compatibility_report_number(r,field_get_offset(field));}else compatibility_report_text(r,"missing or ambiguous");compatibility_report_text(r,"\r\n");}
static void compatibility_write_report(const char *reason){
 CompatibilityReport report={0};compatibility_report_text(&report,"VIBE PC v14.9.1 compatibility\r\nReason: ");compatibility_report_text(&report,reason);
 compatibility_report_text(&report,"\r\nGame version: ");compatibility_report_text(&report,compatibility_game_version[0]?compatibility_game_version:"not exposed by this runtime");
 compatibility_report_text(&report,"\r\nGameAssembly PE timestamp: ");compatibility_report_number(&report,compatibility_image_stamp);compatibility_report_text(&report,"\r\nGameAssembly image bytes: ");compatibility_report_number(&report,compatibility_image_size);
 compatibility_report_text(&report,"\r\nESP core: ");compatibility_report_text(&report,ready?"ready":"missing required binding; ESP paused");
 compatibility_report_text(&report,"\r\nCamera snapshot: ");compatibility_report_text(&report,projection_available?"ready":"Unity point projection fallback");
 compatibility_report_text(&report,"\r\nSkeleton hierarchy: ");compatibility_report_text(&report,skeleton_available?"ready":"unavailable; root bounds fallback");
 compatibility_report_text(&report,"\r\nOptional capabilities mask: ");compatibility_report_number(&report,feature_capabilities());compatibility_report_text(&report,"\r\n");
 compatibility_report_text(&report,"Camera.WorldToScreenPoint: ");compatibility_report_text(&report,camera_project?"bound":"missing or incompatible signature");compatibility_report_text(&report,"\r\nComponent.get_transform: ");compatibility_report_text(&report,component_transform?"bound":"missing or incompatible signature");compatibility_report_text(&report,"\r\nTransform.get_position: ");compatibility_report_text(&report,transform_position?"bound":"missing or incompatible signature");compatibility_report_text(&report,"\r\nScreen dimensions: ");compatibility_report_text(&report,"typed Camera.pixelRect / Camera.rect; Windows extent fallback");compatibility_report_text(&report,"\r\nLocal-player getter: ");compatibility_report_text(&report,is_local?"bound":"missing or incompatible signature");compatibility_report_text(&report,"\r\n");
 compatibility_report_field(&report,"Player health",health_field);compatibility_report_field(&report,"Player animator",animator_field);compatibility_report_field(&report,"Held weapon",weapon_field);compatibility_report_field(&report,"CameraLook",look_field);
 compatibility_report_text(&report,visual_late_installed?"Visual timing: post-LateUpdate hook installed\r\n":"Visual timing: hook unavailable; color overrides paused\r\n");
 compatibility_report_text(&report,frame_sync_installed?"ESP timing: active camera post-OnPreCull reprojection\r\n":"ESP timing: exact WorldToScreenPoint; camera frame hook unavailable\r\n");
 compatibility_report_text(&report,recoil_available?"No recoil: local Shaker pre-LateUpdate\r\n":"No recoil: missing binding/hook\r\n");
 compatibility_report_text(&report,research_learn_available?"Free study: typed Int16 learning route ready\r\n":"Free study: automatic learning unavailable\r\n");
 compatibility_report_text(&report,"ESP renderer: game DX11 Present + queued Unity render markers; independent menu/fallback\r\nNoSpread test toggle: disabled; native binary has no direct callers of getter\r\nClient god/ammo writes: disabled\r\n");
 compatibility_report_field(&report,"Local inventory manager",med_weapon_inventory);compatibility_report_field(&report,"Inventory slots",med_slots);compatibility_report_field(&report,"Hotbar slots",med_hotbar_slots);
 compatibility_report_field(&report,"Horizontal sensitivity",look_horizontal_field);compatibility_report_field(&report,"Vertical sensitivity",look_vertical_field);compatibility_report_field(&report,"Clamped pitch",look_pitch_field);
 compatibility_report_text(&report,"Visible check: ");compatibility_report_text(&report,visibility_available()?"typed raycast ready\r\n":"unavailable; aim pauses when requested\r\n");
 compatibility_report_text(&report,"Player discovery: queued for live camera phase when camera hook is present\r\nESP: actor candidates retained across offscreen camera frames\r\n");
 compatibility_report_text(&report,"\r\nBindings are resolved from the loaded game's metadata.\r\nMissing/ambiguous bindings are disabled; details: esp.log.\r\nAutomatic local rebinding is enabled. No release download endpoint is configured.\r\nAn unsupported layout or renamed method may need a new DLL release.\r\n");
 WCHAR path[1024];if(!session_sibling(menu_directory,"compatibility.txt",path,1024))return;HANDLE file=CreateFileW(path,0x40000000u,3,0,2,0x80,0);if(file==INVALID_HANDLE||!file)return;DWORD written=0;BOOL ok=WriteFile(file,report.data,(DWORD)report.used,&written,0);CloseHandle(file);if(!ok||written!=report.used)logline("Could not write compatibility.txt");
}
static void compatibility_clear_bindings(void){
 if(ready){features_pause(1);skeleton_expire(0,0);}
 if(player_array_handle){gchandle_free(player_array_handle);player_array_handle=0;}
 projection_release();cached_local_key=0;last_player_refresh=0;next_screen_read=0;box_count=0;frame_actor_count=0;player_discovery_pending=1;last_camera_frame_us=0;found_players=-1;aim_reset();projection_state.valid=previous_camera_valid=0;camera_motion_until=0;zeromem(name_cache,sizeof(name_cache));ready=0;
 publish_frame();
}
static void compatibility_update(uint64_t now){
 if(native_faulted)return;
 const char *reason=0;
 if(compatibility_requested&&(!compatibility_last_rebind||now-compatibility_last_rebind>=2000)){compatibility_requested=0;reason="Manual recheck";}
 if(!reason&&ready&&last_resolve&&now>=compatibility_next_version){compatibility_next_version=now+5000;
  if(compatibility_image_changed())reason="Loaded GameAssembly build changed";
  char version[80];if(compatibility_version(version,sizeof(version))){if(compatibility_game_version[0]&&!equal(version,compatibility_game_version))reason="Game version changed";copystr(compatibility_game_version,version,sizeof(compatibility_game_version));}}
 if(!reason&&ready&&compatibility_errors>=5&&now-compatibility_error_window<=10000&&now-compatibility_last_rebind>=30000)reason="Repeated managed exceptions; refresh bindings";
 if(!reason&&!ready&&(!last_resolve||now>=compatibility_next_retry))reason=last_resolve?"Retry unavailable core bindings":"Initial automatic compatibility check";
 if(!reason)return;
 compatibility_clear_bindings();compatibility_status="Checking game metadata";logline(reason);last_resolve=compatibility_last_rebind=now;compatibility_errors=0;compatibility_error_window=now;
 compatibility_image_changed();
 compatibility_version_method=0;char version[80];if(compatibility_version(version,sizeof(version)))copystr(compatibility_game_version,version,sizeof(compatibility_game_version));
 ready=resolve_methods()&&!native_faulted;compatibility_status=native_faulted?"Native Unity fault; restart game":(ready?"ESP ready; automatic metadata check enabled":"Game build unsupported; check compatibility.txt");
 compatibility_next_version=now+5000;compatibility_next_retry=now+compatibility_retry_ms;if(ready)compatibility_retry_ms=1000;else if(compatibility_retry_ms<30000){compatibility_retry_ms*=2;if(compatibility_retry_ms>30000)compatibility_retry_ms=30000;}
 compatibility_write_report(reason);
}
