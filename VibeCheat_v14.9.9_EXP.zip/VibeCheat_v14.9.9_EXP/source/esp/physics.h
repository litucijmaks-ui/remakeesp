/* Exact metadata layout: Vector3, Vector3, face, distance, UV, EntityId(8).
   Use the unique six-argument Raycast overload; no overload guessing. */
typedef struct {Vec3 point,normal;uint32_t face;float distance,u,v;uint64_t entity;} PhysicsHit;
_Static_assert(sizeof(PhysicsHit)==48,"Unity RaycastHit value layout");
static Method physics_ray,hit_collider,component_parent,component_children,hitbox_status,hitbox_multiplier;
static Obj hitbox_type;
static void *weapon_mask_field;
static void resolve_shot_geometry(void);
static Method physics_named_method(void *owner,const char *name,void *returns,void *const *args,unsigned count,BOOL is_static){
 if(!owner||!class_get_methods||!method_get_name)return 0;
 void *iterator=0;Method next,match=0;
 for(unsigned n=0;n<1024;++n){
  next=class_get_methods(owner,&iterator);if(!next)return match;
  if(!equal(method_get_name(next),name)||!compatible_method(next,returns,args,count,is_static))continue;
  if(match)return 0;match=next;
 }
 return 0;
}
static void resolve_physics(void){
 void *component=klass("UnityEngine","Component"),*hitbox=klass("OxideOld.Player","PlayerHitbox"),*vector=klass("UnityEngine","Vector3"),*hit=klass("UnityEngine","RaycastHit"),*collider=klass("UnityEngine","Collider");
 void *boolean=klass("System","Boolean"),*single=klass("System","Single"),*integer=klass("System","Int32"),*type=klass("System","Type");
 void *ray_args[]={vector,vector,hit,single,integer,klass("UnityEngine","QueryTriggerInteraction")};
 physics_ray=physics_named_method(klass("UnityEngine","Physics"),"Raycast",boolean,ray_args,6,1);
 uint32_t alignment=0;if(!hit||!class_value_size||class_value_size(hit,&alignment)!=(int32_t)sizeof(PhysicsHit))physics_ray=0;
 hit_collider=physics_named_method(hit,"get_collider",collider,0,0,0);
 void *parent_args[]={type,boolean};component_parent=physics_named_method(component,"GetComponentInParent",component,parent_args,2,0);component_children=physics_named_method(component,"GetComponentInChildren",component,parent_args,2,0);
 hitbox_type=hitbox?type_get_object(class_get_type(hitbox)):0;
 hitbox_status=method(hitbox,"get_Status",0);hitbox_multiplier=method(hitbox,"GetMultiplierForCollider",2);
 if(!compatible_method(hitbox_status,player_class,0,0,0))hitbox_status=0;
 void *mult_args[]={collider,boolean};if(!compatible_method(hitbox_multiplier,single,mult_args,2,0))hitbox_multiplier=0;
 weapon_mask_field=class_get_field_from_name(klass("OxideOld.Player","HeldWeaponLogic"),"hitMask");
 if(!compatible_field_type(weapon_mask_field,integer,SIZE_MAX)&&!compatible_field_type(weapon_mask_field,klass("UnityEngine","LayerMask"),SIZE_MAX))weapon_mask_field=0;
 logline(physics_ray&&hit_collider&&component_parent?"Typed physics trace and visible-check methods resolved":"Visible check unavailable: typed physics binding/layout missing");
 resolve_shot_geometry();
}

#include "shot_geometry.h"
static BOOL trace_ray(const Vec3 *origin,const Vec3 *direction,float distance,int32_t mask,int32_t triggers,PhysicsHit *hit,BOOL *found){
 *found=0;if(!physics_ray)return 0;zeromem(hit,sizeof(*hit));
 void *args[]={(void*)origin,(void*)direction,hit,&distance,&mask,&triggers};Obj result=0;
 if(!invoke_checked(physics_ray,0,args,&result)||!result)return 0;
 void *value=object_unbox(result);if(!value)return 0;*found=*(unsigned char*)value!=0;return 1;
}
