/* Recognize hit audio only inside the reviewed HitMark coroutine.
   Skip only that PlayOneShot call; do not write source mute/volume or visuals. */
typedef void (ABI *HitFeedbackFunction)(Obj,Obj,unsigned char,Method);
typedef void (ABI *HitMarkFunction)(Obj,unsigned char,Method);
typedef unsigned char (ABI *HitRoutineFunction)(Obj,Method);
typedef void (ABI *HitOneShotFunction)(Obj,Obj,float,Method);
static HitFeedbackFunction hit_feedback_original;
static HitMarkFunction hit_marker_original;
static HitRoutineFunction hit_routine_original;
static HitOneShotFunction hit_one_shot_original;
static void *hit_feedback_entry,*hit_marker_entry,*hit_routine_entry,*hit_one_shot_entry;
static _Atomic BOOL hit_feedback_ready,hit_feedback_installed,hit_marker_ready,hit_marker_installed,hit_mute_ready,hit_routine_installed,hit_one_shot_installed;
static _Atomic uint64_t confirmed_hits,confirmed_heads,marker_hits,marker_heads;
static _Atomic uint64_t hit_audio_pending,hit_native_audio_calls,hit_original_suppressed,hit_queued_body,hit_queued_heads;
static _Atomic DWORD hit_output_state,hit_output_error;
void ABI VibeUiReportHitAudio(DWORD state,DWORD error){hit_output_error=error;hit_output_state=state;}
static void *hit_marker_source_field,*hit_marker_body_field,*hit_marker_head_field,*hit_routine_state_field,*hit_routine_owner_field,*hit_routine_head_field;
static DWORD hit_context_tls=0xffffffffu;
typedef struct {Obj source,clip;unsigned char headshot,consumed;} HitSoundContext;
static BOOL hit_sound_enabled(void){return !native_faulted&&running&&!stop_requested;}
static BOOL hit_audio_active(void){return hit_sound_enabled()&&focused&&(custom_audio_flags&VIBE_CUSTOM_AUDIO);}
static void hit_audio_release(void){atomic_store(&hit_audio_pending,0);}
/* Hit audio does not depend on player discovery, held aim, or overlay visibility. */
static BOOL hit_audio_needs_tick(void){return 0;}
static void hit_audio_tick(BOOL active){(void)active;if(!hit_sound_enabled()||!(custom_audio_flags&VIBE_CUSTOM_AUDIO))hit_audio_release();}
static void hit_queue_audio(unsigned char headshot){
 if(!hit_audio_active()||(custom_sound_mode&&!headshot))return;
 uint64_t previous=atomic_load(&hit_audio_pending),next;
 do{
  uint32_t count=(uint32_t)(headshot?previous>>32:previous);
  if(count==0xffffffffu)return;
  next=previous+(headshot?0x100000000ull:1ull);
 }while(!atomic_compare_exchange_weak(&hit_audio_pending,&previous,next));
 if(headshot)++hit_queued_heads;else ++hit_queued_body;
}
static void ABI hit_one_shot_proxy(Obj source,Obj clip,float volume,Method info){
 HitSoundContext *context=0;
 if(hit_mute_ready&&hit_sound_enabled()&&hit_context_tls!=0xffffffffu){DWORD error=GetLastError();context=TlsGetValue(hit_context_tls);SetLastError(error);}
 if(context&&!context->consumed&&source&&clip&&source==context->source&&clip==context->clip){
  context->consumed=1;++hit_native_audio_calls;hit_queue_audio(context->headshot);
  if(custom_audio_flags&VIBE_CUSTOM_MUTE_HIT){++hit_original_suppressed;return;}
 }
 hit_one_shot_original(source,clip,volume,info);
}
static unsigned char ABI hit_routine_proxy(Obj routine,Method info){
 HitSoundContext context={0};void *previous=0;BOOL installed=0;DWORD before_error=GetLastError();
 if(hit_mute_ready&&hit_sound_enabled()&&routine&&hit_context_tls!=0xffffffffu){
  int32_t state=-1;field_get_value(routine,hit_routine_state_field,&state);
  if(state==0){
   Obj marker=0;field_get_value(routine,hit_routine_owner_field,&marker);
   field_get_value(routine,hit_routine_head_field,&context.headshot);
   if(marker){field_get_value(marker,hit_marker_source_field,&context.source);field_get_value(marker,context.headshot?hit_marker_head_field:hit_marker_body_field,&context.clip);}
  }
  /* Installing an empty context on later states also hides an outer/nested one. */
  previous=TlsGetValue(hit_context_tls);installed=TlsSetValue(hit_context_tls,&context);
 }
 SetLastError(before_error);unsigned char result=hit_routine_original(routine,info);DWORD result_error=GetLastError();
 if(installed)TlsSetValue(hit_context_tls,previous);
 SetLastError(result_error);
 return result;
}
static void ABI hit_marker_proxy(Obj marker,unsigned char headshot,Method info){
 hit_marker_original(marker,headshot,info);++marker_hits;if(headshot)++marker_heads;
}
static void ABI hit_feedback_proxy(Obj weapon,Obj connection,unsigned char headshot,Method info){
 hit_feedback_original(weapon,connection,headshot,info);++confirmed_hits;if(headshot)++confirmed_heads;
}
static void resolve_received_feedback(void){
 hit_feedback_ready=0;
 Method received=method(klass("OxideOld.Player","HeldWeaponLogic"),PC_METHOD_receivedHit,2);
 void *args[]={klass("Mirror","NetworkConnectionToClient"),klass("System","Boolean")};
 static const unsigned char bytes[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57,0x48,0x83,0xec,0x20,0x80,0x3d,0xa2,0xe1,0xee,0x01,0x00,0x41,0x0f};
 if(!compatible_method(received,klass("System","Void"),args,2,0))return;
 if(hit_feedback_installed){hit_feedback_ready=*(void *const*)received==hit_feedback_entry;return;}
 if(!aimkill_entry_matches(received,PC_RVA_receivedHit,pc_prefix_receivedHit,sizeof(pc_prefix_receivedHit)))return;
 hit_feedback_entry=*(void *const*)received;
 DWORD error=VibeCreateNativeHook(hit_feedback_entry,hit_feedback_proxy,(void**)&hit_feedback_original);
 if(error){log_number("Received hit feedback hook status=",error);return;}
 hit_feedback_installed=hit_feedback_ready=1;
}
static BOOL hit_install_hook(Method method,uint32_t rva,const unsigned char *bytes,size_t size,void *proxy,void **entry,void **original,_Atomic BOOL *installed){
 if(!method)return 0;
 if(*installed)return *(void *const*)method==*entry;
 if(!aimkill_entry_matches(method,rva,bytes,size))return 0;
 *entry=*(void *const*)method;DWORD error=VibeCreateNativeHook(*entry,proxy,original);
 if(error){log_number("Hit sound route hook status=",error);return 0;}
 *installed=1;return 1;
}
static void *hit_find_routine_class(void *owner){
 if(owner&&class_get_nested_types&&class_get_name){
  void *iterator=0,*nested=0;unsigned count=0;
  while(count++<64&&(nested=class_get_nested_types(owner,&iterator)))if(equal(class_get_name(nested),"<ShowRoutine>d__18"))return nested;
 }
 return klass("","<ShowRoutine>d__18");
}
static void resolve_hit_feedback(void){
 resolve_received_feedback();hit_marker_ready=hit_mute_ready=0;
 void *owner=klass("OxideOld.UI","HitMark"),*routine=hit_find_routine_class(owner),*boolean=klass("System","Boolean"),*audio=klass("UnityEngine","AudioSource"),*clip=klass("UnityEngine","AudioClip"),*empty=klass("System","Void");
 void *args[]={boolean};Method show=physics_named_method(owner,"Show",empty,args,1,0);
 static const unsigned char marker_bytes[]={0x40,0x55,0x56,0x41,0x57,0x48,0x83,0xec,0x20,0x44,0x0f,0xb6,0xfa,0x48,0x8b,0xe9,0x84,0xd2,0x74,0x06,0x0f,0x10,0x41,0x54};
 hit_marker_ready=hit_install_hook(show,PC_RVA_markerShow,pc_prefix_markerShow,sizeof(pc_prefix_markerShow),hit_marker_proxy,&hit_marker_entry,(void**)&hit_marker_original,&hit_marker_installed);
 hit_marker_source_field=compatible_field(owner,audio,PC_FIELD_markerSource,"ΛӭЫʷƺЭ",0,0x70u,"HitMark audio source");
 hit_marker_body_field=compatible_field(owner,clip,"sound","sound",0,0x28u,"HitMark body clip");
 hit_marker_head_field=compatible_field(owner,clip,"headshotSound","headshotSound",0,0x30u,"HitMark head clip");
 hit_routine_state_field=compatible_field(routine,klass("System","Int32"),PC_FIELD_routineState,"<>1__state",1,0x10u,"HitMark coroutine state");
 hit_routine_owner_field=compatible_field(routine,owner,PC_FIELD_routineOwner,"<>4__this",1,0x28u,"HitMark coroutine owner");
 hit_routine_head_field=compatible_field(routine,boolean,PC_FIELD_routineHead,"headshot",1,0x20u,"HitMark coroutine head flag");
 if(!hit_marker_source_field||!hit_marker_body_field||!hit_marker_head_field||!hit_routine_state_field||!hit_routine_owner_field||!hit_routine_head_field)return;
 Method move=physics_named_method(routine,"MoveNext",boolean,0,0,0);
 void *shot_args[]={clip,klass("System","Single")};Method shot=physics_named_method(audio,"PlayOneShot",empty,shot_args,2,0);
 static const unsigned char routine_bytes[]={0x40,0x56,0x57,0x41,0x55,0x41,0x57,0x48,0x81,0xec,0x88,0x00,0x00,0x00,0x80,0x3d,0x02,0xeb,0x03,0x02,0x00,0x4c,0x8b,0xf9};
 static const unsigned char one_shot_bytes[]={0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83,0xec,0x30,0x80,0x3d,0xf5,0x76,0x9a,0x00,0x00,0x48,0x8b,0xda,0x0f,0x29,0x74,0x24};
 if(hit_context_tls==0xffffffffu)hit_context_tls=TlsAlloc();
 if(hit_context_tls==0xffffffffu)return;
 BOOL move_ok=hit_install_hook(move,PC_RVA_markerRoutine,pc_prefix_markerRoutine,sizeof(pc_prefix_markerRoutine),hit_routine_proxy,&hit_routine_entry,(void**)&hit_routine_original,&hit_routine_installed);
 BOOL shot_ok=hit_install_hook(shot,PC_RVA_audioOneShot,pc_prefix_audioOneShot,sizeof(pc_prefix_audioOneShot),hit_one_shot_proxy,&hit_one_shot_entry,(void**)&hit_one_shot_original,&hit_one_shot_installed);
 hit_mute_ready=move_ok&&shot_ok;
 logline(hit_mute_ready?"Hit audio ready: actual coroutine PlayOneShot, independent mixer, exact original clip suppression":"Hit audio unavailable: original audio remains intact");
}
uint64_t ABI VibeUiTakeHitAudio(void){uint64_t counts=atomic_exchange(&hit_audio_pending,0);return hit_audio_active()?counts:0;}
DWORD ABI VibeUiHitAudioActive(void){return hit_audio_active();}
