/* Local held-model cosmetics through SkinItem's real material-slot API.
   No Mirror SyncVar, ownership value, inventory or purchase data is written. */
static void *skin_string_class;
static void *skin_class,*skin_definition_class,*skin_id_field,*skin_name_field,*skin_model_fields[2];
static Method skin_manager_instance,skin_get_catalog,skin_list_count,skin_list_item,skin_get_current,skin_get_item,skin_apply,skin_reset,skin_children;
static BOOL skin_catalog_array;
static Obj skin_type;
static _Atomic BOOL skin_available;
static _Atomic DWORD skin_status;
static _Atomic uint64_t skin_changes,skin_catalog_requested;
static _Atomic BOOL skin_refresh_requested;
static uint32_t skin_requested_choice,skin_refresh_serial;
static uint64_t skin_next_catalog_retry;
static GCHandle skin_models[2],skin_catalog_root;
static int32_t skin_model_base[2],skin_model_applied[2],skin_model_item[2];
static unsigned skin_written;
static uint32_t skin_scan_index,skin_scan_count;
static uint64_t skin_next_lookup,skin_next_apply;
static VibeSkinCatalog skin_catalog_work,skin_catalog_published;
static atomic_flag skin_catalog_lock=ATOMIC_FLAG_INIT;
static void skin_publish(void){
 if(atomic_flag_test_and_set_explicit(&skin_catalog_lock,memory_order_acquire))return;
 skin_catalog_work.status=skin_status;skin_catalog_published=skin_catalog_work;
 atomic_flag_clear_explicit(&skin_catalog_lock,memory_order_release);
}
DWORD ABI VibeUiReadSkinCatalog(VibeSkinCatalog *out,DWORD bytes){
 if(!out||bytes!=sizeof(*out))return 0;skin_catalog_requested=GetTickCount64()+500;
 if(atomic_flag_test_and_set_explicit(&skin_catalog_lock,memory_order_acquire))return 0;
 *out=skin_catalog_published;out->status=skin_status;
 atomic_flag_clear_explicit(&skin_catalog_lock,memory_order_release);return 1;
}
static BOOL skin_read_int(Method method,Obj obj,int32_t *out){
 Obj value=0;if(!method||!invoke_checked(method,obj,0,&value)||!value)return 0;
 void *data=object_unbox(value);if(!data)return 0;*out=*(int32_t*)data;return 1;
}
static BOOL skin_call(Obj model,int32_t choice){
 Obj result=0;void *args[]={&choice};
 if(!invoke_checked(choice?skin_apply:skin_reset,model,choice?args:0,&result)||!result)return 0;
 void *value=object_unbox(result);return value&&*(unsigned char*)value;
}
static void skin_release_model(unsigned i){
 if(skin_models[i]){
  Obj model=gchandle_get_target(skin_models[i]);int32_t current=0,item=0;
  if((skin_written&(1u<<i))&&alive(model)&&skin_read_int(skin_get_item,model,&item)&&item==skin_model_item[i]&&skin_read_int(skin_get_current,model,&current)&&current==skin_model_applied[i])skin_call(model,skin_model_base[i]);
  gchandle_free(skin_models[i]);skin_models[i]=0;
 }
 skin_written&=~(1u<<i);skin_next_apply=0;
}
static void skin_release_models(void){for(unsigned i=0;i<2;++i)skin_release_model(i);skin_requested_choice=0;}
static void skin_release_catalog(void){
 if(skin_catalog_root)gchandle_free(skin_catalog_root);skin_catalog_root=0;skin_scan_count=skin_scan_index=0;
}
static void skin_release(void){skin_release_models();skin_release_catalog();skin_next_lookup=0;skin_next_catalog_retry=0;skin_status=0;}
DWORD ABI VibeUiRefreshSkinCatalog(void){skin_refresh_requested=1;skin_catalog_requested=GetTickCount64()+1000;return 1;}
static BOOL skin_needs_tick(void){return custom_pending_ready||skin_refresh_requested||(custom_flags&2u)||skin_models[0]||skin_models[1]||skin_catalog_root||GetTickCount64()<skin_catalog_requested;}
static void skin_copy_name(Obj name,uint16_t out[64]){
 for(unsigned i=0;i<64;++i)out[i]=0;
 if(!name||object_get_class(name)!=skin_string_class)return;
 int32_t count=string_length(name);const WCHAR *chars=string_chars(name);if(!chars||count<0)return;if(count>63)count=63;
 for(int32_t i=0;i<count;++i)out[i]=chars[i];
}
static void resolve_skinchanger(void){
 skin_available=0;skin_string_class=klass("System","String");skin_class=klass("OxideOld.Skins","SkinItem");skin_definition_class=klass("OxideOld.Skins","ItemSkinDefinition");
 void *manager=klass("OxideOld.Skins","SkinManager"),*integer=klass("System","Int32"),*boolean=klass("System","Boolean"),*component=klass("UnityEngine","Component"),*game_object=klass("UnityEngine","GameObject"),*weapon=klass("OxideOld.Player","HeldWeaponLogic");
 void *one_int[]={integer},*children_args[]={klass("System","Type"),boolean};
 skin_apply=physics_named_method(skin_class,"ApplySkin",boolean,one_int,1,0);
 skin_reset=physics_named_method(skin_class,"ResetToOriginal",boolean,0,0,0);
 skin_get_current=physics_named_method(skin_class,"GetCurrentSkinId",integer,0,0,0);
 skin_get_item=physics_named_method(skin_class,"GetItemId",integer,0,0,0);
 skin_manager_instance=method(manager,"get_Instance",0);if(!compatible_method(skin_manager_instance,manager,0,0,1))skin_manager_instance=0;
 skin_get_catalog=method(manager,"GetSkinsForItem",1);skin_catalog_array=0;skin_list_count=skin_list_item=0;
 void *catalog_class=skin_get_catalog?class_from_type(method_get_return_type(skin_get_catalog)):0;
 if(!compatible_method(skin_get_catalog,catalog_class,one_int,1,0))skin_get_catalog=0;
 if(skin_get_catalog){
  skin_catalog_array=class_get_element_class(catalog_class)==skin_definition_class;
  if(!skin_catalog_array){skin_list_count=physics_named_method(catalog_class,"get_Count",integer,0,0,0);skin_list_item=physics_named_method(catalog_class,"get_Item",skin_definition_class,one_int,1,0);if(!skin_list_count||!skin_list_item)skin_get_catalog=0;}
 }
 skin_id_field=compatible_field(skin_definition_class,integer,"skinId","skinId",0,SIZE_MAX,"Skin definition id");
 skin_name_field=compatible_field(skin_definition_class,klass("System","String"),"skinName","skinName",0,SIZE_MAX,"Skin definition name");
 skin_model_fields[0]=compatible_field(weapon,game_object,"weaponObject","weaponObject",0,SIZE_MAX,"Skin held weapon model");
 skin_model_fields[1]=compatible_field(weapon,game_object,"toolObject","toolObject",0,SIZE_MAX,"Skin held tool model");
 skin_children=physics_named_method(game_object,"GetComponentInChildren",component,children_args,2,0);
 skin_type=skin_class?type_get_object(class_get_type(skin_class)):0;
 skin_available=skin_apply&&skin_reset&&skin_get_current&&skin_get_item&&skin_manager_instance&&skin_get_catalog&&skin_id_field&&skin_name_field&&skin_children&&skin_type&&(skin_model_fields[0]||skin_model_fields[1])&&item_id_field&&item_name_field;
 skin_status=skin_available?0:1;logline(skin_available?"Local Skinchanger: real held models and item skin catalog resolved":"Local Skinchanger unavailable: compatible SkinItem/catalog bindings missing");
}
static void skin_scan_catalog(void){
 if(!skin_catalog_root)return;Obj array=gchandle_get_target(skin_catalog_root);
 if(!array){skin_release_catalog();skin_status=8;return;}
 uint32_t header=skin_catalog_array?array_object_header_size():0;
 if(skin_catalog_array&&(header<24||header>128)){skin_release_catalog();skin_status=8;return;}
 unsigned budget=8;
 while(budget--&&skin_scan_index<skin_scan_count&&skin_catalog_work.count<VIBE_SKIN_CATALOG_MAX){
  uint32_t i=skin_scan_index++;Obj definition=0;
  if(skin_catalog_array)definition=((Obj*)((unsigned char*)array+header))[i];
  else {int32_t index=(int32_t)i;void *args[]={&index};if(!invoke_checked(skin_list_item,array,args,&definition))break;}
  if(!definition||object_get_class(definition)!=skin_definition_class)continue;
  int32_t id=0;Obj name=0;field_get_value(definition,skin_id_field,&id);if(id<=0||id>1000000)continue;
  BOOL duplicate=0;for(uint32_t j=0;j<skin_catalog_work.count;++j)if(skin_catalog_work.entries[j].id==(uint32_t)id){duplicate=1;break;}if(duplicate)continue;
  VibeSkinEntry *entry=&skin_catalog_work.entries[skin_catalog_work.count++];entry->id=(uint32_t)id;
  field_get_value(definition,skin_name_field,&name);skin_copy_name(name,entry->name);
 }
 if(skin_scan_index>=skin_scan_count||skin_catalog_work.count>=VIBE_SKIN_CATALOG_MAX){skin_release_catalog();skin_status=skin_catalog_work.count?3:5;}
 skin_publish();
}
static void skin_start_catalog(Obj item,int32_t id){
 skin_release_catalog();skin_catalog_work=(VibeSkinCatalog){0};skin_catalog_work.item_id=(uint32_t)id;skin_catalog_work.refresh_serial=++skin_refresh_serial;atomic_store(&skin_refresh_requested,0);skin_next_catalog_retry=GetTickCount64()+1500;
 Obj name=0;field_get_value(item,item_name_field,&name);skin_copy_name(name,skin_catalog_work.item_name);
 Obj manager=invoke(skin_manager_instance,0,0),array=0;void *args[]={&id};
 if(!alive(manager)||!invoke_checked(skin_get_catalog,manager,args,&array)||!array){skin_status=5;skin_publish();return;}
 skin_catalog_root=gchandle_new(array,skin_catalog_array?1:0);if(!skin_catalog_root){skin_status=8;skin_publish();return;}
 array=gchandle_get_target(skin_catalog_root);int32_t count=0;
 if(!array){skin_release_catalog();skin_status=8;return;}
 if(skin_catalog_array)skin_scan_count=array_length(array);
 else if(skin_read_int(skin_list_count,array,&count)&&count>=0)skin_scan_count=(uint32_t)count;
 if(skin_scan_count>1024){skin_release_catalog();skin_status=8;skin_publish();return;}
 skin_status=2;skin_scan_catalog();
}
static void skin_tick(Obj local,BOOL active){
 if(!skin_needs_tick())return;
 if(!active||!skin_available||native_faulted){skin_release();skin_status=skin_available?0:1;skin_publish();return;}
 uint64_t now=GetTickCount64();skin_scan_catalog();if(now<skin_next_lookup)return;skin_next_lookup=now+250;
 Obj weapon=0,item=0;field_get_value(local,weapon_field,&weapon);if(alive(weapon))field_get_value(weapon,item_field,&item);
 int32_t id=0;if(alive(item))field_get_value(item,item_id_field,&id);
 if(id<=0||id>1000000){skin_release();skin_catalog_work=(VibeSkinCatalog){0};skin_publish();return;}
 if(skin_catalog_work.item_id!=(uint32_t)id){skin_release_models();skin_start_catalog(item,id);}
 else if(atomic_exchange(&skin_refresh_requested,0)||(!skin_catalog_root&&!skin_catalog_work.count&&now>=skin_next_catalog_retry)){skin_start_catalog(item,id);}
 if(!(custom_flags&2u)){skin_release_models();skin_publish();return;}
 uint32_t choice=vibe_skin_choice(&custom_current,(uint32_t)id);
 if(!choice){skin_release_models();skin_status=6;skin_catalog_work.current_skin_id=0;skin_catalog_work.models=0;skin_publish();return;}
 if(skin_requested_choice!=choice){skin_requested_choice=choice;skin_next_apply=0;}
 BOOL found=0;for(uint32_t i=0;i<skin_catalog_work.count;++i)if(skin_catalog_work.entries[i].id==choice){found=1;break;}
 if(!found){skin_release_models();if(!skin_catalog_root&&skin_status!=8)skin_status=5;skin_publish();return;}
 Obj candidates[2]={0};
 for(unsigned i=0;i<2;++i){
  Obj object=0;if(skin_model_fields[i])field_get_value(weapon,skin_model_fields[i],&object);
  unsigned char inactive=1;void *args[]={skin_type,&inactive};candidates[i]=alive(object)?invoke(skin_children,object,args):0;
 }
 if(candidates[1]==candidates[0])candidates[1]=0;
 /* Restore departing slots before reading either incoming model. This also
    handles a game-side swap of the weapon/tool components without adopting
    our own applied skin as an original, or undoing the other slot mid-pass. */
 for(unsigned i=0;i<2;++i)if(skin_models[i]&&gchandle_get_target(skin_models[i])!=candidates[i])skin_release_model(i);
 BOOL applied=0,pending=0,requested=0;skin_catalog_work.models=0;
 for(unsigned i=0;i<2;++i){
  Obj model=candidates[i];
  int32_t model_item=0,current=0;
  if(!alive(model)||!skin_read_int(skin_get_item,model,&model_item)||model_item!=id||!skin_read_int(skin_get_current,model,&current)){skin_release_model(i);continue;}
  skin_catalog_work.current_skin_id=(uint32_t)current;++skin_catalog_work.models;
  if(!skin_models[i]){skin_models[i]=gchandle_new(model,0);if(!skin_models[i])continue;skin_model_base[i]=current;skin_model_applied[i]=current;skin_model_item[i]=model_item;}
  if((skin_written&(1u<<i))&&current!=skin_model_applied[i]&&current!=skin_model_base[i])skin_model_base[i]=current;
  if(current==(int32_t)choice){applied=1;continue;}
  if(now<skin_next_apply){pending=1;continue;}
  const char *previous=invoke_context;invoke_context="Local SkinItem.ApplySkin";
  BOOL ok=skin_call(model,(int32_t)choice);invoke_context=previous;
  if(ok){skin_written|=1u<<i;skin_model_applied[i]=(int32_t)choice;++skin_changes;requested=1;
   int32_t observed=0;if(skin_read_int(skin_get_current,model,&observed)&&observed==(int32_t)choice){applied=1;skin_catalog_work.current_skin_id=(uint32_t)observed;}else pending=1;
  }
 }
 if(requested)skin_next_apply=now+1000;
 if(pending)skin_status=9;else if(applied)skin_status=4;else {skin_status=7;skin_next_apply=now+1000;}
 skin_publish();
}
