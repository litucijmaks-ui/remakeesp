/* Project with Unity's actual camera; track motion for sampling only. */
#include "projection_extent.h"
typedef struct {BOOL valid;} ProjectionState;
static Method projection_pixel_rect,projection_viewport_rect;
static BOOL projection_extent_valid;
static Obj projection_extent_key;
static uint64_t projection_extent_until;
static ProjectionState projection_state;
static BOOL projection_available;
static _Atomic uint64_t camera_motion_until;
static Vec3 previous_camera_forward,previous_camera_position;
static BOOL previous_camera_valid;
static GCHandle frame_camera_root;
static BOOL position_value(Obj,Vec3 *);
static BOOL vector_value(Method,Obj,void **,Vec3 *);
static void resolve_frame_sync(void);
static void projection_release(void){if(frame_camera_root)gchandle_free(frame_camera_root);frame_camera_root=0;projection_extent_valid=0;projection_extent_key=0;projection_extent_until=0;previous_camera_valid=0;camera_motion_until=0;}
static void resolve_projection(void){
 projection_release();projection_available=0;projection_state.valid=0;
 logline("ESP projection: exact Unity WorldToScreenPoint; Transform-derived matrix removed");
 void *camera_class=klass("UnityEngine","Camera"),*rect=klass("UnityEngine","Rect");
 projection_pixel_rect=method(camera_class,"get_pixelRect",0);projection_viewport_rect=method(camera_class,"get_rect",0);
 uint32_t align=0;if(!rect||class_value_size(rect,&align)!=16||!compatible_method(projection_pixel_rect,rect,0,0,0)||!compatible_method(projection_viewport_rect,rect,0,0,0))projection_pixel_rect=projection_viewport_rect=0;
 void *marker_params[]={klass("System","IntPtr"),klass("System","Int32")};
 game_marker_method=method(klass("UnityEngine","GL"),"IssuePluginEvent",2);
 if(!compatible_method(game_marker_method,klass("System","Void"),marker_params,2,1))game_marker_method=0;
 resolve_frame_sync();
}
static void projection_update_extent(Obj camera){
 if(!projection_pixel_rect||!projection_viewport_rect)return;uint64_t now=clock_us();
 if(projection_extent_key==camera&&now<projection_extent_until)return;
 projection_extent_key=camera;projection_extent_until=now+250000;
 Obj pixels=invoke(projection_pixel_rect,camera,0),viewport=invoke(projection_viewport_rect,camera,0);if(!pixels||!viewport){projection_extent_valid=0;return;}
 ProjectionRect p=*(ProjectionRect*)object_unbox(pixels),v=*(ProjectionRect*)object_unbox(viewport);int width,height;
 projection_extent_valid=projection_canvas(&p,&v,&width,&height);if(projection_extent_valid){source_width=width;source_height=height;}
}
static BOOL capture_projection(Obj camera){
 if(!alive(camera))return 0;
 if(frame_camera_root&&gchandle_get_target(frame_camera_root)!=camera)projection_release();
 if(!frame_camera_root)frame_camera_root=gchandle_new(camera,0);
 projection_update_extent(camera);
 Obj transform=invoke(component_transform,camera,0);Vec3 position,forward;
 if(!alive(transform)||!position_value(transform,&position)||!vector_value(transform_forward,transform,0,&forward))return 0;
 if(!finite_number(position.x)||!finite_number(position.y)||!finite_number(position.z)||!finite_number(forward.x)||!finite_number(forward.y)||!finite_number(forward.z))return 0;
 if(previous_camera_valid){float angle=__builtin_fabsf(forward.x-previous_camera_forward.x)+__builtin_fabsf(forward.y-previous_camera_forward.y)+__builtin_fabsf(forward.z-previous_camera_forward.z);float motion=__builtin_fabsf(position.x-previous_camera_position.x)+__builtin_fabsf(position.y-previous_camera_position.y)+__builtin_fabsf(position.z-previous_camera_position.z);if(angle>0.015f||motion>0.035f)camera_motion_until=clock_us()+150000;}
 previous_camera_forward=forward;previous_camera_position=position;previous_camera_valid=1;return 1;
}
static uint32_t effective_update_interval(uint64_t now){
 /* During camera motion always sample at fastest rate so boxes do not lag behind players. */
 uint32_t interval=sample_interval_us;
 if(camera_motion_until>now)return performance_profile==PROFILE_ECO?LIGHT_SAMPLE_US:FAST_SAMPLE_US;
 return interval;
}
