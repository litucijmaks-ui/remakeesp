#include <stdint.h>
static int med_text_match(const uint16_t *chars,int count){
 if(!chars||count<=0||count>4096)return 0;
 const char *words[]={"medkit","medicalkit","firstaidkit","bandage","syringe","heal","medical","aidkit","firstaid","stim","morphine","painkiller"};
 const unsigned word_count=12;
 for(unsigned word=0;word<word_count;++word){for(int i=0;i<count;++i){int at=i,j=0;
  while(at<count&&words[word][j]){uint16_t c=chars[at++];if(c==' '||c=='_'||c=='-'||c=='.')continue;if(c>='A'&&c<='Z')c+=32;if(c!=(unsigned char)words[word][j])break;++j;}
  if(!words[word][j])return 1;
 }}
 /* Russian: аптечка */
 const uint16_t russian[]={0x430,0x43f,0x442,0x435,0x447,0x43a,0x430};
 for(int i=0;i+7<=count;++i){int j=0;for(;j<7;++j){uint16_t c=chars[i+j];if(c>=0x410&&c<=0x42f)c+=32;if(c!=russian[j])break;}if(j==7)return 1;}
 /* Russian: бинт */
 const uint16_t bint[]={0x431,0x438,0x43d,0x442};
 for(int i=0;i+4<=count;++i){int j=0;for(;j<4;++j){uint16_t c=chars[i+j];if(c>=0x410&&c<=0x42f)c+=32;if(c!=bint[j])break;}if(j==4)return 1;}
 /* Russian: шприц */
 const uint16_t shprits[]={0x448,0x43f,0x440,0x438,0x446};
 for(int i=0;i+5<=count;++i){int j=0;for(;j<5;++j){uint16_t c=chars[i+j];if(c>=0x410&&c<=0x42f)c+=32;if(c!=shprits[j])break;}if(j==5)return 1;}
 return 0;
}
