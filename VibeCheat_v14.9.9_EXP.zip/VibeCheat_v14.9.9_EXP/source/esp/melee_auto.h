/* The reviewed melee scan performs ordinary hit dispatch but does not invoke
   the primary action, hand-shoot RPC, or first-person swing animation. */
static uint64_t melee_auto_next_ms;
static _Atomic uint64_t melee_auto_attempts,melee_auto_dispatched,melee_auto_blocked;
static BOOL melee_auto_strike(Obj local,Obj camera){
 if(!(custom_flags&VIBE_CUSTOM_AUTO_MELEE)||!melee_input_active()||GetCurrentThreadId()!=game_thread_id||!gameplay_ready(local))return 0;
 if((farm_options&1u)||GetAsyncKeyState(1)<0){melee_state="Auto melee: paused for farm or manual attack";return 0;}
 uint64_t now=GetTickCount64();if(now<melee_auto_next_ms)return 0;
 Obj weapon=0,item=0;
 if(!melee_equipped(local,&weapon,&item)||!melee_scan_method||!aimkill_can_fire||!melee_install()||
    !melee_sample_us||gchandle_get_target(melee_weapon_root)!=weapon||gchandle_get_target(melee_camera_root)!=camera)return 0;
 Obj target=gchandle_get_target(melee_player_root),bone=gchandle_get_target(melee_bone_root);unsigned char dead=1;
 if(!alive(target)||!alive(bone))return 0;field_get_value(target,dead_field,&dead);if(dead)return 0;
 Vec3 origin,point,screen;
 if((!third_shot_origin(camera,&origin)&&!world_position(camera,&origin))||!position_value(bone,&point)||!project_value(camera,&point,&screen)||screen.z<=0)return 0;
 float x=screen.x-source_width*.5f,y=screen.y-source_height*.5f,reach=0;
 field_get_value(weapon,weapon_range_field,&reach);
 Vec3 direction={point.x-origin.x,point.y-origin.y,point.z-origin.z};
 float square=direction.x*direction.x+direction.y*direction.y+direction.z*direction.z;
 if(!finite_number(x)||!finite_number(y)||x*x+y*y>(float)aim_fov_px*aim_fov_px||!finite_number(reach)||reach<=0||reach>8||!finite_number(square)||square<=.0001f||square>reach*reach)return 0;
 float length=__builtin_sqrtf(square);direction.x/=length;direction.y/=length;direction.z/=length;
 int32_t mask=0;field_get_value(weapon,weapon_mask_field,&mask);PhysicsHit hit;BOOL found=0;
 if(!trace_ray(&origin,&direction,length+.01f,mask,0,&hit,&found)||!found){++melee_auto_blocked;melee_state="Auto melee: no clear target hit";return 0;}
 Obj collider=invoke(hit_collider,&hit,0);unsigned char inactive=0;void *args[]={hitbox_type,&inactive};
 Obj box=alive(collider)?invoke(component_parent,collider,args):0;
 if(!alive(box)||invoke(hitbox_status,box,0)!=target){++melee_auto_blocked;melee_state="Auto melee: obstruction or different collider";return 0;}
 Obj allowed=invoke(aimkill_can_fire,weapon,0);void *value=allowed?object_unbox(allowed):0;
 if(!value||!*(unsigned char*)value){melee_state="Auto melee: native weapon gate";return 0;}
 float cooldown=0,swing=0;field_get_value(item,aimkill_cooldown_field,&cooldown);field_get_value(weapon,swing_field,&swing);
 if(!finite_number(cooldown)||cooldown<=0||cooldown>30||!finite_number(swing)||swing<=0||swing>30)return 0;
 float interval=cooldown>swing?cooldown:swing;if(interval<.05f)interval=.05f;
 melee_auto_next_ms=now+(uint64_t)(interval*1000.f+.999f);
 ++melee_auto_attempts;Obj result=0;
 if(!invoke_checked(melee_scan_method,weapon,0,&result)){melee_state="Auto melee: native scan invocation failed";return 0;}
 value=result?object_unbox(result):0;
 if(value&&*(unsigned char*)value){++melee_auto_dispatched;melee_state="Auto melee: normal scan dispatched a hit; server result unconfirmed";return 1;}
 melee_state="Auto melee: native scan found no accepted hit";return 0;
}
