/* Ordinary barrel harvesting and scrap pickup with independent navigation. */
enum {SCRAP_FARM,SCRAP_BARREL,SCRAP_DROP};
static unsigned scrap_kind,scrap_pickup_attempts,scrap_cursor[3];
static GCHandle scrap_arrays[3];static uint64_t scrap_refresh[3];
static BOOL scrap_navigation_owned;
static BOOL scrap_hit_requested;
static Vec3 scrap_last_point,scrap_loot_point;
static uint64_t scrap_loot_until,scrap_pickup_started;
static unsigned scrap_previous_interval;
static _Atomic uint64_t scrap_native_hits,scrap_drop_completed,scrap_loot_waits;
static _Atomic unsigned scrap_effective_interval_ms,scrap_distance_cm;
static unsigned scrap_objects_seen[3];
static _Atomic uint64_t scrap_candidates,scrap_action_failures;
static _Atomic uint64_t scrap_walks,scrap_farm_requests,scrap_strikes,scrap_pickups,scrap_tool_switches;
static BOOL scrap_collecting(void){return scrap_loot_until||(global_scrap_target&&scrap_kind==SCRAP_DROP);}
static BOOL scrap_pending(void){return global_scrap_target||scrap_loot_until;}
static void scrap_navigation_release(void){if(scrap_navigation_owned)navigation_stop();scrap_navigation_owned=0;}
static void global_scrap_clear(void){scrap_navigation_release();farm_timing_release();if(global_scrap_target)gchandle_free(global_scrap_target);global_scrap_target=0;scrap_pickup_attempts=0;scrap_pickup_started=0;scrap_hit_requested=0;global_next_scrap_action=0;}
static void global_scrap_release(void){global_scrap_clear();scrap_loot_until=0;for(unsigned k=0;k<3;k++){if(scrap_arrays[k])gchandle_free(scrap_arrays[k]);scrap_arrays[k]=0;scrap_refresh[k]=scrap_cursor[k]=0;}global_next_scrap_scan=global_next_scrap_action=0;}
static BOOL scrap_barrel_name(Obj object){
 if(global_name_contains(object,"barrel"))return 1;Obj t=invoke(component_transform,object,0);
 for(unsigned n=0;n<3&&alive(t)&&global_methods[GM_globalParent];n++){t=invoke(global_methods[GM_globalParent],t,0);if(alive(t)&&global_name_contains(t,"barrel"))return 1;}
 return 0;
}
static BOOL global_scrap_valid(Obj o,unsigned kind){
 if(!alive(o)||!global_instance_of(o,kind==SCRAP_FARM?farm_class:global_classes[kind==SCRAP_DROP?G_dropped:G_breakable]))return 0;
 Obj go=global_methods[GM_componentObject]?invoke(global_methods[GM_componentObject],o,0):0;
 Obj box=alive(go)&&global_methods[GM_activeGet]?invoke(global_methods[GM_activeGet],go,0):0;if(!box||!*(unsigned char*)object_unbox(box))return 0;
 if(kind==SCRAP_FARM)return 1;
 if(kind==SCRAP_DROP){unsigned char picked=1;if(global_fields[GF_dropPicked])field_get_value(o,global_fields[GF_dropPicked],&picked);return !picked;}
 /* isBreak is an enabled break/replacement setting. Both real barrel
    components have isBreak=true before any hit; it is not a dead flag. */
 if(!global_methods[GM_componentChildren]||!global_types[G_entityEvent]||!global_fields[GF_entityHealth])return 0;
 unsigned char no=0;void *args[]={global_types[G_entityEvent],&no};Obj state=invoke(global_methods[GM_componentChildren],o,args);
 if(!alive(state)||!global_instance_of(state,global_classes[G_entityEvent]))return 0;
 float health=0;field_get_value(state,global_fields[GF_entityHealth],&health);return finite_number(health)&&health>0;
}
static BOOL scrap_prepare_tool(Obj local,Obj *weapon,Obj *item,uint64_t now){
 if(melee_equipped(local,weapon,item))return 1;
 if(!tool_guard_available||!aimkill_kind_field){scrap_state_set("Scrap: put a melee tool in the hotbar");return 0;}
 Obj hotbar=0;field_get_value(local,local_hotbar_field,&hotbar);Obj changing=alive(hotbar)?invoke(hotbar_changing,hotbar,0):0;
 if(!changing){scrap_state_set("Scrap: waiting for hotbar");return 0;}
 if(*(unsigned char*)object_unbox(changing)||now<tool_switch_wait){scrap_state_set("Scrap: waiting for equipped tool");return 0;}
 Obj a=0;int32_t selected=-1;field_get_value(hotbar,hotbar_slots_field,&a);field_get_value(hotbar,hotbar_index_field,&selected);if(!a)return 0;
 uint32_t count=array_length(a),h=array_object_header_size();if(count>32||h<24||h>128)return 0;
 for(unsigned i=0;i<count;i++){Obj slot=((Obj*)((unsigned char*)a+h))[i];if(!alive(slot)||(int32_t)i==selected)continue;Obj candidate=invoke(slot_item,slot,0);int32_t kind=-1;if(alive(candidate))field_get_value(candidate,aimkill_kind_field,&kind);if(kind!=3)continue;
  int32_t index=(int32_t)i;void *args[]={&index};Obj ignored;if(invoke_checked(hotbar_select,hotbar,args,&ignored)){tool_switch_wait=now+1000;++scrap_tool_switches;scrap_state_set("Scrap: selecting melee tool");}return 0;
 }
 scrap_state_set("Scrap: no melee tool in hotbar");return 0;
}
static void global_scrap(Obj local,Obj camera,BOOL active,uint64_t now){
 if(!(custom_flags&VIBE_CUSTOM_SCRAP)||!active){global_scrap_release();scrap_state_set(!(custom_flags&VIBE_CUSTOM_SCRAP)?"Scrap: disabled":"Scrap: paused for menu, focus or local player");return;}
 if(manual_movement()||aim_held||GetAsyncKeyState(1)<0){scrap_navigation_release();farm_timing_release();scrap_state_set("Scrap: paused for manual input");return;}
 unsigned interval=farm_interval_ms;if(interval<20)interval=20;if(interval>2000)interval=2000;
 if(interval!=scrap_previous_interval){scrap_previous_interval=interval;global_next_scrap_action=0;}
 Vec3 origin;if(!world_position(local,&origin)){scrap_navigation_release();farm_timing_release();return;}
 Obj object=global_scrap_target?gchandle_get_target(global_scrap_target):0;
 if(global_scrap_target&&(!global_scrap_valid(object,scrap_kind)||farm_skipped(object,now))){
  if(scrap_kind!=SCRAP_DROP&&scrap_hit_requested&&!farm_skipped(object,now)){scrap_loot_point=scrap_last_point;scrap_loot_until=now+6000;scrap_refresh[SCRAP_DROP]=0;++scrap_loot_waits;}
  else if(scrap_kind==SCRAP_DROP&&scrap_pickup_attempts){++scrap_drop_completed;if(scrap_loot_until)scrap_loot_until=now+1000;}
  global_scrap_clear();global_next_scrap_scan=0;object=0;
 }
 if(scrap_loot_until&&now>=scrap_loot_until&&!object){scrap_loot_until=0;global_next_scrap_scan=0;}
 if(!object&&now>=global_next_scrap_scan){global_next_scrap_scan=now+(scrap_loot_until?100:500);float best=(float)farm_search_m*farm_search_m;
  /* Bags take priority. During the spawn/collection phase no new barrel can
     steal the target, even when it is closer than the delayed drop. */
  for(unsigned pass=0;pass<3;pass++){unsigned k=pass==0?SCRAP_DROP:pass-1;if(pass&&object)break;if(scrap_loot_until&&k!=SCRAP_DROP)continue;
   if(!scrap_arrays[k]||now>=scrap_refresh[k]){
    Obj a=0;if(k==SCRAP_FARM){int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={farm_type,&no},*unsorted[]={farm_type,&inactive,&sort};if(farm_type)a=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);}
    else a=global_find(k==SCRAP_DROP?G_dropped:G_breakable,0);
    GCHandle root=a?gchandle_new(a,0):0;if(root){if(scrap_arrays[k])gchandle_free(scrap_arrays[k]);scrap_arrays[k]=root;}scrap_refresh[k]=now+(k==SCRAP_DROP?250:2000);
   }
   Obj a=scrap_arrays[k]?gchandle_get_target(scrap_arrays[k]):0;if(!a)continue;
   uint32_t count=array_length(a),h=array_object_header_size();scrap_objects_seen[k]=count;if(count>8192||h<24||h>128)continue;
   for(unsigned n=0;n<count&&n<128;n++){if(scrap_cursor[k]>=count)scrap_cursor[k]=0;Obj candidate=((Obj*)((unsigned char*)a+h))[scrap_cursor[k]++];
    if(!global_scrap_valid(candidate,k)||farm_skipped(candidate,now)||!(k==SCRAP_DROP?global_scrap_drop(candidate):scrap_barrel_name(candidate)))continue;
    ++scrap_candidates;Vec3 p;if(!world_position(candidate,&p))continue;if(scrap_loot_until&&point_distance_sq(&scrap_loot_point,&p)>36.f)continue;float d=point_distance_sq(&origin,&p);if(!finite_number(d)||d>=best)continue;
    GCHandle root=gchandle_new(candidate,0);if(!root)continue;global_scrap_clear();global_scrap_target=root;scrap_kind=k;object=candidate;best=d;
   }
  }
 }
 if(!object){scrap_navigation_release();farm_timing_release();scrap_state_set(scrap_loot_until?"Scrap: waiting for barrel loot":"Scrap: searching for barrels and drops");return;}
 Obj weapon=0,item=0;if(scrap_kind!=SCRAP_DROP&&!scrap_prepare_tool(local,&weapon,&item,now)){scrap_navigation_release();farm_timing_release();return;}
 Vec3 point;if(!world_position(object,&point)){global_scrap_clear();return;}scrap_last_point=point;Obj collider=0;
 Vec3 interaction_origin=origin;if(scrap_kind!=SCRAP_DROP&&alive(camera)){if(!third_shot_origin(camera,&interaction_origin)&&!world_position(camera,&interaction_origin))interaction_origin=origin;}
 if(scrap_kind==SCRAP_FARM&&farm_collider_field)field_get_value(object,farm_collider_field,&collider);
 else if(scrap_kind==SCRAP_BARREL&&global_methods[GM_componentChildren]&&global_types[G_collider]){unsigned char no=0;void *args[]={global_types[G_collider],&no};collider=invoke(global_methods[GM_componentChildren],object,args);}
 if(alive(collider)&&collider_closest){void *args[]={&interaction_origin};Vec3 closest;if(vector_value(collider_closest,collider,args,&closest))point=closest;}
 float reach=0;if(scrap_kind==SCRAP_DROP){if(global_fields[GF_dropRadius])field_get_value(object,global_fields[GF_dropRadius],&reach);if(reach>1.5f)reach=1.5f;}else field_get_value(weapon,weapon_range_field,&reach);
 if(!finite_number(reach)||reach<=0||reach>20){scrap_navigation_release();scrap_state_set("Scrap: interaction range unavailable");return;}
 float square=point_distance_sq(&interaction_origin,&point);if(!finite_number(square)){global_scrap_clear();return;}
 scrap_distance_cm=(unsigned)(__builtin_sqrtf(square)*100.f);
 float dx=point.x-origin.x,dz=point.z-origin.z,flat=dx*dx+dz*dz;
 float approach=scrap_kind==SCRAP_DROP?reach:(float)farm_range_cm*.01f;if(approach>reach*.85f)approach=reach*.85f;if(approach<.5f)approach=.5f;
 if(square>reach*reach*.90f||flat>approach*approach){
  farm_timing_release();
  if(flat<.25f){scrap_navigation_release();scrap_state_set("Scrap: target outside native tool reach");return;}
  if(!navigation_available){scrap_navigation_release();scrap_state_set("Scrap: navigation unavailable");return;}
  scrap_navigation_owned=1;if(!navigation_tick_generic(local,&point,object,collider)){global_scrap_clear();return;}++scrap_walks;
  if(aim_available)aim_move_to(local,camera,&point,60,.016667f);scrap_state_set("Scrap: approaching selected target");return;
 }
 scrap_navigation_release();
 Obj ignored=0;
 if(scrap_kind==SCRAP_DROP){farm_timing_release();if(!global_methods[GM_dropInteract]){scrap_state_set("Scrap: pickup method unavailable");return;}
  if(scrap_pickup_started&&now-scrap_pickup_started>=8000){farm_skip(object,now);global_scrap_clear();scrap_loot_until=0;scrap_state_set("Scrap: pickup not acknowledged");return;}
  if(now<global_next_scrap_action)return;global_next_scrap_action=now+500;if(!scrap_pickup_started)scrap_pickup_started=now;
  ++scrap_pickup_attempts;void *args[]={local};if(invoke_checked(global_methods[GM_dropInteract],object,args,&ignored))++scrap_pickups;else {++scrap_action_failures;scrap_state_set("Scrap: pickup invocation failed");return;}
  scrap_state_set("Scrap: waiting for pickup acknowledgement");return;
 }
 float seconds=(float)interval*.001f;farm_timing_apply(0,item,item_cooldown_field,seconds);farm_timing_apply(1,weapon,swing_field,seconds);farm_timing_apply(2,scrap_kind==SCRAP_FARM?object:weapon,scrap_kind==SCRAP_FARM?farm_cooldown_field:melee_delay_field,seconds);
 scrap_effective_interval_ms=interval;
 if(now<global_next_scrap_action)return;
 if(!aim_available||!aim_move_to(local,camera,&point,100,.016667f)){scrap_state_set("Scrap: aiming at barrel");return;}
 if(scrap_kind==SCRAP_FARM&&try_farm&&farm_can&&net_identity){
  Obj can=invoke(farm_can,object,0);if(!can||!*(unsigned char*)object_unbox(can)){scrap_state_set("Scrap: barrel cooldown");return;}
  Obj identity=invoke(net_identity,object,0),name=0;int32_t efficiency=0;field_get_value(item,item_name_field,&name);field_get_value(item,item_efficiency_field,&efficiency);
  if(!alive(identity)||!name||efficiency>10000){scrap_state_set("Scrap: tool data unavailable");return;}
  if(efficiency<1)efficiency=1; /* Same minimum as the ordinary client farm path. */
  void *args[]={identity,&point,&efficiency,name};if(invoke_checked(try_farm,weapon,args,&ignored)){++scrap_farm_requests;scrap_hit_requested=1;}else {++scrap_action_failures;scrap_state_set("Scrap: farm invocation failed");return;}
 }else if(melee_scan_method&&aimkill_can_fire){
  /* PrimaryAction has a held-input latch, so repeated calls are not repeated
     hits. Use the reviewed ordinary collision scan after steering settles. */
  Vec3 screen;if(!project_value(camera,&point,&screen)||screen.z<=0){scrap_state_set("Scrap: aiming at barrel");return;}
  float x=screen.x-source_width*.5f,y=screen.y-source_height*.5f;if(!finite_number(x)||!finite_number(y)||x*x+y*y>576.f){scrap_state_set("Scrap: aiming at barrel");return;}
  Obj allowed=invoke(aimkill_can_fire,weapon,0);void *value=allowed?object_unbox(allowed):0;if(!value||!*(unsigned char*)value){scrap_state_set("Scrap: barrel cooldown");return;}
  if(global_methods[GM_physicsSync]&&!invoke_checked(global_methods[GM_physicsSync],0,0,&ignored)){scrap_state_set("Scrap: physics synchronization failed");return;}
  if(invoke_checked(melee_scan_method,weapon,0,&ignored)){++scrap_strikes;value=ignored?object_unbox(ignored):0;if(value&&*(unsigned char*)value){++scrap_native_hits;scrap_hit_requested=1;}else {global_next_scrap_action=now+100;scrap_state_set("Scrap: native scan missed barrel");return;}}
  else {++scrap_action_failures;scrap_state_set("Scrap: strike invocation failed");return;}
 }else {scrap_state_set("Scrap: barrel action method unavailable");return;}
 global_next_scrap_action=now+interval;
 scrap_state_set("Scrap: normal barrel action requested");
}
