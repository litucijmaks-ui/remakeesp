#include "world_marker.h"
#include "backpack_esp.h"
static void placed_release(void);
static void placed_sample(Obj,const Vec3 *,uint64_t,BOOL);
static Obj balloon_type;
static void *balloon_broken_field,*corpse_ragdoll_field;
static GCHandle balloon_array_root;
static uint64_t balloon_next_scan;
static void balloon_release(void){if(balloon_array_root)gchandle_free(balloon_array_root);balloon_array_root=0;balloon_next_scan=0;world_marker_count=0;}
static void resolve_balloon_bindings(void){
 balloon_release();backpack_release();placed_release();balloon_type=backpack_type=0;balloon_broken_field=0;
 void *backpack=klass("OxideOld.World","Backpack");if(backpack)backpack_type=type_get_object(class_get_type(backpack));
 logline(backpack_type?"Death Backpack ESP binding ready":"Backpack ESP unavailable for this build");
 corpse_ragdoll_field=class_get_field_from_name(player_class,"ragdoll");
 if(corpse_ragdoll_field){void *c=class_from_type(field_get_type(corpse_ragdoll_field));const char *n=c?class_get_name(c):0;if(!n||!equal(n,"Rigidbody[]")||(field_get_flags(corpse_ragdoll_field)&16))corpse_ragdoll_field=0;}
 void *balloon=klass("","LootBoxBalloon");
 balloon_broken_field=compatible_field(balloon,klass("System","Boolean"),"broken","broken",0,SIZE_MAX,"Loot balloon broken flag");
 if(balloon&&balloon_broken_field)balloon_type=type_get_object(class_get_type(balloon));
 logline(balloon_type?"LootBoxBalloon ESP binding ready":"LootBoxBalloon ESP unavailable for this game build");
}
static void balloon_only_sample(Obj camera,const Vec3 *origin,uint64_t now,BOOL discover){
 world_marker_count=0;
 if(!(menu_options&64u)){balloon_release();return;}
 if(!balloon_type||!balloon_broken_field||!alive(camera)||!origin)return;
 if(discover&&(!balloon_array_root||now>=balloon_next_scan)){
  balloon_next_scan=now+(performance_profile==PROFILE_ECO?2000:1000);
  int32_t inactive=0,sort=0;unsigned char include_inactive=0;
  void *unsorted[]={balloon_type,&inactive,&sort},*args[]={balloon_type,&include_inactive};
  Obj array=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);
  if(array){GCHandle root=gchandle_new(array,0);if(root){if(balloon_array_root)gchandle_free(balloon_array_root);balloon_array_root=root;}}
 }
 Obj array=balloon_array_root?gchandle_get_target(balloon_array_root):0;if(!array)return;
 uint32_t count=array_length(array),header=array_object_header_size();if(count>256||header<24||header>128)return;
 Obj *objects=(Obj*)((unsigned char*)array+header);
 for(uint32_t i=0;i<count&&world_marker_count<32;++i){
  Obj balloon=objects[i];if(!alive(balloon))continue;unsigned char broken=1;field_get_value(balloon,balloon_broken_field,&broken);if(broken)continue;
  Vec3 position,screen;if(!world_position(balloon,&position))continue;
  float x=position.x-origin->x,y=position.y-origin->y,z=position.z-origin->z,square=x*x+y*y+z*z;
  if(!finite_number(square)||square<0||square>(float)balloon_max_m*balloon_max_m||!project_value(camera,&position,&screen))continue;
  VibeWorldMarker marker;if(!world_marker_project(&screen,source_width,source_height,&marker))continue;
  marker.distance=__builtin_sqrtf(square);world_markers[world_marker_count++]=marker;
 }
}

/* edge bit 0 is the screen edge; bit 1 identifies a corpse marker. */
static void corpse_sample(Obj camera,const Vec3 *origin){
 if(!(menu_options&128u)||!dead_field||!player_array_handle||!alive(camera)||!origin)return;
 Obj array=gchandle_get_target(player_array_handle);if(!array)return;
 uint32_t count=array_length(array),header=array_object_header_size();if(count>8192||header<24||header>128)return;
 Obj *objects=(Obj*)((unsigned char*)array+header);
 for(uint32_t i=0;i<count&&i<512&&world_marker_count<32;++i){
  Obj player=objects[i];if(player==cached_local_key||!alive(player))continue;
  unsigned char dead=0;field_get_value(player,dead_field,&dead);if(!dead)continue;
  Vec3 position,screen;if(!world_position(player,&position))continue;
  if(corpse_ragdoll_field){Obj parts=0;field_get_value(player,corpse_ragdoll_field,&parts);if(parts){uint32_t n=array_length(parts),h=array_object_header_size();if(n>0&&n<128&&h>=24&&h<=128){Obj body=*(Obj*)((unsigned char*)parts+h);Vec3 live;if(alive(body)&&world_position(body,&live))position=live;}}}
  float x=position.x-origin->x,y=position.y-origin->y,z=position.z-origin->z,square=x*x+y*y+z*z;
  if(!finite_number(square)||square<0||square>(float)range_max_m*range_max_m||!project_value(camera,&position,&screen))continue;
  VibeWorldMarker marker;if(!world_marker_project(&screen,source_width,source_height,&marker))continue;
  marker.distance=__builtin_sqrtf(square);marker.edge|=2u;world_markers[world_marker_count++]=marker;
 }
}
static void balloon_sample(Obj camera,const Vec3 *origin,uint64_t now,BOOL discover){
 balloon_only_sample(camera,origin,now,discover);backpack_sample(camera,origin,now,discover);placed_sample(camera,origin,now,discover);
}
