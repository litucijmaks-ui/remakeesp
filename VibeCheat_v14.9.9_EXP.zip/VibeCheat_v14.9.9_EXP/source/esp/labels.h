/* Compact outline text, bounded by actual pixel width. Nearer players get
   labels first; overlapping text and the reticle area remain clear. */
#define LABEL_GROUP_LIMIT 256
#define LABEL_WIDTH_LIMIT 128
#define LABEL_HEIGHT_LIMIT 24
typedef struct {WCHAR text[64];int length,x,y,width,height;unsigned kind;} RenderLabel;
static RenderLabel labels[LABEL_GROUP_LIMIT*3];
static int label_count;
static BOOL label_rect_overlap(const RECT *a,const RECT *b){return a->left<b->right&&a->right>b->left&&a->top<b->bottom&&a->bottom>b->top;}
static BOOL label_control(WCHAR c){return c<32||c==127||(c>=0x200b&&c<=0x200f)||(c>=0x202a&&c<=0x202e)||(c>=0x2060&&c<=0x2069)||c==0xfeff||(c>=0x0300&&c<=0x036f)||c==0xfe0f;}
static int name_line(const WCHAR *input,int count,WCHAR *out){
 int n=0,points=0;BOOL shortened=0;
 for(int i=0;i<count;++i){WCHAR c=input[i];if(label_control(c))continue;
  if(c=='<'){int j=i+1;while(j<count&&input[j]!='>')++j;if(j<count){i=j;continue;}}
  if(c==' '&&(!n||out[n-1]==' '))continue;
  if(points>=20||n>=59){shortened=1;break;}
  if(c>=0xd800&&c<=0xdbff){if(i+1<count&&input[i+1]>=0xdc00&&input[i+1]<=0xdfff){out[n++]=c;out[n++]=input[++i];++points;}continue;}
  if(c>=0xdc00&&c<=0xdfff)continue;
  out[n++]=c;++points;
 }
 while(n&&out[n-1]==' ')--n;
 if(shortened&&n)out[n++]=0x2026;
 out[n]=0;return n;
}
static int label_prefix(int length,const WCHAR *text){if(length<=0)return 0;--length;if(length&&text[length]>=0xdc00&&text[length]<=0xdfff&&text[length-1]>=0xd800&&text[length-1]<=0xdbff)--length;return length;}
static int label_measure_raw(HDC dc,RenderLabel *label,int limit){
 SIZE size={0};if(label->length<=0||limit<16)return 0;
 if(!GetTextExtentPoint32W(dc,label->text,label->length,&size))size=(SIZE){label->length*14,14};
 if(size.cx>limit){
  int prefix=label->length;if(label->text[prefix-1]==0x2026)--prefix;
  do{prefix=label_prefix(prefix,label->text);if(!prefix)return 0;label->text[prefix]=0x2026;label->length=prefix+1;
   if(!GetTextExtentPoint32W(dc,label->text,label->length,&size))size=(SIZE){label->length*14,14};
  }while(size.cx>limit);
 }
 label->width=size.cx;label->height=size.cy>0?size.cy:14;return label->width>0&&label->height<=LABEL_HEIGHT_LIMIT;
}
typedef struct {WCHAR key[64];int length,limit;RenderLabel value;} LabelMetric;
static LabelMetric label_metrics[256];
static int label_measure(HDC dc,RenderLabel *label,int limit){
 if(label->length<=0||label->length>63)return 0;
 uint32_t hash=2166136261u;for(int i=0;i<label->length;++i)hash=(hash^label->text[i])*16777619u;
 LabelMetric *cache=&label_metrics[hash&255u];BOOL same=cache->length==label->length&&cache->limit==limit;
 if(same)for(int i=0;i<label->length;++i)if(cache->key[i]!=label->text[i]){same=0;break;}
 if(same){unsigned kind=label->kind;*label=cache->value;label->kind=kind;return 1;}
 RenderLabel original=*label;if(!label_measure_raw(dc,label,limit))return 0;
 cache->length=original.length;cache->limit=limit;for(int i=0;i<original.length;++i)cache->key[i]=original.text[i];cache->value=*label;return 1;
}
static BOOL place_label_at(HDC dc,RenderLabel *label,int center,int y,int w,int h,BOOL force){
 int limit=w>LABEL_WIDTH_LIMIT+4?LABEL_WIDTH_LIMIT:w-4;if(!label_measure(dc,label,limit))return 0;
 if(label_count>=LABEL_GROUP_LIMIT*3)return 0;
 if(y<2||y+label->height+2>h){if(!force)return 0;if(y<2)y=2;if(y+label->height+2>h)y=h-label->height-2;if(y<2)return 0;}
 int x=center-label->width/2;if(x<2)x=2;if(x+label->width+2>w)x=w-label->width-2;
 RECT rect={x-2,y-2,x+label->width+2,y+label->height+2},reticle={w/2-18,h/2-15,w/2+18,h/2+15};
 if(label_rect_overlap(&rect,&reticle)){if(!force)return 0;x=center<=w/2?reticle.left-label->width-3:reticle.right+3;if(x<2)x=2;if(x+label->width+2>w)x=w-label->width-2;}
 if(!force)for(int i=0;i<label_count;++i){const RenderLabel *p=&labels[i];RECT previous={p->x-2,p->y-2,p->x+p->width+2,p->y+p->height+2};if(label_rect_overlap(&rect,&previous))return 0;}
 label->x=x;label->y=y;labels[label_count++]=*label;return 1;
}
typedef struct {uintptr_t actor;unsigned kind;int row;} LabelPosition;
static LabelPosition label_positions[1024];
static void place_stable_label(HDC dc,RenderLabel *label,uintptr_t actor,int center,const int *rows,int count,int w,int h){
 uintptr_t hash=(actor>>4)^((uintptr_t)label->kind*2654435761u);LabelPosition *p=&label_positions[hash&1023u];
 int preferred=p->actor==actor&&p->kind==label->kind&&p->row<count?p->row:0;
 if(place_label_at(dc,label,center,rows[preferred],w,h,0))return;
 for(int i=0;i<count;++i)if(i!=preferred&&place_label_at(dc,label,center,rows[i],w,h,0)){*p=(LabelPosition){actor,label->kind,i};return;}
 place_label_at(dc,label,center,rows[preferred],w,h,1);
 *p=(LabelPosition){actor,label->kind,preferred};
}
static void prepare_labels(HDC dc,int w,int h,DWORD flags,float sx,float sy){
 label_count=0;if(!(flags&1)||!(flags&22))return;
 int order[LABEL_GROUP_LIMIT],selected=0;
 for(int i=0;i<render_frame.count;++i){const Box *b=&render_frame.items[i];
  if(!(((flags&4)&&b->name_len)||((flags&2)&&finite_number(b->hp))||((flags&16)&&finite_number(b->distance)&&b->distance>=0)))continue;
  int pos=selected;while(pos>0&&render_frame.items[order[pos-1]].range_sq>b->range_sq)--pos;
  if(pos>=LABEL_GROUP_LIMIT)continue;
  if(selected<LABEL_GROUP_LIMIT)++selected;
  for(int j=selected-1;j>pos;--j)order[j]=order[j-1];
  order[pos]=i;
 }
 /* Names have priority over secondary HP/distance labels. Try nearby rows
    before falling back to a compact, clamped name instead of hiding it. */
 for(int k=0;k<selected;++k){const Box *b=&render_frame.items[order[k]];if(!(flags&4)||!b->name_len)continue;
  int cx=(int)((b->x+b->w*0.5f)*sx),top=(int)(b->y*sy),bottom=(int)((b->y+b->h)*sy);RenderLabel label={0};
  label.kind=ESP_COLOR_NAME;
  label.length=name_line(b->name,b->name_len,label.text);if(!label_measure(dc,&label,LABEL_WIDTH_LIMIT))continue;
  int candidates[]={top-label.height-3,top-label.height-23,top-label.height-43};
  (void)bottom;place_stable_label(dc,&label,b->player_key?b->player_key:(uintptr_t)(order[k]+1),cx,candidates,3,w,h);
 }
 int details=selected;if(details>(performance_profile==PROFILE_ECO?12:24))details=performance_profile==PROFILE_ECO?12:24;
 for(int k=0;k<details;++k){const Box *b=&render_frame.items[order[k]];int cx=(int)((b->x+b->w*0.5f)*sx),bottom=(int)((b->y+b->h)*sy);RenderLabel label={0};
  BOOL hp=(flags&2)&&finite_number(b->hp),distance=(flags&16)&&finite_number(b->distance)&&b->distance>=0;
  RenderLabel group[2]={0};int count=0,total=0;
  if(hp){char text[16];int n=health_text(b->hp,text);for(int i=0;i<n;++i)label.text[i]=(unsigned char)text[i];label.length=n;label.kind=ESP_COLOR_HP;if(label_measure(dc,&label,LABEL_WIDTH_LIMIT)){group[count++]=label;total+=label.height;}}
  if(distance){char text[16];int n=distance_text(b->distance,text);for(int i=0;i<n;++i)label.text[i]=(unsigned char)text[i];label.length=n;label.kind=ESP_COLOR_DISTANCE;if(label_measure(dc,&label,LABEL_WIDTH_LIMIT)){group[count++]=label;total+=label.height;}}
  if(count==2)total+=4;
  int row=bottom+3;if(row+total+2>h)row=h-total-2;if(row<2)row=2;
  uintptr_t key=b->player_key?b->player_key:(uintptr_t)(order[k]+1);
  for(int n=0;n<count;++n){int rows[]={row};place_stable_label(dc,&group[n],key,cx,rows,1,w,h);row+=group[n].height+4;}
 }
}
static void draw_labels(HDC dc){
 static const int offsets[4][2]={{-1,0},{1,0},{0,-1},{0,1}};
 for(int i=0;i<label_count;++i){const RenderLabel *p=&labels[i];SetTextColor(dc,RGB(8,8,10));
  for(int j=0;j<(performance_profile==PROFILE_ECO?2:4);++j)TextOutW(dc,p->x+offsets[j][0],p->y+offsets[j][1],p->text,p->length);
  SetTextColor(dc,visible_color(esp_colors[p->kind<ESP_COLOR_COUNT?p->kind:ESP_COLOR_NAME]));TextOutW(dc,p->x,p->y,p->text,p->length);
 }
}
