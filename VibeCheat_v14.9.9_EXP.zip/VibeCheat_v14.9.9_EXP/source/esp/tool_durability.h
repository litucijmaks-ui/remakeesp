/* Client durability guards. Each slot field is read on its own metadata owner;
   HotbarSlot inherits InventorySlot and is distinct from the bag array type. */
typedef struct {
 void *owner_class,*slot_class,*slots_field,*item_field,*durability_field;
 Method get_item,get_durability,set_durability;
} UnbreakSlots;
static UnbreakSlots unbreak_slots[3]; /* local hotbar, inventory, GUI hotbar */
static UnbreakSlots *unbreak_active_slots;
static void *unbreak_local_hotbar,*unbreak_hotbar_index,*unbreak_inventory_instance,*unbreak_inventory_gui;
static void *unbreak_maximum_field,*unbreak_loss_field;
static GCHandle combat_identity_root,combat_tool_root,unbreak_slot_root;
static float unbreak_loss_base;
static BOOL unbreak_loss_written;
static uint64_t unbreak_next_refresh;
static _Atomic BOOL combat_durability_hook;
static _Atomic uint64_t unbreak_loss_calls,unbreak_blocked_losses,unbreak_repairs,unbreak_zeroed_costs;
static _Atomic DWORD unbreak_slot_source,unbreak_hotbar_count,unbreak_inventory_count,unbreak_gui_count;
static _Atomic(const char *) unbreak_state="Unbreaking disabled";
static void (ABI *combat_original_loss)(Obj,Obj,Obj,float,Method);
static void (ABI *unbreak_original_static_loss)(Obj,Obj,float,Method);
static BOOL unbreak_block_loss(float loss){
 atomic_fetch_add(&unbreak_loss_calls,1);
 if(!native_faulted&&ready&&running&&!stop_requested&&(combat_options&8u)&&finite_number(loss)&&loss>0.f){
  atomic_fetch_add(&unbreak_blocked_losses,1);return 1;
 }
 return 0;
}
static void ABI combat_loss_proxy(Obj inventory,Obj player,Obj item,float loss,Method info){
 if(!unbreak_block_loss(loss))combat_original_loss(inventory,player,item,loss,info);
}
static void ABI unbreak_static_loss_proxy(Obj player,Obj item,float loss,Method info){
 if(!unbreak_block_loss(loss))unbreak_original_static_loss(player,item,loss,info);
}
static void unbreak_clear_slot(void){
 if(unbreak_slot_root)gchandle_free(unbreak_slot_root);
 unbreak_slot_root=0;unbreak_active_slots=0;unbreak_slot_source=0;
}
static void unbreak_release(void){
 if(combat_tool_root&&unbreak_loss_written&&unbreak_loss_field){
  Obj item=gchandle_get_target(combat_tool_root);float current=-1.f;
  if(alive(item)){field_get_value(item,unbreak_loss_field,&current);if(current==0.f)field_set_value(item,unbreak_loss_field,&unbreak_loss_base);}
 }
 unbreak_loss_written=0;unbreak_loss_base=0;
 unbreak_clear_slot();
 if(combat_identity_root)gchandle_free(combat_identity_root);
 if(combat_tool_root)gchandle_free(combat_tool_root);
 combat_identity_root=combat_tool_root=0;unbreak_next_refresh=0;
 unbreak_hotbar_count=unbreak_inventory_count=unbreak_gui_count=0;
 unbreak_state=(combat_options&8u)?"Unbreaking: waiting for a local tool":"Unbreaking disabled";
}
static void unbreak_resolve_slots(UnbreakSlots *route,void *owner,void *item,void *single,void *nothing){
 *route=(UnbreakSlots){0};if(!owner||!class_get_element_class)return;
 void *field=class_get_field_from_name(owner,"slots");
 if(!field||(field_get_flags(field)&0x10u))return;
 void *slot=class_get_element_class(class_from_type(field_get_type(field)));if(!slot)return;
 route->owner_class=owner;route->slot_class=slot;route->slots_field=field;
 route->get_item=method(slot,"GetItem",0);
 if(!compatible_method(route->get_item,item,0,0,0))route->get_item=0;
 if(!route->get_item)route->item_field=compatible_field(slot,item,"item","currentItem",1,SIZE_MAX,"Unbreaking slot Item");
 route->get_durability=method(slot,"GetDurability",0);
 if(!compatible_method(route->get_durability,single,0,0,0))route->get_durability=0;
 if(!route->get_durability)route->durability_field=compatible_field(slot,single,"durability","˦ǝŘ̩Ɍȫ",0,SIZE_MAX,"Unbreaking slot durability");
 void *args[]={single};route->set_durability=method(slot,"SetDurability",1);
 if(!compatible_method(route->set_durability,nothing,args,1,0))route->set_durability=0;
}
static BOOL unbreak_route_ready(const UnbreakSlots *route){
 return route->slots_field&&(route->get_item||route->item_field)&&(route->get_durability||route->durability_field)&&route->set_durability;
}
static void unbreak_resolve(void *item,void *single,void *nothing){
 void *inventory=klass("","InventoryManager"),*hotbar=klass("OxideOld.Player","HotbarManager"),*gui=klass("","InGameGUI"),*integer=klass("System","Int32");
 if(!inventory)inventory=klass("OxideOld.Game","InventoryManager");
 if(!hotbar)hotbar=klass("","HotbarManager");
 if(!gui)gui=klass("OxideOld.Game","InGameGUI");
 unbreak_maximum_field=compatible_field(item,single,"maxDurability","maxDurability",0,SIZE_MAX,"Tool maximum durability");
 unbreak_loss_field=compatible_field(item,single,"durabilityLossPerUse","durabilityLossPerUse",0,SIZE_MAX,"Tool loss per use");
 unbreak_local_hotbar=compatible_field(player_class,hotbar,"ϙ΅ǣƹͶʹ","ǭ˨̍ɭӒƈ",1,SIZE_MAX,"Unbreaking local hotbar");
 unbreak_hotbar_index=compatible_field(hotbar,integer,"selectedIndex","selectedIndex",0,SIZE_MAX,"Unbreaking selected slot");
 unbreak_inventory_gui=compatible_field(inventory,gui,"inGameGUI","inGameGUI",0,SIZE_MAX,"Unbreaking inventory GUI");
 unbreak_inventory_instance=inventory?class_get_field_from_name(inventory,"Instance"):0;
 if(unbreak_inventory_instance&&(!(field_get_flags(unbreak_inventory_instance)&0x10u)||class_from_type(field_get_type(unbreak_inventory_instance))!=inventory))unbreak_inventory_instance=0;
 unbreak_resolve_slots(&unbreak_slots[0],hotbar,item,single,nothing);
 unbreak_resolve_slots(&unbreak_slots[1],inventory,item,single,nothing);
 unbreak_resolve_slots(&unbreak_slots[2],gui,item,single,nothing);
 Method loss=method(inventory,"DecreaseDurabilityForPlayer",3);void *loss_args[]={klass("Mirror","NetworkIdentity"),item,single};
 BOOL is_static=loss&&(method_get_flags(loss,0)&0x10u);
 if(!combat_durability_hook&&compatible_method(loss,nothing,loss_args,3,is_static)){
  const unsigned char *base=GetModuleHandleA("GameAssembly.dll");
  if(base){uint32_t pe=*(const uint32_t*)(base+60);
   if(pe<4096&&*(const uint32_t*)(base+pe)==0x4550){uint32_t size=*(const uint32_t*)(base+pe+80);void *entry=*(void *const*)loss;
    if((uintptr_t)entry>(uintptr_t)base&&(uintptr_t)entry<(uintptr_t)base+size){
     DWORD error=is_static?VibeCreateNativeHook(entry,unbreak_static_loss_proxy,(void**)&unbreak_original_static_loss):VibeCreateNativeHook(entry,combat_loss_proxy,(void**)&combat_original_loss);
     combat_durability_hook=!error;if(error)log_number("Unbreaking hook status=",error);
     log_number("Unbreaking loss method static=",is_static);
    }
   }
  }
 }
 log_number("Unbreaking loss hook ready=",combat_durability_hook);
 log_number("Unbreaking local hotbar binding=",unbreak_local_hotbar&&unbreak_route_ready(&unbreak_slots[0]));
 log_number("Unbreaking inventory binding=",unbreak_inventory_instance&&unbreak_route_ready(&unbreak_slots[1]));
 log_number("Unbreaking GUI hotbar binding=",unbreak_inventory_gui&&unbreak_route_ready(&unbreak_slots[2]));
 log_number("Unbreaking zero loss field binding=",unbreak_loss_field!=0);
}
static Obj unbreak_slot_definition(UnbreakSlots *route,Obj slot){
 if(!slot)return 0;
 if(route->get_item)return invoke(route->get_item,slot,0);
 Obj item=0;if(route->item_field)field_get_value(slot,route->item_field,&item);return item;
}
static BOOL unbreak_same_name(Obj a,Obj b){
 if(!a||!b||!item_name_field)return 0;
 Obj first=0,second=0;field_get_value(a,item_name_field,&first);field_get_value(b,item_name_field,&second);
 if(!first||!second)return 0;
 int n=string_length(first);if(n<=0||n>128||string_length(second)!=n)return 0;
 const WCHAR *x=string_chars(first),*y=string_chars(second);
 return x&&y&&!__builtin_memcmp(x,y,(size_t)n*sizeof(WCHAR));
}
static BOOL unbreak_matches(Obj a,Obj b){
 if(a==b)return a!=0;
 if(!unbreak_same_name(a,b))return 0;
 if(item_id_field){int32_t x=-1,y=-2;field_get_value(a,item_id_field,&x);field_get_value(b,item_id_field,&y);if(x<0||x!=y)return 0;}
 return 1;
}
static BOOL unbreak_scan_slots(UnbreakSlots *route,Obj owner,Obj item,int32_t selected,unsigned source,_Atomic DWORD *seen){
 if(!owner||!object_get_class||object_get_class(owner)!=route->owner_class||!unbreak_route_ready(route))return 0;
 Obj array=0;field_get_value(owner,route->slots_field,&array);if(!array)return 0;
 GCHandle array_root=gchandle_new(array,0);if(!array_root)return 0;
 array=gchandle_get_target(array_root);if(!array){gchandle_free(array_root);return 0;}
 uint32_t count=array_length(array),header=array_object_header_size();*seen=count;
 if(count>128||header<24||header>128){gchandle_free(array_root);return 0;}
 GCHandle match=0;unsigned matches=0;
 if(selected>=0&&(uint32_t)selected<count){
  Obj slot=((Obj*)((unsigned char*)array+header))[selected];
  GCHandle current=slot?gchandle_new(slot,0):0;
  if(current){
   if(unbreak_matches(unbreak_slot_definition(route,gchandle_get_target(current)),item)){match=current;matches=1;}
   else gchandle_free(current);
  }
 }
 if(!match&&!native_faulted)for(uint32_t i=0;i<count;++i){
  array=gchandle_get_target(array_root);if(!array||native_faulted)break;
  Obj slot=((Obj*)((unsigned char*)array+header))[i];if(!slot)continue;
  GCHandle current=gchandle_new(slot,0);if(!current)continue;
  if(unbreak_matches(unbreak_slot_definition(route,gchandle_get_target(current)),item)){++matches;if(!match){match=current;current=0;}}
  if(current)gchandle_free(current);
 }
 gchandle_free(array_root);
 if(native_faulted||matches!=1){if(match)gchandle_free(match);return 0;}
 unbreak_slot_root=match;unbreak_active_slots=route;unbreak_slot_source=source;return 1;
}
static BOOL unbreak_find_slot(Obj local,Obj item){
 unbreak_clear_slot();unbreak_hotbar_count=unbreak_inventory_count=unbreak_gui_count=0;
 Obj hotbar=0;if(unbreak_local_hotbar)field_get_value(local,unbreak_local_hotbar,&hotbar);
 int32_t selected=-1;
 if(hotbar&&object_get_class&&object_get_class(hotbar)==unbreak_slots[0].owner_class&&unbreak_hotbar_index)field_get_value(hotbar,unbreak_hotbar_index,&selected);
 if(unbreak_scan_slots(&unbreak_slots[0],hotbar,item,selected,1,&unbreak_hotbar_count)||native_faulted)return unbreak_slot_root!=0;
 Obj inventory=0;
 if(field_static_get_value&&unbreak_inventory_instance)field_static_get_value(unbreak_inventory_instance,&inventory);
 if(!inventory||!object_get_class||object_get_class(inventory)!=unbreak_slots[1].owner_class)return 0;
 if(unbreak_scan_slots(&unbreak_slots[1],inventory,item,-1,2,&unbreak_inventory_count)||native_faulted)return unbreak_slot_root!=0;
 Obj gui=0;if(unbreak_inventory_gui)field_get_value(inventory,unbreak_inventory_gui,&gui);
 return unbreak_scan_slots(&unbreak_slots[2],gui,item,selected,3,&unbreak_gui_count);
}
static void unbreak_zero_local_loss(Obj item){
 if(!unbreak_loss_field||!field_set_value)return;
 float current=-1.f;field_get_value(item,unbreak_loss_field,&current);
 if(!finite_number(current)||current<0.f||current>100000.f)return;
 if(current!=0.f){unbreak_loss_base=current;field_set_value(item,unbreak_loss_field,&(float){0.f});unbreak_loss_written=1;atomic_fetch_add(&unbreak_zeroed_costs,1);}
}
static void unbreak_tick(Obj local,Obj item,DWORD flags){
 if(!(flags&8u)){unbreak_release();return;}
 unsigned char tree=0,ore=0;
 if(alive(item)){if(item_tree_field)field_get_value(item,item_tree_field,&tree);if(item_ore_field)field_get_value(item,item_ore_field,&ore);}
 if(!tree&&!ore){unbreak_release();unbreak_state="Unbreaking: equip an axe or pickaxe";return;}
 if(!combat_tool_root||gchandle_get_target(combat_tool_root)!=item||!combat_identity_root||gchandle_get_target(combat_identity_root)!=local){
  unbreak_release();combat_identity_root=gchandle_new(local,0);combat_tool_root=gchandle_new(item,0);
 }
 if(!combat_identity_root||!combat_tool_root){unbreak_state="Unbreaking: object rooting failed";return;}
 uint64_t now=GetTickCount64();if(now<unbreak_next_refresh)return;
 unbreak_next_refresh=now+((farm_options&1u)?100u:250u);
 const char *previous=invoke_context;invoke_context="Unbreaking: local tool maintenance";
 unbreak_zero_local_loss(item);
 if(native_faulted){invoke_context=previous;return;}
 if(!unbreak_maximum_field||!unbreak_find_slot(local,item)){
  unbreak_state="Unbreaking: matching slot unavailable; see binding diagnostics";invoke_context=previous;return;
 }
 Obj slot=gchandle_get_target(unbreak_slot_root);item=gchandle_get_target(combat_tool_root);
 UnbreakSlots *route=unbreak_active_slots;
 float maximum=0,current=-1.f;field_get_value(item,unbreak_maximum_field,&maximum);
 if(route->get_durability){Obj value=invoke(route->get_durability,slot,0);void *unboxed=value?object_unbox(value):0;if(unboxed)__builtin_memcpy(&current,unboxed,sizeof(current));}
 else field_get_value(slot,route->durability_field,&current);
 if(native_faulted||!finite_number(maximum)||maximum<=0.f||maximum>100000.f||!finite_number(current)||current<0.f){
  unbreak_state="Unbreaking: invalid durability value";invoke_context=previous;return;
 }
 float desired=maximum>1.f&&current<=1.f?1.f:maximum;
 if(current+0.0001f<desired){
  void *args[]={&desired};Obj ignored=0;
  if(!invoke_checked(route->set_durability,slot,args,&ignored)){unbreak_state="Unbreaking: slot refresh call failed";invoke_context=previous;return;}
  atomic_fetch_add(&unbreak_repairs,1);
 }
 unbreak_state="Unbreaking: local tool maintained; server durability unverified";
 invoke_context=previous;
}
static void unbreak_player_tick(Obj local,BOOL active){
 if(!active||!(combat_options&8u)||!field_set_value){unbreak_release();return;}
 Obj weapon=0,item=0;
 if(weapon_field)field_get_value(local,weapon_field,&weapon);
 if(alive(weapon)&&item_field)field_get_value(weapon,item_field,&item);
 unbreak_tick(local,item,combat_options);
}
