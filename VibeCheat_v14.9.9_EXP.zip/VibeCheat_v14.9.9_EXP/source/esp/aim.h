/* Targets are actual, freshly projected Transform joints. The retained player
   pointer is a comparison key only; it is never dereferenced across samples. */
typedef struct {Obj player;Joint joint;float score;BOOL locked;int joint_index;} AimSelection;
static Obj aim_target_key;
static uint64_t aim_previous_us;
static BOOL aim_logged;
static BOOL visibility_check_point(Obj,const Vec3 *,const Vec3 *);
static void aim_reset(void){aim_target_key=0;aim_previous_us=0;}
static uint32_t aim_joint_mask(DWORD point){
 if(point==AIM_POINT_HEAD)return 1u<<J_HEAD;
 if(point==AIM_POINT_BODY)return (1u<<J_CHEST)|(1u<<J_SPINE)|(1u<<J_HIPS);
 return (1u<<J_LCALF)|(1u<<J_RCALF)|(1u<<J_LFOOT)|(1u<<J_RFOOT);
}
static void aim_consider(AimSelection *best,Obj player,const Box *pose,DWORD point,float cx,float cy,float radius,const Vec3 *origin){
 if(radius<=0||!pose->joint_mask)return;
 uint32_t mask=pose->joint_mask&aim_joint_mask(point);
 /* Prefer chest for Body, then spine and pelvis. Never invent a missing bone. */
 int joint=-1;float score=radius*radius;
 for(int j=0;j<JOINT_COUNT;++j){if(!(mask&(1u<<j)))continue;const Joint *p=&pose->joints[j];
  if(!finite_number(p->x)||!finite_number(p->y)||!finite_number(p->world.x)||!finite_number(p->world.y)||!finite_number(p->world.z))continue;
  float dx=p->x-cx,dy=p->y-cy,s=dx*dx+dy*dy;if(s>score)continue;
  if((aim_options&4)&&!visibility_check_point(player,origin,&p->world))continue;
  score=s;joint=j;
 }
 if(joint<0)return;
 BOOL locked=player==aim_target_key;
 /* A small score bias keeps the lock stable without sticking to a distant
    edge target when a much closer crosshair target becomes available. */
 float adjusted=score*(locked?0.85f:1.f);
 if(best->player&&adjusted>=best->score)return;
 best->player=player;best->joint=pose->joints[joint];best->score=adjusted;best->locked=locked;best->joint_index=joint;
}
/* Freestanding atan2: range reduction leaves |t| <= tan(pi/8), then an odd
   Taylor polynomial through t^17. No CRT dependency or managed math boxing. */
static float aim_atan2(float y,float x){
 float ax=__builtin_fabsf(x),ay=__builtin_fabsf(y);if(ax+ay<1e-12f)return 0;
 BOOL steep=ay>ax;float t=steep?ax/ay:ay/ax,offset=0;
 if(t>0.41421356237f){t=(t-1.f)/(t+1.f);offset=0.785398163397f;}
 float s=t*t;
 float a=t*(1.f+s*(-1.f/3.f+s*(1.f/5.f+s*(-1.f/7.f+s*(1.f/9.f+s*(-1.f/11.f+s*(1.f/13.f+s*(-1.f/15.f+s/17.f))))))));
 a+=offset;if(steep)a=1.570796326795f-a;if(x<0)a=3.14159265359f-a;return y<0?-a:a;
}
static float aim_wrap(float degrees){if(degrees>180)degrees-=360;if(degrees<-180)degrees+=360;return degrees;}
static float aim_alpha(DWORD sharpness,float dt){
 if(sharpness>=100)return 1;
 if(dt<0.001f)dt=0.001f;
 if(dt>0.05f)dt=0.05f;
 float x=(2.f+(float)(sharpness-1u)*0.58f)*dt;int squares=0;
 while(x>0.25f){x*=0.5f;++squares;}
 float e=1.f+x*(-1.f+x*(0.5f+x*(-1.f/6.f+x*(1.f/24.f+x*(-1.f/120.f+x/720.f)))));
 while(squares--)e*=e;
 return 1.f-e;
}
static BOOL aim_move_to(Obj local,Obj camera,const Vec3 *point,DWORD sharpness,float dt){
 if(!aim_available)return 0;
 Obj look=0,pivot=0;field_get_value(local,look_field,&look);if(!alive(look)){aim_reset();return 0;}
 field_get_value(look,look_pivot_field,&pivot);if(!alive(pivot)){aim_reset();return 0;}
 float horizontal=0,vertical=0;field_get_value(look,look_horizontal_field,&horizontal);field_get_value(look,look_vertical_field,&vertical);
 if(!finite_number(horizontal)||!finite_number(vertical)||__builtin_fabsf(horizontal)<0.0001f||__builtin_fabsf(vertical)<0.0001f){aim_reset();return 0;}
 Obj t=invoke(component_transform,camera,0);Vec3 origin,forward;
 if(!alive(t)||!position_value(t,&origin)||!vector_value(transform_forward,t,0,&forward)){aim_reset();return 0;}
 Vec3 d={point->x-origin.x,point->y-origin.y,point->z-origin.z};
 if(!finite_number(d.x)||!finite_number(d.y)||!finite_number(d.z)||!finite_number(forward.x)||!finite_number(forward.y)||!finite_number(forward.z)){aim_reset();return 0;}
 float flat=__builtin_sqrtf(d.x*d.x+d.z*d.z),view_flat=__builtin_sqrtf(forward.x*forward.x+forward.z*forward.z);
 if(flat*flat+d.y*d.y<0.0001f||view_flat*view_flat+forward.y*forward.y<0.01f){aim_reset();return 0;}
 const float degrees=57.2957795131f;
 float yaw=aim_wrap((aim_atan2(d.x,d.z)-aim_atan2(forward.x,forward.z))*degrees);
 /* CameraLook's pitch becomes the pivot's positive-X Euler angle, which
    points down. World +Y target pitch therefore requires a negative delta. */
 float pitch=(aim_atan2(forward.y,view_flat)-aim_atan2(d.y,flat))*degrees;
 float alpha=aim_alpha(sharpness,dt);yaw*=alpha;pitch*=alpha;
 float input_x=yaw/horizontal,input_y=pitch/vertical;void *args[2]={&input_x,&input_y};Obj ignored;
 if(!invoke_checked(look_move,look,args,&ignored)){aim_available=0;aim_reset();logline("Aim disabled after CameraLook exception");return 0;}
 float current_pitch=0;field_get_value(look,look_pitch_field,&current_pitch);
 if(!finite_number(current_pitch)||__builtin_fabsf(current_pitch)>180){aim_available=0;aim_reset();logline("Aim disabled: invalid CameraLook pitch");return 0;}
 /* Apply the clamped pitch immediately. The game's next Update reads the
    same CameraLook pitch, so it does not restore the old aim orientation. */
 Vec3 euler={current_pitch,0,0};void *pivot_args[1]={&euler};
 if(!invoke_checked(transform_local_euler_set,pivot,pivot_args,&ignored)){aim_available=0;aim_reset();logline("Aim disabled after camera-pivot exception");return 0;}
 if(!aim_logged){aim_logged=1;logline("First skeleton aim update applied through CameraLook");}
 return 1;
}
static BOOL aim_apply(Obj local,Obj camera,const AimSelection *target){
 if(!target->player||!aim_available||!aim_held||!focused||menu_open||cursor_wanted||stop_requested){aim_reset();return 0;}
 Obj locked=invoke(cursor_get_lock,0,0);if(!locked||*(int32_t*)object_unbox(locked)!=1){aim_reset();return 0;}
 uint64_t now=sample_started_us?sample_started_us:clock_us();
 float dt=aim_previous_us&&now>aim_previous_us?(float)(now-aim_previous_us)*0.000001f:(float)sample_interval_us*0.000001f;
 if(!aim_move_to(local,camera,&target->joint.world,aim_sharpness,dt))return 0;
 aim_target_key=target->player;aim_previous_us=now;return 1;
}
