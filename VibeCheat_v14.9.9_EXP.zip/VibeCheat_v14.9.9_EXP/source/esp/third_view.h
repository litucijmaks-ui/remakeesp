/* Move the world camera at OnPreCull, after game look/bob updates. The
   first-person weapon camera is disabled separately; FOV is never written. */
typedef struct {GCHandle root;Method get,set;int32_t base,applied;BOOL byte;} ThirdProperty;
static ThirdProperty third_properties[512];
static unsigned third_property_count;
static GCHandle third_camera_root,third_transform_root,third_body_root,third_owner_root;
static Vec3 third_base_local,third_applied_local;
static BOOL third_pose_written;
static BOOL third_body_ready;
static BOOL third_body_visible=1,third_update_hooked;
static void (ABI *third_update_original)(Obj,Method);
static uint64_t third_next_model;
static _Atomic uint64_t third_render_frames;
static _Atomic uint64_t third_pose_restores,third_self_hits;
static void third_unapply_pose(void){
 Obj t=third_transform_root?gchandle_get_target(third_transform_root):0;Vec3 current;
 if(third_pose_written&&alive(t)&&vector_value(global_methods[GM_localPosition],t,0,&current)&&global_vec_equal(current,third_applied_local)){
  void *args[]={&third_base_local};invoke(global_methods[GM_localPositionSetter],t,args);++third_pose_restores;
 }
 third_pose_written=0;
}
static void ABI third_player_update_proxy(Obj player,Method info){
 if(!native_faulted&&third_owner_root&&player==gchandle_get_target(third_owner_root)&&GetCurrentThreadId()==game_thread_id)third_unapply_pose();
 third_update_original(player,info);
}
static BOOL third_install_update(void){
 if(third_update_hooked)return 1;Method m=global_methods[GM_playerUpdate];if(!m)return 0;
 DWORD error=VibeCreateNativeHook(*(void *const*)m,third_player_update_proxy,(void**)&third_update_original);
 if(error){log_number("Third-person update hook status=",error);return 0;}third_update_hooked=1;return 1;
}
static BOOL third_shot_origin(Obj camera,Vec3 *out){
 if(!third_pose_written||!third_camera_root||camera!=gchandle_get_target(third_camera_root))return 0;
 Obj t=gchandle_get_target(third_transform_root),parent=alive(t)?invoke(global_methods[GM_globalParent],t,0):0;
 if(alive(parent)){void *args[]={&third_base_local};return vector_value(global_methods[GM_parentPoint],parent,args,out);}*out=third_base_local;return 1;
}
static BOOL third_collision_distance(Obj local,const Vec3 *origin,const Vec3 *back,float maximum,float *distance){
 Vec3 start=*origin;float advanced=0;*distance=maximum;
 for(unsigned n=0;n<8;n++){
  PhysicsHit hit;BOOL found=0;if(!trace_ray(&start,back,maximum+.25f-advanced,-5,1,&hit,&found))return 0;
  if(!found)return 1;if(!finite_number(hit.distance)||hit.distance<0)return 0;
  Obj collider=hit_collider?invoke(hit_collider,(Obj)&hit,0):0;unsigned char inactive=1;void *args[]={player_type,&inactive};
  Obj owner=alive(collider)&&component_parent&&player_type?invoke(component_parent,collider,args):0;
  if(!alive(local)||owner!=local){*distance=advanced+hit.distance-.25f;if(*distance<.1f)*distance=.1f;if(*distance>maximum)*distance=maximum;return 1;}
  ++third_self_hits;float step=hit.distance+.05f;advanced+=step;if(advanced>=maximum+.25f)return 1;
  start=(Vec3){origin->x+back->x*advanced,origin->y+back->y*advanced,origin->z+back->z*advanced};
 }
 return 0;
}
static BOOL third_get_integer(Method m,Obj o,BOOL byte,int32_t *out){
 Obj boxed=0;if(!m||!invoke_checked(m,o,0,&boxed)||!boxed)return 0;void *p=object_unbox(boxed);if(!p)return 0;*out=byte?*(unsigned char*)p:*(int32_t*)p;return 1;
}
static BOOL third_set_integer(Method m,Obj o,BOOL byte,int32_t value){
 unsigned char b=value!=0;void *args[]={byte?(void*)&b:(void*)&value};Obj ignored=0;return m&&invoke_checked(m,o,args,&ignored);
}
static BOOL third_property(Obj o,Method get,Method set,BOOL byte,int32_t wanted){
 int32_t current;if(!alive(o)||!third_get_integer(get,o,byte,&current))return 0;unsigned i=0;
 for(;i<third_property_count;i++)if(third_properties[i].get==get&&gchandle_get_target(third_properties[i].root)==o)break;
 ThirdProperty *s=0;
 if(i==third_property_count){if(current==wanted)return 1;if(i>=512)return 0;s=&third_properties[i];GCHandle root=gchandle_new(o,0);if(!root)return 0;*s=(ThirdProperty){.root=root,.get=get,.set=set,.base=current,.applied=current,.byte=byte};third_property_count++;}
 else{s=&third_properties[i];if(current!=s->applied)s->base=current;}
 if(current!=wanted&&!third_set_integer(set,o,byte,wanted))return 0;s->applied=wanted;return 1;
}
static void global_camera_release(void){
 third_unapply_pose();
 for(unsigned i=third_property_count;i;){ThirdProperty *s=&third_properties[--i];Obj o=gchandle_get_target(s->root);int32_t v;
  if(alive(o)&&third_get_integer(s->get,o,s->byte,&v)&&v==s->applied)third_set_integer(s->set,o,s->byte,s->base);
  gchandle_free(s->root);*s=(ThirdProperty){0};
 }
 third_property_count=0;third_pose_written=0;third_body_visible=1;
 GCHandle *roots[]={&third_camera_root,&third_transform_root,&third_body_root,&third_owner_root};for(unsigned i=0;i<4;i++){if(*roots[i])gchandle_free(*roots[i]);*roots[i]=0;}third_next_model=0;third_body_ready=0;
}
static void third_body(Obj local,Obj camera,Obj weapon_camera,uint64_t now){
 if(now<third_next_model)return;third_next_model=now+200;third_body_ready=0;
 if(alive(weapon_camera)&&weapon_camera!=camera)third_property(weapon_camera,global_methods[GM_cameraEnabledGet],global_methods[GM_cameraEnabledSet],1,0);
 Obj body=third_body_root?gchandle_get_target(third_body_root):0;
 if(!alive(body)){
  if(third_body_root)gchandle_free(third_body_root);third_body_root=0;
  unsigned char yes=1;void *args[]={global_types[G_body],&yes};body=global_methods[GM_componentChildren]?invoke(global_methods[GM_componentChildren],local,args):0;
  if(alive(body))third_body_root=gchandle_new(body,0);
 }
 if(!alive(body)||!global_fields[GF_bodyRenderers]||!global_fields[GF_bodyVisibleMask]){global_state="Third person: body renderer unavailable";return;}
 Obj gameObject=invoke(global_methods[GM_componentObject],body,0);
 third_property(gameObject,global_methods[GM_activeGet],global_methods[GM_activeSet],1,1);
 int32_t mask=0;field_get_value(body,global_fields[GF_bodyVisibleMask],&mask);unsigned bits=(unsigned)mask;int32_t layer=0;BOOL valid_mask=!bits||!(bits&(bits-1));
 if(valid_mask){if(bits)while((bits>>layer)!=1u)layer++;int32_t current;
  if(third_get_integer(global_methods[GM_cameraMaskGet],camera,0,&current))third_property(camera,global_methods[GM_cameraMaskGet],global_methods[GM_cameraMaskSet],0,(int32_t)((unsigned)current|(1u<<layer)));
 }
 Obj array=0;field_get_value(body,global_fields[GF_bodyRenderers],&array);GCHandle root=array?gchandle_new(array,0):0;if(!root)return;
 array=gchandle_get_target(root);uint32_t count=array_length(array),header=array_object_header_size();
 if(count<=128&&header>=24&&header<=128)for(unsigned i=0;i<count&&!native_faulted;i++){
  array=gchandle_get_target(root);Obj renderer=((Obj*)((unsigned char*)array+header))[i];if(!alive(renderer))continue;
  third_body_ready=1;
  third_property(renderer,global_methods[GM_rendererEnabledGet],global_methods[GM_rendererEnabledSet],1,third_body_visible);
  Obj object=invoke(global_methods[GM_componentObject],renderer,0);if(valid_mask)third_property(object,global_methods[GM_layerGet],global_methods[GM_layerSet],0,layer);
 }
 gchandle_free(root);
}
static void global_third(Obj local,BOOL active,uint64_t now){
 if(!(custom_flags&VIBE_CUSTOM_THIRD)||!active){global_camera_release();return;}
 if(!third_install_update()){global_state="Third person: movement callback unavailable";return;}
 if(third_owner_root&&gchandle_get_target(third_owner_root)!=local)global_camera_release();
 if(!third_owner_root){third_owner_root=gchandle_new(local,0);if(!third_owner_root)return;}
 if(!global_fields[GF_playerMovement]||!global_fields[GF_viewController]||!global_fields[GF_worldCamera]||!global_methods[GM_worldPositionSetter]||!global_methods[GM_parentPoint]){global_state="Third person: world camera binding unavailable";return;}
 Obj movement=0,controller=0,camera=0,weapon=0;field_get_value(local,global_fields[GF_playerMovement],&movement);if(alive(movement))field_get_value(movement,global_fields[GF_viewController],&controller);
 if(alive(controller)){field_get_value(controller,global_fields[GF_worldCamera],&camera);if(global_fields[GF_weaponCamera])field_get_value(controller,global_fields[GF_weaponCamera],&weapon);}
 if(!alive(camera)){global_camera_release();global_state="Third person: waiting for world camera";return;}
 if(third_camera_root&&gchandle_get_target(third_camera_root)!=camera){global_camera_release();third_owner_root=gchandle_new(local,0);if(!third_owner_root)return;}
 if(!third_camera_root){Obj t=invoke(component_transform,camera,0);Vec3 v;if(!alive(t)||!vector_value(global_methods[GM_localPosition],t,0,&v))return;
  third_camera_root=gchandle_new(camera,0);third_transform_root=gchandle_new(t,0);if(!third_camera_root||!third_transform_root){global_camera_release();return;}third_base_local=third_applied_local=v;
 }
 third_body(local,camera,weapon,now);
}
static void third_camera_frame(Obj camera){
 if(!(custom_flags&VIBE_CUSTOM_THIRD)||!third_camera_root||camera!=gchandle_get_target(third_camera_root)||menu_open||!focused)return;
 Obj t=gchandle_get_target(third_transform_root);Vec3 current,origin,forward;
 if(!alive(t)||!vector_value(global_methods[GM_localPosition],t,0,&current))return;
 if(!third_pose_written||!global_vec_equal(current,third_applied_local))third_base_local=current;
 Obj parent=invoke(global_methods[GM_globalParent],t,0);void *base_args[]={&third_base_local};
 if(alive(parent)){if(!vector_value(global_methods[GM_parentPoint],parent,base_args,&origin))return;}else origin=third_base_local;
 if(!vector_value(transform_forward,t,0,&forward))return;
 float distance=(float)custom_third_distance_cm/100.f;Vec3 back={-forward.x,-forward.y,-forward.z};Obj local=gchandle_get_target(third_owner_root);
 if(!third_collision_distance(local,&origin,&back,distance,&distance)){global_state="Third person: collision query unavailable";return;}
 BOOL show=distance>=.65f;if(show!=third_body_visible){third_body_visible=show;third_next_model=0;third_body(local,camera,0,GetTickCount64());}
 Vec3 wanted={origin.x+back.x*distance,origin.y+back.y*distance,origin.z+back.z*distance};void *args[]={&wanted};Obj ignored=0;
 if(invoke_checked(global_methods[GM_worldPositionSetter],t,args,&ignored)&&vector_value(global_methods[GM_localPosition],t,0,&third_applied_local)){third_pose_written=1;++third_render_frames;global_state=third_body_ready?"Third person: world camera behind player":"Third person: world camera ready; waiting for body model";}
}
