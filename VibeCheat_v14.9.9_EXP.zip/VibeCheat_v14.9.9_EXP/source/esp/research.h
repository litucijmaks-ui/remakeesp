/* Reference-compatible client costs and bounded blueprint learning requests. */
#define FARM_RESEARCH_FLAG 64u
#define RESEARCH_COST_LIMIT 2048u
static Obj research_type,research_database_type;
static void *research_note_class,*research_list_class,*research_note_field,*research_level_cost_field,*research_scrap_cost_field;
static void *research_notes_field,*research_items_field,*research_size_field;
static Method research_refresh,research_find_databases;
static void *research_mgr_class,*research_mgr_instance,*research_mgr_level;
static GCHandle research_mgr_root;
static int32_t research_mgr_base,research_mgr_applied;
static _Atomic BOOL research_available,research_database_available;
static _Atomic(const char *) research_state="Free study disabled";
static GCHandle research_array_root,research_database_root;
static uint64_t research_scan_ms,research_database_scan_ms,research_work_ms;
static uint64_t research_selected_ms;
static uint32_t research_database_cursor,research_note_cursor;
static Obj research_last_ui,research_last_note;
typedef struct {GCHandle root;Obj key;int32_t level,scrap;} ResearchCost;
static ResearchCost research_costs[RESEARCH_COST_LIMIT];
static uint16_t research_index[4096];
static _Atomic uint32_t research_cost_count;
static BOOL research_patch_note(Obj);
#include "research_learn.h"
static void research_state_set(const char *value){if(research_state!=value){research_state=value;logline(value);}}
static void resolve_research(void){
 void *inspector=klass("OxideOld.Game","WorkbenchInspector"),*integer=klass("System","Int32");
 void *mgr=klass("OxideOld.Game","WorkbenchManager");if(!mgr)mgr=klass("","WorkbenchManager");
 research_mgr_class=mgr;research_mgr_instance=mgr?class_get_field_from_name(mgr,"Instance"):0;
 if(research_mgr_instance&&!(field_get_flags(research_mgr_instance)&0x10u))research_mgr_instance=0;
 research_mgr_level=mgr?compatible_field(mgr,integer,PC_FIELD_workbenchLevel,"PlayerLevel",0,SIZE_MAX,"WorkbenchManager playerLevel"):0;
 if(!research_mgr_level&&mgr)research_mgr_level=compatible_field(mgr,integer,"PlayerLVL","playerLVL",0,SIZE_MAX,"WorkbenchManager playerLevel");

 void *database=klass("OxideOld.Game","WorkbenchDatabase"),*resources=klass("UnityEngine","Resources");
 research_note_class=klass("","Note");
 if(!research_note_class)research_note_class=klass("OxideOld.Game","Note");
 if(!research_note_class)research_note_class=klass("OxideOld.Player","Note");
 research_note_field=compatible_field(inspector,research_note_class,PC_FIELD_selectedNote,"currentNote",0,SIZE_MAX,"Workbench selected note");
 if(!research_note_field)research_note_field=compatible_field(inspector,research_note_class,"selectedNote","SelectedNote",0,SIZE_MAX,"Workbench selected note");
 if(!research_note_field)research_note_field=compatible_field(inspector,research_note_class,"note","Note",0,SIZE_MAX,"Workbench selected note");
 research_level_cost_field=compatible_field(research_note_class,integer,"PlayerLVL","playerLVL",0,SIZE_MAX,"Note level requirement");
 if(!research_level_cost_field)research_level_cost_field=compatible_field(research_note_class,integer,"Level","level",0,SIZE_MAX,"Note level requirement");
 if(!research_level_cost_field)research_level_cost_field=compatible_field(research_note_class,integer,"playerLevel","PlayerLevel",0,SIZE_MAX,"Note level requirement");
 if(!research_level_cost_field)research_level_cost_field=compatible_field(research_note_class,integer,"lvl","LVL",0,SIZE_MAX,"Note level requirement");
 research_scrap_cost_field=compatible_field(research_note_class,integer,"Scrap","scrap",0,SIZE_MAX,"Note scrap requirement");
 if(!research_scrap_cost_field)research_scrap_cost_field=compatible_field(research_note_class,integer,"Cost","cost",0,SIZE_MAX,"Note scrap requirement");
 research_refresh=method(inspector,"UpdateUI",0);if(!compatible_signature(research_refresh,0,0))research_refresh=0;
 research_type=inspector?type_get_object(class_get_type(inspector)):0;
 /* DLL zeros PlayerLVL/Scrap when present; still allow learn path without cost fields. */
 research_available=object_get_class&&field_set_value&&research_type&&research_note_class&&research_refresh&&research_note_field&&research_level_cost_field&&research_scrap_cost_field;
 if(!research_level_cost_field||!research_scrap_cost_field)logline("Free study: cost fields partial; learn path may still work");
 research_database_available=0;research_list_class=0;research_notes_field=research_items_field=research_size_field=0;
 research_find_databases=method(resources,"FindObjectsOfTypeAll",1);
 if(!research_find_databases||method_get_param_count(research_find_databases)!=1||!(method_get_flags(research_find_databases,0)&0x10u)||class_from_type(method_get_param(research_find_databases,0))!=klass("System","Type")||!class_get_element_class||class_get_element_class(class_from_type(method_get_return_type(research_find_databases)))!=klass("UnityEngine","Object"))research_find_databases=0;
 research_database_type=database?type_get_object(class_get_type(database)):0;
 if(database&&class_get_element_class){
  research_notes_field=class_get_field_from_name(database,"Notes");
  if(research_notes_field&&!(field_get_flags(research_notes_field)&0x10u))research_list_class=class_from_type(field_get_type(research_notes_field));
  void *items=research_list_class?class_get_field_from_name(research_list_class,"_items"):0;
  if(items&&!(field_get_flags(items)&0x10u)&&class_get_element_class(class_from_type(field_get_type(items)))==research_note_class)research_items_field=items;
  if(research_list_class)research_size_field=compatible_field(research_list_class,integer,"_size","_size",0,SIZE_MAX,"Note list length");
  research_database_available=research_available&&research_database_type&&research_notes_field&&research_items_field&&research_size_field&&research_find_databases;
 }
 logline(research_available?"Free study: client Note level/scrap fields and UI refresh verified":"Free study unavailable: missing or changed client cost fields");
 if(research_available)logline(research_database_available?"Free study: all-recipe Note list element type verified":"Free study: only selected recipes available; database list could not be verified");
 resolve_research_learn(database);
}
static void research_refresh_inspectors(void){
 Obj array=research_array_root?gchandle_get_target(research_array_root):0;
 if(!array||!research_refresh)return;
 uint32_t count=array_length(array),header=array_object_header_size();if(header<24||header>128||count>256)return;
 Obj *items=(Obj*)((unsigned char*)array+header);
 for(uint32_t i=0;i<count&&i<8;++i)if(alive(items[i])){Obj ignored;invoke_checked(research_refresh,items[i],0,&ignored);}
}
static void research_release(void){
 research_learn_release();
 if(research_mgr_root){Obj mgr=gchandle_get_target(research_mgr_root);if(alive(mgr)&&research_mgr_level){int32_t value=0;field_get_value(mgr,research_mgr_level,&value);if(value==research_mgr_applied)field_set_value(mgr,research_mgr_level,&research_mgr_base);}gchandle_free(research_mgr_root);research_mgr_root=0;}
 BOOL changed=research_cost_count!=0;
 for(uint32_t i=0;i<research_cost_count;++i){
  ResearchCost *saved=&research_costs[i];Obj note=gchandle_get_target(saved->root);
  if(note&&research_level_cost_field&&research_scrap_cost_field&&object_get_class(note)==research_note_class){
   int32_t level=-1,scrap=-1;field_get_value(note,research_level_cost_field,&level);field_get_value(note,research_scrap_cost_field,&scrap);
   /* Preserve a game-driven update that has replaced our zero. */
   if(level==0)field_set_value(note,research_level_cost_field,&saved->level);
   if(scrap==0)field_set_value(note,research_scrap_cost_field,&saved->scrap);
  }
  gchandle_free(saved->root);*saved=(ResearchCost){0};
 }
 research_cost_count=0;
 zeromem(research_index,sizeof(research_index));research_selected_ms=0;
 if(changed)research_refresh_inspectors();
 if(research_array_root)gchandle_free(research_array_root);
 if(research_database_root)gchandle_free(research_database_root);
 research_array_root=research_database_root=0;research_scan_ms=research_database_scan_ms=research_work_ms=0;
 research_database_cursor=research_note_cursor=0;research_last_ui=research_last_note=0;
}
static BOOL research_patch_note(Obj note){
 if(!note||!research_level_cost_field||!research_scrap_cost_field||object_get_class(note)!=research_note_class)return 0;
 int32_t level=-1,scrap=-1;field_get_value(note,research_level_cost_field,&level);field_get_value(note,research_scrap_cost_field,&scrap);
 if(level<0||scrap<0||level>1000000000||scrap>1000000000)return 0;
 ResearchCost *saved=0;uintptr_t key=(uintptr_t)note;
 unsigned slot=(unsigned)((key>>3)^(key>>17))&4095u;
 while(research_index[slot]){ResearchCost *entry=&research_costs[research_index[slot]-1u];if(entry->key==note){saved=entry;break;}slot=(slot+1u)&4095u;}
 if(!saved){
  if(!level&&!scrap)return 0;
  if(research_cost_count==RESEARCH_COST_LIMIT){research_state_set("Free study: recipe snapshot limit reached");return 0;}
  GCHandle root=gchandle_new(note,0);if(!root)return 0;
  saved=&research_costs[research_cost_count++];*saved=(ResearchCost){root,note,level,scrap};
  research_index[slot]=(uint16_t)research_cost_count;
 }else{
  if(level)saved->level=level;
  if(scrap)saved->scrap=scrap;
 }
 int32_t zero=0;
 if(level)field_set_value(note,research_level_cost_field,&zero);
 if(scrap)field_set_value(note,research_scrap_cost_field,&zero);
 return level||scrap;
}
static void research_scan_roots(uint64_t now){
 if(!research_array_root||now-research_scan_ms>=2000){
  int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={research_type,&no},*unsorted[]={research_type,&inactive,&sort};
  Obj array=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);research_scan_ms=now;
  if(array){GCHandle root=gchandle_new(array,0);if(root){if(research_array_root)gchandle_free(research_array_root);research_array_root=root;}}
 }
 if(research_database_available&&(!research_database_root||now-research_database_scan_ms>=2000)){
  void *args[]={research_database_type};Obj array=invoke(research_find_databases,0,args);research_database_scan_ms=now;
  if(array){GCHandle root=gchandle_new(array,0);if(root){if(research_database_root)gchandle_free(research_database_root);research_database_root=root;}}
 }
}
static void research_patch_selected(void){
 if(!research_note_field||!research_level_cost_field||!research_scrap_cost_field)return;
 Obj array=research_array_root?gchandle_get_target(research_array_root):0;if(!array)return;
 uint32_t count=array_length(array),header=array_object_header_size();if(header<24||header>128||count>256)return;
 Obj *items=(Obj*)((unsigned char*)array+header);
 for(uint32_t i=0;i<count&&i<8;++i){
  Obj ui=items[i],note=0;if(!alive(ui))continue;field_get_value(ui,research_note_field,&note);if(!note)continue;
  BOOL changed=research_patch_note(note);
  if(changed||research_last_ui!=ui||research_last_note!=note){
   Obj ignored;if(invoke_checked(research_refresh,ui,0,&ignored)){
    /* UpdateUI can replace the selected Note with a fresh recipe copy. */
    Obj refreshed=0;field_get_value(ui,research_note_field,&refreshed);
    if(refreshed&&refreshed!=note&&research_patch_note(refreshed)){
     invoke_checked(research_refresh,ui,0,&ignored);
     field_get_value(ui,research_note_field,&refreshed);research_patch_note(refreshed);
    }
    research_last_ui=ui;research_last_note=refreshed;
   }
  }
 }
}
static void research_patch_database(void){
 Obj array=research_database_root?gchandle_get_target(research_database_root):0;if(!array)return;
 uint32_t count=array_length(array),header=array_object_header_size();if(!count||count>16||header<24||header>128)return;
 Obj *databases=(Obj*)((unsigned char*)array+header);unsigned visited=0,budget=performance_profile==PROFILE_ECO?32:64;
 while(visited<count&&budget){
  if(research_database_cursor>=count)research_database_cursor=0;
  Obj db=databases[research_database_cursor],list=0,notes=0;int32_t size=-1;
  if(alive(db)){field_get_value(db,research_notes_field,&list);if(list&&object_get_class(list)==research_list_class){field_get_value(list,research_items_field,&notes);field_get_value(list,research_size_field,&size);}}
  if(!notes||size<0||size>4096||(uint32_t)size>array_length(notes)||research_note_cursor>=(uint32_t)size){
   ++research_database_cursor;research_note_cursor=0;++visited;continue;
  }
  Obj *items=(Obj*)((unsigned char*)notes+header);research_patch_note(items[research_note_cursor++]);--budget;
 }
}
static void research_tick(Obj local,BOOL active){
 if(!(farm_options&FARM_RESEARCH_FLAG)||!active||!research_available){
  research_release();research_state_set(!(farm_options&FARM_RESEARCH_FLAG)?"Free study disabled; original costs restored":!research_available?"Free study unavailable: client fields changed":"Free study paused; original costs restored");return;
 }
 /* DLL: WorkbenchManager.playerLevel -> 999 while free study ON */
 if(research_mgr_instance&&research_mgr_level&&field_static_get_value){
  Obj mgr=0;field_static_get_value(research_mgr_instance,&mgr);
  if(research_mgr_root&&gchandle_get_target(research_mgr_root)!=mgr){Obj old=gchandle_get_target(research_mgr_root);if(alive(old)){int32_t value=0;field_get_value(old,research_mgr_level,&value);if(value==research_mgr_applied)field_set_value(old,research_mgr_level,&research_mgr_base);}gchandle_free(research_mgr_root);research_mgr_root=0;}
  if(alive(mgr)){int32_t cur=0;field_get_value(mgr,research_mgr_level,&cur);if(cur>=0&&cur<999){if(!research_mgr_root){research_mgr_root=gchandle_new(mgr,0);research_mgr_base=cur;}else if(cur!=research_mgr_applied)research_mgr_base=cur;if(research_mgr_root){research_mgr_applied=999;field_set_value(mgr,research_mgr_level,&research_mgr_applied);}}}
 }
 uint64_t now=GetTickCount64();
 if(now>=research_work_ms){research_work_ms=now+200;research_scan_roots(now);research_patch_database();}
 research_learn_tick(local,now);
 if(now>=research_selected_ms){research_selected_ms=now+50;research_patch_selected();}
 if(research_cost_count==RESEARCH_COST_LIMIT)research_state_set("Free study: recipe snapshot limit reached");
 else if(!research_cost_count)research_state_set("Free study ON; select a recipe at a workbench");
 else research_state_set(research_learn_available?(research_learn_confirmed?"Free study: synchronized learned recipes observed; remaining requests pending":"Free study: client costs zeroed; requests pending server synchronization"):"Selected client LVL/Scrap = 0; server costs may apply");
}
