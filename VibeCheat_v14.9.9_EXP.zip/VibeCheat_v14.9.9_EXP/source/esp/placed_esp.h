/* Typed object discovery. Roster handles retain every cached object. */
static GCHandle placed_arrays[3],placed_kept[3][32];
static unsigned placed_kept_count[3],placed_cursor[3];static uint64_t placed_next_scan[3];
static _Atomic uint64_t placed_scan_count;
static const unsigned placed_flags[3]={256u,512u,1024u},placed_kinds[3]={4u,8u,16u};
static const int placed_classes[3]={G_cupboard,G_piece,G_furnace};
static void placed_release_kind(unsigned k){for(unsigned i=0;i<placed_kept_count[k];i++)gchandle_free(placed_kept[k][i]);if(placed_arrays[k])gchandle_free(placed_arrays[k]);placed_arrays[k]=0;placed_kept_count[k]=placed_cursor[k]=0;placed_next_scan[k]=0;}
static void placed_release(void){for(unsigned k=0;k<3;k++)placed_release_kind(k);}
static BOOL placed_valid(Obj o,unsigned k){
 if(!alive(o)||!global_instance_of(o,global_classes[placed_classes[k]]))return 0;
 if(global_methods[GM_componentObject]&&global_methods[GM_activeGet]){Obj go=invoke(global_methods[GM_componentObject],o,0),v=alive(go)?invoke(global_methods[GM_activeGet],go,0):0;if(!v||!*(unsigned char*)object_unbox(v))return 0;}
 if(k==1){unsigned char destroying=1;Obj name=0;
  if(!global_fields[GF_pieceName]||!global_fields[GF_pieceDestroying])return 0;
  field_get_value(o,global_fields[GF_pieceDestroying],&destroying);if(destroying)return 0;field_get_value(o,global_fields[GF_pieceName],&name);
  return global_string_contains(name,"storage box")||global_string_contains(name,"storage_box")||global_string_contains(name,"storagebox")||global_string_contains(name,"chest");
 }
 return 1;
}
static void placed_sample(Obj camera,const Vec3 *origin,uint64_t now,BOOL discover){
 if(!(menu_options&1792u)){placed_release();return;}
 if(!alive(camera)||!origin)return;global_resolve();
 for(unsigned k=0;k<3;k++){
  if(!(menu_options&placed_flags[k])){placed_release_kind(k);continue;}
  if(discover&&(!placed_arrays[k]||now>=placed_next_scan[k])){
   Obj a=global_find(placed_classes[k],0);GCHandle root=a?gchandle_new(a,0):0;placed_next_scan[k]=now+2000;++placed_scan_count;
   if(root){if(placed_arrays[k])gchandle_free(placed_arrays[k]);placed_arrays[k]=root;}
  }
  Obj a=placed_arrays[k]?gchandle_get_target(placed_arrays[k]):0;if(!a)continue;
  unsigned count=array_length(a),h=array_object_header_size();if(count>16384||h<24||h>128)continue;
  if(discover)for(unsigned n=0;n<count&&n<128;n++){
   if(placed_cursor[k]>=count)placed_cursor[k]=0;Obj o=((Obj*)((unsigned char*)a+h))[placed_cursor[k]++];if(!placed_valid(o,k))continue;
   Vec3 p;if(!world_position(o,&p))continue;float dx=p.x-origin->x,dy=p.y-origin->y,dz=p.z-origin->z,square=dx*dx+dy*dy+dz*dz;
   if(!finite_number(square)||square>(float)range_max_m*range_max_m)continue;
   unsigned i=0;for(;i<placed_kept_count[k];i++)if(gchandle_get_target(placed_kept[k][i])==o)break;if(i==placed_kept_count[k]&&i<32){GCHandle root=gchandle_new(o,0);if(root)placed_kept[k][placed_kept_count[k]++]=root;}
  }
  unsigned kept=0;
  for(unsigned i=0;i<placed_kept_count[k];i++){
   GCHandle root=placed_kept[k][i];Obj o=gchandle_get_target(root);Vec3 p,screen;
   if(!placed_valid(o,k)||!world_position(o,&p)){gchandle_free(root);continue;}float dx=p.x-origin->x,dy=p.y-origin->y,dz=p.z-origin->z,square=dx*dx+dy*dy+dz*dz;
   if(!finite_number(square)||square>(float)range_max_m*range_max_m){gchandle_free(root);continue;}
   placed_kept[k][kept++]=root;if(world_marker_count>=128||!project_value(camera,&p,&screen))continue;
   VibeWorldMarker m;if(!world_marker_project(&screen,source_width,source_height,&m))continue;m.distance=__builtin_sqrtf(square);m.edge|=placed_kinds[k];world_markers[world_marker_count++]=m;
  }
  placed_kept_count[k]=kept;
 }
}
