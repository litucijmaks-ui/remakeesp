#pragma once
#include <stdint.h>
typedef struct {float x,y;} VibeJoint;
typedef struct {float x,y,distance;uint32_t edge;} VibeWorldMarker;
typedef struct {float x,y,w,h,hp,distance;uint16_t name[64];int32_t name_len,icon;uint32_t joint_mask;VibeJoint joints[19];} VibeRenderPlayer;
typedef struct {uint32_t width,height,count,flags,line_width,profile,colors[7];uint32_t circle,target;float radius,target_x,target_y;uint64_t serial,age_ms;VibeRenderPlayer players[256];uint32_t marker_count;VibeWorldMarker markers[128];} VibeRenderSnapshot;
