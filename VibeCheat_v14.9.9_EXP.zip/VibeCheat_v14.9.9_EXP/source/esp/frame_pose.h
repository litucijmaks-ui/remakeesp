static void project_after_aim(Obj camera,DWORD flags){
 /* Refresh from the rooted actor array and cached Transform bones at final
    camera phase. No discovery, allocations or gameplay commands here. */
 Obj array=player_array_handle?gchandle_get_target(player_array_handle):0;
 if(!array){box_count=0;return;}uint32_t count=array_length(array),header=array_object_header_size();if(count>8192||header<24||header>128){box_count=0;return;}
 Obj *players=(Obj*)((unsigned char*)array+header);int kept=0;
 for(unsigned i=0;i<frame_actor_count;++i){Box current=frame_actors[i];Box *b=&current;Obj player=0;
  if(b->player_slot<count&&(uintptr_t)players[b->player_slot]==b->player_key)player=players[b->player_slot];
  else for(uint32_t k=0;k<count;++k)if((uintptr_t)players[k]==b->player_key){player=players[k];frame_actors[i].player_slot=k;break;}
  if(!alive(player))continue;unsigned char dead=1;field_get_value(player,dead_field,&dead);if(dead)continue;
  Vec3 foot;Obj model=skeleton_available?skeleton_model_root(player):0;
  if(!(alive(model)&&position_value(model,&foot))&&!world_position(player,&foot))continue;
  if(!finite_number(foot.x)||!finite_number(foot.y)||!finite_number(foot.z))continue;b->foot=b->top=foot;b->top.y+=1.8f;
  if(!project_box(camera,b))continue;
  uint32_t requested=(flags&32)?((1u<<JOINT_COUNT)-1u):((1u<<J_HEAD)|(1u<<J_LFOOT)|(1u<<J_RFOOT));b->joint_mask=0;
  if(performance_profile==PROFILE_ECO&&b->range_sq>2500.f)requested=(1u<<J_HEAD)|(1u<<J_LFOOT)|(1u<<J_RFOOT);
  for(int j=0;j<JOINT_COUNT;++j)if(requested&(1u<<j)){
   Obj bone=skeleton_joint_transform(player,j);Vec3 world,screen;
   if(!alive(bone)||!position_value(bone,&world)||!pose_joint_near(&foot,&world)||!project_value(camera,&world,&screen)||screen.z<=0.01f||!finite_number(screen.z)||!finite_number(screen.x)||!finite_number(screen.y))continue;
   b->joints[j].world=world;b->joints[j].x=screen.x;b->joints[j].y=source_height-screen.y;b->joint_mask|=1u<<j;
  }
  if(!project_box(camera,b))continue;refine_model_box(camera,b);
  /* Keep horizontal extremities inside the box during turning/animation. */
  float left=b->x,right=b->x+b->w,center=(left+right)*0.5f,guard=b->h*1.5f;if(b->w*1.25f>guard)guard=b->w*1.25f;
  for(int j=0;j<JOINT_COUNT;++j)if(b->joint_mask&(1u<<j)){float x=b->joints[j].x;if(__builtin_fabsf(x-center)>guard)continue;if(x<left)left=x;if(x>right)right=x;}
  float padding=b->h*0.025f;b->x=left-padding;b->w=right-left+padding*2;
  if(!(flags&32))b->joint_mask=0;boxes[kept++]=*b;
 }
 box_count=kept;
}
