/* Send the guarded Int16 request and confirm only through the game's
   synchronized database. Failed requests consume the same bounded budget. */
static Method research_get_blueprints,research_learn_player,research_is_learned;
static void *research_note_name,*research_note_id;
static Obj research_blueprints_type;
static GCHandle research_player_root;
static uint64_t research_learn_ms;
static unsigned research_learn_database_cursor,research_learn_note_cursor;
#include "research_retry.h"
static ResearchRetry research_learn_retry[65536];
static _Atomic unsigned research_learn_requests;
static _Atomic unsigned research_learn_confirmed;
static BOOL research_learn_available;
static void research_learn_release(void){
 if(research_player_root)gchandle_free(research_player_root);research_player_root=0;
 research_learn_ms=0;research_learn_database_cursor=research_learn_note_cursor=0;research_learn_requests=research_learn_confirmed=0;zeromem(research_learn_retry,sizeof(research_learn_retry));
}
static void resolve_research_learn(void *database){
 void *blueprints=klass("OxideOld.Player","PlayerBlueprints"),*string=klass("System","String"),*short_class=klass("System","Int16");
 void *get_params[]={klass("System","Type")};research_get_blueprints=visual_named_method(klass("UnityEngine","Component"),"GetComponent",klass("UnityEngine","Component"),get_params,1,0);
 research_blueprints_type=blueprints?type_get_object(class_get_type(blueprints)):0;
 research_note_name=compatible_field(research_note_class,string,"Name","Name",0,SIZE_MAX,"Blueprint name");
 research_note_id=compatible_field(research_note_class,short_class,"id","id",0,SIZE_MAX,"Blueprint Int16 id");
 research_learn_player=method(blueprints,"LearnBlueprint",1);research_is_learned=method(database,PC_METHOD_databaseLearned,1);
 void *name_params[]={string},*id_params[]={short_class};
 if(!compatible_signature(research_learn_player,id_params,1))research_learn_player=0;
 if(!compatible_method(research_is_learned,klass("System","Boolean"),name_params,1,0))research_is_learned=0;
 if(!aimkill_entry_matches(research_learn_player,PC_RVA_directResearch,pc_prefix_directResearch,sizeof(pc_prefix_directResearch)))research_learn_player=0;
 if(!aimkill_entry_matches(research_is_learned,PC_RVA_databaseLearned,pc_prefix_databaseLearned,sizeof(pc_prefix_databaseLearned)))research_is_learned=0;
 research_learn_available=research_database_available&&research_get_blueprints&&research_blueprints_type&&research_note_name&&research_note_id&&research_learn_player&&research_is_learned;
 logline(research_learn_available?"Free study: guarded Int16 request + synchronized learned readback ready":"Free study: automatic learning unavailable; client costs retained");
}
static void research_learn_tick(Obj local,uint64_t now){
 if(!research_learn_available||!alive(local)||now<research_learn_ms)return;
 if(research_player_root&&gchandle_get_target(research_player_root)!=local)research_learn_release();
 research_learn_ms=now+500;
 if(!research_player_root){research_player_root=gchandle_new(local,0);if(!research_player_root)return;}
 void *get_args[]={research_blueprints_type};Obj blueprints=invoke(research_get_blueprints,local,get_args);if(!alive(blueprints))return;
 GCHandle root=gchandle_new(blueprints,0);if(!root)return;
 Obj array=research_database_root?gchandle_get_target(research_database_root):0;uint32_t count=array?array_length(array):0,header=array_object_header_size();
 unsigned attempts=0,visited=0,inspected=0;
 while(count&&count<=16&&header>=24&&header<=128&&visited<count&&attempts<4&&inspected++<64&&!native_faulted){
  if(research_learn_database_cursor>=count)research_learn_database_cursor=0;
  array=gchandle_get_target(research_database_root);Obj db=((Obj*)((unsigned char*)array+header))[research_learn_database_cursor],list=0,notes=0;int32_t size=-1;
  if(alive(db)){field_get_value(db,research_notes_field,&list);if(list&&object_get_class(list)==research_list_class){field_get_value(list,research_items_field,&notes);field_get_value(list,research_size_field,&size);}}
  if(!notes||size<=0||size>4096||(uint32_t)size>array_length(notes)||research_learn_note_cursor>=(unsigned)size){++research_learn_database_cursor;research_learn_note_cursor=0;++visited;continue;}
  Obj note=((Obj*)((unsigned char*)notes+header))[research_learn_note_cursor++];if(!note||object_get_class(note)!=research_note_class)continue;
  int16_t id=0;Obj name=0;field_get_value(note,research_note_id,&id);field_get_value(note,research_note_name,&name);if(id<0||!name)continue;
  unsigned index=(uint16_t)id;ResearchRetry *retry=&research_learn_retry[index];if(retry->confirmed)continue;
  void *name_args[]={name};Obj learned=invoke(research_is_learned,db,name_args);if(!learned)continue;
  void *unboxed=object_unbox(learned);if(!unboxed)continue;
  if(*(unsigned char*)unboxed){if(research_retry_confirm(retry))++research_learn_confirmed;continue;}
  if(!research_retry_due(retry,now))continue;
  research_patch_note(note);Obj ignored=0;void *id_args[]={&id};const char *previous=invoke_context;invoke_context="Free study: PlayerBlueprints.LearnBlueprint(Int16)";
  ++attempts;BOOL sent=invoke_checked(research_learn_player,gchandle_get_target(root),id_args,&ignored);
  /* Pace failed invocations too; a transient fault must not cause a loop. */
  research_retry_sent(retry,now);
  if(sent&&!native_faulted)++research_learn_requests;
  invoke_context=previous;
 }
 gchandle_free(root);
}
