#include "minwin.h"
#include <stdatomic.h>
#include "../settings.h"
#include "../session.h"
#include "render_bridge.h"
#include "custom_bridge.h"
#include "window_extent.h"
#ifndef VIBE_INTERNAL_IMGUI
#include "embedded_menu.h"
#else
extern void ABI vibe_imgui_start(HMODULE module);
#endif

/* Unity reads, camera calls and feature state run on the game's window thread.
   Worker-owned GDI windows keep drawing and input work out of Unity updates. */
typedef void *Obj;
typedef const void *Method;
/* This game's IL2CPP exports use pointer-sized GC handles, not the uint32_t
   indices used by older runtimes. Never truncate the return value or arguments. */
typedef uintptr_t GCHandle;
_Static_assert(sizeof(GCHandle)==8,"This build targets the game's Win64 runtime");
typedef struct { float x,y,z; } Vec3;
#define APIFN(ret,name,args) static ret (ABI *name) args
APIFN(void *, domain_get, (void));
APIFN(void **, domain_get_assemblies, (void *,size_t *));
APIFN(void *, assembly_get_image, (void *));
APIFN(void *, class_from_name, (void *,const char *,const char *));
APIFN(Method, class_get_method_from_name, (void *,const char *,int32_t));
APIFN(const void *, class_get_type, (void *));
APIFN(Obj, type_get_object, (const void *));
APIFN(Obj, runtime_invoke, (Method,Obj,void **,Obj *));
APIFN(void *, object_unbox, (Obj));
APIFN(const char *, method_get_name, (Method));
APIFN(void, format_exception, (Obj,char *,int32_t));
APIFN(void *, thread_current, (void));
APIFN(void *, thread_attach, (void *));
APIFN(void, thread_detach, (void *));
APIFN(GCHandle, gchandle_new, (Obj,unsigned char));
APIFN(void, gchandle_free, (GCHandle));
APIFN(Obj, gchandle_get_target, (GCHandle));
APIFN(uint32_t, array_length, (Obj));
APIFN(uint32_t, array_object_header_size, (void));
APIFN(Obj, array_new, (void *,uintptr_t));
APIFN(void, gc_wbarrier_set_field, (Obj,void **,Obj));
APIFN(void *, class_get_field_from_name, (void *,const char *));
APIFN(void *, class_get_fields, (void *,void **));
APIFN(const void *, field_get_type, (void *));
APIFN(uint32_t, field_get_flags, (void *));
APIFN(size_t, field_get_offset, (void *));
APIFN(void *, class_from_type, (const void *));
APIFN(void *, class_get_element_class, (void *));
APIFN(void *, object_get_class, (Obj));
APIFN(unsigned char, class_is_assignable_from, (void *,void *));
APIFN(Obj, object_new, (void *));
APIFN(int32_t, class_value_size, (void *,uint32_t *));
APIFN(Method, class_get_methods, (void *,void **));
APIFN(void *, class_get_nested_types, (void *,void **));
APIFN(const char *, class_get_name, (void *));
APIFN(const void *, method_get_param, (Method,uint32_t));
APIFN(uint32_t, method_get_param_count, (Method));
APIFN(const void *, method_get_return_type, (Method));
APIFN(uint32_t, method_get_flags, (Method,uint32_t *));
APIFN(void, field_get_value, (Obj,void *,void *));
APIFN(void, field_set_value, (Obj,void *,void *));
APIFN(void, field_static_get_value, (void *,void *));
APIFN(int32_t, string_length, (Obj));
APIFN(const WCHAR *, string_chars, (Obj));

static HMODULE self;
static _Atomic(HWND) game;
static HWND overlay,watermark;
static _Atomic(WNDPROC) original;
static HWND menu_window;
static DWORD menu_exstyle;
static HWND menu_owner;
static int32_t menu_offset_x=20,menu_offset_y=60;
static DWORD menu_pid;
static BOOL menu_attached=0;
static _Atomic BOOL menu_open=0,cursor_wanted=0,focused=0,stop_requested=0;
static volatile BOOL in_tick=0;
#define ESP_TICK 0x8352u
#define ESP_COOKIE 0x45535034u
static int64_t best_window_area;
static uint64_t next_menu_attempt;
static Method cursor_get_lock,cursor_set_lock,cursor_get_visible,cursor_set_visible;
static int32_t saved_cursor_lock;
static unsigned char saved_cursor_visible;
static BOOL cursor_saved=0;
static _Atomic BOOL running=1;
static _Atomic BOOL ready=0;
static _Atomic BOOL native_faulted;
static const char *invoke_context="core";
static _Atomic BOOL compatibility_requested;
static _Atomic(const char *) compatibility_status="Waiting for game compatibility check";
static uint64_t compatibility_next_retry,compatibility_next_version,compatibility_last_rebind,compatibility_error_window;
static unsigned compatibility_retry_ms=1000,compatibility_errors;
static Method compatibility_version_method;
static char compatibility_game_version[80];
static _Atomic DWORD menu_options=31;
static void balloon_release(void);
static void placed_release(void);
static void resolve_balloon_bindings(void);
static _Atomic DWORD range_min_m=0,range_max_m=RANGE_DEFAULT_M,performance_profile=PROFILE_AUTO,balloon_max_m=RANGE_DEFAULT_M;
static _Atomic DWORD aim_options=2,aim_fov_px=AIM_FOV_DEFAULT,aim_bind=AIM_BIND_DEFAULT,aim_point=AIM_POINT_HEAD,aim_sharpness=35;
static _Atomic DWORD aim_mode=AIM_MODE_CAMERA,farm_options=6,farm_mode=FARM_MODE_AUTO,farm_range_cm=300,farm_interval_ms=500,move_options=0,speed_percent=150,farm_search_m=60,farm_reserve_percent=15;
static _Atomic DWORD speed_bind,noclip_bind,rapid_options,rapid_percent=200;
static _Atomic DWORD visual_options,sky_minutes=720,sky_color=RGB(83,130,190),hands_distance_cm=20;
static _Atomic DWORD esp_colors[ESP_COLOR_COUNT]={RGB(0,255,120),RGB(248,248,252),RGB(0,255,120),RGB(0,255,120),RGB(0,255,120),RGB(248,248,252),RGB(225,225,232)};
static _Atomic DWORD medkit_slots=255,medkit_delay_ms=1500,magic_cooldown_ms=500,combat_options,fastkill_damage=250;
static _Atomic DWORD fog_color=RGB(160,170,180),medkit_threshold=60;
static _Atomic DWORD esp_line_width=2;
static _Atomic BOOL movement_input_active;
static _Atomic DWORD pending_movement_toggle,approved_movement_toggle;
static ESPSettings current_settings;
#include "toggle_keys.h"
static _Atomic BOOL aim_held;
#include "focus.h"
#include "custom_settings.h"
static WCHAR settings_path[1024],menu_directory[1024],menu_executable[1024];
static HANDLE request_event,ready_event;
static BOOL focus_request;
static uint64_t next_menu_launch;
static uint64_t last_settings_read;
static void change_profile(DWORD profile);
static void apply_menu_settings(const ESPSettings *record){
 current_settings=*record;
 menu_options=record->flags;range_min_m=0;range_max_m=record->max_m;balloon_max_m=record->balloon_max_m;
 if(!(menu_options&64u))balloon_release();if(!(menu_options&1792u))placed_release();
 aim_options=record->aim_flags;aim_fov_px=record->aim_fov;aim_bind=record->aim_key;aim_point=record->aim_point;aim_sharpness=record->aim_sharpness;aim_mode=record->aim_mode;
 farm_options=record->farm_flags&223u;farm_mode=FARM_MODE_AUTO;farm_range_cm=record->farm_range_cm;farm_interval_ms=record->farm_interval_ms;move_options=record->move_flags;speed_percent=record->speed_percent;farm_search_m=record->farm_search_m;farm_reserve_percent=record->farm_reserve_percent;
 speed_bind=record->speed_key;noclip_bind=record->noclip_key;rapid_options=(record->rapid_flags&21u);rapid_percent=record->rapid_percent;
 sky_minutes=record->sky_minutes;sky_color=record->sky_color;hands_distance_cm=record->hands_distance_cm;visual_options=record->visual_flags;fog_color=record->fog_color;medkit_threshold=record->medkit_threshold;medkit_slots=record->medkit_slots;medkit_delay_ms=record->medkit_delay_ms;magic_cooldown_ms=record->magic_cooldown_ms;combat_options=record->combat_flags&13u;fastkill_damage=record->fastkill_damage;
 for(unsigned i=0;i<ESP_COLOR_COUNT;++i)esp_colors[i]=record->esp_colors[i];
 esp_line_width=record->esp_width;
 if(record->profile!=performance_profile)change_profile(record->profile);
}
static void read_menu_settings(void) {
 uint64_t now=GetTickCount64();
 if(last_settings_read && now-last_settings_read<100)return;
 last_settings_read=now;
 ESPSettings record;if(!settings_load_w(settings_path,&record))return;
 apply_menu_settings(&record);
}
static BOOL finite_number(float v);
static int distance_text(float distance,char *out) {
 if(!finite_number(distance)||distance<0||distance>1000000)return 0;
 unsigned n=(unsigned)distance;char digits[10];int k=0,j=0;
 do{digits[k++]=(char)('0'+n%10);n/=10;}while(n);
 while(k){out[j++]=digits[--k];}
 out[j++]=' ';out[j++]='m';return j;
}
static int health_text(float hp,char *out){
 if(!finite_number(hp))return 0;
 if(hp<0)hp=0;
 if(hp>100)hp=100;
 unsigned value=(unsigned)(hp+0.5f);int n=0;out[n++]='H';out[n++]='P';out[n++]=' ';
 if(value>=100)out[n++]='1';
 if(value>=10)out[n++]=(char)('0'+(value/10)%10);
 out[n++]=(char)('0'+value%10);out[n++]='%';return n;
}
static int api_state=0;
static void *player_class,*health_field,*dead_field,*native_object_field;
static Method find_players, camera_main, camera_project, component_transform, transform_position,
              is_local, player_camera, player_name, object_valid;
static Method find_players_unsorted,position_into,project_into;
static uint64_t next_screen_read;
static Obj cached_local_key;
static void *transform_class,*animator_field;
static Method transform_child_count,transform_child,object_name;
static _Atomic BOOL skeleton_available;
static Method transform_forward,transform_local_euler_set,look_move;
static void *look_field,*look_pivot_field,*look_horizontal_field,*look_vertical_field,*look_pitch_field;
static _Atomic BOOL aim_available;
static Method net_identity;
static void *weapon_field;
static void resolve_features(void);
static void resolve_visuals(void);
static void reset_optional_capabilities(void);
static Obj player_type;
static _Atomic(const char *) status="Initializing IL2CPP...";
static HANDLE logfile=INVALID_HANDLE;
static uint64_t last_player_refresh;
static GCHandle player_array_handle;
#define FAST_SAMPLE_US 16667u
#define LIGHT_SAMPLE_US 33334u
static _Atomic uint32_t sample_interval_us=FAST_SAMPLE_US;
static unsigned warmup_samples,slow_samples,fast_samples;
static BOOL sample_refreshed_players;
static uint64_t sample_started_us;
static _Atomic uint64_t samples_total;
static _Atomic uint64_t draws_total,last_frame_age_us;
static _Atomic DWORD game_renderer_mode;
static _Atomic uint64_t last_sample_us=0,max_sample_us=0,last_render_us=0;
static int64_t performance_frequency;
static uint64_t clock_us(void){int64_t n;if(performance_frequency>0&&QueryPerformanceCounter(&n))return (uint64_t)(n/performance_frequency)*1000000u+(uint64_t)(n%performance_frequency)*1000000u/(uint64_t)performance_frequency;return GetTickCount64()*1000u;}
/* One cadence controls both collection and presentation. Avoid a second
   elapsed-time gate that can skip every other update at the same frequency. */
static uint64_t next_update_time(uint64_t started,uint64_t finished,uint32_t interval){
 uint64_t next=started+interval;
 return next>finished?next:finished+interval; /* No burst of overdue updates. */
}
static void change_profile(DWORD profile){
 performance_profile=profile;sample_interval_us=profile==PROFILE_ECO?LIGHT_SAMPLE_US:FAST_SAMPLE_US;
 warmup_samples=slow_samples=fast_samples=0;
}
static void adapt_sample_rate(uint64_t cost,BOOL refreshed){
 if(performance_profile!=PROFILE_AUTO){sample_interval_us=performance_profile==PROFILE_ECO?LIGHT_SAMPLE_US:FAST_SAMPLE_US;return;}
 if(warmup_samples<3){++warmup_samples;return;}
 /* Initial runtime work and the once-per-second scene search are spikes,
    not a reason to leave the overlay permanently slow. */
 if(refreshed)return;
 cost+=last_render_us;
 if(cost>6000){fast_samples=0;if(++slow_samples>=3){sample_interval_us=LIGHT_SAMPLE_US;slow_samples=0;}}
 else if(cost<2500){slow_samples=0;if(++fast_samples>=30){sample_interval_us=FAST_SAMPLE_US;fast_samples=0;}}
 else {slow_samples=0;fast_samples=0;}
}
static void wait_until(HANDLE timer,uint64_t deadline){
 uint64_t now=clock_us();
 if(deadline<=now)return;
 uint64_t remaining=deadline-now;
 if(remaining>50000)remaining=50000;
 if(timer){
  int64_t due=-(int64_t)(remaining*10u); /* Relative 100-nanosecond units. */
  if(SetWaitableTimer(timer,&due,0,0,0,0)){WaitForSingleObject(timer,60);return;}
 }
 /* Compatibility fallback; QPC deadlines still prevent a busy-wait loop. */
 Sleep((DWORD)((remaining+999u)/1000u));
}
static uint64_t last_resolve;
static BOOL first_tick=1;
static _Atomic int32_t found_players=-1;
static int32_t logged_players=-2,logged_boxes=-2;
static const char *last_logged_status;
static uint64_t last_report;
static BOOL previous_end=0, previous_insert=0, previous_focus=0;

#define JOINT_COUNT 19
typedef struct {Vec3 world;float x,y;} Joint;
typedef struct { float x,y,w,h,hp,distance,range_sq;Vec3 foot,top; WCHAR name[64]; int32_t name_len;int16_t icon_index;uint32_t joint_mask;Joint joints[JOINT_COUNT];uintptr_t player_key;uint32_t player_slot; } Box;
typedef struct {BOOL circle,target;float radius,x,y;} AimVisual;
static AimVisual aim_visual;
static Box boxes[256];
static Box frame_actors[256];
static unsigned frame_actor_count;
static BOOL player_discovery_pending;
static uint64_t last_camera_frame_us;
static _Atomic int32_t box_count;
static int32_t source_width,source_height;
/* Short try-lock only covers snapshot copies. Neither thread waits on the other. */
static VibeWorldMarker world_markers[128];
static uint32_t world_marker_count;
typedef struct { Box items[256];int32_t count,width,height;uint64_t sampled_us,serial;AimVisual aim;uint32_t marker_count;VibeWorldMarker markers[128]; } Frame;
static Frame shared_frame,render_frame;
static atomic_flag frame_lock=ATOMIC_FLAG_INIT;
#include "frame_markers.h"
static void publish_frame(void){
 if(atomic_flag_test_and_set_explicit(&frame_lock,memory_order_acquire))return;
 shared_frame.count=box_count;shared_frame.width=source_width;shared_frame.height=source_height;
 shared_frame.sampled_us=clock_us();
 shared_frame.aim=aim_visual;
 shared_frame.marker_count=world_marker_count;
 for(unsigned i=0;i<world_marker_count;++i)shared_frame.markers[i]=world_markers[i];
 ++shared_frame.serial;
 for(int i=0;i<box_count;++i)shared_frame.items[i]=boxes[i];
 atomic_flag_clear_explicit(&frame_lock,memory_order_release);
}
static void fetch_frame(void){
 if(atomic_flag_test_and_set_explicit(&frame_lock,memory_order_acquire))return;
 render_frame.count=shared_frame.count;render_frame.width=shared_frame.width;render_frame.height=shared_frame.height;
 render_frame.sampled_us=shared_frame.sampled_us;
 render_frame.serial=shared_frame.serial;
 render_frame.aim=shared_frame.aim;
 render_frame.marker_count=shared_frame.marker_count;
 for(unsigned i=0;i<render_frame.marker_count;++i)render_frame.markers[i]=shared_frame.markers[i];
 for(int i=0;i<render_frame.count;++i)render_frame.items[i]=shared_frame.items[i];
 atomic_flag_clear_explicit(&frame_lock,memory_order_release);
}

#ifdef VIBE_INTERNAL_IMGUI
DWORD ABI VibeUiMatchesGameWindow(HWND window){return window==game;}
DWORD ABI VibeUiReadESP(VibeRenderSnapshot *out,DWORD bytes){
 if(!out||bytes!=sizeof(*out)||!ready||!running||!focused||native_faulted)return 0;
 if(atomic_flag_test_and_set_explicit(&frame_lock,memory_order_acquire))return 2;
 out->width=shared_frame.width;out->height=shared_frame.height;out->count=shared_frame.count;out->serial=shared_frame.serial;
 out->marker_count=shared_frame.marker_count;
 for(unsigned i=0;i<out->marker_count;++i)out->markers[i]=shared_frame.markers[i];
 out->profile=performance_profile;out->flags=menu_options;out->line_width=esp_line_width;out->circle=shared_frame.aim.circle;out->target=shared_frame.aim.target;
 out->radius=shared_frame.aim.radius;out->target_x=shared_frame.aim.x;out->target_y=shared_frame.aim.y;
 uint64_t now=clock_us();last_frame_age_us=now>=shared_frame.sampled_us?now-shared_frame.sampled_us:0;out->age_ms=GetTickCount64()-last_frame_age_us/1000;++draws_total;
 for(unsigned i=0;i<ESP_COLOR_COUNT;++i)out->colors[i]=esp_colors[i];
 for(int i=0;i<shared_frame.count&&i<256;++i){const Box *b=&shared_frame.items[i];VibeRenderPlayer *p=&out->players[i];
  p->x=b->x;p->y=b->y;p->w=b->w;p->h=b->h;p->hp=b->hp;p->distance=b->distance;p->name_len=b->name_len;p->icon=b->icon_index;p->joint_mask=b->joint_mask;
  for(int j=0;j<64;++j)p->name[j]=b->name[j];for(int j=0;j<JOINT_COUNT;++j){p->joints[j].x=b->joints[j].x;p->joints[j].y=b->joints[j].y;}
 }
 atomic_flag_clear_explicit(&frame_lock,memory_order_release);return 1;
}
void ABI VibeUiReportGameRenderer(DWORD mode){game_renderer_mode=mode;}
DWORD ABI VibeUiEnableRenderMarkers(DWORD enabled){game_markers_enabled=enabled&&game_marker_method;return game_markers_enabled;}
DWORD ABI VibeUiReadGameESP(VibeRenderSnapshot *out,DWORD bytes){
 if(!out||bytes!=sizeof(*out)||!ready||!running||!focused||native_faulted)return 0;
 if(atomic_flag_test_and_set_explicit(&game_frame_lock,memory_order_acquire))return 2;
 out->width=game_render_frame.width;out->height=game_render_frame.height;out->count=game_render_frame.count;out->serial=game_render_frame.serial;
 out->marker_count=game_render_frame.marker_count;
 for(unsigned i=0;i<out->marker_count;++i)out->markers[i]=game_render_frame.markers[i];
 out->profile=performance_profile;out->flags=menu_options;out->line_width=esp_line_width;out->circle=game_render_frame.aim.circle;out->target=game_render_frame.aim.target;
 out->radius=game_render_frame.aim.radius;out->target_x=game_render_frame.aim.x;out->target_y=game_render_frame.aim.y;
 uint64_t now=clock_us();last_frame_age_us=now>=game_render_stamp_us?now-game_render_stamp_us:0;out->age_ms=GetTickCount64()-last_frame_age_us/1000;++draws_total;
 for(unsigned i=0;i<ESP_COLOR_COUNT;++i)out->colors[i]=esp_colors[i];
 for(int i=0;i<game_render_frame.count&&i<256;++i){const Box *b=&game_render_frame.items[i];VibeRenderPlayer *p=&out->players[i];
  p->x=b->x;p->y=b->y;p->w=b->w;p->h=b->h;p->hp=b->hp;p->distance=b->distance;p->name_len=b->name_len;p->icon=b->icon_index;p->joint_mask=b->joint_mask;
  for(int j=0;j<64;++j)p->name[j]=b->name[j];for(int j=0;j<JOINT_COUNT;++j){p->joints[j].x=b->joints[j].x;p->joints[j].y=b->joints[j].y;}
 }
 atomic_flag_clear_explicit(&game_frame_lock,memory_order_release);return 1;
}
#endif

static void logline(const char *s) {
 OutputDebugStringA(s);
 if(logfile!=INVALID_HANDLE){DWORD wrote;WriteFile(logfile,s,(DWORD)slen(s),&wrote,0);WriteFile(logfile,"\r\n",2,&wrote,0);}
}
/* Ignore historical low-bit key flags and held keys when switching focus. */
static int key_action(BOOL focused,int16_t end_state,int16_t insert_state) {
 BOOL end=end_state<0,insert=insert_state<0;
 int action=0;
 if(focused&&previous_focus){
  if(end&&!previous_end)action=1;
  else if(insert&&!previous_insert)action=2;
 }
 previous_end=end;previous_insert=insert;previous_focus=focused;
 return action;
}
static void log_number(const char *name,uint64_t value) {
 char text[160],digits[24];size_t n=slen(name);if(n>120)n=120;
 for(size_t i=0;i<n;++i)text[i]=name[i];
 int k=0;do{digits[k++]=(char)('0'+value%10);value/=10;}while(value);
 while(k){text[n++]=digits[--k];}text[n]=0;logline(text);
}
static int load_api(void) {
 HMODULE m=GetModuleHandleA("GameAssembly.dll"); if(!m)return 0;
#define LOAD(n) n=(void *)GetProcAddress(m,"il2cpp_" #n);if(!n){status="Missing export: il2cpp_" #n;logline(status);return -1;}
 LOAD(domain_get);LOAD(domain_get_assemblies);LOAD(assembly_get_image);LOAD(class_from_name);
 LOAD(class_get_method_from_name);LOAD(class_get_type);LOAD(type_get_object);LOAD(runtime_invoke);
 LOAD(object_unbox);LOAD(thread_current);LOAD(thread_attach);LOAD(thread_detach);LOAD(array_length);
 LOAD(array_object_header_size);LOAD(class_get_field_from_name);LOAD(field_get_value);
 LOAD(class_get_fields);LOAD(field_get_type);LOAD(field_get_flags);LOAD(field_get_offset);LOAD(class_from_type);
 LOAD(method_get_param);LOAD(method_get_param_count);LOAD(method_get_return_type);LOAD(method_get_flags);
 LOAD(string_length);LOAD(string_chars);LOAD(gchandle_new);LOAD(gchandle_free);LOAD(gchandle_get_target);
#undef LOAD
 field_set_value=(void*)GetProcAddress(m,"il2cpp_field_set_value");
 field_static_get_value=(void*)GetProcAddress(m,"il2cpp_field_static_get_value");
 method_get_name=(void*)GetProcAddress(m,"il2cpp_method_get_name");
 format_exception=(void*)GetProcAddress(m,"il2cpp_format_exception");
 array_new=(void*)GetProcAddress(m,"il2cpp_array_new");
 gc_wbarrier_set_field=(void*)GetProcAddress(m,"il2cpp_gc_wbarrier_set_field");
 class_get_element_class=(void*)GetProcAddress(m,"il2cpp_class_get_element_class");
 object_get_class=(void*)GetProcAddress(m,"il2cpp_object_get_class");
 object_new=(void*)GetProcAddress(m,"il2cpp_object_new");
 class_value_size=(void*)GetProcAddress(m,"il2cpp_class_value_size");
 class_get_methods=(void*)GetProcAddress(m,"il2cpp_class_get_methods");
 class_get_nested_types=(void*)GetProcAddress(m,"il2cpp_class_get_nested_types");
 class_get_name=(void*)GetProcAddress(m,"il2cpp_class_get_name");
 class_is_assignable_from=(void*)GetProcAddress(m,"il2cpp_class_is_assignable_from");
 logline("All IL2CPP exports resolved");
 return 1;
}
static void *klass(const char *ns,const char *name) {
 size_t n=0;void **assemblies=domain_get_assemblies(domain_get(),&n);
 for(size_t i=0;i<n;++i){void *c=class_from_name(assembly_get_image(assemblies[i]),ns,name);if(c)return c;}
 return 0;
}
extern DWORD ABI VibeInvokeManaged(void *,Method,Obj,void **,Obj *,Obj *,DWORD *,uintptr_t *);
extern void ABI VibeInitializeCrashCapture(HMODULE);
extern DWORD ABI VibeCrashDumpStatus(void);
extern const char *ABI VibeNativeFaultModule(void);
extern uintptr_t ABI VibeNativeFaultRva(void);
extern void ABI VibeAutoFirePoll(DWORD);
static BOOL invoke_checked(Method m,Obj obj,void **args,Obj *result) {
 *result=0;if(!m||native_faulted)return 0;
 Obj error=0;DWORD code=0;uintptr_t address=0;
 if(!VibeInvokeManaged((void*)runtime_invoke,m,obj,args,&error,result,&code,&address)){
  native_faulted=1;ready=0;box_count=0;aim_held=0;
  status=compatibility_status="Native Unity fault; calls paused until game restart";
  logline(status);log_number("Native exception code=",code);
  log_number("Native exception address=",address);
  logline("Native call context:");logline(invoke_context);
  logline("Native fault module:");logline(VibeNativeFaultModule());log_number("Native fault module RVA=",VibeNativeFaultRva());
  log_number("Native dump status (1 saved, 2 failed, 3 pending)=",VibeCrashDumpStatus());
  if(VibeCrashDumpStatus()==1)logline("Native dump saved under DLL directory/crash_reports");
  if(method_get_name)logline(method_get_name(m));
  return 0;
 }
 if(error){
 uint64_t fault_now=GetTickCount64();if(!compatibility_error_window||fault_now-compatibility_error_window>10000){compatibility_error_window=fault_now;compatibility_errors=0;}if(compatibility_errors<32)++compatibility_errors;
 status="Unity call failed; details in esp.log";
 static uint64_t last_error;uint64_t now=GetTickCount64();
 if(now-last_error>=1000){
  last_error=now;logline("Managed exception in Unity call");
  if(method_get_name)logline(method_get_name(m));
  if(format_exception){char detail[512];zeromem(detail,sizeof(detail));format_exception(error,detail,511);detail[511]=0;logline(detail);}
 }
 return 0;
 }
 return 1;
}
static Obj invoke(Method m,Obj obj,void **args){Obj result=0;return invoke_checked(m,obj,args,&result)?result:0;}
static uintptr_t native_pointer(Obj obj){uintptr_t pointer=0;if(obj&&native_object_field)field_get_value(obj,native_object_field,&pointer);return pointer;}
static BOOL alive(Obj obj) {
 if(!obj)return 0;
 if(native_object_field)return native_pointer(obj)!=0;
 void *args[1]={obj};Obj b=invoke(object_valid,0,args);
 return b && *(unsigned char *)object_unbox(b);
}
static Method method(void *c,const char *n,int count) {return c?class_get_method_from_name(c,n,count):0;}
#include "game_update_profile.h"
#include "compat.h"
#include "pc_client_guard.h"
#include "projection.h"
static int resolve_methods(void) {
 if(!pc_client_guard_install()){status="Client compatibility profile differs; check esp.log";logline(status);return 0;}
 health_field=dead_field=animator_field=weapon_field=look_field=look_horizontal_field=look_vertical_field=look_pitch_field=0;
 aim_available=skeleton_available=projection_available=0;reset_optional_capabilities();
 void *obj=klass("UnityEngine","Object"),*cam=klass("UnityEngine","Camera"),
      *component=klass("UnityEngine","Component"),*transform=klass("UnityEngine","Transform"),
      *net=klass("Mirror","NetworkBehaviour");
 player_class=klass("OxideOld.Player","PlayerStatus");
 if(!player_class){status="PlayerStatus class not found";logline(status);return 0;}
 find_players=method(obj,"FindObjectsOfType",2); camera_main=method(cam,"get_main",0);
 find_players_unsorted=method(obj,"FindObjectsByType",3);native_object_field=class_get_field_from_name(obj,"m_CachedPtr");
 position_into=method(transform,"get_position_Injected",2);project_into=method(cam,"WorldToScreenPoint_Injected",4);
 logline(native_object_field&&position_into&&project_into?"Allocation-free vector readers enabled":"Vector readers use compatible boxed fallback");
 camera_project=method(cam,"WorldToScreenPoint",1);object_valid=method(obj,"op_Implicit",1);
 component_transform=method(component,"get_transform",0);transform_position=method(transform,"get_position",0);
 is_local=method(net,"get_isLocalPlayer",0);player_camera=method(player_class,"get_PlayerCamera",0);
 net_identity=method(net,"get_netIdentity",0);
 weapon_field=compatible_field(player_class,klass("OxideOld.Player","HeldWeaponLogic"),PC_FIELD_weapon,"ӢʓŇͩΚ΄",1,SIZE_MAX,"PlayerStatus held weapon");
 player_name=method(player_class,"get_NetworkPlayerName",0);
 health_field=class_get_field_from_name(player_class,"health");dead_field=class_get_field_from_name(player_class,"isDead");
 if(!compatible_field_type(health_field,klass("System","Single"),SIZE_MAX)){health_field=0;compatibility_missing("Player health float field");}
 if(!compatible_field_type(dead_field,klass("System","Boolean"),SIZE_MAX)){dead_field=0;compatibility_missing("Player death boolean field");}
 transform_class=transform;animator_field=class_get_field_from_name(player_class,"characterAnimator");
 if(!compatible_field_type(animator_field,klass("UnityEngine","Animator"),SIZE_MAX)){animator_field=0;compatibility_missing("Player model Animator reference");}
 transform_child_count=method(transform,"get_childCount",0);transform_child=method(transform,"GetChild",1);object_name=method(obj,"get_name",0);
 skeleton_available=transform_class&&transform_child_count&&transform_child&&object_name&&array_new&&gc_wbarrier_set_field;
 logline(skeleton_available?"Skeleton hierarchy methods resolved":"Skeleton hierarchy unavailable; box ESP remains ready");
 void *look=klass("OxideOld.DynamicPlayer","CameraLook"),*cursor=klass("UnityEngine","Cursor");
 look_field=compatible_field(player_class,look,PC_FIELD_look,"ûӦʮćƙǘ",1,SIZE_MAX,"PlayerStatus CameraLook");
 look_pivot_field=look?class_get_field_from_name(look,"cameraPivot"):0;
 void *single=klass("System","Single");
 look_horizontal_field=compatible_field(look,single,PC_FIELD_horizontal,"ĂȀ̻ǣţů",0,0xb8,"CameraLook horizontal sensitivity");
 look_vertical_field=compatible_field(look,single,PC_FIELD_vertical,"Ǟ͞˘ɮǇҸ",0,0xbc,"CameraLook vertical sensitivity");
 look_pitch_field=compatible_field(look,single,PC_FIELD_pitch,"ϽȀӏɒǍǳ",0,0xc4,"CameraLook clamped pitch");
 const char *look_names[]={PC_METHOD_lookInput,"ϩϨѵʿĒͱ","ͅͶ̅ɟɤƻ","ю̨Ʌ҇ǊȂ","Ƿɵυͻ̱Ь"};void *look_params[]={single,single};look_move=0;
 for(unsigned i=0;i<5&&!look_move;++i){Method candidate=method(look,look_names[i],2);if(compatible_signature(candidate,look_params,2))look_move=candidate;}
 if(!look_move)compatibility_missing("CameraLook input method (two float parameters)");
 logline(method(look,look_names[0],2)?"Compatibility profile: supplied desktop 2026-10-12 v3":"Compatibility profile: legacy desktop or typed reference fallback");
 transform_forward=method(transform,"get_forward",0);transform_local_euler_set=method(transform,"set_localEulerAngles",1);
 cursor_get_lock=method(cursor,"get_lockState",0);
 aim_available=skeleton_available&&look_field&&look_pivot_field&&look_horizontal_field&&look_vertical_field&&look_pitch_field&&look_move&&transform_forward&&transform_local_euler_set&&cursor_get_lock;
 logline(aim_available?"Skeleton aim and CameraLook methods resolved":"Aim unavailable for this game build; check esp.log; ESP remains available");
 resolve_projection();resolve_visuals();resolve_features();resolve_balloon_bindings();
 player_type=type_get_object(class_get_type(player_class));
 void *vector=klass("UnityEngine","Vector3"),*boolean=klass("System","Boolean"),*integer=klass("System","Int32"),*vec_params[]={vector},*obj_params[]={obj};
 if(!compatible_method(camera_project,vector,vec_params,1,0))camera_project=0;
 if(!compatible_method(component_transform,transform,0,0,0))component_transform=0;
 if(!compatible_method(transform_position,vector,0,0,0))transform_position=0;
 if(!compatible_method(is_local,boolean,0,0,0))is_local=0;
 if(!compatible_method(object_valid,boolean,obj_params,1,1))object_valid=0;
 if(!find_players||!camera_project||!component_transform||!transform_position||!is_local||!object_valid||!player_type){
  status="Required Unity/Mirror method not found";logline(status);return 0;
 }
 logline("PlayerStatus and projection methods resolved");status="Ready; enter a match";return 1;
}
static BOOL vector_value(Method m,Obj obj,void **args,Vec3 *v) {
 Obj box=invoke(m,obj,args);if(!box)return 0;
 *v=*(Vec3 *)object_unbox(box);return 1;
}
static BOOL position_value(Obj transform,Vec3 *value){
 if(position_into&&native_object_field){uintptr_t pointer=native_pointer(transform);if(!pointer)return 0;void *args[2]={&pointer,value};Obj ignored;if(invoke_checked(position_into,0,args,&ignored))return 1;position_into=0;logline("Position reader switched to compatible fallback");}
 return vector_value(transform_position,transform,0,value);
}
static BOOL project_value(Obj camera,const Vec3 *world,Vec3 *screen){
 if(project_into&&native_object_field){uintptr_t pointer=native_pointer(camera);if(!pointer)return 0;int32_t eye=2;void *args[4]={&pointer,(void*)world,&eye,screen};Obj ignored;if(invoke_checked(project_into,0,args,&ignored))return 1;project_into=0;logline("Projection reader switched to compatible fallback");}
 void *args[1]={(void*)world};return vector_value(camera_project,camera,args,screen);
}
static BOOL world_position(Obj component,Vec3 *v) {
 Obj t=invoke(component_transform,component,0);return alive(t)&&position_value(t,v);
}
static BOOL finite_number(float v) {return v==v&&v>-10000000.f&&v<10000000.f;}
typedef struct {Obj key;uint64_t next_read,seen;WCHAR text[64];int32_t len;} NameCache;
static NameCache name_cache[256];
static void cached_name(Obj player,Box *box,uint64_t now){
 unsigned start=(unsigned)(((uintptr_t)player>>4)^((uintptr_t)player>>12))&255u;NameCache *entry=0;
 for(unsigned n=0;n<256;++n){NameCache *c=&name_cache[(start+n)&255u];if(c->key==player){entry=c;break;}if(!c->key||now-c->seen>5000){entry=c;break;}}
 if(!entry)entry=&name_cache[start];
 if(entry->key!=player){zeromem(entry,sizeof(*entry));entry->key=player;}
 entry->seen=now;
 if(now>=entry->next_read){
  entry->next_read=now+(entry->len?2000:250);Obj name=invoke(player_name,player,0);
  if(name){int n=string_length(name);if(n>63)n=63;if(n>0){const WCHAR *s=string_chars(name);if(s){for(int j=0;j<n;++j)entry->text[j]=s[j];entry->len=n;}}}
 }
 box->name_len=entry->len;for(int j=0;j<entry->len;++j)box->name[j]=entry->text[j];
}
static BOOL in_distance_range(float square,DWORD minimum,DWORD maximum){
 return finite_number(square)&&square>=(float)minimum*(float)minimum&&square<=(float)maximum*(float)maximum;
}
#include "pose_bounds.h"
#include "skeleton.h"
#include "aim.h"
#include "physics.h"
#include "visibility.h"
#include "silent.h"
#include "aimkill.h"
#include "balloons.h"
#include "visuals.h"
static void global_release(void);
#include "features.h"
#include "global_update.h"
DWORD ABI VibeUiReadScrapStatus(char *out,DWORD bytes){
 if(!out||!bytes)return 0;const char *state=menu_open&&(farm_options&1u)&&(custom_flags&VIBE_CUSTOM_SCRAP)?scrap_last_activity:scrap_state;DWORD n=0;
 while(state[n]&&n+1<bytes){out[n]=state[n];++n;}out[n]=0;return n;
}
#include "placed_esp.h"
#include "farm_dispatch.h"
#include "silent_sync.h"
#include "silent_target.h"
#include "melee_auto.h"
#ifdef VIBE_INTERNAL_IMGUI
void ABI VibeUiRequestCompatibilityCheck(void){compatibility_status="Compatibility recheck requested";compatibility_requested=1;}
DWORD ABI VibeUiReadCompatibilityStatus(char *out,DWORD bytes){
 if(!out||!bytes)return 0;const char *state=compatibility_status;DWORD n=0;
 while(state[n]&&n+1<bytes){out[n]=state[n];++n;}out[n]=0;return n;
}
#endif
#include "../game_item_assets.h"
typedef struct {uintptr_t player,item,sprite;int16_t index;uint64_t seen;} HeldIconCache;
static HeldIconCache held_icon_cache[64];
static int held_icon_lookup(Obj player,uint64_t now){
 if(!player||!weapon_field||!item_field||!item_icon_field||!object_get_name_method)return -1;
 Obj weapon=0,item=0,sprite=0;field_get_value(player,weapon_field,&weapon);if(!alive(weapon))return -1;field_get_value(weapon,item_field,&item);if(!alive(item))return -1;field_get_value(item,item_icon_field,&sprite);if(!alive(sprite))return -1;
 uintptr_t key=(uintptr_t)player;unsigned slot=(unsigned)((key>>4)^(key>>19))&63u;
 for(unsigned n=0;n<64;++n){HeldIconCache *c=&held_icon_cache[slot];if(c->player==key&&c->sprite==(uintptr_t)sprite&&now-c->seen<1000)return c->index;if(!c->player||c->player==key)break;slot=(slot+1u)&63u;}
 int result=-1;Obj name=invoke(object_get_name_method,sprite,0);if(name){int length=string_length(name);const WCHAR *chars=string_chars(name);if(chars&&length>0&&length<128){for(unsigned i=0;i<GAME_ICON_COUNT;++i){const char *candidate=game_icon_names[i];int j=0;while(candidate[j]&&j<length&&(unsigned char)candidate[j]==chars[j])++j;if(!candidate[j]&&j==length){result=(int)i;break;}}}}
 HeldIconCache *c=&held_icon_cache[slot];c->player=key;c->item=(uintptr_t)item;c->sprite=(uintptr_t)sprite;c->index=(int16_t)result;c->seen=now;return result;
}
static void reset_optional_capabilities(void){melee_available=silent_available=farm_available=speed_available=tool_guard_available=noclip_available=research_available=rapid_available=sky_time_available=sky_color_available=hands_available=0;}
static BOOL project_box(Obj camera,Box *box){
 Vec3 foot,head;if(!project_value(camera,&box->foot,&foot)||!project_value(camera,&box->top,&head))return 0;
 if(foot.z<=0.01f||head.z<=0.01f||!finite_number(foot.z)||!finite_number(head.z)||!finite_number(foot.x)||!finite_number(head.x)||!finite_number(foot.y)||!finite_number(head.y))return 0;
 float height=head.y-foot.y;if(height<=0||height>source_height*3.f)return 0;
 if(height<2.f)height=2.f;
 float width=height*0.45f;if(width<2.f)width=2.f;
 if(head.y<0||foot.y>source_height)return 0;
 float center=(foot.x+head.x)*0.5f,width_shift=__builtin_fabsf(head.x-foot.x);if(width_shift+height*0.22f>width)width=width_shift+height*0.22f;
 if(center+width*0.5f<0||center-width*0.5f>source_width)return 0;
 box->x=center-width/2;box->y=source_height-head.y;box->w=width;box->h=height;return 1;
}
static void refine_model_box(Obj camera,Box *box){
 uint32_t mask=box->joint_mask;if(!(mask&(1u<<J_HEAD)))return;
 Vec3 foot=box->foot,head=box->joints[J_HEAD].world;head.y+=0.12f;
 if(mask&(1u<<J_LFOOT))foot=box->joints[J_LFOOT].world;
 if(mask&(1u<<J_RFOOT)){Vec3 right=box->joints[J_RFOOT].world;if(mask&(1u<<J_LFOOT)){foot.x=(foot.x+right.x)*0.5f;foot.z=(foot.z+right.z)*0.5f;if(right.y<foot.y)foot.y=right.y;}else foot=right;}
 if(mask&((1u<<J_LFOOT)|(1u<<J_RFOOT)))foot.y-=0.06f;
 float height=head.y-foot.y;if(!finite_number(height)||height<0.35f||height>3.2f)return;
 Box candidate=*box;candidate.foot=foot;candidate.top=head;if(project_box(camera,&candidate)){box->foot=foot;box->top=head;box->x=candidate.x;box->y=candidate.y;box->w=candidate.w;box->h=candidate.h;}
}
#include "frame_pose.h"
static void refresh_player_array(void){
 if(!ready||native_faulted||!player_type||!focused||!running||stop_requested)return;
 int32_t inactive=0,sort=0;unsigned char include_inactive=0;
 void *unsorted_args[3]={player_type,&inactive,&sort},*args[2]={player_type,&include_inactive};
 const char *previous=invoke_context;invoke_context="Player discovery in active camera frame";
 Obj next=find_players_unsorted?invoke(find_players_unsorted,0,unsorted_args):invoke(find_players,0,args);invoke_context=previous;
 last_player_refresh=GetTickCount64();player_discovery_pending=0;
 if(next){GCHandle root=gchandle_new(next,0);if(root){if(player_array_handle)gchandle_free(player_array_handle);player_array_handle=root;cached_local_key=0;}}
}
#include "frame_sync.h"
static BOOL sample_has_local;
static BOOL sample_scene_paused;
static void sample_impl(void) {
 custom_apply_pending();
 static BOOL first_sample=1;
 BOOL trace=first_sample;first_sample=0;
 if(trace)logline("First sample: screen dimensions");
 box_count=0;frame_actor_count=0;world_marker_count=0;found_players=-1;sample_refreshed_players=0;
 if(frame_sync_installed&&(!last_camera_frame_us||clock_us()-last_camera_frame_us>250000)){
  player_discovery_pending=1;sample_scene_paused=1;movement_input_active=0;
  status="Waiting for active camera frame";return;
 }
 projection_state.valid=0;
 DWORD aopts=aim_options;BOOL esp_enabled=(menu_options&1)&&(menu_options&62),aim_enabled=(aopts&1)!=0;
 /* Prepare the shot callback when Silent is enabled so a first aim/fire
    press can refresh its target before the next worker hold sample. */
 if(aim_enabled&&silent_available&&(aim_mode==AIM_MODE_SILENT||aim_mode==AIM_MODE_AIMKILL))silent_install();
 aim_visual=(AimVisual){(aim_enabled||(custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE)))&&(aopts&2)!=0,0,(float)aim_fov_px,0,0};
 BOOL gun_aim_active=aim_enabled&&focused&&aim_held&&!menu_open&&!cursor_wanted&&!stop_requested&&(
  aim_mode==AIM_MODE_SILENT?silent_available:
  aim_mode==AIM_MODE_AIMKILL?aimkill_available&&silent_available:
aim_available);
 BOOL melee_active=melee_input_active();BOOL aim_active=gun_aim_active||melee_active;
 AimSelection selection={0};selection.score=(float)aim_fov_px*(float)aim_fov_px;
 if(!aim_active)aim_reset();
 skeleton_discovery_nodes=performance_profile==PROFILE_ECO?16:32;skeleton_discovery_deadline=clock_us()+750;
 skeleton_expire(GetTickCount64(),esp_enabled||aim_enabled||melee_active);
 uint64_t now=GetTickCount64();DWORD flags=menu_options,min_range=0,max_range=range_max_m;
 if(min_range>max_range)min_range=max_range;
 if(now>=next_screen_read||source_width<=0||source_height<=0){
  if(!projection_extent_valid&&!window_extent(game,&source_width,&source_height)){source_width=source_height=0;box_count=0;return;}
  next_screen_read=now+250;
 }
 if(source_width<=0||source_height<=0)return;
 /* Aim-only idle needs just the cached screen size for its FOV circle. */
 if(!esp_enabled&&!(menu_options&1984u)&&!aim_active&&!(farm_options&(1|64|128))&&!move_options&&!rapid_options&&!(custom_flags&(VIBE_CUSTOM_MELEE_MASK|VIBE_CUSTOM_GLOBAL_MASK))&&!combat_options&&!speed_bind&&!noclip_bind&&!visual_options&&!skin_needs_tick()&&!hit_audio_needs_tick()){aim_reset();features_pause(0);return;}
 if(!player_array_handle||now-last_player_refresh>=1000){
  sample_refreshed_players=1;
  if(frame_sync_installed)player_discovery_pending=1;else refresh_player_array();
 }
 if(trace)logline("First sample: resolve 64-bit GC handle");
 Obj array=player_array_handle?gchandle_get_target(player_array_handle):0;
 if(!array){status="No player array returned";return;}
 uint32_t count=array_length(array),header=array_object_header_size();found_players=(int32_t)count;
 if(count>8192||header<24||header>128){status="Unexpected array layout";return;}
 Obj *players=(Obj *)((unsigned char *)array+header);Obj camera=0,local_player=0;
 if(trace)log_number("First sample: player count=",count);
 Vec3 local_pos={0,0,0};BOOL have_local_pos=0;
 if(cached_local_key){for(uint32_t i=0;i<count;++i)if(players[i]==cached_local_key&&alive(players[i])){Obj local=invoke(is_local,players[i],0);if(local&&*(unsigned char*)object_unbox(local))local_player=players[i];break;}}
 if(local_player){camera=invoke(player_camera,local_player,0);have_local_pos=world_position(local_player,&local_pos);}
 else {
 cached_local_key=0;
 for(uint32_t i=0;i<count;++i){
  Obj p=players[i];if(!alive(p))continue;Obj b=invoke(is_local,p,0);
  if(b&&*(unsigned char *)object_unbox(b)){cached_local_key=local_player=p;camera=invoke(player_camera,p,0);have_local_pos=world_position(p,&local_pos);break;}
 }
 }
 unsigned char research_local_dead=1;if(local_player&&dead_field)field_get_value(local_player,dead_field,&research_local_dead);
 research_tick(local_player,local_player&&alive(local_player)&&!research_local_dead&&focused&&!stop_requested&&running);
 visual_tick(local_player,local_player&&alive(local_player)&&!research_local_dead&&focused&&!stop_requested&&running);
 if(!alive(camera))camera=invoke(camera_main,0,0);
 if(!alive(camera)){status="No active player camera";return;}
 capture_projection(camera);
 if(!have_local_pos)have_local_pos=world_position(camera,&local_pos);
 if(!have_local_pos){status="Waiting for distance origin";return;}
 if(aim_enabled&&!(aim_mode==AIM_MODE_SILENT?silent_available:aim_mode==AIM_MODE_AIMKILL?aimkill_available&&silent_available:aim_available))status="Selected aim mode unavailable; see esp.log";
 else status="VIBE v14.10.14 EXP | INSERT: menu | END: stop";
 unsigned char local_dead=0;if(local_player&&dead_field)field_get_value(local_player,dead_field,&local_dead);
 BOOL playing=!local_dead&&gameplay_ready(local_player);hit_audio_tick(playing);movement_input_active=playing;sample_has_local=1;
 DWORD requested_toggle=atomic_exchange(&pending_movement_toggle,0);if(playing&&requested_toggle)atomic_fetch_or(&approved_movement_toggle,requested_toggle);
 Obj melee_weapon=0,melee_item=0;float melee_reach=0;
 melee_active=melee_active&&playing&&melee_equipped(local_player,&melee_weapon,&melee_item);
 if(melee_active)field_get_value(melee_weapon,weapon_range_field,&melee_reach);
 aim_active=playing&&(gun_aim_active||melee_active);
 if(!playing){aim_active=0;aim_reset();}
 Vec3 aim_origin={0};
 BOOL aim_vis_origin_ok=1;
 if(aim_active&&(aopts&4)){
  if(!visibility_available()||(!third_shot_origin(camera,&aim_origin)&&!world_position(camera,&aim_origin))){
   aim_vis_origin_ok=0;
   static uint64_t last_vis;uint64_t n=GetTickCount64();
   if(n>=last_vis+3000){last_vis=n;logline("Visible check: camera origin unavailable; aiming without LOS filter this frame");}
  }
 }
 rapid_tick(local_player,playing);melee_tick(local_player,playing);
 if(melee_active)field_get_value(melee_weapon,weapon_range_field,&melee_reach);
 skin_tick(local_player,local_player&&alive(local_player)&&!local_dead&&running&&!stop_requested&&!native_faulted);
 noclip_tick(local_player,playing);
 movement_tick(local_player,playing);
 unbreak_player_tick(local_player,local_player&&alive(local_player)&&!local_dead&&running&&!stop_requested&&!native_faulted);
 if(native_faulted)return;

 global_tick(local_player,camera,playing);
 BOOL camera_changed=farm_dispatch(local_player,camera,playing);

 float current_health = 0.0f;

 if (local_player && health_field)
 {
     field_get_value(
         local_player,
         health_field,
         &current_health
     );
 }

 extras_tick(local_player,playing,current_health);

 skeleton_discovery_deadline=clock_us()+(performance_profile==PROFILE_ECO?350:650);
 uint64_t head_discovery_deadline=clock_us()+1200;unsigned head_candidates=0;
 uint32_t joints_wanted=esp_enabled&&(flags&32)?(1u<<JOINT_COUNT)-1u:aim_active?aim_joint_mask(aim_point):0;
 for(uint32_t i=0;i<count&&frame_actor_count<256&&box_count<256;++i){
  Obj p=players[i];if(p==local_player||!alive(p))continue;
  unsigned char dead=0;if(dead_field)field_get_value(p,dead_field,&dead);if(dead)continue;
  Vec3 foot;if(!world_position(p,&foot))continue;
  float dx=foot.x-local_pos.x,dy=foot.y-local_pos.y,dz=foot.z-local_pos.z,square=dx*dx+dy*dy+dz*dz;
  if(!in_distance_range(square,min_range,max_range))continue;
  Box pose={0};pose.range_sq=square;pose.player_key=(uintptr_t)p;pose.player_slot=i;pose.icon_index=-1;Vec3 model_foot=foot;
  if(animator_field&&skeleton_available){Obj model=skeleton_model_root(p);Vec3 rendered;if(alive(model)&&position_value(model,&rendered)&&finite_number(rendered.x)&&finite_number(rendered.y)&&finite_number(rendered.z))model_foot=rendered;}
  pose.foot=pose.top=model_foot;pose.top.y+=1.8f;BOOL in_view=project_box(camera,&pose);
  if(esp_enabled){
   pose.hp=__builtin_nanf("");if((flags&2)&&health_field)field_get_value(p,health_field,&pose.hp);
   pose.distance=(flags&16)?__builtin_sqrtf(square):-1;pose.name_len=0;if(flags&4)cached_name(p,&pose,now);
   if(in_view&&performance_profile!=PROFILE_ECO)pose.icon_index=(int16_t)held_icon_lookup(p,now);
   frame_actors[frame_actor_count++]=pose;
  }
  if(!in_view)continue;
  uint32_t wanted=joints_wanted;
  float cx=pose.x+pose.w*0.5f,cy=pose.y+pose.h*0.5f,reach=(float)aim_fov_px+pose.h*0.55f;
  BOOL near_fov=__builtin_fabsf(cx-source_width*0.5f)<=reach&&__builtin_fabsf(cy-source_height*0.5f)<=reach;
  if(!(esp_enabled&&(flags&32))&&!near_fov)wanted=0;
  /* Eco 30 keeps stable box bounds while skipping expensive full-rig reads
     for distant actors. Nearby/FOV actors retain the complete skeleton. */
  if(performance_profile==PROFILE_ECO&&square>2500.f&&!near_fov)wanted=0;
  if((flags&32)&&pose.h<12.f)wanted=aim_active&&near_fov?aim_joint_mask(aim_point):0;
  if(esp_enabled&&pose.h>=12.f)wanted|=(1u<<J_HEAD)|(1u<<J_LFOOT)|(1u<<J_RFOOT);
  if(wanted&&skeleton_available)skeleton_sample_mask(p,camera,&pose,wanted);
  if(aim_active&&aim_point==AIM_POINT_HEAD&&near_fov&&!(pose.joint_mask&(1u<<J_HEAD))&&head_candidates<8&&clock_us()<head_discovery_deadline){
   ++head_candidates;Vec3 center,extents,screen;
   if(shot_head_geometry(p,&center,&extents)&&project_value(camera,&center,&screen)&&screen.z>.01f&&finite_number(screen.x)&&finite_number(screen.y)){
    pose.joints[J_HEAD]=(Joint){.world=center,.x=screen.x,.y=source_height-screen.y};pose.joint_mask|=1u<<J_HEAD;
   }
  }
  if(esp_enabled)refine_model_box(camera,&pose);
  if(aim_active&&(!melee_active||(finite_number(melee_reach)&&melee_reach>0&&square<=(melee_reach+1.f)*(melee_reach+1.f))))aim_consider(&selection,p,&pose,aim_point,(float)source_width*0.5f,(float)source_height*0.5f,(float)aim_fov_px,(aopts&4)&&aim_vis_origin_ok?&aim_origin:0);
  if(!esp_enabled)continue;
  frame_actors[frame_actor_count-1]=pose;
  boxes[box_count++]=pose;
 }
 if(aim_active&&selection.player&&aim_point==AIM_POINT_HEAD){
  Vec3 center,extents,screen;
  if(shot_head_geometry(selection.player,&center,&extents)&&project_value(camera,&center,&screen)&&screen.z>.01f){
   float dx=screen.x-source_width*.5f,dy=screen.y-source_height*.5f;
   if(dx*dx+dy*dy<=(float)aim_fov_px*aim_fov_px){selection.joint.world=center;selection.joint.x=screen.x;selection.joint.y=source_height-screen.y;}
   else selection.player=0;
  }
 }
 if(aim_active&&selection.player){
  BOOL applied=0;
  if(melee_active){silent_clear();applied=melee_select(local_player,camera,&selection);if(applied)melee_auto_strike(local_player,camera);}
  else if(aim_mode==AIM_MODE_SILENT){melee_clear_target();silent_select(local_player,camera,&selection);applied=silent_sample_us!=0;}
  else if(aim_mode==AIM_MODE_AIMKILL){BOOL vis=(aim_options&4u)!=0;applied=aimkill_fire(local_player,camera,&selection,vis);}
  else {silent_clear();applied=aim_apply(local_player,camera,&selection);if(applied)camera_changed=1;}
  if(applied){
   Vec3 screen;
   if(aim_visual.circle&&project_value(camera,&selection.joint.world,&screen)&&screen.z>0.01f&&finite_number(screen.x)&&finite_number(screen.y)){aim_visual.target=1;aim_visual.x=screen.x;aim_visual.y=source_height-screen.y;}
  }
 }else {aim_reset();silent_clear();melee_clear_target();}
 if(camera_changed){capture_projection(camera);project_after_aim(camera,flags);}
 balloon_sample(camera,&local_pos,now,1);
 if(trace)logline("First sample completed");
}
static void sample(void){sample_has_local=sample_scene_paused=0;sample_impl();if(!sample_has_local&&!sample_scene_paused)features_pause(0);}
#include "compatibility_update.h"
/* All GDI work and window positioning run on the worker, never on Unity's thread. */
static HDC buffer_dc;
static HBITMAP buffer_bitmap;
static HGDIOBJ previous_bitmap;
static HPEN box_pen;
static HPEN aim_pen,aim_shadow_pen;
static HPEN style_pens[ESP_COLOR_COUNT];
static DWORD style_colors[ESP_COLOR_COUNT],style_widths[ESP_COLOR_COUNT],shadow_width;
static HBRUSH mark_brush,mark_border,mark_shadow,mark_key;
static HFONT mark_title,mark_small,esp_font;
#define MARK_WIDTH 330
#define MARK_HEIGHT 52
static BOOL watermark_last_open=-1;
static int buffer_width,buffer_height;
static RECT painted_bounds;
static BOOL have_painted_bounds,overlay_redraw=1;
static uint64_t drawn_serial,last_dirty_pixels;
static DWORD drawn_options;
static DWORD visible_color(DWORD color){return color?color:RGB(1,1,1);}
static BOOL refresh_style(void){
 BOOL changed=0;DWORD width=esp_line_width;
 for(unsigned i=0;i<ESP_COLOR_COUNT;++i){DWORD color=esp_colors[i];if(style_pens[i]&&style_colors[i]==color&&style_widths[i]==width)continue;HPEN replacement=CreatePen(0,(int32_t)width,visible_color(color));if(!replacement)continue;if(style_pens[i])DeleteObject(style_pens[i]);style_pens[i]=replacement;style_colors[i]=color;style_widths[i]=width;changed=1;}
 box_pen=style_pens[ESP_COLOR_BOX];aim_pen=style_pens[ESP_COLOR_FOV];
 if(!aim_shadow_pen||shadow_width!=width+2){HPEN replacement=CreatePen(0,(int32_t)(width+2),RGB(22,22,26));if(replacement){if(aim_shadow_pen)DeleteObject(aim_shadow_pen);aim_shadow_pen=replacement;shadow_width=width+2;changed=1;}}
 return changed;
}
static BOOL overlay_shown=0,mark_shown=0,menu_shown=0;
static POINT last_screen={-100000,-100000};
static int last_width,last_height;
static void free_buffer(void){
 if(buffer_dc&&previous_bitmap)SelectObject(buffer_dc,previous_bitmap);
 if(buffer_bitmap)DeleteObject(buffer_bitmap);
 if(buffer_dc)DeleteDC(buffer_dc);
 buffer_dc=0;buffer_bitmap=0;previous_bitmap=0;buffer_width=buffer_height=0;have_painted_bounds=0;overlay_redraw=1;
}
static void include_bounds(RECT *out,BOOL *have,int left,int top,int right,int bottom,int w,int h){
 if(left<0)left=0;
 if(top<0)top=0;
 if(right>w)right=w;
 if(bottom>h)bottom=h;
 if(right<=left||bottom<=top)return;
 if(!*have){*out=(RECT){left,top,right,bottom};*have=1;return;}
 if(left<out->left)out->left=left;
 if(top<out->top)out->top=top;
 if(right>out->right)out->right=right;
 if(bottom>out->bottom)out->bottom=bottom;
}
static DWORD held_icon_pixels[GAME_ICON_SIZE*GAME_ICON_SIZE];
static int held_icon_pixels_index=-1;
typedef struct {DWORD size;int32_t width,height;uint16_t planes,bits;DWORD compression,image_size;int32_t xppm,yppm;DWORD used,important;} HeldIconBitmapInfo;
static void draw_held_icon(HDC dc,const Box *box,int x,int y,int bw,int bh,int screen_w,int screen_h){
 int index=box->icon_index;if(index<0||index>=GAME_ICON_COUNT)return;
 if(index!=held_icon_pixels_index){for(unsigned i=0;i<GAME_ICON_SIZE*GAME_ICON_SIZE;++i){DWORD packed=game_icon_pixels[(unsigned)index*GAME_ICON_SIZE*GAME_ICON_SIZE+i];held_icon_pixels[i]=packed?RGB((packed>>16)&255u,(packed>>8)&255u,packed&255u):RGB(0,0,0);}held_icon_pixels_index=index;}
 int ix=x+bw+6,iy=y+bh/2-GAME_ICON_SIZE/2;if(ix+GAME_ICON_SIZE>screen_w)ix=x-GAME_ICON_SIZE-6;if(ix<0||iy<0||iy+GAME_ICON_SIZE>screen_h)return;
 HeldIconBitmapInfo info={sizeof(info),GAME_ICON_SIZE,-GAME_ICON_SIZE,1,32,0,(DWORD)(GAME_ICON_SIZE*GAME_ICON_SIZE*4),0,0,0,0};
 SetDIBitsToDevice(dc,ix,iy,GAME_ICON_SIZE,GAME_ICON_SIZE,0,0,0,GAME_ICON_SIZE,held_icon_pixels,&info,0);
}
#include "labels.h"
static BOOL frame_bounds(RECT *out,int w,int h,DWORD flags){
 BOOL have=0;float sx=render_frame.width>0?(float)w/render_frame.width:1,sy=render_frame.height>0?(float)h/render_frame.height:1;
 if(render_frame.aim.circle&&render_frame.aim.radius>0){int rx=(int)(render_frame.aim.radius*sx)+4,ry=(int)(render_frame.aim.radius*sy)+4;include_bounds(out,&have,w/2-rx,h/2-ry,w/2+rx+1,h/2+ry+1,w,h);}
 if(render_frame.aim.circle&&render_frame.aim.target){int x=(int)(render_frame.aim.x*sx),y=(int)(render_frame.aim.y*sy);include_bounds(out,&have,x-8,y-8,x+9,y+9,w,h);}
 if(flags&1)for(int i=0;i<render_frame.count;++i){const Box *b=&render_frame.items[i];int x=(int)(b->x*sx),y=(int)(b->y*sy),bw=(int)(b->w*sx),bh=(int)(b->h*sy);
  int cx=x+bw/2;if(cx<68)cx=68;if(cx>w-68)cx=w>136?w-68:w/2;
  if(flags&2){include_bounds(out,&have,x-10,y-4,x+bw+4,y+bh+4,w,h);include_bounds(out,&have,cx-70,y+bh+1,cx+70,y+bh+31,w,h);}
  if((flags&4)&&b->name_len)include_bounds(out,&have,cx-70,y-80,cx+70,y+bh+80,w,h);
  if(flags&8)include_bounds(out,&have,x+bw/2<w/2?x+bw/2-4:w/2-4,y+bh-4,x+bw/2>w/2?x+bw/2+4:w/2+4,h,w,h);
  if(flags&16)include_bounds(out,&have,cx-70,y+bh+1,cx+70,y+bh+60,w,h);
  if(flags&32)for(int j=0;j<JOINT_COUNT;++j)if(b->joint_mask&(1u<<j)){int jx=(int)(b->joints[j].x*sx),jy=(int)(b->joints[j].y*sy);include_bounds(out,&have,jx-4,jy-4,jx+4,jy+4,w,h);}
  if(b->icon_index>=0){int ix=x+bw+6;if(ix+GAME_ICON_SIZE>w)ix=x-GAME_ICON_SIZE-6;int iy=y+bh/2-GAME_ICON_SIZE/2;include_bounds(out,&have,ix,iy,ix+GAME_ICON_SIZE,iy+GAME_ICON_SIZE,w,h);}
 }
 if(flags&1)for(int i=0;i<label_count;++i){const RenderLabel *p=&labels[i];include_bounds(out,&have,p->x-2,p->y-2,p->x+p->width+2,p->y+p->height+2,w,h);}
 return have;
}
static void draw(void){
 if(!overlay||!overlay_shown)return;
 uint64_t begin=clock_us();
 int w=last_width,h=last_height;if(w<1||h<1)return;
 DWORD flags=menu_options;
 if(refresh_style())overlay_redraw=1;
 if(!overlay_redraw&&w==buffer_width&&h==buffer_height&&drawn_serial==render_frame.serial&&drawn_options==flags)return;
 BOOL full_damage=overlay_redraw||w!=buffer_width||h!=buffer_height;
 HDC target=GetDC(overlay);if(!target)return;
 if(!buffer_dc||w!=buffer_width||h!=buffer_height){
  free_buffer();buffer_dc=CreateCompatibleDC(target);buffer_bitmap=CreateCompatibleBitmap(target,w,h);
  if(!buffer_dc||!buffer_bitmap){free_buffer();ReleaseDC(overlay,target);return;}
  previous_bitmap=SelectObject(buffer_dc,buffer_bitmap);buffer_width=w;buffer_height=h;
 }
 if(!esp_font)esp_font=CreateFontA(-14,0,0,0,600,0,0,0,1,0,0,4,0,"Segoe UI");
 HGDIOBJ old_font=esp_font?SelectObject(buffer_dc,esp_font):0;
 float sx=render_frame.width>0?(float)w/render_frame.width:1,sy=render_frame.height>0?(float)h/render_frame.height:1;
 prepare_labels(buffer_dc,w,h,flags,sx,sy);
 RECT current={0},damage={0};BOOL have_current=frame_bounds(&current,w,h,flags),have_damage=0;
 if(have_current)include_bounds(&damage,&have_damage,current.left,current.top,current.right,current.bottom,w,h);
 if(have_painted_bounds)include_bounds(&damage,&have_damage,painted_bounds.left,painted_bounds.top,painted_bounds.right,painted_bounds.bottom,w,h);
 if(full_damage){damage=(RECT){0,0,w,h};have_damage=1;}
 if(!have_damage){if(old_font)SelectObject(buffer_dc,old_font);ReleaseDC(overlay,target);drawn_serial=render_frame.serial;drawn_options=flags;last_dirty_pixels=0;last_render_us=0;return;}
 int saved=SaveDC(buffer_dc);if(saved)IntersectClipRect(buffer_dc,damage.left,damage.top,damage.right,damage.bottom);
 FillRect(buffer_dc,&damage,(HBRUSH)GetStockObject(4));
 SetBkMode(buffer_dc,1);SetTextColor(buffer_dc,RGB(230,230,230));
 HGDIOBJ old_pen=SelectObject(buffer_dc,box_pen),old_brush=SelectObject(buffer_dc,GetStockObject(5));
 if(flags&1){for(int i=0;i<render_frame.count;++i){Box *b=&render_frame.items[i];int x=(int)(b->x*sx),y=(int)(b->y*sy),bw=(int)(b->w*sx),bh=(int)(b->h*sy);
  if(flags&2){SelectObject(buffer_dc,box_pen);Rectangle(buffer_dc,x,y,x+bw,y+bh);}
  if(flags&8){SelectObject(buffer_dc,style_pens[ESP_COLOR_LINE]);MoveToEx(buffer_dc,w/2,h,0);LineTo(buffer_dc,x+bw/2,y+bh);}
  if((flags&32)&&b->joint_mask){SelectObject(buffer_dc,style_pens[ESP_COLOR_SKELETON]);skeleton_draw(buffer_dc,b,sx,sy);}
  if((flags&2)&&finite_number(b->hp)){
   float hp=b->hp;if(hp<0)hp=0;if(hp>100)hp=100;
   SelectObject(buffer_dc,style_pens[ESP_COLOR_HP]);
   MoveToEx(buffer_dc,x-5,y+bh,0);LineTo(buffer_dc,x-5,y+bh-(int)(bh*hp/100));
  }
  draw_held_icon(buffer_dc,b,x,y,bw,bh,w,h);
 }}
 if(render_frame.aim.circle&&render_frame.aim.radius>0){
  int rx=(int)(render_frame.aim.radius*sx),ry=(int)(render_frame.aim.radius*sy);
  SelectObject(buffer_dc,aim_shadow_pen);Ellipse(buffer_dc,w/2-rx,h/2-ry,w/2+rx,h/2+ry);
  SelectObject(buffer_dc,aim_pen);Ellipse(buffer_dc,w/2-rx,h/2-ry,w/2+rx,h/2+ry);
  if(render_frame.aim.target){int tx=(int)(render_frame.aim.x*sx),ty=(int)(render_frame.aim.y*sy);MoveToEx(buffer_dc,tx-5,ty,0);LineTo(buffer_dc,tx+6,ty);MoveToEx(buffer_dc,tx,ty-5,0);LineTo(buffer_dc,tx,ty+6);}
 }
 draw_labels(buffer_dc);
 BitBlt(target,damage.left,damage.top,damage.right-damage.left,damage.bottom-damage.top,buffer_dc,damage.left,damage.top,0x00cc0020);
 SelectObject(buffer_dc,old_pen);SelectObject(buffer_dc,old_brush);if(old_font)SelectObject(buffer_dc,old_font);if(saved)RestoreDC(buffer_dc,saved);ReleaseDC(overlay,target);
 painted_bounds=current;have_painted_bounds=have_current;overlay_redraw=0;drawn_serial=render_frame.serial;drawn_options=flags;
 last_dirty_pixels=(uint64_t)(damage.right-damage.left)*(uint64_t)(damage.bottom-damage.top);
 last_render_us=clock_us()-begin;
 ++draws_total;
 last_frame_age_us=render_frame.sampled_us&&begin>=render_frame.sampled_us?begin-render_frame.sampled_us:0;
}
static void paint_watermark(void){
 if(!watermark)return;
 HDC dc=GetDC(watermark);if(!dc)return;
 if(!mark_brush){mark_brush=CreateSolidBrush(RGB(15,15,17));mark_border=CreateSolidBrush(RGB(50,50,55));mark_shadow=CreateSolidBrush(RGB(6,6,7));mark_key=CreateSolidBrush(RGB(1,1,1));}
 if(!mark_title){mark_title=CreateFontA(-20,0,0,0,700,0,0,0,1,0,0,5,0,"Segoe UI");mark_small=CreateFontA(-12,0,0,0,500,0,0,0,1,0,0,5,0,"Segoe UI");}
 RECT r={0,0,MARK_WIDTH,MARK_HEIGHT};FillRect(dc,&r,mark_key);SetBkMode(dc,1);
 HGDIOBJ old_pen=SelectObject(dc,GetStockObject(8)),old_brush=SelectObject(dc,mark_shadow);
 RoundRect(dc,0,2,MARK_WIDTH,MARK_HEIGHT,16,16);SelectObject(dc,mark_border);RoundRect(dc,0,0,MARK_WIDTH,MARK_HEIGHT-2,16,16);
 SelectObject(dc,mark_brush);RoundRect(dc,1,1,MARK_WIDTH-1,MARK_HEIGHT-3,14,14);
 HGDIOBJ old_font=SelectObject(dc,mark_title);SetTextColor(dc,RGB(238,238,241));TextOutA(dc,17,13,"VIBE",4);
 RECT separator={78,11,79,39};FillRect(dc,&separator,mark_border);
 SelectObject(dc,mark_small);SetTextColor(dc,RGB(222,222,230));const char *channel="t.me/Vibe_cheat";TextOutA(dc,94,10,channel,(int32_t)slen(channel));
 const char *label=menu_open?"HIDE MENU  /  INSERT":"OPEN MENU  /  ALT + CLICK";
 SetTextColor(dc,RGB(165,165,175));TextOutA(dc,94,29,label,(int32_t)slen(label));TextOutA(dc,284,10,"v14.10.14",8);
 SelectObject(dc,old_font);SelectObject(dc,old_brush);SelectObject(dc,old_pen);ReleaseDC(watermark,dc);ValidateRect(watermark,0);watermark_last_open=menu_open;
}
static void set_menu_open(BOOL open){
 if(menu_open==open)return;
 menu_open=open;logline(open?"Menu opened":"Menu hidden");
#ifndef VIBE_INTERNAL_IMGUI
 paint_watermark();
#endif
}
#ifdef VIBE_INTERNAL_IMGUI
DWORD ABI VibeUiGetMenuOpen(void){return menu_open?1u:0u;}
void ABI VibeUiSetMenuOpen(DWORD open){set_menu_open(open!=0);}
#endif
static void cursor_for_menu(void) {
 if(!cursor_wanted&&!cursor_saved)return;
 if(api_state!=1||!domain_get())return;
 if(!cursor_set_lock){
  void *c=klass("UnityEngine","Cursor");
  cursor_get_lock=method(c,"get_lockState",0);cursor_set_lock=method(c,"set_lockState",1);
  cursor_get_visible=method(c,"get_visible",0);cursor_set_visible=method(c,"set_visible",1);
 }
 if(!cursor_set_lock||!cursor_set_visible)return;
 static uint64_t next_cursor_check;
 if(cursor_wanted){
  if(cursor_saved&&GetTickCount64()<next_cursor_check)return;
  next_cursor_check=GetTickCount64()+500;
  if(!cursor_saved){
   Obj lock=invoke(cursor_get_lock,0,0),show=invoke(cursor_get_visible,0,0);
   if(!lock||!show)return;
   saved_cursor_lock=*(int32_t*)object_unbox(lock);saved_cursor_visible=*(unsigned char*)object_unbox(show);cursor_saved=1;
  }
  int32_t unlocked=0;unsigned char show=1;void *a[1]={&unlocked},*b[1]={&show};
  invoke(cursor_set_lock,0,a);invoke(cursor_set_visible,0,b);ClipCursor(0);
 }else if(cursor_saved){
  void *a[1]={&saved_cursor_lock},*b[1]={&saved_cursor_visible};
  invoke(cursor_set_lock,0,a);invoke(cursor_set_visible,0,b);cursor_saved=0;
 }
}
#ifndef VIBE_INTERNAL_IMGUI
static void release_menu(void){
 if(menu_window&&IsWindow(menu_window)&&menu_attached){
  ShowWindowAsync(menu_window,0);
  SetWindowLongPtrA(menu_window,-8,(intptr_t)menu_owner);
  SetWindowLongPtrA(menu_window,-20,(intptr_t)menu_exstyle);
 }
 menu_attached=0;menu_shown=0;next_menu_attempt=0;
}
#define IMGUI_MENU_CLASS "VibeImGuiOverlay15"
#define IMGUI_MENU_TITLE "Vibe ImGui"
static HWND external_menu_window(void){
 HWND h=FindWindowA(IMGUI_MENU_CLASS,IMGUI_MENU_TITLE);
 if(h&&(DWORD)(uintptr_t)GetPropA(h,SESSION_PID_PROPERTY)!=GetCurrentProcessId()){
  PostMessageA(h,SESSION_QUIT_MESSAGE,SESSION_COOKIE,0);h=0;
 }
 return h;
}
static BOOL launch_external_menu(void){
 if(external_menu_window())return 1;
 HANDLE file=CreateFileW(menu_executable,0x80000000u,7,0,3,0x80,0);
 if(file==INVALID_HANDLE)return 0;
 CloseHandle(file);
 WCHAR command[1200];if(!session_menu_command(menu_executable,GetCurrentProcessId(),command,1200))return 0;
 STARTUPINFOW info;PROCESS_INFORMATION process;zeromem(&info,sizeof(info));zeromem(&process,sizeof(process));info.cb=sizeof(info);
 if(!CreateProcessW(menu_executable,command,0,0,0,0,0,menu_directory,&info,&process))return 0;
 CloseHandle(process.thread);CloseHandle(process.process);logline("External ImGui menu launched");return 1;
}
static void close_session_menu(void){
 HWND external=external_menu_window();
 if(external)PostMessageA(external,SESSION_QUIT_MESSAGE,SESSION_COOKIE,0);
 if(menu_window&&IsWindow(menu_window)&&(DWORD)(uintptr_t)GetPropA(menu_window,SESSION_PID_PROPERTY)==GetCurrentProcessId()){
  uintptr_t ignored=0;if(!SendMessageTimeoutA(menu_window,SESSION_QUIT_MESSAGE,SESSION_COOKIE,0,0x23,200,&ignored))PostMessageA(menu_window,SESSION_QUIT_MESSAGE,SESSION_COOKIE,0);
 }
 vibe_menu_destroy();
 menu_window=0;menu_pid=0;menu_attached=menu_shown=0;next_menu_attempt=next_menu_launch=0;
}
static void connect_menu(void){
 if(menu_attached&&menu_window&&IsWindow(menu_window))return;
 uint64_t now=GetTickCount64();if(now<next_menu_attempt)return;next_menu_attempt=now+1000;
 menu_attached=0;menu_shown=0;
 if(external_menu_window())return;
 menu_window=FindWindowA(MENU_WINDOW_CLASS,"VIBE CHEAT");
 if(menu_window&&(DWORD)(uintptr_t)GetPropA(menu_window,SESSION_PID_PROPERTY)!=GetCurrentProcessId()){
  PostMessageA(menu_window,SESSION_QUIT_MESSAGE,SESSION_COOKIE,0);menu_window=0;
 }
 if(!menu_window&&menu_open&&now>=next_menu_launch){
  next_menu_launch=now+3000;
  if(launch_external_menu())return;
  menu_window=vibe_menu_create(self,game,settings_path,apply_menu_settings);
  if(menu_window){menu_pid=GetCurrentProcessId();logline("External menu unavailable; embedded GDI fallback created");}
  else log_number("Embedded menu fallback failed; Windows error=",GetLastError());
 }
 if(!menu_window||!game)return;
 menu_exstyle=(DWORD)GetWindowLongPtrA(menu_window,-20);menu_owner=GetWindow(menu_window,4);
 GetWindowThreadProcessId(menu_window,&menu_pid);
 /* Keep the fallback menu a nonactivating owned popup. */
 SetWindowLongPtrA(menu_window,-8,(intptr_t)game);
 SetWindowLongPtrA(menu_window,-20,(intptr_t)(menu_exstyle|0x08000080u));
 ShowWindowAsync(menu_window,0);menu_attached=1;menu_shown=0;
 logline("Embedded fallback menu connected as movable nonactivating game overlay");
}
#else
static void release_menu(void){menu_attached=0;menu_shown=0;menu_window=0;next_menu_attempt=0;}
static void close_session_menu(void){set_menu_open(0);release_menu();}
static void connect_menu(void){}
#endif
static void dispose_windows(void){
 release_menu();
 if(overlay&&IsWindow(overlay))DestroyWindow(overlay);
 if(watermark&&IsWindow(watermark))DestroyWindow(watermark);
 overlay=watermark=0;overlay_shown=mark_shown=0;
 free_buffer();last_width=last_height=0;last_screen.x=last_screen.y=-100000;
}
static void update_windows(void){
#ifdef VIBE_INTERNAL_IMGUI
 return;
#endif
 if(!game)return;
 if(!overlay){
  overlay=CreateWindowExA(0x080800a8,"RemakeESPOverlay","Remake Survival ESP",0x80000000,0,0,1,1,game,0,self,0);
  if(!overlay||!SetLayeredWindowAttributes(overlay,0,255,1)){log_number("Overlay creation/layer error=",GetLastError());return;}
  logline("Overlay created on worker thread");
 }
 connect_menu();
#ifndef VIBE_INTERNAL_IMGUI
 vibe_menu_capabilities(feature_capabilities());
 vibe_menu_compatibility(compatibility_status,request_compatibility_check);
#endif
 RECT r;POINT p={0,0};if(!GetClientRect(game,&r)||!ClientToScreen(game,&p))return;
 int w=r.right-r.left,h=r.bottom-r.top;if(w<1||h<1||w>8192||h>8192)return;
 BOOL moved=p.x!=last_screen.x||p.y!=last_screen.y||w!=last_width||h!=last_height;
 if(menu_attached&&menu_shown&&!moved){
  RECT mr;if(GetWindowRect(menu_window,&mr)){menu_offset_x=mr.left-p.x;menu_offset_y=mr.top-p.y;}
 }
 BOOL show=focused&&((((menu_options&1)&&(menu_options&62))||(menu_options&1984u))||((aim_options&3)==3&&aim_fov_px>0));
 static uint64_t next_overlay_raise=0;
 uint64_t window_now=GetTickCount64();
 if(show&&(moved||!overlay_shown||window_now>=next_overlay_raise)){
  SetWindowPos(overlay,(HWND)(intptr_t)-1,p.x,p.y,w,h,0x10u|0x40u);
  overlay_shown=1;overlay_redraw=1;next_overlay_raise=window_now+350;
 }else if(!show&&overlay_shown){
  ShowWindow(overlay,0);overlay_shown=0;overlay_redraw=1;
 }
 if(moved){last_screen=p;last_width=w;last_height=h;}
 show=focused&&menu_open&&menu_attached;
 static uint64_t next_menu_raise=0;
 if(menu_window&&(moved||show!=menu_shown||(show&&window_now>=next_menu_raise))){
  UINT flags=0x4000u|0x10u|(show?0x40u:0x80u);
  if(menu_offset_x<0)menu_offset_x=0;
  if(menu_offset_y<0)menu_offset_y=0;
  int32_t max_x=w>650?w-650:0,max_y=h>450?h-450:0;
  if(menu_offset_x>max_x)menu_offset_x=max_x;
  if(menu_offset_y>max_y)menu_offset_y=max_y;
  SetWindowPos(menu_window,(HWND)(intptr_t)-1,p.x+menu_offset_x,p.y+menu_offset_y,650,450,flags);
  if(show)next_menu_raise=window_now+350;
  menu_shown=show;
 }
}
static LRESULT ABI hooked(HWND h,UINT message,WPARAM w,LPARAM l);
static void reset_window(HWND h,BOOL finish){
 app_activation=-1;
 aim_held=0;aim_reset();
 silent_sample_us=0;
 if(finish&&!native_faulted){cursor_wanted=0;cursor_for_menu();features_pause(1);balloon_release();placed_release();backpack_release();projection_release();skeleton_expire(0,0);if(player_array_handle){gchandle_free(player_array_handle);player_array_handle=0;}}
 if(finish)pc_client_guard_remove();
 if(original&&GetWindowLongPtrA(h,-4)==(intptr_t)hooked)SetWindowLongPtrA(h,-4,(intptr_t)original);
 game=0;original=0;first_tick=1;previous_focus=0;
 if(finish)running=0;
 /* Owned windows are cleaned up only by their creating worker thread. */
}
static LRESULT ABI hooked(HWND h,UINT message,WPARAM w,LPARAM l){
 WNDPROC next=original;
 activation_event(h,message,w,l);
 if(message==MENU_CLOSE_MESSAGE&&w==MENU_CLOSE_COOKIE&&h==game){menu_open=0;cursor_wanted=0;return 0;}
 if(message==ESP_TICK&&w==ESP_COOKIE&&running&&h==game){
  if(in_tick)return 0;
  in_tick=1;
  if(first_tick){first_tick=0;logline("First lightweight Unity update received");}
  if(stop_requested){reset_window(h,1);in_tick=0;return 1;}
  if(focused&&!native_faulted){
   if(api_state==0)api_state=load_api();
   if(api_state==1&&domain_get()){
    if(!thread_current())thread_attach(domain_get());
    uint64_t now=GetTickCount64();compatibility_update(now);cursor_for_menu();custom_apply_pending();if(!(((menu_options&1)&&(menu_options&62))||(menu_options&1984u))&&!(aim_options&1)&&!(custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE)))skeleton_expire(0,0);
    if(ready&&((((menu_options&1)&&(menu_options&62))||(menu_options&1984u))||(aim_options&1)||(farm_options&(1|64|128))||move_options||rapid_options||(custom_flags&(VIBE_CUSTOM_MELEE_MASK|VIBE_CUSTOM_GLOBAL_MASK))||combat_options||speed_bind||noclip_bind||visual_options||global_work_active||visuals_have_roots()||extras_have_roots()||movement_root||farm_array_root||research_array_root||research_database_root||research_cost_count||rapid_item_root||melee_player_root||melee_timings[0].root||melee_timings[1].root||melee_timings[2].root||melee_timings[3].root||silent_player_root||noclip_root||navigation_root||skin_needs_tick()||hit_audio_needs_tick())){
     uint64_t begin=clock_us();sample_started_us=begin;sample();uint64_t cost=clock_us()-begin;
     last_sample_us=cost;if(cost>max_sample_us)max_sample_us=cost;
     adapt_sample_rate(cost,sample_refreshed_players);++samples_total;
     if(!frame_sync_installed||!last_camera_frame_us||clock_us()-last_camera_frame_us>100000)publish_frame();
    }
   }
  }else if(!native_faulted){aim_reset();if(api_state==1)features_pause(0);if(cursor_saved){cursor_wanted=0;cursor_for_menu();}}
  in_tick=0;return 1;
 }
 if((message==2||message==0x82)&&h==game){reset_window(h,0);return next?CallWindowProcA(next,h,message,w,l):DefWindowProcA(h,message,w,l);}
 if(cursor_wanted&&focused&&(message==0xff||(message==0x100||message==0x102||message==0x104||message==0x106)||(message>=0x200&&message<=0x20e)))return DefWindowProcA(h,message,w,l);
 return next?CallWindowProcA(next,h,message,w,l):DefWindowProcA(h,message,w,l);
}
static BOOL ABI find_window(HWND h,LPARAM unused){
 (void)unused;DWORD pid=0;GetWindowThreadProcessId(h,&pid);if(pid!=GetCurrentProcessId()||!IsWindowVisible(h)||GetWindow(h,4))return 1;
 char name[128];GetClassNameA(h,name,128);RECT r;
 if(equal(name,"UnityWndClass")&&GetClientRect(h,&r)){int64_t area=(int64_t)(r.right-r.left)*(r.bottom-r.top);if(area>best_window_area){best_window_area=area;game=h;}}
 return 1;
}
static LRESULT ABI overlay_proc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(h==watermark){
  if(m==0x21)return 3; /* MA_NOACTIVATE */
  if(m==0x202){set_menu_open(!menu_open);return 0;}
  if(m==0xf){paint_watermark();return 0;}
 }
 if(h==overlay&&m==0xf){overlay_redraw=1;ValidateRect(h,0);return 0;}
 if(m==0x14)return 1;
 return DefWindowProcA(h,m,w,l);
}
static void pump_windows(void){
 MSG m;uint64_t begin=clock_us();
 for(unsigned n=0;n<64&&PeekMessageA(&m,0,0,0,1);++n){
  TranslateMessage(&m);DispatchMessageA(&m);
  if(n>=3&&clock_us()-begin>=2000)break;
 }
}
static void report_progress(void){
 uint64_t now=GetTickCount64();if(now-last_report<5000)return;
 static uint64_t reported_samples,reported_draws;
 uint64_t elapsed=last_report?now-last_report:0,total=samples_total;
 last_report=now;
 if(status!=last_logged_status){last_logged_status=status;logline(status);}
 if(found_players!=logged_players&&found_players>=0){logged_players=found_players;log_number("Player objects found=",(uint64_t)found_players);}
 if(box_count!=logged_boxes){logged_boxes=box_count;log_number("Boxes projected=",(uint64_t)box_count);}
 log_number("Post-LateUpdate frames=",visual_late_frames);log_number("ESP final-camera refresh frames=",frame_sync_frames);logline(med_state);logline(global_state);logline(scrap_state);log_number("Scrap FarmObject count=",scrap_objects_seen[0]);log_number("Scrap BreakableObject count=",scrap_objects_seen[1]);log_number("Scrap DroppedItem count=",scrap_objects_seen[2]);log_number("Scrap recognized candidates=",scrap_candidates);log_number("Scrap failed actions=",scrap_action_failures);log_number("Third-person render frames=",third_render_frames);log_number("Third-person pose resets=",third_pose_restores);log_number("Third-person own colliders ignored=",third_self_hits);log_number("Backpack scans=",backpack_scan_count);log_number("Placed object ESP scans=",placed_scan_count);log_number("Scrap approaches=",scrap_walks);log_number("Scrap farm requests=",scrap_farm_requests);log_number("Scrap barrel strikes=",scrap_strikes);log_number("Scrap pickup requests=",scrap_pickups);log_number("Scrap tool switches=",scrap_tool_switches);
 log_number("Scrap native scan accepted=",scrap_native_hits);log_number("Scrap drops gone after request=",scrap_drop_completed);log_number("Scrap loot wait phases=",scrap_loot_waits);log_number("Scrap client interval ms=",scrap_effective_interval_ms);log_number("Scrap target surface distance cm=",scrap_distance_cm);
 log_number("Sample time us=",last_sample_us);log_number("Max sample time us=",max_sample_us);log_number("Worker GDI draw time us=",last_render_us);
 log_number("Target ESP period us=",sample_interval_us);
 log_number("ESP min distance m=",range_min_m);log_number("ESP max distance m=",range_max_m);log_number("Last damaged pixels=",last_dirty_pixels);
 log_number("Camera FOV verified=",camera_fov_get&&camera_fov_set);log_number("Zoom held=",camera_zoom_held);log_number("Camera FOV tenths=",camera_effective_fov_tenths);log_number("Camera FOV frames=",camera_fov_frames);
 log_number("Aim enabled=",(aim_options&1)!=0);log_number("Aim runtime ready=",aim_available);log_number("Aim hold VK=",aim_bind);log_number("Aim FOV radius px=",aim_fov_px);
 log_number("Aim mode (0 camera, 1 silent, 2 aimkill)=",aim_mode);log_number("Aimkill ready=",aimkill_available?1:0);log_number("Autofire attack input requests (damage unconfirmed)=",aimkill_fire_requests);log_number("Aimkill native shots redirected (damage unconfirmed)=",aimkill_shots);logline(aimkill_state);log_number("Silent runtime ready=",silent_available);log_number("Silent shots redirected=",silent_shots);log_number("Silent attempts=",silent_attempts);log_number("Silent shot-time refreshes=",silent_live_refreshes);log_number("Silent physics syncs=",silent_physics_syncs);log_number("Silent no live target=",silent_no_target);log_number("Silent FOV candidate rejects=",silent_fov_rejects);log_number("Silent LOS candidate rejects=",silent_los_rejects);log_number("Silent target budget exhausted=",silent_budget_exhausted);log_number("Silent stale targets=",silent_stale);log_number("Silent blocked shots=",silent_blocked);log_number("Silent alternate-bone hits=",silent_fallback_shots);log_number("Farm commands sent=",farm_attempts);log_number("Farm requested interval ms=",farm_interval_ms);log_number("Farm runtime ready=",farm_available);log_number("Movement runtime ready=",speed_available);
 log_number("Last autofire category=",aimkill_last_kind);log_number("Last autofire magazine=",aimkill_last_mag);log_number("Last autofire ammo cost=",aimkill_last_cost);log_number("Last autofire ammo type present=",aimkill_last_ammo_present);
 log_number("Received server hit feedback ready=",hit_feedback_ready);log_number("Confirmed hits (all modes)=",confirmed_hits);log_number("Confirmed headshots (all modes)=",confirmed_heads);
 log_number("Custom hit sound enabled=",custom_flags&1u);log_number("Custom hit volume percent=",custom_sound_volume);log_number("Rapid fire selected mode (0 client EXP, 1 native HvH)=",custom_rapid_mode);
 log_number("Native hitmarker show ready=",hit_marker_ready);log_number("Hit audio output state (0 waiting, 1 ready, 2 device error, 3 worker error)=",hit_output_state);log_number("Hit audio output error=",hit_output_error);log_number("Game marker hits=",marker_hits);log_number("Game marker headshots=",marker_heads);log_number("Original hitmarker mute ready=",hit_mute_ready);log_number("Native hit audio calls=",hit_native_audio_calls);log_number("Original hit audio suppressed=",hit_original_suppressed);log_number("Queued custom body sounds=",hit_queued_body);log_number("Queued custom head sounds=",hit_queued_heads);log_number("Hit sound mode (0 all, 1 head only)=",custom_sound_mode);log_number("Local Skinchanger ready=",skin_available);log_number("Local skin status=",skin_status);log_number("Local skin applications=",skin_changes);
 log_number("Auto melee enabled=",(custom_flags&VIBE_CUSTOM_AUTO_MELEE)!=0);log_number("Auto melee scans requested=",melee_auto_attempts);log_number("Auto melee scans dispatched hit=",melee_auto_dispatched);log_number("Auto melee preflight blocked=",melee_auto_blocked);log_number("PC melee ready=",melee_available);log_number("Silent Melee enabled=",(custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE))!=0);log_number("Fast Melee enabled=",(custom_flags&VIBE_CUSTOM_FAST_MELEE)!=0);log_number("Melee speed percent=",custom_melee_percent);log_number("Silent melee requested range cm=",500);log_number("Silent melee range owned=",melee_timings[3].root!=0);log_number("PC Silent Melee rays=",melee_redirected);logline(melee_state);
 log_number("Silent proxy installed=",silent_installed);log_number("Combat options=",combat_options);log_number("Medkit slot mask=",medkit_slots);log_number("Medkit cooldown ms=",medkit_delay_ms);log_number("Magic cooldown ms=",magic_cooldown_ms);
 log_number("Unbreaking enabled=",(combat_options&8u)!=0);log_number("Unbreaking loss hook ready=",combat_durability_hook);log_number("Unbreaking loss calls=",unbreak_loss_calls);log_number("Unbreaking losses blocked=",unbreak_blocked_losses);log_number("Unbreaking slot refreshes=",unbreak_repairs);
 log_number("Unbreaking slot source (1 local hotbar, 2 inventory, 3 GUI)=",unbreak_slot_source);
 log_number("Unbreaking local hotbar slots=",unbreak_hotbar_count);log_number("Unbreaking inventory slots=",unbreak_inventory_count);log_number("Unbreaking GUI hotbar slots=",unbreak_gui_count);
 log_number("Unbreaking local cost writes=",unbreak_zeroed_costs);logline(unbreak_state);
 log_number("Fast reload timer writes=",reload_timing_changes);logline(reload_timing_state);
 log_number("Visible check enabled=",(aim_options&4)!=0);log_number("Visible check bindings ready=",visibility_available());
 log_number("ESP render mode (1 game Present, 3 matched render frame, 8 overlay fallback)=",game_renderer_mode);log_number("Game render marker frames=",game_marker_frames);log_number("Game render marker drops=",game_marker_drops);log_number("ESP retained actors=",frame_actor_count);log_number("Unity camera canvas width=",source_width);log_number("Unity camera canvas height=",source_height);log_number("Unity camera viewport dimensions active=",projection_extent_valid);
 log_number("Farm enabled=",(farm_options&1)!=0);log_number("Farm options=",farm_options);log_number("Farm movement ready=",navigation_available);log_number("Farm resources in scene=",farm_resources_seen);log_number("Farm target distance cm=",farm_target_distance_cm);logline(farm_state);
 log_number("Free study checkbox=",(farm_options&64)!=0);log_number("Client cost fields ready=",research_available);log_number("All-recipe database ready=",research_database_available);log_number("Recipe cost snapshots=",research_cost_count);log_number("Blueprint learning requests=",research_learn_requests);/* magic farm removed */log_number("No recoil Shaker ready=",recoil_available);logline(research_state);
 log_number("Speed toggle key=",speed_bind);log_number("Noclip toggle key=",noclip_bind);log_number("Feature flags=",rapid_options);log_number("Rapid fire enabled=",rapid_options&1u);log_number("Rapid fire ready=",rapid_available);logline(rapid_state);
 log_number("Game foreground focus=",focused);log_number("Menu open=",menu_open);log_number("Samples total=",samples_total);log_number("Text labels drawn=",label_count);
 log_number("Focus source (1 foreground, 2 GUI, 3 activation)=",focus_source);log_number("Foreground process PID=",foreground_pid);log_number("Focus query error=",focus_error);
 if(elapsed){log_number("Measured ESP updates per second=",(total-reported_samples)*1000u/elapsed);log_number("Measured overlay draws per second=",(draws_total-reported_draws)*1000u/elapsed);}
 log_number("Latest box age us=",last_frame_age_us);
 reported_samples=total;reported_draws=draws_total;
}
static void free_render_resources(void){
 dispose_windows();
 for(unsigned i=0;i<ESP_COLOR_COUNT;++i){if(style_pens[i])DeleteObject(style_pens[i]);style_pens[i]=0;style_widths[i]=0;}
 if(aim_shadow_pen)DeleteObject(aim_shadow_pen);
 box_pen=aim_pen=aim_shadow_pen=0;shadow_width=0;
 HBRUSH brushes[]={mark_brush,mark_border,mark_shadow,mark_key};for(unsigned i=0;i<4;++i)if(brushes[i])DeleteObject(brushes[i]);mark_brush=mark_border=mark_shadow=mark_key=0;
 HFONT fonts[]={esp_font,mark_title,mark_small};for(unsigned i=0;i<3;++i)if(fonts[i])DeleteObject(fonts[i]);esp_font=mark_title=mark_small=0;watermark_last_open=-1;
}
static void begin_session(BOOL resume){
 app_activation=-1;foreground_pid=focus_source=focus_error=0;
 running=1;stop_requested=0;aim_held=0;focused=0;cursor_wanted=cursor_saved=0;menu_open=1;focus_request=1;
 movement_input_active=0;zeromem(movement_keys,sizeof(movement_keys));
 pending_movement_toggle=approved_movement_toggle=0;
 api_state=0;ready=0;last_resolve=0;game=0;original=0;first_tick=1;previous_focus=previous_insert=previous_end=0;
 compatibility_requested=0;compatibility_status="Waiting for game compatibility check";compatibility_next_retry=compatibility_next_version=compatibility_last_rebind=compatibility_error_window=0;compatibility_retry_ms=1000;compatibility_errors=0;compatibility_version_method=0;compatibility_game_version[0]=0;
 projection_state.valid=previous_camera_valid=0;camera_motion_until=0;label_count=0;zeromem(label_positions,sizeof(label_positions));
 box_count=0;found_players=-1;cached_local_key=0;next_screen_read=0;last_player_refresh=0;next_menu_attempt=next_menu_launch=0;
 shared_frame.count=render_frame.count=0;shared_frame.aim=render_frame.aim=(AimVisual){0};aim_visual=(AimVisual){0};
 zeromem(name_cache,sizeof(name_cache));aim_reset();change_profile(performance_profile);status="Connecting to game window...";
 if(native_faulted)status=compatibility_status="Native Unity fault; calls paused until game restart";
 if(resume)logline("v14.10.14 session resumed after END; methods and caches will refresh");
}
static BOOL open_request(void){
 if(!request_event||WaitForSingleObject(request_event,0)!=0)return 0;
 set_menu_open(1);focus_request=1;return 1;
}
static void focus_game_for_request(void){
 if(!focus_request||!game)return;
 focus_request=0;if(IsIconic(game))ShowWindowAsync(game,9);
 BOOL ok=SetForegroundWindow(game);log_number("Requested game foreground; Windows accepted=",ok);
 if(ok)app_activation=1;
}
static DWORD ABI setup(void *unused){
 (void)unused;vibe_custom_default(&custom_current);
 /* Window procedures and the worker retain code pointers until game exit. */
 HMODULE pinned=0;if(!GetModuleHandleExA(5,(const char*)setup,&pinned))OutputDebugStringA("DLL lifetime pin unavailable; stop with END and restart the game before replacing DLL");
 if(session_directory(self,menu_directory,1024)){
#ifndef VIBE_INTERNAL_IMGUI
  session_sibling(menu_directory,"VibeMenu.exe",menu_executable,1024);
#endif
  session_sibling(menu_directory,"esp_menu.bin",settings_path,1024);
  WCHAR path[1024];session_sibling(menu_directory,"esp.log",path,1024);logfile=CreateFileW(path,0x40000000u,3,0,2,0x80,0);
 }
#ifdef VIBE_INTERNAL_IMGUI
 vibe_imgui_start(self);
#endif
 QueryPerformanceFrequency(&performance_frequency);
 settings_default(&current_settings);apply_menu_settings(&current_settings);
 VibeInitializeCrashCapture(self);
 logline("Remake Survival VIBE v14.10.14 EXP: Coroutine hit sound replacement; independent PCM mixer");log_number("DLL loaded in process=",GetCurrentProcessId());
 WNDCLASSEXA c;zeromem(&c,sizeof(c));c.cbSize=sizeof(c);c.lpfnWndProc=overlay_proc;c.hCursor=LoadCursorA(0,(const char*)(uintptr_t)32512);c.hInstance=self;c.lpszClassName="RemakeESPOverlay";
 if(!RegisterClassExA(&c)){log_number("RegisterClassEx error=",GetLastError());return 1;}
 HANDLE pacing_timer=CreateWaitableTimerExW(0,0,2,0x00100002u);
 if(pacing_timer)logline("High-resolution overlay pacing enabled");
 else {pacing_timer=CreateWaitableTimerExW(0,0,0,0x00100002u);logline("Overlay pacing uses compatibility timer");}
 BOOL resume=0;
 for(;;){
  begin_session(resume);
  uint64_t last_delivery_log=0,next_update=0;HWND attached_game=0;BOOL delivered=0,last_focus=-1;
  while(running){
   pump_windows();read_menu_settings();BOOL requested=open_request();
   if(!game||!IsWindow(game)){
    if(attached_game){ResetEvent(ready_event);close_session_menu();dispose_windows();attached_game=0;logline("Game window changed; reconnecting");}
    game=0;best_window_area=0;EnumWindows(find_window,0);
    if(!game){Sleep(100);continue;}
    original=(WNDPROC)SetWindowLongPtrA(game,-4,(intptr_t)hooked);
    if(!original){log_number("Window subclass error=",GetLastError());game=0;Sleep(1000);continue;}
    attached_game=game;first_tick=1;SetEvent(ready_event);game_thread_id=GetWindowThreadProcessId(game,0);log_number("Selected window thread=",game_thread_id);logline("Game-window session ready; independent UI worker active");
   }
   focus_game_for_request();
   {
    BOOL raw_focus=input_focus();
    static uint64_t focus_grace_until=0;
    uint64_t focus_now=GetTickCount64();
    if(raw_focus)focus_grace_until=focus_now+350;
    focused=raw_focus||(focus_now<focus_grace_until&&game&&IsWindowVisible(game)&&!IsIconic(game));
   }
   if(focused!=last_focus){last_focus=focused;logline(focused?"Game focus active; updates enabled":"Game focus inactive; updates paused until focus returns");log_number("Foreground process PID=",foreground_pid);log_number("Focus source (1 foreground, 2 GUI, 3 activation)=",focus_source);}
   VibeAutoFirePoll(focused&&!menu_open&&!stop_requested&&!native_faulted&&aim_mode==AIM_MODE_AIMKILL&&aim_held);
   int action=key_action(focused,GetAsyncKeyState(0x23),GetAsyncKeyState(0x2d));
   if(action==1){stop_requested=1;if(requested)SetEvent(request_event);}
   if(action==2)set_menu_open(!menu_open);
   cursor_wanted=focused&&(menu_open||GetAsyncKeyState(0x12)<0);
   DWORD toggle=movement_key_poll(speed_bind,noclip_bind,focused&&!menu_open&&!cursor_wanted&&!stop_requested&&movement_input_active);
   if(toggle)atomic_fetch_xor(&pending_movement_toggle,toggle);
   aim_held=focused&&!menu_open&&!cursor_wanted&&!stop_requested&&((aim_options&1)||(custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE)))&&GetAsyncKeyState((int32_t)aim_bind)<0;
   uint64_t now=clock_us();
   if(stop_requested||now>=next_update){
    uintptr_t result=0;SetLastError(0);
    LRESULT sent=SendMessageTimeoutA(game,ESP_TICK,ESP_COOKIE,0,0x23,200,&result);
    if(sent&&result){if(!delivered){delivered=1;logline("Lightweight update delivery confirmed");}}
    else if(now-last_delivery_log>=5000000){last_delivery_log=now;log_number("Update missing/timeout; Windows error=",GetLastError());}
    BOOL active=focused&&((((menu_options&1)&&(menu_options&62))||(menu_options&1984u))||(aim_options&1)||(farm_options&(1|64|128))||move_options||rapid_options||(custom_flags&(VIBE_CUSTOM_MELEE_MASK|VIBE_CUSTOM_GLOBAL_MASK))||combat_options);
    next_update=next_update_time(now,clock_us(),active?effective_update_interval(clock_us()):50000u);
   }
   if(!running)break;
   DWORD approved=atomic_exchange(&approved_movement_toggle,0);
   if(approved&&focused&&!menu_open&&!cursor_wanted&&!stop_requested){current_settings.move_flags^=approved;settings_save_w(settings_path,&current_settings);apply_menu_settings(&current_settings);log_number("Movement toggled from bind; flags=",move_options);}
   update_windows();
#ifndef VIBE_INTERNAL_IMGUI
   if(menu_attached)vibe_menu_status(research_state,rapid_state);
#endif
   #ifndef VIBE_INTERNAL_IMGUI
   if(focused){fetch_frame();draw();}
#endif
   report_progress();uint64_t wake=next_update,ui_wake=clock_us()+8000;if(menu_open&&ui_wake<wake)wake=ui_wake;wait_until(pacing_timer,wake);
  }
  ResetEvent(ready_event);close_session_menu();free_render_resources();
  VibeAutoFirePoll(0);
#ifdef VIBE_INTERNAL_IMGUI
  logline("Stopped by END; original speeds and shot entry restored. INSERT or VibeOpenMenu resumes.");
#else
  logline("Stopped by END; original speeds and shot entry restored. INSERT or StartMenu.exe resumes.");
#endif
  if(!request_event)break;
  BOOL insert_down=GetAsyncKeyState(0x2d)<0;
  for(;;){
   DWORD result=WaitForSingleObject(request_event,50);if(result==0)break;if(result!=0x102u)return 1;
   BOOL down=GetAsyncKeyState(0x2d)<0;
   if(down&&!insert_down&&input_focus())break;
   insert_down=down;
  }
  resume=1;
 }
 if(pacing_timer)CloseHandle(pacing_timer);
 if(logfile!=INVALID_HANDLE){CloseHandle(logfile);logfile=INVALID_HANDLE;}
 return 0;
}
#ifndef VIBE_ENTRY_VIS
#define VIBE_ENTRY_VIS
#endif
VIBE_ENTRY_VIS DWORD ABI VibeOpenMenu(void *unused){(void)unused;return request_event&&SetEvent(request_event)?1u:0u;}
VIBE_ENTRY_VIS BOOL ABI DllMain(HMODULE module,DWORD reason,void *reserved){
 (void)reserved;
 if(reason==1){
  self=module;DisableThreadLibraryCalls(module);char name[96];DWORD pid=GetCurrentProcessId();
  session_event_name(name,SESSION_REQUEST_PREFIX,pid);request_event=CreateEventA(0,0,0,name);
  session_event_name(name,SESSION_READY_PREFIX,pid);ready_event=CreateEventA(0,1,0,name);
  if(!request_event||!ready_event){if(request_event)CloseHandle(request_event);if(ready_event)CloseHandle(ready_event);request_event=ready_event=0;return 0;}
  HANDLE thread=CreateThread(0,0,setup,0,0,0);if(!thread){CloseHandle(request_event);CloseHandle(ready_event);request_event=ready_event=0;return 0;}CloseHandle(thread);
 }
 return 1;
}
