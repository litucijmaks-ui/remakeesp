/* A command invocation is a request. Mark learned only after the game's
   synchronized database reports the recipe learned. Budgets are per ID. */
typedef struct {uint64_t after;unsigned char attempts,confirmed;} ResearchRetry;
static BOOL research_retry_due(const ResearchRetry *r,uint64_t now){return !r->confirmed&&r->attempts<3&&now>=r->after;}
static void research_retry_sent(ResearchRetry *r,uint64_t now){if(r->attempts<3)++r->attempts;r->after=now+5000;}
static BOOL research_retry_confirm(ResearchRetry *r){if(r->confirmed)return 0;r->confirmed=1;return 1;}
