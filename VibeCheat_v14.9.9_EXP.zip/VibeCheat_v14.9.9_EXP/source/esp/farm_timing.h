/* Local timing snapshots. They never change tool efficiency or item identity. */
typedef struct {GCHandle root;void *field;float base,applied;} FarmTimingWrite;
static FarmTimingWrite farm_timing_writes[3];
static void farm_timing_restore(unsigned index){
 FarmTimingWrite *w=&farm_timing_writes[index];if(!w->root)return;
 Obj object=gchandle_get_target(w->root);float current=0;
 if(alive(object)){field_get_value(object,w->field,&current);if(finite_number(current)&&__builtin_fabsf(current-w->applied)<0.00001f)field_set_value(object,w->field,&w->base);}
 gchandle_free(w->root);*w=(FarmTimingWrite){0};
}
static BOOL farm_timing_apply(unsigned index,Obj object,void *field,float seconds){
 FarmTimingWrite *w=&farm_timing_writes[index];
 if(!object||!field||!alive(object)||!finite_number(seconds)||seconds<0.02f||seconds>2.f){farm_timing_restore(index);return 0;}
 if(w->root&&(gchandle_get_target(w->root)!=object||w->field!=field))farm_timing_restore(index);
 float current=0;field_get_value(object,field,&current);if(!finite_number(current)||current<0||current>60.f){farm_timing_restore(index);return 0;}
 if(!w->root){w->root=gchandle_new(object,0);if(!w->root)return 0;w->field=field;w->base=w->applied=current;}
 else if(__builtin_fabsf(current-w->applied)>0.00001f)w->base=current;
 float desired=w->base<seconds?w->base:seconds;
 if(__builtin_fabsf(current-desired)>0.00001f)field_set_value(object,field,&desired);
 w->applied=desired;return 1;
}
static void farm_timing_release(void){for(unsigned i=0;i<3;++i)farm_timing_restore(i);}
