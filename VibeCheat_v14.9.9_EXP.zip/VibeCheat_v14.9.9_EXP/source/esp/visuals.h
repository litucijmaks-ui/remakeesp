static void hands_camera_tick(Obj,BOOL);
static void hands_camera_release(void);
static BOOL hands_camera_has_roots(void);
/* Local sky and separate first-person perspective settings. Rooted objects
   are restored only while their properties still contain our applied value. */
static _Atomic BOOL sky_time_available,sky_color_available,hands_available,sky_uniform_available;
static void *sky_class,*sky_cycle_field,*sky_day_field,*sky_night_field,*sky_initialized_field,*cycle_hour_field;
static Method model_get_component,model_active;
static Method sky_publish_color;
static void *sky_resources_field,*sky_uniform_id_fields[2],*sky_derived_color_fields[2];
typedef struct {float r,g,b,a;} SkyColor;
static BOOL sky_uniform_written;
static int32_t sky_uniform_ids[2];
static SkyColor sky_uniform_base[2];
static void *model_object_fields[2],*model_offset_field,*offset_position_field;
static Obj sky_type,model_setup_type;
static GCHandle sky_root,cycle_root;
static GCHandle hands_model_root,hands_setup_root,hands_offset_root;
static float sky_hour_base,sky_hour_applied,hands_z_base,hands_z_applied;
static BOOL sky_hour_written,hands_written;
static uint64_t next_sky_scan,next_hands_lookup;
static BOOL visual_in_late;
static _Atomic BOOL visual_active;
#include "visual_restore.h"
static VisualRestore visual_restore;
static void visual_unroot(GCHandle *root){if(*root)gchandle_free(*root);*root=0;}
static Obj visual_target(GCHandle root){return root?gchandle_get_target(root):0;}
static BOOL sky_initialized(Obj sky){unsigned char initialized=0;if(!alive(sky)||!sky_initialized_field)return 0;field_get_value(sky,sky_initialized_field,&initialized);return initialized!=0;}
static Method visual_named_method(void *owner,const char *name,void *returns,void *const *params,unsigned count,BOOL arrays){
 if(!owner||!returns||!class_get_methods||!method_get_name)return 0;
 void *iterator=0;Method candidate;unsigned budget=128;
 while(budget--&&(candidate=class_get_methods(owner,&iterator))){
  if(!equal(method_get_name(candidate),name)||method_get_param_count(candidate)!=count||(method_get_flags(candidate,0)&0x10u)||class_from_type(method_get_return_type(candidate))!=returns)continue;
  BOOL valid=1;for(unsigned i=0;i<count;++i){void *type=class_from_type(method_get_param(candidate,i));if(arrays)type=type&&class_get_element_class?class_get_element_class(type):0;if(!params[i]||type!=params[i]){valid=0;break;}}
  if(valid)return candidate;
 }
 return 0;
}
#include "fog.h"
extern DWORD ABI VibeCreateNativeHook(void *target,void *proxy,void **original);
static void (ABI *visual_original_late)(Obj,Method);
static void *visual_late_entry;
static BOOL visual_late_installed;
static _Atomic uint64_t visual_late_frames;
static void sky_color_tick(Obj sky,DWORD color);
static void sky_restore_at_late(Obj sky);
static void sky_apply_hour(Obj cycle);
static void ABI visual_late_proxy(Obj sky,Method info){
 if(!native_faulted&&ready&&GetCurrentThreadId()==game_thread_id&&running&&!stop_requested&&focused&&visual_active&&(visual_options&VISUAL_TIME)&&sky_time_available&&sky==visual_target(sky_root)&&sky_initialized(sky))sky_apply_hour(visual_target(cycle_root));
 visual_original_late(sky,info);
 if(native_faulted||!ready||GetCurrentThreadId()!=game_thread_id)return;
 BOOL initialized=sky_initialized(sky);
 unsigned restore=visual_restore_take(&visual_restore,(uintptr_t)sky,initialized);
 if(!initialized)return;
 visual_in_late=1;
 if(restore&RESTORE_FOG)fog_restore_at_late(sky);
 if(!native_faulted&&(restore&RESTORE_SKY))sky_restore_at_late(sky);
 if(!running||stop_requested||!focused||!visual_active||native_faulted||sky!=visual_target(sky_root)){visual_in_late=0;return;}
 ++visual_late_frames;
 if((visual_options&VISUAL_SKY_COLOR)&&sky_color_available)sky_color_tick(sky,sky_color);
 if(visual_options&VISUAL_FOG)fog_tick(visual_options);
 visual_in_late=0;
}
static BOOL visual_install_late(void){
 if(visual_late_installed)return 1;
 Method late=method(sky_class,"LateUpdate",0);if(!compatible_method(late,klass("System","Void"),0,0,0))return 0;
 HMODULE module=GetModuleHandleA("GameAssembly.dll");if(!module)return 0;
 const unsigned char *base=module;uint32_t pe=*(const uint32_t*)(base+60);if(pe>4096||*(const uint32_t*)(base+pe)!=0x4550)return 0;
 uint32_t size=*(const uint32_t*)(base+pe+24+56);void *entry=*(void *const*)late;
 if((uintptr_t)entry<(uintptr_t)base||(uintptr_t)entry>=(uintptr_t)base+size)return 0;
 if(!aimkill_entry_matches(late,PC_RVA_skyLate,pc_prefix_skyLate,sizeof(pc_prefix_skyLate))){logline("Sky publisher unavailable: supplied LateUpdate entry differs");return 0;}
 DWORD error=VibeCreateNativeHook(entry,visual_late_proxy,(void**)&visual_original_late);
 if(error){log_number("Post-LateUpdate hook failed; MinHook status=",error);return 0;}
 visual_late_entry=entry;visual_late_installed=1;logline("Post-LateUpdate visual publisher installed");return 1;
}
static void resolve_visuals(void){
 sky_uniform_available=0;
 void *single=klass("System","Single"),*boolean=klass("System","Boolean"),*nothing=klass("System","Void");
 sky_class=klass("","TOD_Sky");void *cycle=klass("","TOD_CycleParameters");
 sky_cycle_field=compatible_field(sky_class,cycle,"Cycle","Cycle",0,SIZE_MAX,"TOD sky cycle");
 sky_initialized_field=compatible_field(sky_class,boolean,"<Initialized>k__BackingField","<Initialized>k__BackingField",0,SIZE_MAX,"TOD initialized state");
 cycle_hour_field=compatible_field(cycle,single,"Hour","Hour",0,SIZE_MAX,"TOD cycle hour");
 sky_type=sky_class?type_get_object(class_get_type(sky_class)):0;
 sky_time_available=field_set_value&&sky_type&&sky_cycle_field&&sky_initialized_field&&cycle_hour_field;
 void *resources=klass("","TOD_Resources"),*color_type=klass("UnityEngine","Color"),*integer=klass("System","Int32");
 sky_resources_field=compatible_field(sky_class,resources,"<Resources>k__BackingField","<Resources>k__BackingField",0,SIZE_MAX,"TOD shader resources");
 const char *ids[]={"<ID_SunSkyColor>k__BackingField","<ID_MoonSkyColor>k__BackingField"};
 const char *derived[]={"<SunSkyColor>k__BackingField","<MoonSkyColor>k__BackingField"};
 for(unsigned i=0;i<2;++i){sky_uniform_id_fields[i]=compatible_field(resources,integer,ids[i],ids[i],0,SIZE_MAX,"TOD sky shader uniform ID");sky_derived_color_fields[i]=compatible_field(sky_class,color_type,derived[i],derived[i],0,SIZE_MAX,"TOD rendered sky color");}
 void *publish_args[]={integer,color_type};sky_publish_color=physics_named_method(klass("UnityEngine","Shader"),"SetGlobalColor",nothing,publish_args,2,1);
 if(!compatible_method(sky_publish_color,nothing,publish_args,2,1))sky_publish_color=0;
 sky_uniform_available=sky_resources_field&&sky_uniform_id_fields[0]&&sky_uniform_id_fields[1]&&sky_derived_color_fields[0]&&sky_derived_color_fields[1]&&sky_publish_color;
 sky_color_available=sky_uniform_available&&sky_time_available;
 resolve_fog();
 if(!visual_install_late()){sky_color_available=0;fog_set_color=0;logline("Sky/fog colors disabled: end-of-frame publisher unavailable");}
 void *weapon=klass("OxideOld.Player","HeldWeaponLogic"),*game_object=klass("UnityEngine","GameObject"),*setup=klass("","WeaponSetup"),*offset=klass("OxideOld.DynamicPlayer.Utility","TransformOffset");
 model_object_fields[0]=compatible_field(weapon,game_object,"weaponObject","weaponObject",0,SIZE_MAX,"Held weapon model");
 model_object_fields[1]=compatible_field(weapon,game_object,"toolObject","toolObject",0,SIZE_MAX,"Held tool model");
 model_offset_field=compatible_field(setup,offset,"ƏǄþХη˳","ƏǄþХη˳",1,SIZE_MAX,"WeaponSetup transform offset");
 offset_position_field=compatible_field(offset,klass("UnityEngine","Vector3"),"m_Position","m_Position",0,SIZE_MAX,"Hands desired position");
 void *component_params[]={klass("System","Type")};model_get_component=visual_named_method(game_object,"GetComponent",klass("UnityEngine","Component"),component_params,1,0);
 model_active=method(game_object,"get_activeInHierarchy",0);
 model_setup_type=setup?type_get_object(class_get_type(setup)):0;
 hands_available=0; /* Resolves lazily against both local camera bindings. */
 logline(sky_time_available?"Local custom sky time resolved":"Custom time unavailable; see TOD diagnostics");
 logline(sky_color_available?"Local rendered sky shader uniforms resolved":"Custom sky color unavailable; ESP remains ready");
 logline("Hands perspective: waiting for local world/viewmodel camera validation");
}
static void sky_restore_hour(void){
 Obj cycle=visual_target(cycle_root);if(cycle&&sky_hour_written){float current=0;field_get_value(cycle,cycle_hour_field,&current);if(finite_number(current)&&__builtin_fabsf(current-sky_hour_applied)<0.1f)field_set_value(cycle,cycle_hour_field,&sky_hour_base);}
 sky_hour_written=0;
}
static void sky_apply_hour(Obj cycle){
 if(!cycle)return;
 float current=0;field_get_value(cycle,cycle_hour_field,&current);
 if(!finite_number(current)||current<0||current>24)return;
 if(!sky_hour_written||__builtin_fabsf(current-sky_hour_applied)>=0.1f)sky_hour_base=current;
 float desired=(float)(sky_minutes%1440u)/60.f;
 if(__builtin_fabsf(current-desired)>0.00001f)field_set_value(cycle,cycle_hour_field,&desired);
 sky_hour_applied=desired;sky_hour_written=1;
}
static void sky_restore_color(void){
 if(sky_uniform_written)visual_restore_queue(&visual_restore,(uintptr_t)visual_target(sky_root),RESTORE_SKY);
 sky_uniform_written=0;
}
static void sky_restore_at_late(Obj sky){
 if(!visual_in_late||!sky_initialized(sky)||!sky_publish_color)return;
 Obj resources=0,ignored=0;field_get_value(sky,sky_resources_field,&resources);if(!resources)return;
 const char *previous=invoke_context;invoke_context="TOD LateUpdate: sky restore";
 for(unsigned i=0;i<2&&!native_faulted;++i){int32_t id=0;SkyColor color={0};field_get_value(resources,sky_uniform_id_fields[i],&id);field_get_value(sky,sky_derived_color_fields[i],&color);if(id){void *args[]={&id,&color};invoke_checked(sky_publish_color,0,args,&ignored);}}
 invoke_context=previous;
}
static void sky_release(void){fog_release();sky_restore_hour();sky_restore_color();visual_unroot(&cycle_root);visual_unroot(&sky_root);next_sky_scan=0;}
static void hands_release_offset(void){
 Obj offset=visual_target(hands_offset_root);if(offset&&hands_written){Vec3 current={0};field_get_value(offset,offset_position_field,&current);if(finite_number(current.z)&&__builtin_fabsf(current.z-hands_z_applied)<0.0001f){current.z=hands_z_base;field_set_value(offset,offset_position_field,&current);}}
 visual_unroot(&hands_offset_root);hands_written=0;
}
static void hands_release(void){hands_camera_release();hands_release_offset();visual_unroot(&hands_setup_root);visual_unroot(&hands_model_root);next_hands_lookup=0;}
static void visuals_release(void){visual_active=0;fog_release();sky_release();hands_release();}
static BOOL visuals_have_roots(void){return sky_root||cycle_root||fog_written||hands_model_root||hands_offset_root||hands_camera_has_roots();}
static void sky_color_tick(Obj sky,DWORD color){
 if(!sky_uniform_available||!visual_in_late||!sky_initialized(sky)||native_faulted)return;
 Obj resources=0,ignored=0;field_get_value(sky,sky_resources_field,&resources);if(!resources)return;
 SkyColor tint={(float)(color&255u)/255.f,(float)((color>>8)&255u)/255.f,(float)((color>>16)&255u)/255.f,1.f};
 for(unsigned i=0;i<2;++i){int32_t id=0;field_get_value(resources,sky_uniform_id_fields[i],&id);if(!id)continue;
  if(!sky_uniform_written)field_get_value(sky,sky_derived_color_fields[i],&sky_uniform_base[i]);
  sky_uniform_ids[i]=id;void *args[]={&id,&tint};invoke_checked(sky_publish_color,0,args,&ignored);
 }
 sky_uniform_written=1;
}
static void sky_tick(DWORD options){
 DWORD effective=options&((sky_time_available?VISUAL_TIME:0)|(sky_color_available?VISUAL_SKY_COLOR:0)|(fog_set_color&&fog_derived_field?VISUAL_FOG:0));if(!effective){fog_release();sky_release();return;}
 Obj sky=visual_target(sky_root);uint64_t now=GetTickCount64();
 if(!sky_initialized(sky)){
  uint64_t retry=next_sky_scan;sky_release();if(now<retry){next_sky_scan=retry;return;}next_sky_scan=now+2000;
  int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={sky_type,&no},*unsorted[]={sky_type,&inactive,&sort};Obj array=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);
  GCHandle array_root=array?gchandle_new(array,0):0;if(!array_root)return;array=visual_target(array_root);
  uint32_t count=array_length(array),header=array_object_header_size();if(count<=256&&header>=24&&header<=128){Obj *items=(void*)((unsigned char*)array+header);for(unsigned i=0;i<count;++i){unsigned char initialized=0;if(!alive(items[i]))continue;field_get_value(items[i],sky_initialized_field,&initialized);if(initialized){sky_root=gchandle_new(items[i],0);sky=visual_target(sky_root);break;}}}
  visual_unroot(&array_root);if(!sky)return;
 }
 Obj cycle=0;field_get_value(sky,sky_cycle_field,&cycle);
 if(cycle!=visual_target(cycle_root)){sky_restore_hour();visual_unroot(&cycle_root);if(cycle)cycle_root=gchandle_new(cycle,0);}
 cycle=visual_target(cycle_root);
 if((effective&VISUAL_TIME)&&cycle)sky_apply_hour(cycle);
 else sky_restore_hour();
 if(!(effective&VISUAL_SKY_COLOR))sky_restore_color();
 if(!(effective&VISUAL_FOG))fog_release();
}
static BOOL hands_model_valid(Obj model){if(!alive(model))return 0;if(!model_active)return 1;Obj value=invoke(model_active,model,0);return value&&*(unsigned char*)object_unbox(value);}
static void hands_tick(Obj local,DWORD options){
 hands_camera_tick(local,(options&VISUAL_HANDS)!=0);
}
static void visual_tick(Obj local,BOOL active){visual_active=active;if(!active){visuals_release();return;}DWORD options=visual_options;sky_tick(options);hands_tick(local,options);}
