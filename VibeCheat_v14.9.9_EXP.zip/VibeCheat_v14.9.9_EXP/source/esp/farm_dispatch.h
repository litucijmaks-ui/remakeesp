/* One navigation/action owner at a time. Mixed resources receive bounded turns. */
static unsigned farm_dispatch_mode;static uint64_t farm_dispatch_until;
static BOOL farm_dispatch(Obj local,Obj camera,BOOL active){
 BOOL scrap=(custom_flags&VIBE_CUSTOM_SCRAP)!=0,resources=(farm_options&6u)!=0;
 if(!active||!(farm_options&1u)){global_scrap_release();farm_release();farm_dispatch_mode=0;farm_dispatch_until=0;if(scrap)scrap_state_set(!(farm_options&1u)?"Scrap: farm master off":"Scrap: paused for menu, focus or local player");return 0;}
 if(!scrap){global_scrap_release();farm_dispatch_mode=0;return farm_tick(local,camera,active);}
 if(!resources){if(farm_dispatch_mode!=2)farm_release();farm_dispatch_mode=2;global_scrap(local,camera,active,GetTickCount64());return scrap_pending();}
 uint64_t now=GetTickCount64();
 if(!farm_dispatch_mode||(now>=farm_dispatch_until&&!(farm_dispatch_mode==2&&scrap_collecting()))){global_scrap_clear();farm_release();farm_dispatch_mode=farm_dispatch_mode==2?1:2;farm_dispatch_until=now+12000;}
 uint64_t before=farm_attempts+scrap_farm_requests+scrap_strikes+scrap_pickups;
 BOOL moved=0;if(farm_dispatch_mode==2){global_scrap(local,camera,active,now);moved=scrap_pending();}else moved=farm_tick(local,camera,active);
 BOOL target=farm_dispatch_mode==2?scrap_pending():farm_target_root!=0;
 if(!target&&before==farm_attempts+scrap_farm_requests+scrap_strikes+scrap_pickups){
  global_scrap_clear();farm_release();farm_dispatch_mode=farm_dispatch_mode==2?1:2;farm_dispatch_until=now+12000;
  if(farm_dispatch_mode==2){global_scrap(local,camera,active,now);moved=scrap_pending();}else moved=farm_tick(local,camera,active);
 }
 return moved;
}
