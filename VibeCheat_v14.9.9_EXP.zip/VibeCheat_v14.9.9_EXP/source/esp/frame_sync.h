/* Discover rooted actors at a live Unity camera phase, then project a stable
   candidate list. No gameplay commands are sent from this callback. */
static void *frame_camera_field;
static BOOL frame_sync_installed;
static _Atomic uint64_t frame_sync_frames;
static void (ABI *frame_original_precull)(Obj,Method);
static void ABI frame_precull_proxy(Obj component,Method info){
 if(!native_faulted&&ready&&running&&!stop_requested&&focused&&!in_tick&&frame_camera_field&&GetCurrentThreadId()==game_thread_id){
  Obj camera=0;field_get_value(component,frame_camera_field,&camera);if(alive(camera)){third_camera_frame(camera);camera_controls_frame(camera);}
 }
 frame_original_precull(component,info);
 if(native_faulted||!ready||!running||stop_requested||!focused||in_tick||!frame_camera_field||GetCurrentThreadId()!=game_thread_id)return;
 Obj camera=0;field_get_value(component,frame_camera_field,&camera);
 if(!alive(camera))return;uint64_t now=clock_us();
 if(frame_camera_root&&camera!=gchandle_get_target(frame_camera_root)){
  if(last_camera_frame_us&&now-last_camera_frame_us<250000)return;
  if(camera!=invoke(camera_main,0,0))return;
  projection_release();frame_actor_count=box_count=0;player_discovery_pending=1;
 }
 last_camera_frame_us=now;
 if(player_discovery_pending){in_tick=1;refresh_player_array();in_tick=0;if(native_faulted)return;}
 if(!frame_camera_root||(!((menu_options&1)&&(menu_options&62))&&!(menu_options&1984u)))return;
 in_tick=1;projection_update_extent(camera);project_after_aim(camera,menu_options);
 Obj local=cached_local_key;Vec3 origin;
 if(alive(local)&&world_position(local,&origin))balloon_sample(camera,&origin,GetTickCount64(),0);else world_marker_count=0;
 if(!native_faulted){++frame_sync_frames;publish_frame();queue_game_render_frame();}in_tick=0;
}
static void resolve_frame_sync(void){
 void *component=klass("","TOD_Camera");frame_camera_field=compatible_field(component,klass("UnityEngine","Camera"),"camera","Camera",0,SIZE_MAX,"Render camera before culling");
 if(!frame_camera_field)frame_camera_field=compatible_field(component,klass("UnityEngine","Camera"),"m_Camera","m_camera",0,SIZE_MAX,"Render camera before culling");
 if(!frame_camera_field)frame_camera_field=compatible_field(component,klass("UnityEngine","Camera"),"ʌƩˑғǂ͞","ʌƩˑғǂ͞",1,SIZE_MAX,"Render camera before culling");
 if(frame_sync_installed||!frame_camera_field)return;
 Method precull=method(component,"OnPreCull",0);HMODULE module=GetModuleHandleA("GameAssembly.dll");
 if(!module||!compatible_signature(precull,0,0))return;
 const unsigned char *base=module;uint32_t pe=*(const uint32_t*)(base+60);if(pe>4096||*(const uint32_t*)(base+pe)!=0x4550)return;
 uint32_t size=*(const uint32_t*)(base+pe+80);void *entry=*(void *const*)precull;
 if((uintptr_t)entry<=(uintptr_t)base||(uintptr_t)entry>=(uintptr_t)base+size)return;
 DWORD error=VibeCreateNativeHook(entry,frame_precull_proxy,(void**)&frame_original_precull);
 frame_sync_installed=!error;if(error)log_number("ESP camera frame hook status=",error);
 logline(frame_sync_installed?"ESP camera-turn refresh installed after active camera OnPreCull":"ESP frame refresh unavailable; exact point projection retained");
}
