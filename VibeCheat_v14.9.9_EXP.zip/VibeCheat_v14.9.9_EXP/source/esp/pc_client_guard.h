/* Own only the first return instruction of two reviewed game response
   handlers. Windows process/Unity exit APIs are left untouched. */
typedef struct {const char *name;uint32_t rva;BOOL is_static;unsigned char prefix[32];} PcClientGuardSite;
typedef struct {uint32_t rva;unsigned char bytes[5];} PcClientCallGuard;
#include "pc_client_guard_profile.h"
typedef struct {unsigned char *address;DWORD protection;BOOL owned;} PcClientOwnedGuard;
static PcClientOwnedGuard pc_client_owned[2];
static BOOL pc_client_guard_active;
static unsigned pc_client_guard_preexisting;
static BOOL pc_client_code_equal(const unsigned char *code,const unsigned char *expected,size_t size,BOOL returned){
 for(size_t i=0;i<size;++i)if(code[i]!=(i==0&&returned?0xc3:expected[i]))return 0;return 1;
}
static BOOL pc_client_executable(const unsigned char *base,const unsigned char *address,size_t size){
 MEMORY_BASIC_INFORMATION range={0};
 if(!VirtualQuery(address,&range,sizeof(range))||range.allocation!=(void*)base||range.state!=0x1000u||
    !(range.protect&0xf0u)||(range.protect&0x101u))return 0;
 uintptr_t begin=(uintptr_t)address,region=(uintptr_t)range.base;
 return begin>=region&&begin-region<=range.region_size&&size<=range.region_size-(begin-region);
}
static BOOL pc_client_write(PcClientOwnedGuard *record,unsigned char value){
 DWORD before=0,ignored=0;
 if(!VirtualProtect(record->address,1,0x40u,&before))return 0;
 if(!record->protection)record->protection=before;
 *(volatile unsigned char*)record->address=value;
 BOOL flushed=FlushInstructionCache(GetCurrentProcess(),record->address,1);
 BOOL protected=VirtualProtect(record->address,1,record->protection,&ignored);
 return flushed&&protected&&*record->address==value;
}
static void pc_client_guard_remove(void){
 pc_client_guard_active=0;
 for(unsigned i=2;i;){--i;PcClientOwnedGuard *record=&pc_client_owned[i];if(!record->owned)continue;
  if(*record->address==pc_client_sites[i].prefix[0]){
   DWORD ignored=0;
   if(!record->protection||VirtualProtect(record->address,1,record->protection,&ignored))record->owned=0;
   else logline("Client compatibility page protection restoration failed; retained for retry");
   continue;
  }
  if(!pc_client_code_equal(record->address,pc_client_sites[i].prefix,32,1)){
   logline("Client compatibility restore conflict: another writer changed code; left untouched");record->owned=0;continue;
  }
  if(pc_client_write(record,pc_client_sites[i].prefix[0]))record->owned=0;
  else logline("Client compatibility restoration failed; retained for retry");
 }
}
static BOOL pc_client_guard_install(void){
 if(pc_client_guard_active)return 1;
 if(pc_client_owned[0].owned||pc_client_owned[1].owned){pc_client_guard_remove();if(pc_client_owned[0].owned||pc_client_owned[1].owned)return 0;}
 const unsigned char *base=GetModuleHandleA("GameAssembly.dll");if(!base)return 0;
 uint32_t pe=*(const uint32_t*)(base+60);
 if(pe>4096||*(const uint32_t*)(base+pe)!=0x4550||*(const uint16_t*)(base+pe+4)!=0x8664||
    *(const uint32_t*)(base+pe+8)!=PC_CLIENT_IMAGE_STAMP||*(const uint32_t*)(base+pe+24+56)!=PC_CLIENT_IMAGE_SIZE)return 0;
 void *bootstrap=klass("","ClientAntiCheatBootstrap"),*text=klass("System","String"),*nothing=klass("System","Void");
 if(!bootstrap||!text||!nothing)return 0;void *params[]={text,text};BOOL existing[2]={0};
 /* Validate every entry/call before changing the first byte. A complete
    existing return+unchanged body is recognized but never owned by us. */
 for(unsigned i=0;i<2;++i){const PcClientGuardSite *site=&pc_client_sites[i];
  Method m=method(bootstrap,site->name,2);unsigned char *address=(unsigned char*)base+site->rva;
  if(site->rva>PC_CLIENT_IMAGE_SIZE-32u||!compatible_method(m,nothing,params,2,site->is_static)||
     *(void *const*)m!=(void*)address||!pc_client_executable(base,address,32))return 0;
  existing[i]=*address==0xc3;
  if(!pc_client_code_equal(address,site->prefix,32,existing[i]))return 0;
 }
 for(unsigned i=0;i<sizeof(pc_client_calls)/sizeof(pc_client_calls[0]);++i){const PcClientCallGuard *call=&pc_client_calls[i];
  if(call->rva>PC_CLIENT_IMAGE_SIZE-5u||!pc_client_executable(base,base+call->rva,5)||
     !pc_client_code_equal(base+call->rva,call->bytes,5,0))return 0;
 }
 pc_client_guard_preexisting=0;
 for(unsigned i=0;i<2;++i){PcClientOwnedGuard *record=&pc_client_owned[i];
  record->address=(unsigned char*)base+pc_client_sites[i].rva;record->protection=0;
  if(existing[i]){++pc_client_guard_preexisting;continue;}
  record->owned=1;
  if(!pc_client_write(record,0xc3)){pc_client_guard_remove();return 0;}
 }
 pc_client_guard_active=1;
 logline("Client compatibility: reviewed game-owned response handlers ready; server checks unchanged");
 return 1;
}
