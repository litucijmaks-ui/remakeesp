/* GetForegroundWindow can be NULL during activation. Query the actual
   foreground GUI queue, then use Windows activation notifications. A known
   different foreground process always overrides a previous active state. */
static _Atomic int32_t app_activation=-1;
static DWORD focus_source,foreground_pid,focus_error;
static BOOL focus_pid_owned(DWORD pid){return pid&&pid==GetCurrentProcessId();}
static void activation_event(HWND h,UINT message,WPARAM w,LPARAM l){
 if(h!=game)return;
 int32_t active=-1;
 if(message==0x1cu)active=w?1:0; /* WM_ACTIVATEAPP */
 else if(message==6u){ /* WM_ACTIVATE */
  if((w&65535u)!=0)active=1;
  else {DWORD pid=0;if(l)GetWindowThreadProcessId((HWND)l,&pid);active=focus_pid_owned(pid)?1:0;}
 }else if(message==5u&&w==1u)active=0; /* SIZE_MINIMIZED */
 if(active>=0){app_activation=active;if(!active){focused=0;aim_held=0;}}
}
static BOOL input_focus(void){
 foreground_pid=focus_source=focus_error=0;
 HWND foreground=GetForegroundWindow();
 if(foreground)GetWindowThreadProcessId(foreground,&foreground_pid);
 if(foreground_pid){focus_source=1;BOOL own=focus_pid_owned(foreground_pid);app_activation=own;return own;}
 GUITHREADINFO info;zeromem(&info,sizeof(info));info.size=sizeof(info);
 if(GetGUIThreadInfo(0,&info)){
  HWND active=info.active?info.active:info.focus;
  if(active)GetWindowThreadProcessId(active,&foreground_pid);
  if(foreground_pid){focus_source=2;BOOL own=focus_pid_owned(foreground_pid);app_activation=own;return own;}
 }else focus_error=GetLastError();
 if(app_activation>=0)focus_source=3;
 return app_activation==1&&game&&IsWindow(game)&&IsWindowVisible(game)&&!IsIconic(game);
}
