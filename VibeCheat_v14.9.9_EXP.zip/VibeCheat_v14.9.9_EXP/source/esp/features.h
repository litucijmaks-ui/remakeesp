/* Optional modules use real named fields and managed methods. Runtime calls
   stay on the Unity window thread; scene scans and writes have fixed budgets. */
static void *movement_field,*speed_fields[3],*sprint_field,*item_field,*item_tree_field,*item_ore_field,*item_efficiency_field,*item_name_field,*item_cooldown_field,*item_id_field,*item_icon_field,*weapon_range_field,*swing_field;
static Method object_get_name_method;
static void *farm_class,*farm_kind_field,*farm_collider_field,*farm_cooldown_field;
static Method speed_setters[3],sprint_setter,try_farm,farm_can,farm_has,collider_closest;
static _Atomic BOOL speed_available,farm_available;
static Obj farm_type;
static GCHandle movement_root,farm_array_root,farm_target_root;
static float speed_base[3],speed_applied[3];
static unsigned speed_written;
static unsigned char sprint_base;
static BOOL sprint_written;
static uint32_t sprint_applied_value[3];
static uint64_t next_speed_read,last_farm_refresh,next_farm_attempt;
static _Atomic uint64_t farm_attempts;
static _Atomic DWORD farm_resources_seen,farm_target_distance_cm;
static uint32_t farm_cursor;
static float farm_best_square=1e12f;
#include "farm_rate.h"
#include "farm_timing.h"
#include "movement_wrappers.h"
#include "movement_speed.h"
#include "farm_nav.h"
#include "research.h"
#include "rapid.h"
#include "extras.h"
#include "hit_feedback.h"
#include "skinchanger.h"
#include "melee.h"
static void resolve_features(void){
 void *movement=klass("OxideOld.DynamicPlayer","MovementController"),*weapon=klass("OxideOld.Player","HeldWeaponLogic"),*item=klass("","Item"),*collider=klass("UnityEngine","Collider"),*object=klass("UnityEngine","Object"),*string_class=klass("System","String"),*sprite=klass("UnityEngine","Sprite");
 movement_field=class_get_field_from_name(player_class,"movementController");
 const char *fields[]={"walkSpeed","runSpeed","crouchSpeed"},*setters[]={"set_WalkSpeed","set_RunSpeed","set_CrouchSpeed"};
 speed_available=movement&&movement_field;
 for(int i=0;i<3;++i){speed_fields[i]=movement?class_get_field_from_name(movement,fields[i]):0;speed_setters[i]=method(movement,setters[i],1);if(!speed_fields[i]||!speed_setters[i])speed_available=0;}
 sprint_field=movement?class_get_field_from_name(movement,"<SprintInput>k__BackingField"):0;sprint_setter=method(movement,"set_SprintInput",1);
 if(!sprint_field||!sprint_setter)speed_available=0;
 resolve_movement_wrappers(movement);
 resolve_movement_speed(movement);
 item_field=weapon?class_get_field_from_name(weapon,"itemData"):0;
 item_tree_field=item?class_get_field_from_name(item,"can_farm_tree"):0;item_ore_field=item?class_get_field_from_name(item,"can_farm_ore"):0;
 item_efficiency_field=item?class_get_field_from_name(item,"farmEfficiency"):0;item_name_field=item?class_get_field_from_name(item,"itemName"):0;item_cooldown_field=compatible_field(item,klass("System","Single"),"fireCooldown","fireCooldown",0,SIZE_MAX,"Farm tool cooldown");
 item_id_field=compatible_field(item,klass("System","Int32"),"id","id",0,SIZE_MAX,"Item id");
 item_icon_field=compatible_field(item,sprite,"icon","icon",0,SIZE_MAX,"Held item icon");
 object_get_name_method=method(object,"get_name",0);if(!compatible_method(object_get_name_method,string_class,0,0,0))object_get_name_method=0;
 weapon_range_field=weapon?class_get_field_from_name(weapon,"interactDistance"):0;swing_field=compatible_field(weapon,klass("System","Single"),"swingDuration","swingDuration",0,SIZE_MAX,"Farm swing duration");
 farm_class=klass("OxideOld.World","FarmObject");farm_kind_field=farm_class?class_get_field_from_name(farm_class,"type"):0;farm_collider_field=farm_class?class_get_field_from_name(farm_class,"hitboxCollider"):0;farm_cooldown_field=compatible_field(farm_class,klass("System","Single"),"farmCooldown","farmCooldown",0,SIZE_MAX,"Farm resource cooldown");
 try_farm=method(weapon,"CmdTryFarm",4);farm_can=method(farm_class,"CanBeFarmed",0);farm_has=method(farm_class,"HasLoot",0);collider_closest=method(collider,"ClosestPoint",1);
 void *identity_class=klass("Mirror","NetworkIdentity"),*vector_class=klass("UnityEngine","Vector3");
 void *farm_params[]={identity_class,vector_class,klass("System","Int32"),klass("System","String")};
 if(!compatible_signature(try_farm,farm_params,4)){try_farm=0;compatibility_missing("HeldWeaponLogic CmdTryFarm signature");}
 farm_type=farm_class?type_get_object(class_get_type(farm_class)):0;
 farm_available=weapon_field&&item_field&&item_tree_field&&item_ore_field&&item_efficiency_field&&item_name_field&&item_cooldown_field&&weapon_range_field&&swing_field&&farm_type&&farm_kind_field&&farm_collider_field&&farm_cooldown_field&&try_farm&&farm_can&&collider_closest&&net_identity;
 resolve_physics();resolve_aimkill();resolve_navigation(movement,item);
 resolve_research();
 resolve_rapid(weapon,item);resolve_extras(weapon,item);resolve_melee();
 void *boolean_class=klass("System","Boolean");
 void *shoot_params[]={identity_class,vector_class,vector_class,boolean_class,klass("System","Single"),boolean_class,vector_class,vector_class};
 Method shoot=physics_named_method(weapon,"CmdShootWeapon",klass("System","Void"),shoot_params,8,0);
 if(!compatible_signature(shoot,shoot_params,8)){shoot=0;compatibility_missing("HeldWeaponLogic CmdShootWeapon signature");}
 silent_resolve(shoot);resolve_hit_feedback();resolve_skinchanger();
 logline(speed_available?"Movement final speed getter resolved":"Movement unavailable for this game build");
 logline(farm_available?"Nearby farm methods and tool fields resolved":"Farm unavailable for this game build");
 logline(silent_available?"Silent hitscan signature verified":"Silent hitscan unavailable; see dependency/signature diagnostics above");
}
DWORD ABI VibeUiReadCombatFeedback(VibeCombatFeedback *out,DWORD bytes){
 if(!out||bytes!=sizeof(*out))return 0;
 out->native_actions=aimkill_fire_requests;out->confirmed_hits=confirmed_hits;out->confirmed_heads=confirmed_heads;out->marker_hits=marker_hits;out->marker_heads=marker_heads;
 out->feedback_ready=hit_feedback_ready;out->rapid_ready=rapid_available;out->skin_ready=skin_available;out->marker_ready=hit_marker_ready;out->mute_ready=hit_mute_ready;out->muted_sources=0;
 out->native_audio_calls=hit_native_audio_calls;out->original_audio_suppressed=hit_original_suppressed;out->queued_body=hit_queued_body;out->queued_heads=hit_queued_heads;return 1;
}
static DWORD feature_capabilities(void){return (aim_available?1u:0u)|(silent_available?2u:0u)|(farm_available&&aim_available?4u:0u)|(speed_available?8u:0u)|(noclip_available?16u:0u)|(tool_guard_available?32u:0u)|(research_available?64u:0u)|(rapid_available?128u:0u)|(sky_time_available?256u:0u)|(sky_color_available?512u:0u)|(hands_available?1024u:0u);}
static BOOL gameplay_ready(Obj local){
 if(!local||!alive(local)||!focused||menu_open||cursor_wanted||stop_requested||!running)return 0;
 unsigned char dead=1;if(dead_field)field_get_value(local,dead_field,&dead);if(dead)return 0;
 Obj lock=invoke(cursor_get_lock,0,0);return lock&&*(int32_t*)object_unbox(lock)==1;
}
static void movement_release(void){
 movement_speed_controller=0;
 if(!movement_root)return;
 Obj controller=gchandle_get_target(movement_root);
 if(alive(controller)){
  if(sprint_written&&movement_sprint_owned(controller,sprint_applied_value))movement_set_sprint(controller,sprint_base);
 }
 gchandle_free(movement_root);movement_root=0;speed_written=0;sprint_written=0;next_speed_read=0;
}
static void movement_tick(Obj local,BOOL active){
 DWORD options=move_options&3u;
 if(!active||!options||!speed_available){movement_release();return;}
 Obj controller=0;field_get_value(local,movement_field,&controller);
 if(!alive(controller)){movement_release();return;}
 if(movement_root&&gchandle_get_target(movement_root)!=controller)movement_release();
 if(!movement_root){
  movement_root=gchandle_new(controller,0);if(!movement_root)return;
 }
 movement_speed_controller=0;
 if((options&1)&&speed_percent>100u&&speed_percent<=300u){
  if(movement_speed_install())movement_speed_controller=controller;
  else logline("Speed multiplier unavailable; normal movement preserved");
 }
 if(options&2){unsigned char current=0;if(!movement_read_sprint(controller,&current)){movement_release();speed_available=0;return;}if(!current){if(!sprint_written)sprint_base=current;if(movement_set_sprint(controller,1))sprint_written=movement_sprint_snapshot(controller,sprint_applied_value);}}
 else if(sprint_written){if(movement_sprint_owned(controller,sprint_applied_value))movement_set_sprint(controller,sprint_base);sprint_written=0;}
}
static void farm_clear_target(void){farm_timing_restore(2);navigation_release();if(farm_target_root)gchandle_free(farm_target_root);farm_target_root=0;farm_best_square=1e12f;farm_target_distance_cm=0;}
static void farm_release(void){farm_timing_release();farm_clear_target();if(farm_array_root)gchandle_free(farm_array_root);farm_array_root=0;farm_cursor=0;last_farm_refresh=next_farm_attempt=0;farm_resources_seen=0;}
static BOOL farm_point(Obj resource,const Vec3 *origin,Vec3 *out){
 Obj collider=0;field_get_value(resource,farm_collider_field,&collider);if(!alive(collider))return 0;
 void *args[]={(void*)origin};if(!vector_value(collider_closest,collider,args,out))return 0;
 return finite_number(out->x)&&finite_number(out->y)&&finite_number(out->z);
}
static BOOL farm_matches(Obj resource,unsigned char trees,unsigned char ore){
 int32_t kind=-1;field_get_value(resource,farm_kind_field,&kind);
 /* Values 0 = trees, 1 = ore verified in HeldWeaponLogic's tool checks. */
 return (kind==0&&trees&&(farm_options&2))||(kind==1&&ore&&(farm_options&4));
}
static float point_distance_sq(const Vec3 *a,const Vec3 *b){float x=a->x-b->x,y=a->y-b->y,z=a->z-b->z;return x*x+y*y+z*z;}
static uint64_t next_farm_work;
static BOOL farm_tick(Obj local,Obj camera,BOOL active){
 /* magic farm removed per request — ordinary farm only */
 if(!active||!(farm_options&1)||!farm_available){farm_release();next_farm_work=0;farm_state_set(!(farm_options&1)?"Farm disabled":!farm_available?"Farm unavailable: unresolved game methods":"Farm paused: menu, cursor, focus or local player");return 0;}
 if(!(farm_options&6)){farm_release();farm_state_set("Farm paused: enable Trees or Ore");return 0;}
 if(aim_held||GetAsyncKeyState(1)<0||manual_movement()){farm_timing_release();navigation_release();farm_state_set("Farm paused: manual input");return 0;}
 uint64_t now=GetTickCount64();static uint32_t previous_interval;uint32_t interval=farm_interval_ms;if(interval<20)interval=20;
 if(interval!=previous_interval){previous_interval=interval;next_farm_work=next_farm_attempt=0;}if(now<next_farm_work)return 0;next_farm_work=now+farm_work_interval(interval);
 Obj weapon=0,item=0;field_get_value(local,weapon_field,&weapon);if(alive(weapon))field_get_value(weapon,item_field,&item);
 if(!farm_prepare_tool(local,item)){farm_timing_release();navigation_release();return 0;}
 if(!alive(weapon)||!alive(item)){farm_timing_release();navigation_release();farm_state_set("Farm paused: no equipped tool");return 0;}
 unsigned char trees=0,ore=0;field_get_value(item,item_tree_field,&trees);field_get_value(item,item_ore_field,&ore);
 float range=0;field_get_value(weapon,weapon_range_field,&range);float wanted=(float)farm_range_cm*0.01f;
 if(!finite_number(range)||range<=0||range>100){navigation_release();farm_state_set("Farm paused: invalid tool interaction range");return 0;}
 if(range>wanted)range=wanted;
 float search=(farm_options&8)?(float)farm_search_m:range;
 Vec3 origin;if(!world_position(camera,&origin)){navigation_release();farm_state_set("Farm paused: no camera position");return 0;}
 if(!farm_array_root||now-last_farm_refresh>=(performance_profile==PROFILE_ECO?6000u:4000u)){
  int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={farm_type,&no},*unsorted[]={farm_type,&inactive,&sort};
  Obj next=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);last_farm_refresh=now;
  if(next){GCHandle root=gchandle_new(next,0);if(root){if(farm_array_root)gchandle_free(farm_array_root);farm_array_root=root;}}
 }
 Obj resource=farm_target_root?gchandle_get_target(farm_target_root):0;Vec3 hit;
 if(resource&&(!alive(resource)||!farm_matches(resource,trees,ore)||farm_skipped(resource,now)||!farm_point(resource,&origin,&hit)||point_distance_sq(&hit,&origin)>search*search)){farm_clear_target();resource=0;}
 /* HasLoot reads the resource's local loot list. The ordinary client
    farming path does not gate on it; the server validates remaining loot. */
 Obj array=farm_array_root?gchandle_get_target(farm_array_root):0;
 if(!resource&&array){
  uint32_t count=array_length(array),header=array_object_header_size();farm_resources_seen=count;if(count>8192)count=8192;
  if(header>=24&&header<=128&&count){
   Obj *items=(Obj*)((unsigned char*)array+header);uint64_t deadline=clock_us()+650;unsigned budget=performance_profile==PROFILE_ECO?48u:96u;
   for(unsigned n=0;n<budget&&n<count&&clock_us()<deadline;++n){
    if(farm_cursor>=count)farm_cursor=0;
    Obj candidate=items[farm_cursor++];if(!alive(candidate)||!farm_matches(candidate,trees,ore)||farm_skipped(candidate,now))continue;
    Vec3 position;if(!world_position(candidate,&position))continue;
    if(point_distance_sq(&position,&origin)>(search+12.f)*(search+12.f))continue;
    Vec3 point;if(!farm_point(candidate,&origin,&point))continue;float square=point_distance_sq(&point,&origin);
    if(!finite_number(square)||square>search*search||square>=farm_best_square)continue;
    GCHandle root=gchandle_new(candidate,0);if(root){farm_clear_target();farm_target_root=root;farm_best_square=square;hit=point;resource=candidate;}
   }
  }
 }
 if(!resource){farm_timing_release();navigation_release();farm_state_set("Farm: searching for matching resources");return 0;}
 float square=point_distance_sq(&hit,&origin);
 if(!finite_number(square)){farm_clear_target();return 0;}
 farm_target_distance_cm=(DWORD)(__builtin_sqrtf(square)*100.f);
 BOOL moved=0;
 if(square>range*range*((farm_options&8)?0.90f:1.f)){
  farm_timing_release();
  if(!(farm_options&8)){farm_clear_target();farm_state_set("Farm: enable Walk to resources or move into tool range");return 0;}
  if(!navigation_available){farm_clear_target();farm_state_set("Farm paused: movement input methods unavailable");return 0;}
  if(!navigation_tick(local,&hit,resource)){farm_clear_target();return 0;}
  if(aim_available)moved=aim_move_to(local,camera,&hit,30,0.1f);
  farm_state_set("Farm: moving to resource");return moved;
 }
 navigation_release();farm_best_square=square;
 float requested_seconds=(float)interval*0.001f;farm_timing_apply(0,item,item_cooldown_field,requested_seconds);farm_timing_apply(1,weapon,swing_field,requested_seconds);farm_timing_apply(2,resource,farm_cooldown_field,requested_seconds);
 if(now<next_farm_attempt)return 0;
 Obj can=invoke(farm_can,resource,0);if(!can||!*(unsigned char*)object_unbox(can)){farm_state_set("Farm: waiting for resource cooldown");return 0;}
 int32_t efficiency=0;Obj name=0;field_get_value(item,item_efficiency_field,&efficiency);field_get_value(item,item_name_field,&name);Obj identity=invoke(net_identity,resource,0);
 if(efficiency>10000||!name||!alive(identity)){farm_state_set("Farm paused: invalid resource identity or tool data");return 0;}
 if(efficiency<1)efficiency=1; /* Same minimum as the reviewed client strike. */
 if(!aim_available){farm_state_set("Farm paused: camera steering unavailable");return 0;}moved=aim_move_to(local,camera,&hit,100,0.016667f);if(!moved)return 0;
 float cooldown=0,swing=0,resource_cooldown=0;field_get_value(item,item_cooldown_field,&cooldown);field_get_value(weapon,swing_field,&swing);field_get_value(resource,farm_cooldown_field,&resource_cooldown);
 float wait=(float)interval;if(finite_number(cooldown)&&cooldown*1000>wait)wait=cooldown*1000;if(finite_number(swing)&&swing*1000>wait)wait=swing*1000;if(finite_number(resource_cooldown)&&resource_cooldown*1000>wait)wait=resource_cooldown*1000;
 next_farm_attempt=now+(uint64_t)(wait+0.999f);
 void *args[]={identity,&hit,&efficiency,name};Obj ignored;
 if(invoke_checked(try_farm,weapon,args,&ignored)){++farm_attempts;farm_state_set("Farm: harvesting with equipped tool");}
 else {farm_available=0;farm_release();farm_state_set("Farm disabled after command exception");}
 return moved;
}
static void features_pause(BOOL finish){global_release();movement_input_active=0;pending_movement_toggle=approved_movement_toggle=0;unbreak_release();extras_release();visuals_release();movement_release();farm_release();research_release();rapid_release();melee_release();skin_release();if(finish||!hit_audio_active())hit_audio_release();noclip_release();silent_clear();if(finish)silent_remove();}
