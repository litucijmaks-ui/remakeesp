/* Reload/fall routes use the active local player. Durability follows the
   supplied reference's process-wide client loss block while its checkbox is on. */
static Method combat_reload;
static void *combat_reload_time;
static void *combat_fall_fields[4];
static uint64_t combat_next_reload,combat_last_y_time;
static float combat_last_y;
#include "tool_durability.h"
#include "reload_timing.h"
static DWORD combat_float_bits(float value){DWORD bits;__builtin_memcpy(&bits,&value,4);return bits;}
static void combat_release(void){
 reload_timing_release();combat_next_reload=combat_last_y_time=0;
}
static void resolve_combat(void *weapon,void *item){
 void *single=klass("System","Single"),*nothing=klass("System","Void");
 combat_reload_time=compatible_field(item,single,"reloadTime","reloadTime",0,SIZE_MAX,"Weapon reload delay");
 combat_reload=method(weapon,"CmdRequestReload",1);void *reload_args[]={klass("Mirror","NetworkConnectionToClient")};if(!compatible_method(combat_reload,nothing,reload_args,1,0))combat_reload=0;
 const char *names[]={"fallTime","maxFallDamage","minFallTime","maxFallTime"};for(unsigned i=0;i<4;++i)combat_fall_fields[i]=compatible_field(player_class,single,names[i],names[i],0,SIZE_MAX,names[i]);
 unbreak_resolve(item,single,nothing);
 logline(combat_reload?"Auto reload command resolved":"Auto reload command unavailable");
 logline(combat_durability_hook?"Unbreaking reference-style loss hook resolved":"Unbreaking durability hook unavailable");
}
static void combat_tick(Obj local,BOOL active){
 if(!active){combat_release();return;}
 DWORD flags=combat_options;Obj weapon=0,item=0;field_get_value(local,weapon_field,&weapon);if(alive(weapon))field_get_value(weapon,item_field,&item);
 reload_timing_tick(item,(flags&1u)&&combat_reload&&alive(weapon));
 if(native_faulted)return;
 uint64_t now=GetTickCount64();
 if((flags&1)&&combat_reload&&alive(weapon)&&alive(item)&&rapid_mag_field&&extra_mag_size&&rapid_ammo_field&&now>=combat_next_reload){
  int32_t ammo=0,size=0;Obj ammo_type=0;field_get_value(weapon,rapid_mag_field,&ammo);field_get_value(item,extra_mag_size,&size);field_get_value(item,rapid_ammo_field,&ammo_type);
  if(ammo<=0&&size>0&&size<=10000&&ammo_type){float delay=2.f;if(combat_reload_time)field_get_value(item,combat_reload_time,&delay);if(!finite_number(delay)||delay<0.f||delay>30.f)delay=2.f;
   combat_next_reload=now+(uint64_t)(delay*1000.f)+250;void *args[]={0};Obj ignored=0;const char *previous=invoke_context;invoke_context="Auto reload: CmdRequestReload";BOOL ok=invoke_checked(combat_reload,weapon,args,&ignored);invoke_context=previous;logline(ok?"Auto reload requested":"Auto reload invocation failed");
  }
 }else if(!(flags&1))combat_next_reload=0;
 if(native_faulted)return;
 if(flags&4){
  for(unsigned i=0;i<4;++i)if(combat_fall_fields[i])extra_write(i+1,local,combat_fall_fields[i],combat_float_bits(i<2?0.f:9999.f),0);
  Vec3 position;BOOL falling=0;if(world_position(local,&position)){if(combat_last_y_time&&now>combat_last_y_time&&now-combat_last_y_time<250){float velocity=(position.y-combat_last_y)*1000.f/(float)(now-combat_last_y_time);falling=finite_number(velocity)&&velocity<-9.f;}combat_last_y=position.y;combat_last_y_time=now;}
  if(falling&&extra_god)extra_write(5,local,extra_god,1,1);else extra_restore(&extra_writes[5]);
 }else {for(unsigned i=1;i<=5;++i)extra_restore(&extra_writes[i]);combat_last_y_time=0;}
}
