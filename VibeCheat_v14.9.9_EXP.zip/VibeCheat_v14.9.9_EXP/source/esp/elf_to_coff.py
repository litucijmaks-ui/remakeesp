"""Translate allocated AMD64 ELF relocatable sections into COFF for GNU PE ld.
Supports the relocation types emitted by this project's freestanding PIE build.
"""
import struct
from pathlib import Path

def convert(source, destination):
    b = Path(source).read_bytes()
    assert b[:7] == b'\x7fELF\x02\x01\x01'
    shoff = struct.unpack_from('<Q', b, 40)[0]
    shsize, shnum, shstr = struct.unpack_from('<HHH', b, 58)
    sections = [struct.unpack_from('<IIQQQQIIQQ', b, shoff+i*shsize) for i in range(shnum)]
    s = sections[shstr]
    names = b[s[4]:s[4]+s[5]]
    def cstr(data, at):
        return data[at:data.index(0, at)].decode()
    selected = [i for i,s in enumerate(sections) if s[2] & 2]
    index = {old: new+1 for new,old in enumerate(selected)}
    sym_index = next(i for i,s in enumerate(sections) if s[1] == 2)
    symsect = sections[sym_index]
    strsect = sections[symsect[6]]
    strings = b[strsect[4]:strsect[4]+strsect[5]]
    symbols = [struct.unpack_from('<IBBHQQ', b, at) for at in range(symsect[4], symsect[4]+symsect[5], 24)]
    kept = [i for i,s in enumerate(symbols) if i and (s[3] in index or s[3] == 0 or s[3] == 0xfff1)]
    syms = {old: new for new,old in enumerate(kept)}
    pool = bytearray(b'\0'*4)
    def longname(name):
        offset=len(pool);pool.extend(name.encode()+b'\0');return offset
    def symbol_name(name):
        return name.encode().ljust(8,b'\0') if len(name.encode()) <= 8 else struct.pack('<II',0,longname(name))
    raws = {i:bytearray(b[sections[i][4]:sections[i][4]+sections[i][5]]) if sections[i][1] != 8 else bytearray() for i in selected}
    relocs = {i:[] for i in selected}
    for s in sections:
        if s[1] != 4 or s[7] not in index:
            continue
        assert s[6] == sym_index
        for at in range(s[4], s[4]+s[5], 24):
            off, info, addend = struct.unpack_from('<QQq', b, at)
            typ=info&0xffffffff; symbol=info>>32
            if typ in (2,4):
                cofftype=4;size=4;value=addend+4
            elif typ==1:
                cofftype=1;size=8;value=addend
            elif typ in (10,11):
                cofftype=2;size=4;value=addend
            else:
                raise ValueError(f'Unsupported ELF relocation {typ}')
            raw=raws[s[7]]
            raw[off:off+size]=(value&((1<<(8*size))-1)).to_bytes(size,'little')
            relocs[s[7]].append(struct.pack('<IIH',off,syms[symbol],cofftype))
    payload=bytearray()
    headers=[]
    for i in selected:
        s=sections[i];name=cstr(names,s[0])
        encoded=name.encode().ljust(8,b'\0') if len(name.encode())<=8 else ('/'+str(longname(name))).encode().ljust(8,b'\0')
        assert len(encoded)==8
        rawpos=20+40*len(selected)+len(payload) if raws[i] else 0
        payload.extend(raws[i])
        relpos=20+40*len(selected)+len(payload) if relocs[i] else 0
        for r in relocs[i]:payload.extend(r)
        attrs=0x00500000
        attrs|=0x60000020 if s[2]&4 else (0xc0000080 if s[1]==8 else (0xc0000040 if s[2]&1 else 0x40000040))
        headers.append(encoded+struct.pack('<IIIIIIHHI',0,0,s[5],rawpos,relpos,0,len(relocs[i]),0,attrs))
    symbytes=bytearray()
    for i in kept:
        nameoff,info,other,sect,value,size=symbols[i]
        name=cstr(strings,nameoff) if nameoff else cstr(names,sections[sect][0])
        sec=index.get(sect,-1 if sect==0xfff1 else 0)
        symbytes.extend(symbol_name(name)+struct.pack('<IhHBB',value,sec,0x20 if info&15==2 else 0,2 if info>>4 else 3,0))
    struct.pack_into('<I',pool,0,len(pool))
    header=struct.pack('<HHIIIHH',0x8664,len(selected),0,20+40*len(selected)+len(payload),len(kept),0,0)
    Path(destination).write_bytes(header+b''.join(headers)+payload+symbytes+pool)

if __name__=='__main__':
    import sys
    convert(sys.argv[1],sys.argv[2])
