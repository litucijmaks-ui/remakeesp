/* Global Remake controls, sampled on the existing game callback. */
#include "global_profile.h"
static void *global_classes[G_COUNT],*global_fields[GF_COUNT];
static Method global_methods[GM_COUNT];
static Obj global_types[G_COUNT];
static BOOL global_bound;
static void *global_database_instance;
static BOOL global_work_active;
static unsigned global_craft_owned;
static uint64_t global_next_graphics,global_next_items,global_next_craft,global_next_scrap_scan,global_next_scrap_action;
static GCHandle global_items,global_barrels,global_drops,global_scrap_target;
static unsigned global_craft_cursor;
static BOOL global_scrap_is_drop;
static _Atomic(const char *) global_state="Global controls disabled";
static _Atomic(const char *) scrap_state="Scrap: disabled";
static _Atomic(const char *) scrap_last_activity="Scrap: not started";
static void scrap_state_set(const char *state){
 if(!equal(state,"Scrap: disabled")&&!equal(state,"Scrap: farm master off")&&!equal(state,"Scrap: paused for menu, focus or local player")&&!equal(state,"Scrap: paused for manual input"))scrap_last_activity=state;
 if(scrap_state!=state){scrap_state=state;logline(state);}
}
typedef struct {BOOL owned;Method get,set;float base,applied;BOOL integer;} GlobalValue;
static GlobalValue global_values[3];
typedef struct {GCHandle root;void *field;float base,applied;} GlobalCraftWrite;
static GlobalCraftWrite global_craft_writes[1024];
static void *global_class(const char *full){
 char ns[160],name[160];unsigned split=0,len=0;while(full[len]){if(full[len]=='.')split=len+1;++len;if(len>=159)return 0;}
 unsigned n=0;for(unsigned i=0;i+1<split;++i)ns[n++]=full[i];ns[n]=0;n=0;for(unsigned i=split;i<len;++i)name[n++]=full[i];name[n]=0;
 return klass(ns,name);
}
static BOOL global_type(const void *type,const char *name){
 void *actual=class_from_type(type);unsigned n=0;while(name[n])++n;
 if(n>2&&name[n-2]=='['&&name[n-1]==']'){char base[160];if(n-2>=sizeof(base)||!class_get_element_class)return 0;for(unsigned i=0;i<n-2;i++)base[i]=name[i];base[n-2]=0;return class_get_element_class(actual)==global_class(base);}
 return actual==global_class(name);
}
static void global_resolve(void){
 if(global_bound)return;global_bound=1;
 for(unsigned i=0;i<G_COUNT;i++){global_classes[i]=global_class(global_class_names[i]);if(global_classes[i])global_types[i]=type_get_object(class_get_type(global_classes[i]));}
 for(unsigned i=0;i<GF_COUNT;i++){
  const GlobalFieldSpec *s=&global_field_specs[i];void *f=global_classes[s->owner]?class_get_field_from_name(global_classes[s->owner],s->name):0;
  if(f&&!(field_get_flags(f)&16u)&&field_get_offset(f)==s->offset&&global_type(field_get_type(f),s->type))global_fields[i]=f;
 }
 for(unsigned i=0;i<GM_COUNT;i++){
  const GlobalMethodSpec *s=&global_method_specs[i];void *iterator=0;Method m=0;
  if(!global_classes[s->owner])continue;
  for(unsigned n=0;n<1024&&(m=class_get_methods(global_classes[s->owner],&iterator));n++){
   if(!equal(method_get_name(m),s->name)||method_get_param_count(m)!=(unsigned)s->count||!!(method_get_flags(m,0)&16u)!=s->is_static||!global_type(method_get_return_type(m),s->returns)||!aimkill_entry_matches(m,s->rva,s->prefix,24))continue;
   BOOL ok=1;for(int j=0;j<s->count;j++)if(!global_type(method_get_param(m,j),s->params[j]))ok=0;if(ok){global_methods[i]=m;break;}
  }
  if(!global_methods[i]){logline("Global binding missing:");logline(s->name);}
 }
 void *instance=global_classes[G_itemDatabase]?class_get_field_from_name(global_classes[G_itemDatabase],"Instance"):0;
 if(instance&&(field_get_flags(instance)&16u)&&field_get_offset(instance)==0&&global_type(field_get_type(instance),"ItemDatabase"))global_database_instance=instance;
 logline("Dump-backed global controls resolved");
}
static float global_get(Method get,BOOL integer){Obj box=invoke(get,0,0);if(!box)return 0;return integer?(float)*(int32_t*)object_unbox(box):*(float*)object_unbox(box);}
static void global_set(Method set,BOOL integer,float value){int32_t i=(int32_t)value;void *args[]={integer?(void*)&i:(void*)&value};invoke(set,0,args);}
static void global_graphics_release(void){
 for(unsigned i=0;i<3;i++){GlobalValue *s=&global_values[i];if(!s->owned)continue;
  if(__builtin_fabsf(global_get(s->get,s->integer)-s->applied)<.00001f)global_set(s->set,s->integer,s->base);s->owned=0;
 }
}
static void global_graphics(BOOL active,uint64_t now){
 if(!(custom_flags&VIBE_CUSTOM_POTATO)){global_graphics_release();return;}
 if(!active||now<global_next_graphics)return;global_next_graphics=now+1000;
 const int gets[]={GM_lightsGet,GM_lodGet,GM_textureGet},sets[]={GM_lightsSet,GM_lodSet,GM_textureSet};const float desired[]={0,.25f,3};
 for(unsigned i=0;i<3;i++){
  if(!global_methods[gets[i]]||!global_methods[sets[i]]){global_state="Potato graphics unavailable: accessor differs";continue;}
  GlobalValue *s=&global_values[i];s->get=global_methods[gets[i]];s->set=global_methods[sets[i]];s->integer=i!=1;
  float current=global_get(s->get,s->integer);if(!finite_number(current))continue;
  if(!s->owned||__builtin_fabsf(current-s->applied)>.00001f)s->base=current;
  if(__builtin_fabsf(current-desired[i])>.00001f)global_set(s->set,s->integer,desired[i]);s->applied=desired[i];s->owned=1;
 }
}
static void global_craft_release(void){
 if(!global_items&&!global_craft_owned)return;
 for(unsigned i=0;i<1024;i++){GlobalCraftWrite *s=&global_craft_writes[i];if(!s->root)continue;Obj o=gchandle_get_target(s->root);float v=0;
  if(o){field_get_value(o,s->field,&v);if(finite_number(v)&&__builtin_fabsf(v-s->applied)<.00001f)field_set_value(o,s->field,&s->base);}gchandle_free(s->root);*s=(GlobalCraftWrite){0};}
 if(global_items){gchandle_free(global_items);global_items=0;}global_craft_cursor=0;global_craft_owned=0;
}
static void global_craft_apply(Obj o,void *field){
 if(!o||!field)return;unsigned i=0;for(;i<1024;i++){GlobalCraftWrite *s=&global_craft_writes[i];if(!s->root||(gchandle_get_target(s->root)==o&&s->field==field))break;}if(i==1024)return;
 GlobalCraftWrite *s=&global_craft_writes[i];float v=0;field_get_value(o,field,&v);if(!finite_number(v)||v<=0||v>86400)return;
 if(!s->root){s->root=gchandle_new(o,0);if(!s->root)return;++global_craft_owned;s->field=field;s->base=s->applied=v;}else if(__builtin_fabsf(v-s->applied)>.00001f)s->base=v;
 float desired=s->base*100.f/(float)custom_craft_percent;if(desired<.1f)desired=.1f;if(desired>s->base)desired=s->base;if(__builtin_fabsf(v-desired)>.00001f)field_set_value(o,field,&desired);s->applied=desired;
}
static Obj global_find(int c,BOOL all){
 if(!global_types[c])return 0;
 if(all){void *args[]={global_types[c]};return global_methods[GM_findAll]?invoke(global_methods[GM_findAll],0,args):0;}
 int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={global_types[c],&no},*unsorted[]={global_types[c],&inactive,&sort};return find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);
}
static void global_craft(BOOL active,uint64_t now){
 /* The server owns RunQueue and TargetUnitFinished. Client Item timers do
    not accelerate completion and must not misrepresent a queued result. */
 (void)active;(void)now;global_craft_release();
}
static BOOL global_vec_equal(Vec3 a,Vec3 b){return __builtin_fabsf(a.x-b.x)<.00001f&&__builtin_fabsf(a.y-b.y)<.00001f&&__builtin_fabsf(a.z-b.z)<.00001f;}
#include "third_view.h"
#include "camera_controls.h"
static BOOL global_string_contains(Obj s,const char *needle){
 if(!s)return 0;const WCHAR *text=string_chars(s);int count=string_length(s);if(!text||count<1||count>128)return 0;
 for(int i=0;i<count;i++){unsigned j=0;while(needle[j]&&i+(int)j<count){unsigned c=text[i+j];if(c>='A'&&c<='Z')c+='a'-'A';if(c!=(unsigned char)needle[j])break;j++;}if(!needle[j])return 1;}return 0;
}
static BOOL global_name_contains(Obj o,const char *needle){return object_get_name_method&&global_string_contains(invoke(object_get_name_method,o,0),needle);}
static BOOL global_instance_of(Obj o,void *expected){if(!o||!expected)return 0;void *actual=object_get_class(o);return actual==expected||(class_is_assignable_from&&class_is_assignable_from(expected,actual));}
static BOOL global_scrap_drop(Obj o){
 if(global_database_instance&&global_fields[GF_dropItemId]&&global_methods[GM_itemById]){
  int32_t id=-1;Obj database=0;field_get_value(o,global_fields[GF_dropItemId],&id);field_static_get_value(global_database_instance,&database);
  if(id>=0&&alive(database)){void *args[]={&id};Obj item=invoke(global_methods[GM_itemById],database,args),name=0,definition=0;
   if(item&&global_instance_of(item,global_classes[G_item])){
    if(item_name_field)field_get_value(item,item_name_field,&name);if(global_string_contains(name,"scrap"))return 1;
    if(global_fields[GF_itemDefinition])field_get_value(item,global_fields[GF_itemDefinition],&definition);
    if(definition&&global_instance_of(definition,global_classes[G_itemData])&&global_fields[GF_itemShortName]){field_get_value(definition,global_fields[GF_itemShortName],&name);if(global_string_contains(name,"scrap"))return 1;}
   }
  }
 }
 if(global_name_contains(o,"scrap"))return 1;
 Obj t=invoke(component_transform,o,0);for(unsigned n=0;n<3&&alive(t)&&global_methods[GM_globalParent];n++){t=invoke(global_methods[GM_globalParent],t,0);if(alive(t)&&global_name_contains(t,"scrap"))return 1;}
 if(!global_methods[GM_componentChildren]||!global_types[G_scrapbag]||!global_fields[GF_scrapBagName])return 0;
 unsigned char no=0;void *args[]={global_types[G_scrapbag],&no};Obj bag=invoke(global_methods[GM_componentChildren],o,args),s=0;
 if(!alive(bag)||object_get_class(bag)!=global_classes[G_scrapbag])return 0;field_get_value(bag,global_fields[GF_scrapBagName],&s);if(!s)return 0;
 const WCHAR *text=string_chars(s);int n=string_length(s);if(!text||n>128)return 0;
 for(int i=0;i+5<=n;i++){const char *word="scrap";unsigned j=0;for(;j<5;j++){unsigned c=text[i+j];if(c>='A'&&c<='Z')c+=32;if(c!=(unsigned)word[j])break;}if(j==5)return 1;}return 0;
}

#include "scrap_farm.h"
static void global_release(void){camera_controls_release();global_graphics_release();global_craft_release();global_camera_release();global_scrap_release();global_work_active=0;}
static void global_tick(Obj local,Obj camera,BOOL active){
 if(!(custom_flags&VIBE_CUSTOM_GLOBAL_MASK)){if(global_work_active)global_release();return;}global_work_active=1;global_resolve();uint64_t now=GetTickCount64();global_graphics(active,now);global_craft(active,now);global_third(local,active,now);camera_controls_tick(local,active);(void)camera;
}
