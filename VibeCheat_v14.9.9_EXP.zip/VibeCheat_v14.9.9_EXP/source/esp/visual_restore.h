#include <stdint.h>
typedef struct {uintptr_t owner;unsigned mask;} VisualRestore;
enum {RESTORE_FOG=1,RESTORE_SKY=2};
static void visual_restore_queue(VisualRestore *state,uintptr_t owner,unsigned mask){
 if(!owner)return;
 if(state->owner!=owner){state->owner=owner;state->mask=0;}
 state->mask|=mask;
}
static unsigned visual_restore_take(VisualRestore *state,uintptr_t owner,int initialized){
 if(!state->mask||state->owner!=owner)return 0;
 unsigned mask=state->mask;state->owner=0;state->mask=0;return initialized?mask:0;
}
