#pragma once
#include <stdint.h>
#include <stddef.h>
static inline void vibe_scale_pcm16(unsigned char *data,size_t size,uint32_t volume){
 if(volume>100)volume=100;
 for(size_t i=0;i+1<size;i+=2){
  int32_t value=(int32_t)((uint32_t)data[i]|((uint32_t)data[i+1]<<8));if(value>=32768)value-=65536;
  value=value*(int32_t)volume/100;uint16_t result=(uint16_t)value;data[i]=(unsigned char)result;data[i+1]=(unsigned char)(result>>8);
 }
}
