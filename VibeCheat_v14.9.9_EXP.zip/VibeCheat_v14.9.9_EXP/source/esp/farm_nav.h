typedef struct {float x,y;} Vec2;
static Method external_setter,jump_setter,slot_item,slot_durability,hotbar_select,hotbar_changing,collider_enabled,collider_enable;
static void *external_field,*jump_field,*noclip_field,*controller_field,*local_hotbar_field,*hotbar_slots_field,*hotbar_index_field,*item_max_field,*item_loss_field;
static _Atomic BOOL navigation_available,tool_guard_available;
static BOOL navigation_jump_wrapped;
static _Atomic BOOL noclip_available;
static GCHandle navigation_root,noclip_root,noclip_collider_root;
static Vec2 navigation_base;
static unsigned char navigation_sprint,navigation_jump,noclip_base,noclip_collider_base;
static Vec3 navigation_last_position;
static uint64_t navigation_progress,next_navigation,tool_switch_wait;
static unsigned navigation_stalls;
static _Atomic(const char *) farm_state="Farm idle";
static Obj skipped_resources[16];static uint64_t skipped_until[16];static unsigned skipped_cursor;
static void farm_state_set(const char *value){if(farm_state!=value){farm_state=value;logline(value);}}
static void resolve_navigation(void *movement,void *item){
 void *hotbar=klass("OxideOld.Player","HotbarManager"),*slot=klass("","InventorySlot"),*collider=klass("UnityEngine","Collider");
 external_field=movement?class_get_field_from_name(movement,"externalMovementInput"):0;
 jump_field=movement?class_get_field_from_name(movement,"<JumpInput>k__BackingField"):0;
 external_setter=method(movement,"set_ExternalMovementInput",1);jump_setter=method(movement,"set_JumpInput",1);
 void *boolean=klass("System","Boolean"),*wrapped_bool=klass("OxideOld.AntiCheat","ObfuscatedBool"),*nothing=klass("System","Void");void *jargs[]={boolean},*jwargs[]={wrapped_bool};
 navigation_jump_wrapped=movement_wrapped&&compatible_field_type(jump_field,wrapped_bool,132u)&&compatible_method(jump_setter,nothing,jwargs,1,0)&&aimkill_entry_matches(jump_setter,PC_RVA_jumpSetter,pc_prefix_jumpSetter,sizeof(pc_prefix_jumpSetter));
 BOOL jump_valid=navigation_jump_wrapped||(compatible_field_type(jump_field,boolean,SIZE_MAX)&&compatible_method(jump_setter,nothing,jargs,1,0));
 navigation_available=external_field&&external_setter&&(movement_wrapped||movement_primitive)&&jump_valid&&transform_forward;
 noclip_field=movement?class_get_field_from_name(movement,"noclipEnabled"):0;controller_field=movement?class_get_field_from_name(movement,"characterController"):0;
 collider_enabled=method(collider,"get_enabled",0);collider_enable=method(collider,"set_enabled",1);
 noclip_available=noclip_field&&field_set_value&&controller_field&&collider_enabled&&collider_enable;
 local_hotbar_field=compatible_field(player_class,hotbar,"ϙ΅ǣƹͶʹ","ǭ˨̍ɭӒƈ",1,SIZE_MAX,"PlayerStatus hotbar");
 hotbar_slots_field=hotbar?class_get_field_from_name(hotbar,"slots"):0;hotbar_index_field=hotbar?class_get_field_from_name(hotbar,"selectedIndex"):0;
 slot_item=method(slot,"GetItem",0);slot_durability=method(slot,"GetDurability",0);
 hotbar_select=method(hotbar,"SelectSlot",1);hotbar_changing=method(hotbar,"get_IsChangingHeldItem",0);
 item_max_field=item?class_get_field_from_name(item,"maxDurability"):0;item_loss_field=item?class_get_field_from_name(item,"durabilityLossPerUse"):0;
 tool_guard_available=local_hotbar_field&&hotbar_slots_field&&hotbar_index_field&&slot_item&&hotbar_select&&hotbar_changing;
 logline(tool_guard_available?"Hotbar tool selection resolved":"Hotbar tool selection unavailable; see compatibility diagnostics");
}
static void noclip_release(void){
 if(noclip_root){Obj controller=gchandle_get_target(noclip_root);if(alive(controller))field_set_value(controller,noclip_field,&noclip_base);gchandle_free(noclip_root);noclip_root=0;}
 if(noclip_collider_root){Obj collider=gchandle_get_target(noclip_collider_root);if(alive(collider)){void *args[]={&noclip_collider_base};Obj ignored;invoke_checked(collider_enable,collider,args,&ignored);}gchandle_free(noclip_collider_root);noclip_collider_root=0;}
}
static void noclip_tick(Obj local,BOOL active){
 if(!active||!(move_options&4)||!noclip_available){noclip_release();return;}
 Obj controller=0;field_get_value(local,movement_field,&controller);
 if(!alive(controller)){noclip_release();return;}
 if(noclip_root&&gchandle_get_target(noclip_root)!=controller)noclip_release();
 if(!noclip_root){
  Obj collider=0;field_get_value(controller,controller_field,&collider);Obj enabled=alive(collider)?invoke(collider_enabled,collider,0):0;if(!enabled)return;
  noclip_collider_base=*(unsigned char*)object_unbox(enabled);field_get_value(controller,noclip_field,&noclip_base);
  noclip_root=gchandle_new(controller,0);noclip_collider_root=gchandle_new(collider,0);if(!noclip_root||!noclip_collider_root){noclip_release();return;}
  unsigned char yes=1;field_set_value(controller,noclip_field,&yes);logline("Native movement noclip enabled");
 }
}
static BOOL set_input(Obj controller,Vec2 input,unsigned char sprint,unsigned char jump){
 void *args[]={&input};Obj ignored;if(!invoke_checked(external_setter,controller,args,&ignored))return 0;
 if(!movement_set_sprint(controller,sprint))return 0;
 if(navigation_jump_wrapped)return movement_set_wrapped(jump_setter,movement_bool_ctor,controller,&jump);
 void *j[]={&jump};return invoke_checked(jump_setter,controller,j,&ignored);
}
static void navigation_release(void){
 if(navigation_root){Obj controller=gchandle_get_target(navigation_root);if(alive(controller))set_input(controller,navigation_base,navigation_sprint,navigation_jump);gchandle_free(navigation_root);navigation_root=0;}
 navigation_progress=next_navigation=0;navigation_stalls=0;
}
/* External steering belongs to automation. Stop it at arrival instead of
   restoring a stale direction captured during a preceding farm turn. */
static void navigation_stop(void){
 if(navigation_root){navigation_base=(Vec2){0,0};navigation_sprint=navigation_jump=0;}
 navigation_release();
}
static BOOL farm_skipped(Obj resource,uint64_t now){for(int i=0;i<16;++i)if(skipped_resources[i]==resource&&now<skipped_until[i])return 1;return 0;}
static void farm_skip(Obj resource,uint64_t now){unsigned i=skipped_cursor++%16;skipped_resources[i]=resource;skipped_until[i]=now+15000;}
static BOOL manual_movement(void){return GetAsyncKeyState('W')<0||GetAsyncKeyState('A')<0||GetAsyncKeyState('S')<0||GetAsyncKeyState('D')<0||GetAsyncKeyState(0x26)<0||GetAsyncKeyState(0x28)<0||GetAsyncKeyState(0x25)<0||GetAsyncKeyState(0x27)<0;}
/* Bounded steering with local obstacle checks. This is not a NavMesh route
   planner: unreachable nodes are skipped rather than pushed indefinitely. */
static BOOL navigation_tick_generic(Obj local,const Vec3 *target,Obj resource,Obj target_collider){
 if(!navigation_available)return 0;
 uint64_t now=GetTickCount64();if(now<next_navigation)return 1;
 next_navigation=now+100;
 Obj controller=0;field_get_value(local,movement_field,&controller);if(!alive(controller)){navigation_release();return 0;}
 if(navigation_root&&gchandle_get_target(navigation_root)!=controller)navigation_release();
 Vec3 position,forward;Obj transform=invoke(component_transform,local,0);
 if(!alive(transform)||!position_value(transform,&position)||!vector_value(transform_forward,transform,0,&forward)){navigation_release();return 0;}
 if(!navigation_root){field_get_value(controller,external_field,&navigation_base);if(!movement_read_sprint(controller,&navigation_sprint))return 0;
  if(navigation_jump_wrapped){MovementWrappedValue wrapped={0};field_get_value(controller,jump_field,&wrapped);if(!movement_value_call(2u,movement_bool_read,&wrapped,&navigation_jump))return 0;}
  else field_get_value(controller,jump_field,&navigation_jump);
  navigation_root=gchandle_new(controller,0);navigation_progress=now;navigation_last_position=position;if(!navigation_root)return 0;}
 float dx=target->x-position.x,dz=target->z-position.z,length=__builtin_sqrtf(dx*dx+dz*dz),flat=__builtin_sqrtf(forward.x*forward.x+forward.z*forward.z);
 if(!finite_number(length)||!finite_number(flat)||length<0.1f||flat<0.01f){navigation_release();return 0;}
 dx/=length;dz/=length;forward.x/=flat;forward.z/=flat;
 unsigned char jump=0;
 if(now-navigation_progress>=1000){
  float x=position.x-navigation_last_position.x,z=position.z-navigation_last_position.z;
  if(x*x+z*z<0.09f){++navigation_stalls;jump=1;}else navigation_stalls=0;
  navigation_progress=now;navigation_last_position=position;
  if(navigation_stalls>=4){farm_skip(resource,now);navigation_release();farm_state_set("Farm: unreachable resource skipped for 15 seconds");return 0;}
 }
 Vec3 start=position;start.y+=0.8f;Vec3 direction={dx,0,dz};PhysicsHit hit;BOOL found=0;
 if(trace_ray(&start,&direction,1.6f,-5,1,&hit,&found)&&found){
  Obj obstruction=hit_collider?invoke(hit_collider,&hit,0):0;
  if(obstruction&&obstruction==target_collider)found=0;
 }
 if(found){
  BOOL found_path=0;
  for(int side=0;side<2;++side){float sign=(navigation_stalls&1?1.f:-1.f)*(side? -1.f:1.f);Vec3 trial={dx*0.5f-dz*0.8660254f*sign,0,dz*0.5f+dx*0.8660254f*sign};
   if(trace_ray(&start,&trial,1.6f,-5,1,&hit,&found)&&!found){direction=trial;found_path=1;break;}
  }
  if(!found_path){direction=(Vec3){0,0,0};jump=navigation_stalls>0;}
 }
 Vec2 input={direction.x*forward.z-direction.z*forward.x,direction.x*forward.x+direction.z*forward.z};
 if(!set_input(controller,input,1,jump)){navigation_release();return 0;}return 1;
}
static BOOL navigation_tick(Obj local,const Vec3 *target,Obj resource){
 Obj collider=0;if(alive(resource)&&object_get_class(resource)==farm_class)field_get_value(resource,farm_collider_field,&collider);
 return navigation_tick_generic(local,target,resource,collider);
}
static BOOL tool_matches(Obj item){
 if(!alive(item))return 0;
 unsigned char trees=0,ore=0;field_get_value(item,item_tree_field,&trees);field_get_value(item,item_ore_field,&ore);
 return (trees&&(farm_options&2))||(ore&&(farm_options&4));
}
static BOOL same_tool_item(Obj slot_item_,Obj equipped){
 if(slot_item_==equipped)return slot_item_!=0;
 if(!item_id_field||!alive(slot_item_)||!alive(equipped))return 0;
 int32_t a=-1,b=-2;field_get_value(slot_item_,item_id_field,&a);field_get_value(equipped,item_id_field,&b);
 return a>=0&&a==b;
}
static BOOL farm_prepare_tool(Obj local,Obj equipped){
 if(!(farm_options&16)){if(tool_matches(equipped))return 1;farm_state_set("Farm paused: equip a tool matching Trees/Ore");return 0;}
 if(!tool_guard_available){farm_state_set("Farm paused: hotbar tool selection unavailable");return 0;}
 Obj hotbar=0;field_get_value(local,local_hotbar_field,&hotbar);if(!alive(hotbar)){farm_state_set("Farm paused: local hotbar unavailable");return 0;}
 Obj changing=invoke(hotbar_changing,hotbar,0);if(!changing||*(unsigned char*)object_unbox(changing)||GetTickCount64()<tool_switch_wait)return 0;
 Obj array=0;int32_t selected=-1;field_get_value(hotbar,hotbar_slots_field,&array);field_get_value(hotbar,hotbar_index_field,&selected);
 if(!array)return 0;
 uint32_t count=array_length(array),header=array_object_header_size();if(count>32||header<24||header>128)return 0;
 Obj *slots=(Obj*)((unsigned char*)array+header);
 if(selected>=0&&(uint32_t)selected<count&&alive(slots[selected])){
  Obj item=invoke(slot_item,slots[selected],0);if(same_tool_item(item,equipped)&&tool_matches(equipped)&&tool_matches(item))return 1;
 }
 if(farm_options&16)for(uint32_t i=0;i<count;++i){
  if((int32_t)i==selected||!alive(slots[i]))continue;
  Obj item=invoke(slot_item,slots[i],0);
  if(!tool_matches(item))continue;
  int32_t index=(int32_t)i;void *args[]={&index};Obj ignored;
  if(invoke_checked(hotbar_select,hotbar,args,&ignored)){tool_switch_wait=GetTickCount64()+1000;farm_state_set("Farm: switching to a usable hotbar tool");}return 0;
 }
 farm_state_set("Farm paused: equip a matching tool in the hotbar");return 0;
}
