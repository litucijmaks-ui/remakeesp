/* Reference DLL RVA 0x5543B..0x5553E clears Shaker offsets and its live
   shake list. Bind those fields to the local weapon's Shaker, never Item data. */
static void *recoil_weapon_shaker,*recoil_movement_shaker,*recoil_position,*recoil_rotation,*recoil_instances;
static Method recoil_clear;
static GCHandle recoil_root;
static BOOL recoil_available,recoil_hook_installed;
static void (ABI *recoil_original_late)(Obj,Method);
extern DWORD ABI VibeCreateNativeHook(void *,void *,void **);
static void recoil_release(void){if(recoil_root)gchandle_free(recoil_root);recoil_root=0;}
static void recoil_clear_shake(Obj shaker){
 if(!recoil_available||native_faulted||!shaker)return;
 Vec3 zero={0};Obj instances=0,ignored=0;
 field_get_value(shaker,recoil_instances,&instances);
 if(instances){const char *previous=invoke_context;invoke_context="No recoil: Shaker list Clear";invoke_checked(recoil_clear,instances,0,&ignored);invoke_context=previous;}
 if(!native_faulted){field_set_value(shaker,recoil_position,&zero);field_set_value(shaker,recoil_rotation,&zero);}
}
static void ABI recoil_late_proxy(Obj shaker,Method info){
 if(ready&&!native_faulted&&running&&!stop_requested&&focused&&!menu_open&&!cursor_wanted&&(rapid_options&16u)&&GetCurrentThreadId()==game_thread_id&&recoil_root&&gchandle_get_target(recoil_root)==shaker)recoil_clear_shake(shaker);
 recoil_original_late(shaker,info);
}
static void resolve_recoil(void *weapon){
 void *shaker=klass("OxideOld.Game","Shaker"),*vector=klass("UnityEngine","Vector3"),*movement=klass("OxideOld.DynamicPlayer","MovementController");
 recoil_weapon_shaker=compatible_field(weapon,shaker,PC_FIELD_weaponShaker,"Ш҈ѸȞĴѬ",1,SIZE_MAX,"Local weapon Shaker");
 recoil_movement_shaker=compatible_field(movement,shaker,PC_FIELD_movementShaker,"˰ωĦ̊ȱͨ",1,SIZE_MAX,"Local camera Shaker");
 recoil_position=compatible_field(shaker,vector,PC_FIELD_shakerPosition,"m_PositionAddShake",0,SIZE_MAX,"Shaker position offset");
 recoil_rotation=compatible_field(shaker,vector,PC_FIELD_shakerRotation,"m_RotationAddShake",0,SIZE_MAX,"Shaker rotation offset");
 recoil_instances=shaker?class_get_field_from_name(shaker,PC_FIELD_shakerInstances):0;
 if(recoil_instances&&(field_get_flags(recoil_instances)&0x10u))recoil_instances=0;
 recoil_clear=recoil_instances?method(class_from_type(field_get_type(recoil_instances)),"Clear",0):0;
 if(!compatible_signature(recoil_clear,0,0))recoil_clear=0;
 recoil_available=field_set_value&&recoil_weapon_shaker&&recoil_position&&recoil_rotation&&recoil_instances&&recoil_clear;
 if(recoil_available&&!recoil_hook_installed){
  Method late=method(shaker,"LateUpdate",0);void *entry=late?*(void *const*)late:0;HMODULE module=GetModuleHandleA("GameAssembly.dll");
  if(module&&compatible_signature(late,0,0)){
   const unsigned char *base=module;uint32_t pe=*(const uint32_t*)(base+60);
   if(pe<4096&&*(const uint32_t*)(base+pe)==0x4550){uint32_t size=*(const uint32_t*)(base+pe+80);
    if((uintptr_t)entry>(uintptr_t)base&&(uintptr_t)entry<(uintptr_t)base+size){DWORD error=VibeCreateNativeHook(entry,recoil_late_proxy,(void**)&recoil_original_late);recoil_hook_installed=!error;if(error)log_number("Shaker hook status=",error);}
   }
  }
 }
 /* No asynchronous field rewriting fallback: reset immediately before the
    original local Shaker update, so its transform sees the cleared impulses. */
 recoil_available=recoil_available&&recoil_hook_installed;
 logline(recoil_available?"No recoil: local Shaker pre-LateUpdate installed; weapon recoilForce unchanged":"No recoil unavailable: Shaker binding/hook missing");
}
static void recoil_tick(Obj local,BOOL active){
 if(!active||!(rapid_options&16u)||!recoil_available){recoil_release();return;}
 Obj weapon=0,shaker=0;if(weapon_field)field_get_value(local,weapon_field,&weapon);
 if(alive(weapon))field_get_value(weapon,recoil_weapon_shaker,&shaker);
 if(!alive(shaker)&&movement_field&&recoil_movement_shaker){Obj movement=0;field_get_value(local,movement_field,&movement);if(alive(movement))field_get_value(movement,recoil_movement_shaker,&shaker);}
 if(!alive(shaker)){recoil_release();return;}
 if(recoil_root&&gchandle_get_target(recoil_root)!=shaker)recoil_release();
 if(!recoil_root)recoil_root=gchandle_new(shaker,0);
}
