#pragma once
/* Unity Rect is x, y, width, height; derive the complete pixel canvas from
   the normalized camera viewport, including partial viewports and DPI scaling. */
typedef struct {float x,y,w,h;} ProjectionRect;
static inline int projection_canvas(const ProjectionRect *pixels,const ProjectionRect *viewport,int *width,int *height){
 if(!__builtin_isfinite(pixels->x)||!__builtin_isfinite(pixels->y)||!__builtin_isfinite(pixels->w)||!__builtin_isfinite(pixels->h)||!__builtin_isfinite(viewport->x)||!__builtin_isfinite(viewport->y)||!__builtin_isfinite(viewport->w)||!__builtin_isfinite(viewport->h)||pixels->w<=0||pixels->h<=0||viewport->w<=0||viewport->h<=0||viewport->w>1.001f||viewport->h>1.001f)return 0;
 float w=pixels->w/viewport->w,h=pixels->h/viewport->h;
 if(w<64||h<64||w>32768||h>32768||__builtin_fabsf(pixels->x-viewport->x*w)>1.5f||__builtin_fabsf(pixels->y-viewport->y*h)>1.5f)return 0;
 *width=(int)(w+0.5f);*height=(int)(h+0.5f);return 1;
}
