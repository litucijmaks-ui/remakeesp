/* Refresh from the already rooted player roster on the actual shot callback.
   No object discovery, movement or additional shot is performed here. */
static _Atomic uint64_t silent_live_refreshes,silent_no_target;
static _Atomic uint64_t silent_fov_rejects,silent_los_rejects,silent_budget_exhausted;
static BOOL silent_refresh_shot_target(Obj weapon,const Vec3 *shot_origin,Vec3 *resolved_origin){
 if(!shot_origin||!resolved_origin||!finite_number(shot_origin->x)||!finite_number(shot_origin->y)||!finite_number(shot_origin->z)){silent_clear();return 0;}
 if(!player_array_handle){silent_clear();return 0;}
 Obj array=gchandle_get_target(player_array_handle);if(!array){silent_clear();return 0;}
 uint32_t count=array_length(array),header=array_object_header_size();
 if(count>8192||header<24||header>128){silent_clear();return 0;}
 Obj local=0,current=0,retained=silent_player_root?gchandle_get_target(silent_player_root):0;BOOL retained_present=0;
 Obj *players=(Obj*)((unsigned char*)array+header);
 for(unsigned i=0;i<count;i++){if(players[i]==cached_local_key)local=players[i];if(retained&&players[i]==retained)retained_present=1;}
 if(!gameplay_ready(local)){silent_clear();return 0;}
 field_get_value(local,weapon_field,&current);if(current!=weapon){silent_clear();return 0;}
 Obj camera=invoke(player_camera,local,0);if(!alive(camera)){silent_clear();return 0;}
 Vec3 origin=*shot_origin;third_shot_origin(camera,&origin);*resolved_origin=origin;
 if(!silent_sync_physics()){silent_clear();return 0;}
 AimSelection best={0};best.score=(float)aim_fov_px*aim_fov_px;
 uint32_t allowed=aim_joint_mask(aim_point);
 uint64_t deadline=clock_us()+4000;
 /* Always examine the existing lock first, then rotate the bounded roster. */
 static unsigned cursor;
 for(unsigned n=0;n<count+1&&n<65&&clock_us()<deadline;n++){
  if(cursor>=count)cursor=0;Obj p=n?players[cursor++]:(retained_present?retained:0);
  if(p==local||!alive(p))continue;unsigned char dead=1;field_get_value(p,dead_field,&dead);if(dead)continue;
  for(int j=0;j<JOINT_COUNT;j++)if(allowed&(1u<<j)){
   Obj bone=skeleton_joint_transform(p,j);Vec3 points[8],world={0},screen;unsigned candidates=silent_candidate_points(p,bone,&origin,points);BOOL have=0;float score=0;
   unsigned probe_limit=performance_profile==PROFILE_ECO?6u:9u;if(candidates>probe_limit)candidates=probe_limit;
   for(unsigned k=0;k<candidates;k++){
    world=points[k];
    float dx=world.x-origin.x,dy=world.y-origin.y,dz=world.z-origin.z,range=dx*dx+dy*dy+dz*dz;
    if(!finite_number(range)||range>(float)range_max_m*range_max_m)continue;
    if(!project_value(camera,&world,&screen)||!finite_number(screen.x)||!finite_number(screen.y)||!finite_number(screen.z)||screen.z<=0)continue;
    float x=screen.x-source_width*.5f,y=screen.y-source_height*.5f;score=x*x+y*y;
    if(!finite_number(score)||score>(float)aim_fov_px*aim_fov_px){++silent_fov_rejects;continue;}
    if(best.player&&score*(p==aim_target_key?.85f:1.f)>=best.score)continue;
    if((aim_options&4u)&&!visibility_check_point(p,&origin,&world)){++silent_los_rejects;continue;}
    have=1;break;
   }
   if(!have)continue;
   if(p==aim_target_key)score*=.85f;
   if(best.player&&score>=best.score)continue;
   best.player=p;best.joint_index=j;best.score=score;
  }
 }
 if(clock_us()>=deadline)++silent_budget_exhausted;
 if(!best.player){++silent_no_target;silent_clear();return 0;}
 silent_select(local,camera,&best);if(!silent_sample_us)return 0;
 ++silent_live_refreshes;return 1;
}
