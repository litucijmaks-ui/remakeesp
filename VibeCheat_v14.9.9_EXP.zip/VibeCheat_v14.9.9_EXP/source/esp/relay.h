/* Win64 reserves at 64 KiB boundaries. Keep a rel32-safe margin around the
   full signed displacement range; the relay entry is at page + 64. Search
   cursors survive updates, so a busy address space cannot disable Silent
   just because one frame's query/time budget was used up. */
#define RELAY_GRANULARITY ((uintptr_t)65536)
#define RELAY_REACH ((uintptr_t)0x7fff0000)
#define RELAY_QUERY_BUDGET 32u
#define RELAY_TIME_BUDGET_US 350u
#define RELAY_RETRY_US UINT64_C(2000000)
typedef struct {
 uintptr_t entry,lower,upper,cursor[2];
 uint64_t retry_after;
 unsigned side;
 BOOL exhausted_notified;
 _Atomic BOOL pending;
 _Atomic DWORD probes,last_error;
} RelaySearch;
static RelaySearch silent_relay_search;
static uintptr_t relay_align_up(uintptr_t value){
 if(value>UINTPTR_MAX-(RELAY_GRANULARITY-1))return 0;
 return (value+RELAY_GRANULARITY-1)&~(RELAY_GRANULARITY-1);
}
static uintptr_t relay_candidate(const RelaySearch *search,uintptr_t value){
 return value>=search->lower&&value<=search->upper?value:0;
}
static void relay_restart(RelaySearch *search){
 uintptr_t anchor=search->entry&~(RELAY_GRANULARITY-1);
 search->cursor[0]=relay_candidate(search,anchor>=RELAY_GRANULARITY?anchor-RELAY_GRANULARITY:0);
 search->cursor[1]=relay_candidate(search,anchor<=UINTPTR_MAX-RELAY_GRANULARITY?anchor+RELAY_GRANULARITY:0);
 search->side=0;
}
static unsigned char *relay_allocate(RelaySearch *search,unsigned char *entry){
 uintptr_t address=(uintptr_t)entry;
 if(search->entry!=address){
  search->entry=address;
  search->lower=relay_align_up(address>RELAY_REACH?address-RELAY_REACH:RELAY_GRANULARITY);
  search->upper=(address<UINTPTR_MAX-RELAY_REACH?address+RELAY_REACH:UINTPTR_MAX-4095)&~(RELAY_GRANULARITY-1);
  search->retry_after=0;search->exhausted_notified=0;search->probes=0;search->last_error=0;search->pending=1;
  relay_restart(search);
  logline("Silent relay search started; bounded queries across rel32 range");
 }
 uint64_t begin=clock_us();
 search->pending=1;
 if(begin<search->retry_after)return 0;
 search->retry_after=0;
 if(!search->cursor[0]&&!search->cursor[1])relay_restart(search);
 for(unsigned n=0;n<RELAY_QUERY_BUDGET;++n){
  if(n&&clock_us()-begin>=RELAY_TIME_BUDGET_US)break;
  unsigned side=search->side;search->side^=1;
  if(!search->cursor[side])side^=1;
  uintptr_t candidate=search->cursor[side];if(!candidate)break;
  MEMORY_BASIC_INFORMATION region;zeromem(&region,sizeof(region));++search->probes;
  if(VirtualQuery((void*)candidate,&region,sizeof(region))!=sizeof(region)){
   search->last_error=GetLastError();search->cursor[side]=0;continue;
  }
  uintptr_t base=(uintptr_t)region.base;
  if(!region.region_size||base>candidate||region.region_size>UINTPTR_MAX-base||candidate-base>=region.region_size){
   search->cursor[side]=0;continue;
  }
  uintptr_t end=base+region.region_size;
  uintptr_t next=side?relay_align_up(end):(base?(base-1)&~(RELAY_GRANULARITY-1):0);
  if(region.state==0x10000u){
   unsigned char *page=end-candidate>=4096?VirtualAlloc((void*)candidate,4096,0x3000,4):0;
   if(page){search->pending=0;search->last_error=0;return page;}
   DWORD error=end-candidate>=4096?GetLastError():0,previous=search->last_error;
   if(error)search->last_error=error;
   /* An allocation race at one hint must not skip an entire free region.
      Commit-limit failures instead pause retries, retaining this hint. */
   if(error==8||error==1455){
    search->retry_after=clock_us()+RELAY_RETRY_US;
    if(previous!=error){logline("Silent relay allocation postponed; Windows memory pressure");log_number("Silent relay Windows error=",error);}
    return 0;
   }
   next=side?(candidate<=UINTPTR_MAX-RELAY_GRANULARITY?candidate+RELAY_GRANULARITY:0):(candidate>=RELAY_GRANULARITY?candidate-RELAY_GRANULARITY:0);
  }
  if(next&&(side?next<=candidate:next>=candidate))next=0;
  search->cursor[side]=relay_candidate(search,next);
 }
 if(!search->cursor[0]&&!search->cursor[1]){
  search->retry_after=clock_us()+RELAY_RETRY_US;
  if(!search->exhausted_notified){search->exhausted_notified=1;logline("Silent relay search waiting for free address space; automatic retry enabled");log_number("Silent relay Windows error=",search->last_error);}
 }
 return 0;
}
