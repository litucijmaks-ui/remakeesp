/* Own only the local world's FOV and the separate first-person FOV. Calls run
   on the existing Unity callback; no aiming/model/projectile pose is changed. */
#include "camera_math.h"
#include "camera_profile.h"
typedef struct {GCHandle root;float base,applied;BOOL written;} CameraFovState;
static CameraFovState camera_world_fov,camera_hands;
static Method camera_fov_get,camera_fov_set;
static BOOL camera_fov_tried,camera_world_active;
static _Atomic BOOL camera_zoom_held;
static _Atomic uint64_t camera_fov_frames;
static _Atomic DWORD camera_effective_fov_tenths;
static BOOL camera_read_fov(Obj o,float *out){
 Obj result=0;if(!alive(o)||!camera_fov_get||!invoke_checked(camera_fov_get,o,0,&result)||!result)return 0;
 void *value=object_unbox(result);if(!value)return 0;*out=*(float*)value;
 return finite_number(*out)&&*out>=1.f&&*out<179.f;
}
static BOOL camera_write_fov(Obj o,float value){Obj ignored=0;void *args[]={&value};return camera_fov_set&&invoke_checked(camera_fov_set,o,args,&ignored);}
static void camera_fov_restore(CameraFovState *s){
 Obj camera=s->root?gchandle_get_target(s->root):0;float current;
 if(s->written&&camera_read_fov(camera,&current)&&__builtin_fabsf(current-s->applied)<.001f)camera_write_fov(camera,s->base);
 s->written=0;
}
static void camera_fov_release(CameraFovState *s){
 camera_fov_restore(s);
 if(s->root)gchandle_free(s->root);*s=(CameraFovState){0};
}
static void camera_controls_release(void){camera_world_active=0;camera_zoom_held=0;camera_effective_fov_tenths=0;camera_fov_release(&camera_world_fov);}
static void hands_camera_release(void){camera_fov_release(&camera_hands);}
static BOOL hands_camera_has_roots(void){return camera_hands.root!=0;}
static BOOL camera_fov_resolve(void){
 if(camera_fov_tried)return camera_fov_get&&camera_fov_set;camera_fov_tried=1;
 void *camera=klass("UnityEngine","Camera"),*single=klass("System","Single"),*nothing=klass("System","Void"),*params[]={single};
 camera_fov_get=method(camera,"get_fieldOfView",0);camera_fov_set=method(camera,"set_fieldOfView",1);
 if(!compatible_method(camera_fov_get,single,0,0,0)||!aimkill_entry_matches(camera_fov_get,PC_CAMERA_FOV_GET,pc_camera_fov_get_prefix,24))camera_fov_get=0;
 if(!compatible_method(camera_fov_set,nothing,params,1,0)||!aimkill_entry_matches(camera_fov_set,PC_CAMERA_FOV_SET,pc_camera_fov_set_prefix,24))camera_fov_set=0;
 global_resolve();
 if(!global_fields[GF_playerMovement]||!global_fields[GF_viewController]||!global_fields[GF_worldCamera]||!global_fields[GF_weaponCamera])camera_fov_get=camera_fov_set=0;
 hands_available=camera_fov_get&&camera_fov_set;
 logline(hands_available?"Camera FOV and separate viewmodel FOV verified":"Camera FOV unavailable: method/profile differs");
 return hands_available;
}
static BOOL camera_pair(Obj local,Obj *world,Obj *hands){
 Obj movement=0,controller=0;*world=*hands=0;if(!alive(local))return 0;
 field_get_value(local,global_fields[GF_playerMovement],&movement);if(!alive(movement))return 0;
 field_get_value(movement,global_fields[GF_viewController],&controller);if(!alive(controller))return 0;
 field_get_value(controller,global_fields[GF_worldCamera],world);field_get_value(controller,global_fields[GF_weaponCamera],hands);
 return alive(*world);
}
static BOOL camera_fov_bind(CameraFovState *s,Obj camera,float *current){
 if(s->root&&gchandle_get_target(s->root)!=camera)camera_fov_release(s);
 if(!camera_read_fov(camera,current))return 0;
 if(!s->root){s->root=gchandle_new(camera,0);if(!s->root)return 0;s->base=s->applied=*current;}
 if(!s->written||__builtin_fabsf(*current-s->applied)>=.001f)s->base=*current;
 return 1;
}
static void camera_fov_apply(CameraFovState *s,Obj camera,float current,float desired){
 if(__builtin_fabsf(current-desired)<.001f){s->applied=desired;return;}
 if(camera_write_fov(camera,desired)){s->applied=desired;s->written=1;}
}
static void camera_controls_frame(Obj camera){
 if((visual_options&VISUAL_HANDS)&&!(custom_flags&VIBE_CUSTOM_THIRD)&&gameplay_ready(cached_local_key)){
  Obj world,hands;if(camera_pair(cached_local_key,&world,&hands)&&world==camera)hands_camera_tick(cached_local_key,1);
 }
 if(!camera_world_active||!camera_world_fov.root||camera!=gchandle_get_target(camera_world_fov.root))return;
 if(menu_open||cursor_wanted||!focused||!running||stop_requested||!gameplay_ready(cached_local_key)){camera_controls_release();return;}
 DWORD flags=custom_flags;BOOL zoom=(flags&VIBE_CUSTOM_ZOOM)&&custom_zoom_key&&GetAsyncKeyState((int32_t)custom_zoom_key)<0;
 if(!(flags&VIBE_CUSTOM_CAMERA_FOV)&&!zoom){camera_zoom_held=0;camera_effective_fov_tenths=0;camera_fov_restore(&camera_world_fov);return;}
 float current;if(!camera_fov_bind(&camera_world_fov,camera,&current))return;
 float desired=(flags&VIBE_CUSTOM_CAMERA_FOV)?(float)custom_camera_fov_deg:camera_world_fov.base;
 if(zoom)desired=camera_zoom_fov(desired,custom_zoom_percent);
 camera_fov_apply(&camera_world_fov,camera,current,desired);camera_zoom_held=zoom;
 camera_effective_fov_tenths=(DWORD)(desired*10.f);++camera_fov_frames;
}
static void camera_controls_tick(Obj local,BOOL active){
 if(!active||menu_open||cursor_wanted||!(custom_flags&VIBE_CUSTOM_CAMERA_MASK)){camera_controls_release();return;}
 if(!camera_fov_resolve())return;
 Obj world,hands;if(!camera_pair(local,&world,&hands)){camera_controls_release();return;}
 float current;if(!camera_fov_bind(&camera_world_fov,world,&current)){camera_controls_release();return;}
 camera_world_active=1;camera_controls_frame(world);
}
static void hands_camera_tick(Obj local,BOOL active){
 if(!active||menu_open||cursor_wanted||!focused||!running||stop_requested||(custom_flags&VIBE_CUSTOM_THIRD)){hands_camera_release();return;}
 if(!camera_fov_resolve())return;
 Obj world,hands;if(!camera_pair(local,&world,&hands)||!alive(hands)||hands==world){hands_camera_release();return;}
 float current;if(!camera_fov_bind(&camera_hands,hands,&current)){hands_camera_release();return;}
 float desired=camera_hands_fov(camera_hands.base,hands_distance_cm);
 camera_fov_apply(&camera_hands,hands,current,desired);
}
