/* Actual Transform joints, discovered once per model and held in rooted managed
   arrays. No synthetic stick figure. Unity calls remain
   on its window thread. */
enum {J_HEAD,J_NECK,J_CHEST,J_SPINE,J_HIPS,J_LARM,J_LFOREARM,J_LHAND,
 J_RARM,J_RFOREARM,J_RHAND,J_LTHIGH,J_LCALF,J_LFOOT,J_RTHIGH,J_RCALF,J_RFOOT,J_LSHOULDER,J_RSHOULDER};
#define SKELETON_CACHE_COUNT 32
#define SKELETON_QUEUE_COUNT 256
typedef struct {char name[24];unsigned char joint,priority;} BoneAlias;
static const BoneAlias bone_aliases[]={
 {"head",J_HEAD,30},{"head01",J_HEAD,20},{"skull",J_HEAD,20},
 {"neck",J_NECK,30},{"neck1",J_NECK,20},{"neck01",J_NECK,20},
 {"spine2",J_CHEST,20},{"spine02",J_CHEST,20},{"spine3",J_CHEST,30},{"spine03",J_CHEST,30},{"chest",J_CHEST,25},{"upperchest",J_CHEST,35},
 {"spine",J_SPINE,10},{"spine1",J_SPINE,20},{"spine01",J_SPINE,20},{"spinelower",J_SPINE,10},
 {"hips",J_HIPS,30},{"pelvis",J_HIPS,30},
 {"leftarm",J_LARM,30},{"leftupperarm",J_LARM,30},{"upperarml",J_LARM,30},{"lupperarm",J_LARM,30},{"larm",J_LARM,20},
 {"leftforearm",J_LFOREARM,30},{"leftlowerarm",J_LFOREARM,30},{"lowerarml",J_LFOREARM,30},{"forearml",J_LFOREARM,30},{"lforearm",J_LFOREARM,30},
 {"lefthand",J_LHAND,30},{"handl",J_LHAND,30},{"lhand",J_LHAND,30},{"leftwrist",J_LHAND,20},
 {"rightarm",J_RARM,30},{"rightupperarm",J_RARM,30},{"upperarmr",J_RARM,30},{"rupperarm",J_RARM,30},{"rarm",J_RARM,20},
 {"rightforearm",J_RFOREARM,30},{"rightlowerarm",J_RFOREARM,30},{"lowerarmr",J_RFOREARM,30},{"forearmr",J_RFOREARM,30},{"rforearm",J_RFOREARM,30},
 {"righthand",J_RHAND,30},{"handr",J_RHAND,30},{"rhand",J_RHAND,30},{"rightwrist",J_RHAND,20},
 {"leftupleg",J_LTHIGH,30},{"leftupperleg",J_LTHIGH,30},{"leftthigh",J_LTHIGH,30},{"thighl",J_LTHIGH,30},{"lthigh",J_LTHIGH,30},
 {"leftleg",J_LCALF,30},{"leftlowerleg",J_LCALF,30},{"leftcalf",J_LCALF,30},{"calfl",J_LCALF,30},{"lcalf",J_LCALF,30},
 {"leftfoot",J_LFOOT,30},{"footl",J_LFOOT,30},{"lfoot",J_LFOOT,30},{"leftankle",J_LFOOT,20},
 {"rightupleg",J_RTHIGH,30},{"rightupperleg",J_RTHIGH,30},{"rightthigh",J_RTHIGH,30},{"thighr",J_RTHIGH,30},{"rthigh",J_RTHIGH,30},
 {"rightleg",J_RCALF,30},{"rightlowerleg",J_RCALF,30},{"rightcalf",J_RCALF,30},{"calfr",J_RCALF,30},{"rcalf",J_RCALF,30},
 {"rightfoot",J_RFOOT,30},{"footr",J_RFOOT,30},{"rfoot",J_RFOOT,30},{"rightankle",J_RFOOT,20},
 {"leftshoulder",J_LSHOULDER,30},{"shoulderl",J_LSHOULDER,30},{"lclavicle",J_LSHOULDER,30},{"claviclel",J_LSHOULDER,30},
 {"rightshoulder",J_RSHOULDER,30},{"shoulderr",J_RSHOULDER,30},{"rclavicle",J_RSHOULDER,30},{"clavicler",J_RSHOULDER,30}
};
static BOOL text_prefix(const char *s,const char *prefix){while(*prefix){if(*s++!=*prefix++)return 0;}return 1;}
static int match_bone_name(const WCHAR *input,int count,unsigned char *priority){
 char name[64];int start=0,n=0;
 for(int i=0;i<count;++i)if(input[i]==':')start=i+1;
 for(int i=start;i<count&&n<63;++i){unsigned c=input[i];if(c>='A'&&c<='Z')c+=32;if((c>='a'&&c<='z')||(c>='0'&&c<='9'))name[n++]=(char)c;}
 name[n]=0;const char *s=name;
 if(text_prefix(s,"mixamorig"))s+=9;
 else if(text_prefix(s,"bip001"))s+=6;
 else if(text_prefix(s,"bip01"))s+=5;
 else if(text_prefix(s,"bip"))s+=3;
 else if(text_prefix(s,"bone"))s+=4;
 for(size_t i=0;i<sizeof(bone_aliases)/sizeof(bone_aliases[0]);++i){if(equal(s,bone_aliases[i].name)){*priority=bone_aliases[i].priority;return bone_aliases[i].joint;}}
 return -1;
}
typedef struct {
 Obj player_key;GCHandle player_root,bones_root,queue_root;
 uint64_t seen,recheck,retry;
 unsigned head,tail;BOOL complete;uint32_t known;
 BOOL expanding;int32_t child_index,child_count;
 unsigned char priority[JOINT_COUNT],unknown_names;
} SkeletonCache;
static SkeletonCache skeleton_cache[SKELETON_CACHE_COUNT];
static int skeleton_discovery_nodes;
static uint64_t skeleton_discovery_deadline;
static Obj *transform_array_items(Obj array,uintptr_t required){
 if(!array||array_length(array)<required)return 0;
 uint32_t header=array_object_header_size();if(header<24||header>128)return 0;
 return (Obj *)((unsigned char *)array+header);
}
static void skeleton_release(SkeletonCache *c){
 if(c->player_root)gchandle_free(c->player_root);
 if(c->bones_root)gchandle_free(c->bones_root);
 if(c->queue_root)gchandle_free(c->queue_root);
 zeromem(c,sizeof(*c));
}
static void skeleton_expire(uint64_t now,BOOL enabled){
 for(int i=0;i<SKELETON_CACHE_COUNT;++i){SkeletonCache *c=&skeleton_cache[i];if(c->player_key&&(!enabled||now-c->seen>5000))skeleton_release(c);}
}
static Obj skeleton_model_root(Obj player){
 Obj animator=0;if(animator_field)field_get_value(player,animator_field,&animator);
 Obj root=invoke(component_transform,alive(animator)?animator:player,0);
 return alive(root)?root:0;
}
static BOOL skeleton_bind(SkeletonCache *c,Obj player,uint64_t now){
 Obj root=skeleton_model_root(player);if(!root)return 0;
 c->player_root=gchandle_new(player,0);if(!c->player_root)return 0;
 Obj bones=array_new(transform_class,JOINT_COUNT);if(!bones)return 0;
 c->bones_root=gchandle_new(bones,0);if(!c->bones_root)return 0;
 Obj queue=array_new(transform_class,SKELETON_QUEUE_COUNT);if(!queue)return 0;
 c->queue_root=gchandle_new(queue,0);if(!c->queue_root)return 0;
 Obj *items=transform_array_items(queue,SKELETON_QUEUE_COUNT);if(!items)return 0;
 /* Slot zero roots the current model throughout the cache lifetime. */
 gc_wbarrier_set_field(queue,&items[0],root);gc_wbarrier_set_field(queue,&items[1],root);
 c->head=1;c->tail=2;c->recheck=now+1000;return 1;
}
static SkeletonCache *skeleton_entry(Obj player,uint64_t now){
 SkeletonCache *slot=0,*oldest=&skeleton_cache[0];
 for(int i=0;i<SKELETON_CACHE_COUNT;++i){SkeletonCache *c=&skeleton_cache[i];if(c->player_key==player){slot=c;break;}if(!c->player_key&&!slot)slot=c;if(c->seen<oldest->seen)oldest=c;}
 /* More than 32 visible players must not evict models still sampled every
    frame. Repeated eviction previously restarted discovery and allocated
    managed arrays continuously. Wait for a slot unused for two seconds. */
 if(!slot){if(now-oldest->seen<2000)return 0;slot=oldest;}
 if(slot->player_key!=player){skeleton_release(slot);slot->player_key=player;}
 slot->seen=now;
 if(slot->queue_root&&now>=slot->recheck){
  slot->recheck=now+1000;Obj queue=gchandle_get_target(slot->queue_root);Obj *items=transform_array_items(queue,SKELETON_QUEUE_COUNT);
  if(!items||items[0]!=skeleton_model_root(player)){skeleton_release(slot);slot->player_key=player;slot->seen=now;}
 }
 if(!slot->queue_root&&now>=slot->retry&&skeleton_discovery_nodes>0&&clock_us()<skeleton_discovery_deadline){
  if(!skeleton_bind(slot,player,now)){skeleton_release(slot);slot->player_key=player;slot->seen=now;slot->retry=now+5000;}
 }
 return slot;
}
static void skeleton_discover(SkeletonCache *c){
 if(c->complete||!c->queue_root)return;
 Obj queue=gchandle_get_target(c->queue_root),bones=gchandle_get_target(c->bones_root);
 Obj *pending=transform_array_items(queue,SKELETON_QUEUE_COUNT),*joints=transform_array_items(bones,JOINT_COUNT);
 if(!pending||!joints)return;
 while(c->head<c->tail&&skeleton_discovery_nodes>0&&clock_us()<skeleton_discovery_deadline){
  Obj t=pending[c->head];
  if(!c->expanding){
   --skeleton_discovery_nodes;
   if(!alive(t)){gc_wbarrier_set_field(queue,&pending[c->head++],0);continue;}
   Obj name=invoke(object_name,t,0);
   if(name){
   int len=string_length(name);unsigned char priority=0;int joint=match_bone_name(string_chars(name),len,&priority);
   if(joint>=0&&priority>c->priority[joint]){gc_wbarrier_set_field(bones,&joints[joint],t);c->priority[joint]=priority;c->known|=1u<<joint;}
   else if(joint<0&&c->unknown_names<6){
    char text[80];const WCHAR *s=string_chars(name);int n=len<79?len:79;
    for(int i=0;i<n;++i)text[i]=s[i]<128?(char)s[i]:'?';
    text[n]=0;
    logline("Skeleton hierarchy node:");logline(text);++c->unknown_names;
   }
   }
   Obj count=invoke(transform_child_count,t,0);c->child_count=count?*(int32_t *)object_unbox(count):0;
   if(c->child_count<0||c->child_count>1024)c->child_count=0;
   c->child_index=0;c->expanding=1;
  }
  while(c->child_index<c->child_count&&c->tail<SKELETON_QUEUE_COUNT&&skeleton_discovery_nodes>0&&clock_us()<skeleton_discovery_deadline){
   int32_t i=c->child_index++;--skeleton_discovery_nodes;void *args[1]={&i};Obj child=invoke(transform_child,t,args);if(child)gc_wbarrier_set_field(queue,&pending[c->tail++],child);
  }
  if(c->child_index>=c->child_count||c->tail>=SKELETON_QUEUE_COUNT){gc_wbarrier_set_field(queue,&pending[c->head++],0);c->expanding=0;}
  else break;
 }
 if(c->head>=c->tail){c->complete=1;unsigned count=0;for(int i=0;i<JOINT_COUNT;++i)if(c->known&(1u<<i))++count;log_number("Skeleton bones cached=",count);}
}
static void skeleton_sample_mask(Obj player,Obj camera,Box *box,uint32_t requested){
 box->joint_mask=0;
 SkeletonCache *c=skeleton_entry(player,GetTickCount64());if(!c)return;skeleton_discover(c);
 Obj bones=c->bones_root?gchandle_get_target(c->bones_root):0;Obj *items=transform_array_items(bones,JOINT_COUNT);if(!items)return;
 for(int i=0;i<JOINT_COUNT;++i){
  if(!(requested&c->known&(1u<<i))||!alive(items[i]))continue;
  Vec3 world,screen;if(!position_value(items[i],&world)||!pose_joint_near(&box->foot,&world))continue;
  if(!project_value(camera,&world,&screen))continue;
  if(screen.z<=0.01f||!finite_number(screen.z)||!finite_number(screen.x)||!finite_number(screen.y))continue;
  box->joints[i].world=world;box->joints[i].x=screen.x;box->joints[i].y=source_height-screen.y;box->joint_mask|=1u<<i;
 }
}
static Obj skeleton_joint_transform(Obj player,int joint){
 if(joint<0||joint>=JOINT_COUNT)return 0;
 for(int i=0;i<SKELETON_CACHE_COUNT;++i){SkeletonCache *c=&skeleton_cache[i];
  if(c->player_key!=player||!c->bones_root)continue;
  Obj *items=transform_array_items(gchandle_get_target(c->bones_root),JOINT_COUNT);
  return items&&alive(items[joint])?items[joint]:0;
 }
 return 0;
}
static void skeleton_chain(HDC dc,const Box *box,const unsigned char *chain,int count,float sx,float sy){
 int previous=-1;
 for(int i=0;i<count;++i){int joint=chain[i];if(!(box->joint_mask&(1u<<joint)))continue;
  if(previous>=0){MoveToEx(dc,(int32_t)(box->joints[previous].x*sx),(int32_t)(box->joints[previous].y*sy),0);LineTo(dc,(int32_t)(box->joints[joint].x*sx),(int32_t)(box->joints[joint].y*sy));}
  previous=joint;
 }
}
static void skeleton_draw(HDC dc,const Box *box,float sx,float sy){
 static const unsigned char torso[]={J_HEAD,J_NECK,J_CHEST,J_SPINE,J_HIPS};
 unsigned char anchor=(box->joint_mask&(1u<<J_CHEST))?J_CHEST:(box->joint_mask&(1u<<J_NECK))?J_NECK:J_SPINE;
 unsigned char left_arm[]={anchor,J_LSHOULDER,J_LARM,J_LFOREARM,J_LHAND},right_arm[]={anchor,J_RSHOULDER,J_RARM,J_RFOREARM,J_RHAND};
 static const unsigned char left_leg[]={J_HIPS,J_LTHIGH,J_LCALF,J_LFOOT},right_leg[]={J_HIPS,J_RTHIGH,J_RCALF,J_RFOOT};
 skeleton_chain(dc,box,torso,5,sx,sy);skeleton_chain(dc,box,left_arm,5,sx,sy);skeleton_chain(dc,box,right_arm,5,sx,sy);skeleton_chain(dc,box,left_leg,4,sx,sy);skeleton_chain(dc,box,right_leg,4,sx,sy);
}
