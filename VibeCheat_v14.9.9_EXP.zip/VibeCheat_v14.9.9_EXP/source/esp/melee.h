/* Native melee keeps its own swing, collision scan, commands and lock gates.
   Only the ray within the reviewed target scan is redirected. */
typedef struct {Vec3 origin,direction;} MeleeRay;
_Static_assert(sizeof(MeleeRay)==24,"Unity Ray value layout");
typedef unsigned char (ABI *MeleeScanFunction)(Obj,Method);
typedef MeleeRay (ABI *MeleeRayFunction)(Obj,Vec3 *,Method);
static MeleeScanFunction melee_scan_original;
static MeleeRayFunction melee_ray_original;
static Method melee_scan_method,melee_ray_method;
static unsigned char *melee_scan_entry,*melee_ray_entry;
static BOOL melee_scan_installed,melee_ray_installed;
static _Atomic BOOL melee_available;
static GCHandle melee_local_root,melee_player_root,melee_camera_root,melee_bone_root,melee_weapon_root;
static uint64_t melee_sample_us;
static Obj melee_scan_scope;
static BOOL melee_ray_used;
static void *melee_delay_field;
static _Atomic uint64_t melee_redirected;
static _Atomic(const char *) melee_state="Melee: disabled";
typedef struct {GCHandle root;void *field;float base,applied;} MeleeTimingWrite;
static MeleeTimingWrite melee_timings[4];
static void melee_clear_target(void){
 melee_sample_us=0;melee_scan_scope=0;
 GCHandle *roots[]={&melee_local_root,&melee_player_root,&melee_camera_root,&melee_bone_root,&melee_weapon_root};
 for(unsigned i=0;i<5;++i){if(*roots[i])gchandle_free(*roots[i]);*roots[i]=0;}
}
static void melee_restore_timing(unsigned i){
 MeleeTimingWrite *w=&melee_timings[i];if(!w->root)return;
 Obj object=gchandle_get_target(w->root);float observed=0;
 if(alive(object)){field_get_value(object,w->field,&observed);if(finite_number(observed)&&__builtin_fabsf(observed-w->applied)<.00001f)field_set_value(object,w->field,&w->base);}
 gchandle_free(w->root);*w=(MeleeTimingWrite){0};
}
static void melee_release(void){melee_clear_target();for(unsigned i=0;i<4;++i)melee_restore_timing(i);}
static BOOL melee_equipped(Obj local,Obj *weapon,Obj *item){
 *weapon=*item=0;if(!alive(local)||!weapon_field||!aimkill_item_field||!aimkill_kind_field)return 0;
 field_get_value(local,weapon_field,weapon);if(!alive(*weapon))return 0;
 field_get_value(*weapon,aimkill_item_field,item);if(!alive(*item))return 0;
 int32_t kind=0;field_get_value(*item,aimkill_kind_field,&kind);return kind==3;
}
static BOOL melee_input_active(void){return melee_available&&(custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE))&&running&&!stop_requested&&!native_faulted&&focused&&!menu_open&&!cursor_wanted&&aim_held;}
static unsigned char ABI melee_scan_proxy(Obj weapon,Method info){
 /* Only the Unity thread accesses scope; other threads remain pass-through. */
 if(GetCurrentThreadId()!=game_thread_id)return melee_scan_original(weapon,info);
 Obj previous=melee_scan_scope;BOOL used=melee_ray_used;
 melee_scan_scope=melee_input_active()&&melee_weapon_root&&gchandle_get_target(melee_weapon_root)==weapon?weapon:0;melee_ray_used=0;
 unsigned char result=melee_scan_original(weapon,info);
 melee_scan_scope=previous;melee_ray_used=used;return result;
}
static BOOL melee_redirect_ray(Obj camera,MeleeRay *ray){
 if(GetCurrentThreadId()!=game_thread_id||!melee_scan_scope||melee_ray_used||!melee_input_active()||GetAsyncKeyState((int32_t)aim_bind)>=0||!melee_sample_us)return 0;
 melee_ray_used=1;uint64_t now=clock_us();if(now<melee_sample_us||now-melee_sample_us>120000)return 0;
 Obj player=gchandle_get_target(melee_player_root),bone=gchandle_get_target(melee_bone_root),weapon=gchandle_get_target(melee_weapon_root);
 if(camera!=gchandle_get_target(melee_camera_root)||weapon!=melee_scan_scope||!alive(player)||!alive(camera)||!alive(bone)||!alive(weapon))return 0;
 Obj local=gchandle_get_target(melee_local_root),current_weapon=0,item=0;
 if(!melee_equipped(local,&current_weapon,&item)||current_weapon!=weapon)return 0;
 Obj lock=invoke(cursor_get_lock,0,0);void *lock_value=lock?object_unbox(lock):0;if(!lock_value||*(int32_t*)lock_value!=1)return 0;
 unsigned char local_dead=1;field_get_value(local,dead_field,&local_dead);if(local_dead)return 0;
 unsigned char dead=1;field_get_value(player,dead_field,&dead);if(dead)return 0;
 Vec3 point;if(!position_value(bone,&point))return 0;
 Vec3 origin=ray->origin;third_shot_origin(camera,&origin);
 float reach=0;field_get_value(weapon,weapon_range_field,&reach);
 Vec3 d={point.x-origin.x,point.y-origin.y,point.z-origin.z},screen;
 float square=d.x*d.x+d.y*d.y+d.z*d.z;
 if(!finite_number(reach)||reach<=0||reach>8||!finite_number(square)||square<=.0001f||square>reach*reach||!project_value(camera,&point,&screen)||screen.z<=0)return 0;
 float x=screen.x-source_width*.5f,y=screen.y-source_height*.5f;
 if(!finite_number(x)||!finite_number(y)||x*x+y*y>(float)aim_fov_px*aim_fov_px)return 0;
 float length=__builtin_sqrtf(square);d.x/=length;d.y/=length;d.z/=length;
 int32_t mask=0;field_get_value(weapon,weapon_mask_field,&mask);PhysicsHit hit;BOOL found=0;
 if(!trace_ray(&origin,&d,length+.01f,mask,0,&hit,&found)||!found)return 0;
 Obj collider=invoke(hit_collider,&hit,0);unsigned char inactive=0;void *args[]={hitbox_type,&inactive};
 Obj hitbox=alive(collider)?invoke(component_parent,collider,args):0;
 if(!alive(hitbox)||invoke(hitbox_status,hitbox,0)!=player)return 0;
 ray->origin=origin;ray->direction=d;++melee_redirected;melee_state="Silent Melee: native swing ray redirected; damage unconfirmed";return 1;
}
static MeleeRay ABI melee_ray_proxy(Obj camera,Vec3 *point,Method info){
 MeleeRay ray=melee_ray_original(camera,point,info);melee_redirect_ray(camera,&ray);return ray;
}
static BOOL melee_install(void){
 if(!melee_available)return 0;
 if(!melee_ray_installed){DWORD error=VibeCreateNativeHook(melee_ray_entry,melee_ray_proxy,(void**)&melee_ray_original);if(error){melee_state="Melee: camera-ray hook unavailable";return 0;}melee_ray_installed=1;}
 if(!melee_scan_installed){DWORD error=VibeCreateNativeHook(melee_scan_entry,melee_scan_proxy,(void**)&melee_scan_original);if(error){melee_state="Melee: target-scan hook unavailable";return 0;}melee_scan_installed=1;}
 return 1;
}
static void resolve_melee(void){
 melee_available=0;void *weapon=klass("OxideOld.Player","HeldWeaponLogic"),*ray=klass("UnityEngine","Ray"),*vector=klass("UnityEngine","Vector3");
 Method scan=method(weapon,PC_METHOD_meleeScan,0);void *args[]={vector};
 Method camera_ray=physics_named_method(klass("UnityEngine","Camera"),PC_METHOD_meleeRay,ray,args,1,0);
 uint32_t alignment=0;
 if(!compatible_method(scan,klass("System","Boolean"),0,0,0)||!ray||!class_value_size||class_value_size(ray,&alignment)!=24||!camera_ray)return;
 if((melee_scan_installed&&*(void *const*)scan!=melee_scan_entry)||(melee_ray_installed&&*(void *const*)camera_ray!=melee_ray_entry))return;
 if(!melee_scan_installed&&!aimkill_entry_matches(scan,PC_RVA_meleeScan,pc_prefix_meleeScan,sizeof(pc_prefix_meleeScan)))return;
 if(!melee_ray_installed&&!aimkill_entry_matches(camera_ray,PC_RVA_meleeRay,pc_prefix_meleeRay,sizeof(pc_prefix_meleeRay)))return;
 melee_delay_field=compatible_field(weapon,klass("System","Single"),PC_FIELD_meleeDelay,PC_FIELD_meleeDelay,0,PC_OFFSET_meleeDelay,"Melee impact delay");
 melee_scan_method=scan;melee_ray_method=camera_ray;melee_scan_entry=*(unsigned char *const*)scan;melee_ray_entry=*(unsigned char *const*)camera_ray;
 melee_available=aimkill_item_field&&aimkill_kind_field&&aimkill_cooldown_field&&compatible_field_type(weapon_range_field,klass("System","Single"),312u)&&swing_field&&melee_delay_field&&dead_field&&cursor_get_lock&&physics_ray&&hit_collider&&component_parent&&hitbox_status&&hitbox_type&&weapon_mask_field;
 log_number("PC native melee binding ready=",melee_available);
}
static BOOL melee_select(Obj local,Obj camera,const AimSelection *selection){
 Obj weapon,item;if(!melee_input_active()||!selection||!alive(selection->player)||!melee_equipped(local,&weapon,&item)||!melee_install()){melee_clear_target();return 0;}
 Obj bone=skeleton_joint_transform(selection->player,selection->joint_index);
 if(!alive(bone)||!alive(camera)||!silent_set_root(&melee_local_root,local)||!silent_set_root(&melee_player_root,selection->player)||!silent_set_root(&melee_camera_root,camera)||!silent_set_root(&melee_bone_root,bone)||!silent_set_root(&melee_weapon_root,weapon)){melee_clear_target();return 0;}
 melee_sample_us=clock_us();aim_target_key=selection->player;return 1;
}
static void melee_apply_timing(unsigned i,Obj object,void *field,float floor,DWORD percent){
 MeleeTimingWrite *w=&melee_timings[i];if(w->root&&(gchandle_get_target(w->root)!=object||w->field!=field))melee_restore_timing(i);
 float observed=0;field_get_value(object,field,&observed);
 if(!finite_number(observed)||observed<=0||observed>30){melee_restore_timing(i);return;}
 if(!w->root){w->root=gchandle_new(object,0);if(!w->root)return;w->field=field;w->base=w->applied=observed;}
 else if(__builtin_fabsf(observed-w->applied)>.00001f)w->base=observed;
 float desired=w->base*(100.f/(float)percent);if(desired<floor)desired=floor;if(desired>w->base)desired=w->base;
 if(__builtin_fabsf(observed-desired)>.00001f)field_set_value(object,field,&desired);w->applied=desired;
}
static void melee_tick(Obj local,BOOL active){
 if(!active||!melee_available||!(custom_flags&VIBE_CUSTOM_MELEE_MASK)){melee_release();return;}
 Obj weapon,item;if(!melee_equipped(local,&weapon,&item)){melee_release();melee_state="Melee: equip a melee weapon";return;}
 if(!(custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE))||!aim_held)melee_clear_target();
 if((custom_flags&(VIBE_CUSTOM_SILENT_MELEE|VIBE_CUSTOM_AUTO_MELEE))&&aim_held&&!(farm_options&1u)){
  MeleeTimingWrite *w=&melee_timings[3];if(w->root&&(gchandle_get_target(w->root)!=weapon||w->field!=weapon_range_field))melee_restore_timing(3);
  float observed=0;field_get_value(weapon,weapon_range_field,&observed);
  if(finite_number(observed)&&observed>0&&observed<=8){
   if(!w->root){w->root=gchandle_new(weapon,0);if(w->root){w->field=weapon_range_field;w->base=w->applied=observed;}}
   if(w->root){if(__builtin_fabsf(observed-w->applied)>.00001f)w->base=observed;float desired=5.f;if(__builtin_fabsf(observed-desired)>.00001f)field_set_value(weapon,weapon_range_field,&desired);w->applied=desired;}
  }else melee_restore_timing(3);
 }else melee_restore_timing(3);
 /* Farm owns these same timing fields while automated harvesting runs. */
 DWORD percent=custom_melee_percent;
 if((custom_flags&VIBE_CUSTOM_FAST_MELEE)&&!(farm_options&1u)&&percent>100&&percent<=1000){
  melee_apply_timing(0,item,aimkill_cooldown_field,.05f,percent);melee_apply_timing(1,weapon,swing_field,.05f,percent);melee_apply_timing(2,weapon,melee_delay_field,.025f,percent);
 }else for(unsigned i=0;i<3;++i)melee_restore_timing(i);
}
