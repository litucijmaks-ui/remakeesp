/* Perspective magnification, independent of the aim FOV circle and model pose. */
static float camera_limit(float v,float lo,float hi){return v<lo?lo:v>hi?hi:v;}
static float camera_zoom_fov(float base,unsigned percent){
 float scale=(float)percent*.01f;
 float value=camera_limit(2.f*__builtin_atanf(__builtin_tanf(base*.00872664626f)/scale)*57.29577951f,5.f,170.f);
 return value>base?base:value;
}
static float camera_hands_fov(float base,unsigned reduction){
 float scale=1.f+(float)reduction*.01f;
 float value=camera_limit(2.f*__builtin_atanf(__builtin_tanf(base*.00872664626f)*scale)*57.29577951f,5.f,150.f);
 return value<base?base:value;
}
