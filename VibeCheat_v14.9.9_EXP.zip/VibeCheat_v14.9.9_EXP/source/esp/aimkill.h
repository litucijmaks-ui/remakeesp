/* Autofire requests normal mouse input; Unity dispatches its own attack in
   Update. Do not runtime-invoke PrimaryAction from the window callback: the
   user's 14.10.8 dump shows a native null read in that invocation path. */
extern DWORD ABI VibeAutoFireInput(void);
static float rapid_effective_cooldown(float original);
static Method aimkill_shoot,aimkill_primary,aimkill_can_fire;
static void *aimkill_item_field,*aimkill_ammo_field,*aimkill_cost_field,*aimkill_mag_field,*aimkill_cooldown_field,*aimkill_kind_field;
static _Atomic BOOL aimkill_available;
static uint64_t aimkill_next_ms;
static _Atomic uint64_t aimkill_fire_requests;
static _Atomic int32_t aimkill_last_kind,aimkill_last_mag,aimkill_last_cost;
static _Atomic DWORD aimkill_last_ammo_present;
static _Atomic(const char *) aimkill_state="Native autofire: waiting for target";
static BOOL aimkill_entry_matches(Method candidate,uint32_t rva,const unsigned char *expected,unsigned count){
 if(!candidate)return 0;const unsigned char *base=GetModuleHandleA("GameAssembly.dll");if(!base)return 0;
 uint32_t pe=*(const uint32_t*)(base+60);
 if(pe>4096||*(const uint32_t*)(base+pe)!=0x4550||*(const uint16_t*)(base+pe+4)!=0x8664)return 0;
 uint32_t size=*(const uint32_t*)(base+pe+24+56);
 if(rva>=size||count>size-rva||*(void *const*)candidate!=(void*)(base+rva))return 0;
 for(unsigned i=0;i<count;++i)if(base[rva+i]!=expected[i])return 0;return 1;
}
static void resolve_aimkill(void){
 void *weapon=klass("OxideOld.Player","HeldWeaponLogic"),*item=klass("","Item");
 void *identity=klass("Mirror","NetworkIdentity"),*vector=klass("UnityEngine","Vector3"),*boolean=klass("System","Boolean"),*single=klass("System","Single"),*integer=klass("System","Int32");
 void *shoot_params[]={identity,vector,vector,boolean,single,boolean,vector,vector};
 aimkill_shoot=method(weapon,"CmdShootWeapon",8);if(!compatible_signature(aimkill_shoot,shoot_params,8))aimkill_shoot=0;
 /* Names, RVA and immutable instruction bytes were jointly checked against
    the supplied Windows update and packed v107 metadata. */
 aimkill_primary=method(weapon,PC_METHOD_primaryAction,0);aimkill_can_fire=method(weapon,PC_METHOD_canPrimaryFire,0);
 if(!compatible_signature(aimkill_primary,0,0)||!aimkill_entry_matches(aimkill_primary,PC_RVA_primaryAction,pc_prefix_primaryAction,sizeof(pc_prefix_primaryAction)))aimkill_primary=0;
 if(!compatible_method(aimkill_can_fire,boolean,0,0,0)||!aimkill_entry_matches(aimkill_can_fire,PC_RVA_canPrimaryFire,pc_prefix_canPrimaryFire,sizeof(pc_prefix_canPrimaryFire)))aimkill_can_fire=0;
 aimkill_item_field=compatible_field(weapon,item,"itemData","itemData",0,SIZE_MAX,"Autofire item");
 aimkill_ammo_field=compatible_field(item,item,"ammoType","ammoType",0,SIZE_MAX,"Autofire ammo item");
 aimkill_cost_field=compatible_field(item,integer,"ammoPerShot","ammoPerShot",0,SIZE_MAX,"Autofire ammo cost");
 aimkill_mag_field=compatible_field(weapon,integer,"currentAmmoInMag","currentAmmoInMag",0,SIZE_MAX,"Autofire magazine");
 aimkill_cooldown_field=compatible_field(item,single,"fireCooldown","fireCooldown",0,SIZE_MAX,"Autofire original cooldown");
 aimkill_kind_field=compatible_field(item,klass("","ƖɅĨȡϪЀ"),"itemType","itemType",0,0x38u,"Autofire reviewed item category");
 aimkill_available=net_identity&&weapon_field&&dead_field&&aimkill_shoot&&aimkill_primary&&aimkill_can_fire&&aimkill_item_field&&aimkill_ammo_field&&aimkill_cost_field&&aimkill_mag_field&&aimkill_cooldown_field&&aimkill_kind_field;
 log_number("Native autofire ready=",aimkill_available);
 log_number("Native autofire reviewed primary handler=",aimkill_primary!=0);
 log_number("Native autofire reviewed weapon gate=",aimkill_can_fire!=0);
 logline("Autofire uses normal attack input in Unity Update; PrimaryAction runtime invocation removed");
}
static BOOL aimkill_fire(Obj local,Obj camera,const AimSelection *selection,BOOL want_visible){
 if(!aimkill_available||!silent_available||!selection||!selection->player||!alive(local)||!alive(selection->player)||!alive(camera)||
    native_faulted||!running||stop_requested||!focused||menu_open||cursor_wanted||!aim_held||GetCurrentThreadId()!=game_thread_id||
    aim_mode!=AIM_MODE_AIMKILL)return 0;
 unsigned char dead=1;field_get_value(local,dead_field,&dead);if(dead)return 0;field_get_value(selection->player,dead_field,&dead);if(dead)return 0;
 silent_select(local,camera,selection);if(!silent_sample_us)return 0;
 /* Holding the real fire button uses the game's own input path. It must not
    also trigger another automatic primary action in the same frame. */
 if(GetAsyncKeyState(1)<0){aimkill_state="Native autofire: manual fire button active";return 1;}
 uint64_t now=GetTickCount64();if(now<aimkill_next_ms)return 1;
 aimkill_next_ms=now+40; /* Poll budget only. The weapon's native gate decides firing. */
 Obj weapon=0,item=0,ammo=0;field_get_value(local,weapon_field,&weapon);
 if(alive(weapon))field_get_value(weapon,aimkill_item_field,&item);
 if(!alive(weapon)||!alive(item)){aimkill_state="Native autofire: equip a firearm";return 0;}
 int32_t cost=0,mag=0,kind=0;float cooldown=0;
 field_get_value(item,aimkill_ammo_field,&ammo);field_get_value(item,aimkill_cost_field,&cost);field_get_value(item,aimkill_kind_field,&kind);
 field_get_value(weapon,aimkill_mag_field,&mag);field_get_value(item,aimkill_cooldown_field,&cooldown);
 aimkill_last_kind=kind;aimkill_last_mag=mag;aimkill_last_cost=cost;aimkill_last_ammo_present=ammo!=0;
 /* Categories 2 and 13 are the reviewed firearm branches. No consumable,
    farming, melee, throwable or rocket dispatch is triggered automatically. */
 if((kind!=2&&kind!=13)||!ammo||cost<1||cost>32||mag<cost){aimkill_state="Native autofire: waiting for loaded firearm";return 0;}
 if(!finite_number(cooldown)||cooldown<=0||cooldown>30.f){aimkill_state="Native autofire: invalid weapon cooldown";return 0;}
 Obj allowed=0;const char *previous=invoke_context;invoke_context="Native autofire weapon gate";
 BOOL ok=invoke_checked(aimkill_can_fire,weapon,0,&allowed);invoke_context=previous;
 void *unboxed=allowed?object_unbox(allowed):0;
 if(!ok||!unboxed||!*(unsigned char*)unboxed){aimkill_state="Native autofire: native cooldown or reload gate";return 1;}
 Vec3 origin;Obj bone=skeleton_joint_transform(selection->player,selection->joint_index);
 if(!third_shot_origin(camera,&origin)&&!world_position(camera,&origin))return 0;
 PhysicsHit hit;Vec3 direction;unsigned char head=0;float multiplier=0;
 if(!selected_shot_probe(weapon,selection->player,camera,bone,&origin,&hit,&direction,&head,&multiplier,0)){aimkill_state="Native autofire: no target hit; shot withheld";return 1;}
 /* Every probe already checks the actual obstruction from this origin. */
 (void)want_visible;
 /* The shared shot proxy redirects the current shot without writing camera
    rotation or player look angles. Visible aiming belongs to Camera mode. */
 /* Preserve pacing across target/weapon switches and invocation failures. */
 aimkill_next_ms=now+40;
 ok=VibeAutoFireInput()!=0;
 if(ok){++aimkill_fire_requests;aim_target_key=selection->player;aimkill_next_ms=now+80;aimkill_state="Native autofire: normal attack input requested; damage unconfirmed";return 1;}
 aimkill_state="Native autofire: input unavailable or already held";return 0;
}
