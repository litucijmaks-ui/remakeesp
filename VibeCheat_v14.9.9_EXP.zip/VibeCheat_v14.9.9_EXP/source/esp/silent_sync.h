static _Atomic uint64_t silent_physics_syncs;
static BOOL silent_sync_physics(void){
 global_resolve();if(!global_methods[GM_physicsSync])return 1;
 Obj ignored=0;if(!invoke_checked(global_methods[GM_physicsSync],0,0,&ignored))return 0;
 ++silent_physics_syncs;return !native_faulted;
}
