/* Pure decisions shared by the live command path and regression fixture. */
static float interaction_reach(float weapon_range,uint32_t configured_cm){
 if(!finite_number(weapon_range)||weapon_range<0.5f||weapon_range>20.f)return 0;
 float reach=(float)configured_cm*0.01f;if(reach>weapon_range)reach=weapon_range;if(reach>2.5f)reach=2.5f;return reach>0.2f?reach-0.15f:0;
}
static BOOL interaction_in_reach(const Vec3 *player,const Vec3 *camera,const Vec3 *center,const Vec3 *hit,float reach){
 if(!finite_number(reach)||reach<=0)return 0;float square=reach*reach;
 float a=point_distance_sq(player,center),b=point_distance_sq(player,hit),c=point_distance_sq(camera,hit);
 return finite_number(a)&&finite_number(b)&&finite_number(c)&&a<=square&&b<=square&&c<=square;
}
static uint32_t interaction_cooldown(uint32_t configured,float item,float swing,float resource){
 float values[]={item,swing,resource};uint32_t wait=configured<150?150:configured;
 for(unsigned i=0;i<3;++i){if(!finite_number(values[i])||values[i]<0||values[i]>60.f)return 0;uint32_t ms=(uint32_t)(values[i]*1000.f+0.999f);if(ms>wait)wait=ms;}return wait;
}
