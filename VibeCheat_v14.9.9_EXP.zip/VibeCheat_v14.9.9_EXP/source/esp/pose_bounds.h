#pragma once
static BOOL pose_joint_near(const Vec3 *root,const Vec3 *joint){
 if(!finite_number(joint->x)||!finite_number(joint->y)||!finite_number(joint->z))return 0;
 float x=joint->x-root->x,y=joint->y-root->y,z=joint->z-root->z;
 float square=x*x+y*y+z*z;return finite_number(square)&&square<=16.f;
}
