/* The UI sends plain settings; only the Unity window thread applies profiles.
   A failed try-lock is retried rather than blocking either thread. */
static VibeCustomSettings custom_current,custom_pending;
static atomic_flag custom_lock=ATOMIC_FLAG_INIT;
static _Atomic BOOL custom_pending_ready;
static _Atomic DWORD custom_flags,custom_sound_volume=70,custom_rapid_mode,custom_sound_mode;
static _Atomic DWORD custom_audio_flags;
static _Atomic DWORD custom_melee_percent=500;
static _Atomic DWORD custom_third_distance_cm=300,custom_craft_percent=300;
static _Atomic DWORD custom_camera_fov_deg=90,custom_zoom_key=67,custom_zoom_percent=200;
DWORD ABI VibeUiWriteCustom(const VibeCustomSettings *s,DWORD bytes){
 if(bytes!=sizeof(*s)||!vibe_custom_valid(s))return 0;
 if(atomic_flag_test_and_set_explicit(&custom_lock,memory_order_acquire))return 0;
 custom_pending=*s;custom_pending_ready=1;
 custom_audio_flags=s->flags&(VIBE_CUSTOM_AUDIO|VIBE_CUSTOM_MUTE_HIT);custom_sound_mode=s->sound_mode;
 atomic_flag_clear_explicit(&custom_lock,memory_order_release);return 1;
}
static void custom_apply_pending(void){
 if(!custom_pending_ready||atomic_flag_test_and_set_explicit(&custom_lock,memory_order_acquire))return;
 custom_current=custom_pending;custom_pending_ready=0;
 atomic_flag_clear_explicit(&custom_lock,memory_order_release);
 custom_flags=custom_current.flags&~VIBE_CUSTOM_CRAFT;custom_sound_volume=custom_current.sound_volume;custom_rapid_mode=custom_current.rapid_mode;custom_sound_mode=custom_current.sound_mode;
 custom_melee_percent=custom_current.melee_percent;
 custom_third_distance_cm=custom_current.third_distance_cm;custom_craft_percent=custom_current.craft_percent;
 custom_camera_fov_deg=custom_current.camera_fov_deg;custom_zoom_key=custom_current.zoom_key;custom_zoom_percent=custom_current.zoom_percent;
}
