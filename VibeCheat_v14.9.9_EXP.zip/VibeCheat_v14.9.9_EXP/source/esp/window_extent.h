/* Read the drawable Windows client area without Unity's Screen singleton.
   The supplied crash is Screen_Get_Custom_PropWidth dereferencing null. */
static BOOL window_extent(HWND window,int32_t *width,int32_t *height){
 RECT area={0};
 if(!window||!IsWindow(window)||IsIconic(window)||!GetClientRect(window,&area))return 0;
 int64_t w=(int64_t)area.right-area.left,h=(int64_t)area.bottom-area.top;
 if(w<=0||h<=0||w>32768||h>32768)return 0;
 *width=(int32_t)w;*height=(int32_t)h;return 1;
}
