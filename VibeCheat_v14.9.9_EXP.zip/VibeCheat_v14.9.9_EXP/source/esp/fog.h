static Method fog_set_color;
static void *fog_derived_field,*fog_shader_id_field;
static SkyColor fog_base,fog_last;
static BOOL fog_written;
static void resolve_fog(void){
 void *render=klass("UnityEngine","RenderSettings"),*color=klass("UnityEngine","Color"),*nothing=klass("System","Void"),*params[]={color};
 fog_set_color=method(render,"set_fogColor",1);
 if(!compatible_method(fog_set_color,nothing,params,1,1))fog_set_color=0;
 fog_derived_field=compatible_field(sky_class,color,"<FogColor>k__BackingField","<FogColor>k__BackingField",0,SIZE_MAX,"TOD current fog color");
 fog_shader_id_field=compatible_field(klass("","TOD_Resources"),klass("System","Int32"),"<ID_FogColor>k__BackingField","<ID_FogColor>k__BackingField",0,SIZE_MAX,"TOD fog shader id");
 logline(fog_set_color?"Fog color setter resolved":"Fog color unavailable in this game runtime");
}
static BOOL fog_equal(SkyColor a,SkyColor b){return __builtin_fabsf(a.r-b.r)<0.0001f&&__builtin_fabsf(a.g-b.g)<0.0001f&&__builtin_fabsf(a.b-b.b)<0.0001f;}
static void fog_publish(Obj sky,SkyColor *color,BOOL restore){
 if(!visual_in_late||!sky_initialized(sky)||native_faulted)return;
 const char *previous=invoke_context;invoke_context=restore?"TOD LateUpdate: fog restore":"TOD LateUpdate: fog apply";
 Obj ignored=0;void *args[]={color};BOOL ok=invoke_checked(fog_set_color,0,args,&ignored);
 Obj resources=0;if(ok&&sky_resources_field&&fog_shader_id_field&&sky_publish_color){field_get_value(sky,sky_resources_field,&resources);if(resources){int32_t id=0;field_get_value(resources,fog_shader_id_field,&id);if(id){void *shader_args[]={&id,color};invoke_checked(sky_publish_color,0,shader_args,&ignored);}}}
 invoke_context=previous;
}
static void fog_release(void){
 if(fog_written)visual_restore_queue(&visual_restore,(uintptr_t)visual_target(sky_root),RESTORE_FOG);
 fog_written=0;
}
static void fog_restore_at_late(Obj sky){SkyColor current={0};if(fog_set_color&&fog_derived_field){field_get_value(sky,fog_derived_field,&current);fog_publish(sky,&current,1);}}
static void fog_tick(DWORD options){
 if(!(options&VISUAL_FOG)||!fog_derived_field||!fog_set_color){fog_release();return;}
 Obj sky=visual_target(sky_root);if(!alive(sky)){fog_release();return;}SkyColor current={0};field_get_value(sky,fog_derived_field,&current);fog_base=current;
 DWORD color=fog_color;SkyColor desired={(float)(color&255u)/255.f,(float)((color>>8)&255u)/255.f,(float)((color>>16)&255u)/255.f,1};
 fog_publish(sky,&desired,0);
 fog_last=desired;fog_written=1;
}
