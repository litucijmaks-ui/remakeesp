"""Rebuild the core, preferring native Windows COFF with unwind information."""
from pathlib import Path
import shutil, subprocess, tempfile, hashlib, json, os
root=Path(__file__).resolve().parent
build=root/'native-build-single'
build.mkdir(exist_ok=True)
obj=build/'esp.c.obj'
zig=shutil.which('zig')
for parent in root.parents:
    candidate=parent/'.tools'/'ziglang'/'zig.exe'
    if candidate.is_file():
        zig=str(candidate)
        break
clang=shutil.which('clang')
common=['-c','-O2','-std=c11','-DVIBE_INTERNAL_IMGUI=1','-fno-stack-protector',
        '-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-variable']
if zig or clang:
    with tempfile.TemporaryDirectory(prefix='vibe-core-') as temporary:
        native=Path(temporary)/'esp.obj'
        compiler=[zig,'cc','-target',os.environ.get('VIBE_CORE_TARGET','x86_64-windows-msvc')] if zig else [clang,'--target=x86_64-pc-windows-msvc']
        subprocess.run(compiler+common+['-g','-gcodeview','-o',str(native),str(root/'esp.c')],check=True)
        shutil.copyfile(native,obj)
else:
    from elf_to_coff import convert
    gcc=shutil.which('gcc')
    if not gcc:
        raise SystemExit('Install Clang or Zig, or use the included current COFF object.')
    elf=build/'esp.c.elf.o'
    subprocess.run([gcc]+common+['-ffreestanding','-fno-builtin','-fpie','-mno-red-zone',
        '-fno-asynchronous-unwind-tables','-fno-unwind-tables','-fno-math-errno',
        '-o',str(elf),str(root/'esp.c')],check=True)
    convert(elf,obj)
source_root=root.parent
files={f.relative_to(source_root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in source_root.rglob('*') if f.is_file() and f.suffix in ('.h','.c') and 'native-build-single' not in f.parts}
manifest={'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'sources':files}
(build/'core-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(obj)
