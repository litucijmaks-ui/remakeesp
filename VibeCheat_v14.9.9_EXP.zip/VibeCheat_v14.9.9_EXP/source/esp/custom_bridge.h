#pragma once
#include <stdint.h>
#include <stddef.h>
#define VIBE_CUSTOM_MAGIC 0x31584356u
#define VIBE_SKIN_PROFILES 32u
#define VIBE_SKIN_CATALOG_MAX 96u
#define VIBE_CUSTOM_AUDIO 1u
#define VIBE_CUSTOM_SKINS 2u
#define VIBE_CUSTOM_MUTE_HIT 4u
#define VIBE_CUSTOM_SILENT_MELEE 8u
#define VIBE_CUSTOM_FAST_MELEE 16u
#define VIBE_CUSTOM_AUTO_MELEE 512u
#define VIBE_CUSTOM_MELEE_MASK 536u
#define VIBE_CUSTOM_POTATO 32u
#define VIBE_CUSTOM_THIRD 64u
#define VIBE_CUSTOM_CRAFT 128u
#define VIBE_CUSTOM_SCRAP 256u
#define VIBE_CUSTOM_CAMERA_FOV 1024u
#define VIBE_CUSTOM_ZOOM 2048u
#define VIBE_CUSTOM_CAMERA_MASK 3072u
#define VIBE_CUSTOM_GLOBAL_MASK 3552u
typedef struct {uint32_t item_id,skin_id;} VibeSkinProfile;
typedef struct {
 uint32_t magic,version,flags,sound_volume,rapid_mode,profile_count;
 VibeSkinProfile profiles[VIBE_SKIN_PROFILES];
 uint32_t checksum;
} VibeCustomSettingsV1;
typedef struct {
 uint32_t magic,version,flags,sound_volume,rapid_mode,profile_count;
 VibeSkinProfile profiles[VIBE_SKIN_PROFILES];
 uint32_t head_sound,body_sound,sound_mode,checksum;
} VibeCustomSettingsV2;
typedef struct {
 uint32_t magic,version,flags,sound_volume,rapid_mode,profile_count;
 VibeSkinProfile profiles[VIBE_SKIN_PROFILES];
 uint32_t head_sound,body_sound,sound_mode,melee_percent,checksum;
} VibeCustomSettingsV3;

typedef struct {
 uint32_t magic,version,flags,sound_volume,rapid_mode,profile_count;
 VibeSkinProfile profiles[VIBE_SKIN_PROFILES];
 uint32_t head_sound,body_sound,sound_mode,melee_percent;
 uint32_t third_distance_cm,craft_percent,fps_mode,checksum; /* fps_mode retained only for file layout migration. */
} VibeCustomSettingsV5;
typedef struct {
 uint32_t magic,version,flags,sound_volume,rapid_mode,profile_count;
 VibeSkinProfile profiles[VIBE_SKIN_PROFILES];
 uint32_t head_sound,body_sound,sound_mode,melee_percent;
 uint32_t third_distance_cm,craft_percent,fps_mode;
 uint32_t camera_fov_deg,zoom_key,zoom_percent,checksum;
} VibeCustomSettings;
typedef struct {uint32_t id;uint16_t name[64];} VibeSkinEntry;
typedef struct {
 uint32_t item_id,current_skin_id,count,status,models,refresh_serial;
 uint16_t item_name[64];
 VibeSkinEntry entries[VIBE_SKIN_CATALOG_MAX];
} VibeSkinCatalog;
typedef struct {
 uint64_t native_actions,confirmed_hits,confirmed_heads,marker_hits,marker_heads;
 uint32_t feedback_ready,rapid_ready,skin_ready,marker_ready,mute_ready,muted_sources;
 uint64_t native_audio_calls,original_audio_suppressed,queued_body,queued_heads;
} VibeCombatFeedback;
static inline uint32_t vibe_bytes_checksum(const void *data,size_t size){
 const unsigned char *bytes=(const unsigned char*)data;uint32_t h=2166136261u;
 for(size_t i=0;i<size;++i)h=(h^bytes[i])*16777619u;
 return h;
}
static inline uint32_t vibe_custom_checksum(const VibeCustomSettings *s){return vibe_bytes_checksum(s,offsetof(VibeCustomSettings,checksum));}
static inline void vibe_custom_default(VibeCustomSettings *s){
 VibeCustomSettings value={0};value.magic=VIBE_CUSTOM_MAGIC;value.version=6;value.flags=0;value.sound_volume=70;
 value.head_sound=1;value.body_sound=2;value.melee_percent=500;value.third_distance_cm=300;value.craft_percent=300;
 value.camera_fov_deg=90;value.zoom_key=67;value.zoom_percent=200;
 value.checksum=vibe_custom_checksum(&value);*s=value;
}
static inline int vibe_profiles_valid(const VibeSkinProfile *p,uint32_t count){
 if(count>VIBE_SKIN_PROFILES)return 0;
 for(uint32_t i=0;i<count;++i){
  if(!p[i].item_id||p[i].item_id>1000000||p[i].skin_id>1000000)return 0;
  for(uint32_t j=0;j<i;++j)if(p[i].item_id==p[j].item_id)return 0;
 }
 return 1;
}
static inline int vibe_custom_valid(const VibeCustomSettings *s){
 return s&&s->magic==VIBE_CUSTOM_MAGIC&&s->version==6&&s->flags<=4095&&s->sound_volume<=100&&s->rapid_mode<=1&&s->head_sound<=2&&s->body_sound<=2&&s->sound_mode<=1&&s->melee_percent>=100&&s->melee_percent<=1000&&s->third_distance_cm>=100&&s->third_distance_cm<=500&&s->craft_percent>=100&&s->craft_percent<=1000&&s->fps_mode==0&&
        s->camera_fov_deg>=40&&s->camera_fov_deg<=120&&s->zoom_percent>=125&&s->zoom_percent<=800&&
        (s->zoom_key==0||(s->zoom_key<255&&s->zoom_key!=27&&s->zoom_key!=35&&s->zoom_key!=45&&s->zoom_key!=18&&s->zoom_key!=164&&s->zoom_key!=165))&&
        vibe_profiles_valid(s->profiles,s->profile_count)&&s->checksum==vibe_custom_checksum(s);
}
static inline int vibe_custom_decode(VibeCustomSettings *out,const void *data,size_t size){
 if(!out||!data)return 0;
 if(size==sizeof(VibeCustomSettings)){
  VibeCustomSettings value;unsigned char *dest=(unsigned char*)&value;const unsigned char *src=(const unsigned char*)data;
  for(size_t i=0;i<size;++i)dest[i]=src[i];
  if(!vibe_custom_valid(&value))return 0;*out=value;return 1;
 }
 if(size==sizeof(VibeCustomSettingsV5)){
  VibeCustomSettingsV5 old;unsigned char *dest=(unsigned char*)&old;const unsigned char *src=(const unsigned char*)data;
  for(size_t i=0;i<size;++i)dest[i]=src[i];
  if(old.magic!=VIBE_CUSTOM_MAGIC||(old.version!=4&&old.version!=5)||old.flags>1023||old.fps_mode>6||old.checksum!=vibe_bytes_checksum(&old,offsetof(VibeCustomSettingsV5,checksum)))return 0;
  VibeCustomSettings value;vibe_custom_default(&value);dest=(unsigned char*)&value;src=(const unsigned char*)&old;
  for(size_t i=0;i<offsetof(VibeCustomSettingsV5,checksum);++i)dest[i]=src[i];
  if(old.version==4)value.flags&=511u; /* Old bit 512 was FPS, not automatic melee. */
  value.version=6;value.fps_mode=0;value.checksum=vibe_custom_checksum(&value);
  if(!vibe_custom_valid(&value))return 0;*out=value;return 1;
 }
 if(size==sizeof(VibeCustomSettingsV3)){
  VibeCustomSettingsV3 old;unsigned char *dest=(unsigned char*)&old;const unsigned char *src=(const unsigned char*)data;
  for(size_t i=0;i<size;++i)dest[i]=src[i];
  if(old.magic!=VIBE_CUSTOM_MAGIC||old.version!=3||old.flags>511||old.checksum!=vibe_bytes_checksum(&old,offsetof(VibeCustomSettingsV3,checksum)))return 0;
  VibeCustomSettings value;vibe_custom_default(&value);dest=(unsigned char*)&value;src=(const unsigned char*)&old;
  for(size_t i=0;i<offsetof(VibeCustomSettingsV3,checksum);++i)dest[i]=src[i];
  value.version=6;value.checksum=vibe_custom_checksum(&value);if(!vibe_custom_valid(&value))return 0;*out=value;return 1;
 }
 if(size==sizeof(VibeCustomSettingsV2)){
  VibeCustomSettingsV2 old;unsigned char *dest=(unsigned char*)&old;const unsigned char *src=(const unsigned char*)data;
  for(size_t i=0;i<size;++i)dest[i]=src[i];
  if(old.magic!=VIBE_CUSTOM_MAGIC||old.version!=2||old.checksum!=vibe_bytes_checksum(&old,offsetof(VibeCustomSettingsV2,checksum)))return 0;
  VibeCustomSettings value;vibe_custom_default(&value);dest=(unsigned char*)&value;src=(const unsigned char*)&old;
  for(size_t i=0;i<offsetof(VibeCustomSettingsV2,checksum);++i)dest[i]=src[i];
  value.version=6;value.checksum=vibe_custom_checksum(&value);if(!vibe_custom_valid(&value))return 0;*out=value;return 1;
 }
 if(size!=sizeof(VibeCustomSettingsV1))return 0;
 VibeCustomSettingsV1 old;unsigned char *dest=(unsigned char*)&old;const unsigned char *src=(const unsigned char*)data;
 for(size_t i=0;i<size;++i)dest[i]=src[i];
 if(old.magic!=VIBE_CUSTOM_MAGIC||old.version!=1||old.flags>3||old.sound_volume>100||old.rapid_mode>1||!vibe_profiles_valid(old.profiles,old.profile_count)||
    old.checksum!=vibe_bytes_checksum(&old,offsetof(VibeCustomSettingsV1,checksum)))return 0;
 vibe_custom_default(out);out->flags=old.flags|VIBE_CUSTOM_MUTE_HIT;out->sound_volume=old.sound_volume;out->rapid_mode=old.rapid_mode;
 for(uint32_t i=0;i<old.profile_count;++i)if(old.profiles[i].skin_id)out->profiles[out->profile_count++]=old.profiles[i];
 out->checksum=vibe_custom_checksum(out);return 1;
}
static inline uint32_t vibe_skin_choice(const VibeCustomSettings *s,uint32_t item){
 for(uint32_t i=0;i<s->profile_count;++i)if(s->profiles[i].item_id==item)return s->profiles[i].skin_id;
 return 0;
}
static inline int vibe_skin_set_choice(VibeCustomSettings *s,uint32_t item,uint32_t skin){
 if(!item||item>1000000||skin>1000000)return 0;
 for(uint32_t i=0;i<s->profile_count;++i)if(s->profiles[i].item_id==item){
  if(skin)s->profiles[i].skin_id=skin;
  else {for(uint32_t j=i+1;j<s->profile_count;++j)s->profiles[j-1]=s->profiles[j];VibeSkinProfile empty={0};s->profiles[--s->profile_count]=empty;}
  s->checksum=vibe_custom_checksum(s);return 1;
 }
 if(!skin)return 1;if(s->profile_count>=VIBE_SKIN_PROFILES)return 0;
 VibeSkinProfile value={item,skin};s->profiles[s->profile_count++]=value;s->checksum=vibe_custom_checksum(s);return 1;
}
