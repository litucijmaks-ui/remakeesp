#pragma once
#include <stdint.h>
static inline uint32_t world_marker_flag(uint32_t kind){return kind&2u?128u:kind&4u?256u:kind&8u?512u:kind&16u?1024u:64u;}
static inline const char *world_marker_name(uint32_t kind){return kind&2u?"Death backpack":kind&4u?"Cupboard":kind&8u?"Storage chest":kind&16u?"Furnace":"Loot balloon";}
