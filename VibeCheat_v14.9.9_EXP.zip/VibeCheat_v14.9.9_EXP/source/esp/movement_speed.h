/* Scale the final computed speed. Speed never writes fields or input. */
typedef float (ABI *MovementSpeedFunction)(Obj,Method);
static MovementSpeedFunction movement_speed_original;
static Method movement_speed_method;
static void *movement_speed_entry;
static BOOL movement_speed_hook_ready,movement_speed_installed;
static _Atomic(Obj) movement_speed_controller;
static float ABI movement_speed_proxy(Obj controller,Method info){
 float value=movement_speed_original(controller,info);
 if(!running||stop_requested||native_faulted||!focused||menu_open||cursor_wanted||
    !(move_options&1u)||speed_percent<=100u||controller!=movement_speed_controller)return value;
 if(!finite_number(value)||value<=0.f||value>50.f||speed_percent>300u)return value;
 float scaled=value*(float)speed_percent*.01f;
 return finite_number(scaled)&&scaled<=150.f?scaled:value;
}
static void resolve_movement_speed(void *movement){
 Method candidate=method(movement,PC_METHOD_movementSpeed,0);
 movement_speed_hook_ready=compatible_method(candidate,klass("System","Single"),0,0,0)&&
  ((movement_speed_installed&&candidate==movement_speed_method&&*(void *const*)candidate==movement_speed_entry)||
   aimkill_entry_matches(candidate,PC_RVA_movementSpeed,pc_prefix_movementSpeed,sizeof(pc_prefix_movementSpeed)));
 if(movement_speed_installed&&candidate!=movement_speed_method)movement_speed_hook_ready=0;
 if(!movement_speed_installed)movement_speed_method=candidate;
 speed_available=speed_available&&movement_speed_hook_ready;
 logline(movement_speed_hook_ready?"Speed: final native float getter verified; fields/input unchanged":"Speed unavailable: final getter profile differs");
}
static BOOL movement_speed_install(void){
 if(movement_speed_installed)return movement_speed_hook_ready;
 if(!movement_speed_hook_ready||!movement_speed_method)return 0;
 movement_speed_entry=*(void *const*)movement_speed_method;
 DWORD error=VibeCreateNativeHook(*(void *const*)movement_speed_method,movement_speed_proxy,(void**)&movement_speed_original);
 if(error){log_number("Speed native hook failed=",error);return 0;}
 movement_speed_installed=1;logline("Speed final result multiplier installed; 1x is exact pass-through");return 1;
}
