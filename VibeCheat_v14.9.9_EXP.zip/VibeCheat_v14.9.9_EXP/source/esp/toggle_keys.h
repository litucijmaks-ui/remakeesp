typedef struct {DWORD key;BOOL down;} ToggleKey;
static ToggleKey movement_keys[2];
/* Observe releases even while input is paused. Assigning a held key, returning
   focus or closing the menu cannot manufacture a new key press. */
static DWORD movement_key_poll(DWORD speed,DWORD noclip,BOOL allowed){
 DWORD keys[]={speed,noclip},mask=0;
 for(unsigned i=0;i<2;++i){ToggleKey *state=&movement_keys[i];DWORD key=keys[i];BOOL down=key&&GetAsyncKeyState((int32_t)key)<0;
  BOOL rising=state->key==key&&down&&!state->down;state->key=key;state->down=down;
  if(allowed&&key&&rising)mask|=i?4u:1u;
 }
 return mask;
}
