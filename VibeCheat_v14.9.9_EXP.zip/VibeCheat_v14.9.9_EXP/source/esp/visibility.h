/* Query only the current camera-to-joint segment. A failed query never grants
   visibility. The first collider may be the target's own compound hitbox. */
static BOOL visibility_available(void){return physics_ray&&hit_collider&&component_parent&&player_type;}
static BOOL visibility_check_point(Obj player,const Vec3 *origin,const Vec3 *point){
 if(!visibility_available()||!alive(player)||!origin||!point)return 0;
 if(!finite_number(origin->x)||!finite_number(origin->y)||!finite_number(origin->z)||!finite_number(point->x)||!finite_number(point->y)||!finite_number(point->z))return 0;
 Vec3 direction={point->x-origin->x,point->y-origin->y,point->z-origin->z};
 float square=direction.x*direction.x+direction.y*direction.y+direction.z*direction.z;
 if(!finite_number(square)||square<0.000001f)return 0;
 float distance=__builtin_sqrtf(square);direction.x/=distance;direction.y/=distance;direction.z/=distance;
 PhysicsHit hit;BOOL found=0;
 /* DefaultRaycastLayers (-5): do not inherit a weapon mask that could exclude
    walls. Ignore trigger volumes; solid target colliders are accepted below. */
 if(!trace_ray(origin,&direction,distance,-5,1,&hit,&found))return 0;
 if(!found)return 1;
 Obj collider=invoke(hit_collider,&hit,0);if(!alive(collider))return 0;
 unsigned char inactive=0;
 if(hitbox_type&&hitbox_status){
  void *args[]={hitbox_type,&inactive};Obj hitbox=invoke(component_parent,collider,args);
  if(alive(hitbox)&&invoke(hitbox_status,hitbox,0)==player)return 1;
 }
 void *args[]={player_type,&inactive};return invoke(component_parent,collider,args)==player;
}
