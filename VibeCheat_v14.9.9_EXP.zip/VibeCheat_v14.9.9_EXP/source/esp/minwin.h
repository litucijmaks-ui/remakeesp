#pragma once
#include <stdint.h>
#include <stddef.h>
#ifdef _MSC_VER
#define ABI __stdcall
#define IMPORT __declspec(dllimport)
#else
#define ABI __attribute__((ms_abi))
#define IMPORT
#endif
typedef void *HANDLE;
typedef HANDLE HMODULE;
typedef HANDLE HWND;
typedef HANDLE HDC;
typedef HANDLE HGDIOBJ;
typedef HANDLE HBRUSH;
typedef HANDLE HPEN;
typedef HANDLE HBITMAP;
typedef HANDLE HFONT;
typedef uint32_t DWORD;
typedef int32_t BOOL;
typedef uint32_t UINT;
typedef uint16_t WCHAR;
typedef uintptr_t WPARAM;
typedef intptr_t LPARAM;
typedef intptr_t LRESULT;
typedef LRESULT (ABI *WNDPROC)(HWND, UINT, WPARAM, LPARAM);
typedef DWORD (ABI *THREADPROC)(void *);
typedef BOOL (ABI *ENUMPROC)(HWND, LPARAM);
typedef struct { int32_t x,y; } POINT;
typedef struct { int32_t cx,cy; } SIZE;
typedef struct { int32_t left,top,right,bottom; } RECT;
typedef struct {DWORD size,flags;HWND active,focus,capture,menu_owner,move_size,caret;RECT caret_rect;} GUITHREADINFO;
typedef struct {HDC hdc;BOOL erase;RECT paint;BOOL restore,incremental;unsigned char reserved[32];} PAINTSTRUCT;
typedef struct { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; POINT pt; DWORD lPrivate; } MSG;
typedef struct {
 UINT cbSize, style; WNDPROC lpfnWndProc; int32_t cbClsExtra, cbWndExtra;
 HMODULE hInstance; HANDLE hIcon,hCursor; HBRUSH hbrBackground; const char *lpszMenuName,*lpszClassName; HANDLE hIconSm;
} WNDCLASSEXA;
typedef struct { DWORD dwSize,cntUsage,th32ProcessID; uintptr_t th32DefaultHeapID; DWORD th32ModuleID,cntThreads,th32ParentProcessID; int32_t pcPriClassBase; DWORD dwFlags; char szExeFile[260]; } PROCESSENTRY32;
typedef struct { DWORD dwSize,th32ModuleID,th32ProcessID,GlblcntUsage,ProccntUsage; unsigned char *modBaseAddr; DWORD modBaseSize; HMODULE hModule; char szModule[256],szExePath[260]; } MODULEENTRY32;
typedef struct {DWORD cb;char *reserved,*desktop,*title;DWORD x,y,cx,cy,xchars,ychars,fill,flags;uint16_t show,reserved_bytes;void *reserved_data;HANDLE input,output,error;} STARTUPINFOA;
typedef struct {HANDLE process,thread;DWORD pid,tid;} PROCESS_INFORMATION;
typedef struct {DWORD cb;WCHAR *reserved,*desktop,*title;DWORD x,y,cx,cy,xchars,ychars,fill,flags;uint16_t show,reserved_bytes;void *reserved_data;HANDLE input,output,error;} STARTUPINFOW;
typedef struct {void *base,*allocation;DWORD allocation_protect,alignment;size_t region_size;DWORD state,protect,type,padding;} MEMORY_BASIC_INFORMATION;
#define INVALID_HANDLE ((HANDLE)(intptr_t)-1)
#define RGB(r,g,b) ((DWORD)((r)|((g)<<8)|((b)<<16)))
#define DECL(ret, name, args) IMPORT ret ABI name args
DECL(HMODULE, GetModuleHandleA, (const char *));
DECL(void *, GetProcAddress, (HMODULE,const char *));
DECL(BOOL, GetModuleHandleExA, (DWORD,const char *,HMODULE *));
DECL(DWORD, GetModuleFileNameA, (HMODULE,char *,DWORD));
DECL(DWORD, GetModuleFileNameW, (HMODULE,WCHAR *,DWORD));
DECL(int32_t, WideCharToMultiByte, (UINT,DWORD,const WCHAR *,int32_t,char *,int32_t,const char *,BOOL *));
DECL(BOOL, SetCurrentDirectoryW, (const WCHAR *));
DECL(UINT, WinExec, (const char *,UINT));
DECL(BOOL, CreateProcessA, (const char *,char *,void *,void *,BOOL,DWORD,void *,const char *,STARTUPINFOA *,PROCESS_INFORMATION *));
DECL(BOOL, CreateProcessW, (const WCHAR *,WCHAR *,void *,void *,BOOL,DWORD,void *,const WCHAR *,STARTUPINFOW *,PROCESS_INFORMATION *));
DECL(HANDLE, CreateEventA, (void *,BOOL,BOOL,const char *));
DECL(HANDLE, OpenEventA, (DWORD,BOOL,const char *));
DECL(BOOL, SetEvent, (HANDLE));
DECL(BOOL, ResetEvent, (HANDLE));
DECL(BOOL, DisableThreadLibraryCalls, (HMODULE));
DECL(HANDLE, CreateThread, (void *,size_t,THREADPROC,void *,DWORD,DWORD *));
DECL(BOOL, CloseHandle, (HANDLE));
DECL(void, Sleep, (DWORD));
DECL(uint64_t, GetTickCount64, (void));
DECL(DWORD, GetCurrentProcessId, (void));
DECL(DWORD, GetCurrentThreadId, (void));
DECL(DWORD, TlsAlloc, (void));
DECL(void *, TlsGetValue, (DWORD));
DECL(BOOL, TlsSetValue, (DWORD,void *));
DECL(DWORD, GetLastError, (void));
DECL(void, SetLastError, (DWORD));
DECL(BOOL, QueryPerformanceCounter, (int64_t *));
DECL(BOOL, QueryPerformanceFrequency, (int64_t *));
DECL(HANDLE, CreateWaitableTimerExW, (void *,const WCHAR *,DWORD,DWORD));
DECL(BOOL, SetWaitableTimer, (HANDLE,const int64_t *,int32_t,void *,void *,BOOL));
DECL(void, OutputDebugStringA, (const char *));
DECL(HANDLE, CreateFileA, (const char *,DWORD,DWORD,void *,DWORD,DWORD,HANDLE));
DECL(HANDLE, CreateFileW, (const WCHAR *,DWORD,DWORD,void *,DWORD,DWORD,HANDLE));
DECL(BOOL, ReadFile, (HANDLE,void *,DWORD,DWORD *,void *));
DECL(BOOL, WriteFile, (HANDLE,const void *,DWORD,DWORD *,void *));
DECL(BOOL, MoveFileExA, (const char *,const char *,DWORD));
DECL(BOOL, MoveFileExW, (const WCHAR *,const WCHAR *,DWORD));
DECL(BOOL, DeleteFileA, (const char *));
DECL(BOOL, DeleteFileW, (const WCHAR *));
DECL(HANDLE, CreateToolhelp32Snapshot, (DWORD,DWORD));
DECL(BOOL, Process32First, (HANDLE,PROCESSENTRY32 *));
DECL(BOOL, Process32Next, (HANDLE,PROCESSENTRY32 *));
DECL(BOOL, Module32First, (HANDLE,MODULEENTRY32 *));
DECL(BOOL, Module32Next, (HANDLE,MODULEENTRY32 *));
DECL(HANDLE, OpenProcess, (DWORD,BOOL,DWORD));
DECL(HANDLE, GetCurrentProcess, (void));
DECL(void *, VirtualAlloc, (void *,size_t,DWORD,DWORD));
DECL(BOOL, VirtualFree, (void *,size_t,DWORD));
DECL(BOOL, VirtualProtect, (void *,size_t,DWORD,DWORD *));
DECL(size_t, VirtualQuery, (const void *,MEMORY_BASIC_INFORMATION *,size_t));
DECL(BOOL, FlushInstructionCache, (HANDLE,const void *,size_t));
DECL(void *, VirtualAllocEx, (HANDLE,void *,size_t,DWORD,DWORD));
DECL(BOOL, VirtualFreeEx, (HANDLE,void *,size_t,DWORD));
DECL(BOOL, WriteProcessMemory, (HANDLE,void *,const void *,size_t,size_t *));
DECL(HANDLE, CreateRemoteThread, (HANDLE,void *,size_t,THREADPROC,void *,DWORD,DWORD *));
DECL(DWORD, WaitForSingleObject, (HANDLE,DWORD));
DECL(DWORD, WaitForMultipleObjects, (DWORD,const HANDLE *,BOOL,DWORD));
DECL(BOOL, GetExitCodeThread, (HANDLE,DWORD *));
DECL(DWORD, GetFullPathNameA, (const char *,DWORD,char *,char **));
DECL(char *, GetCommandLineA, (void));
DECL(WCHAR *, GetCommandLineW, (void));
DECL(void, ExitProcess, (UINT));
DECL(BOOL, EnumWindows, (ENUMPROC,LPARAM));
DECL(BOOL, SetProcessDPIAware, (void));
DECL(DWORD, GetWindowThreadProcessId, (HWND,DWORD *));
DECL(BOOL, IsWindowVisible, (HWND));
DECL(BOOL, IsWindow, (HWND));
DECL(HWND, GetWindow, (HWND,UINT));
DECL(HWND, GetForegroundWindow, (void));
DECL(BOOL, GetGUIThreadInfo, (DWORD,GUITHREADINFO *));
DECL(BOOL, SetForegroundWindow, (HWND));
DECL(BOOL, AllowSetForegroundWindow, (DWORD));
DECL(BOOL, IsIconic, (HWND));
DECL(BOOL, SetPropA, (HWND,const char *,HANDLE));
DECL(HANDLE, GetPropA, (HWND,const char *));
DECL(HANDLE, RemovePropA, (HWND,const char *));
DECL(HWND, FindWindowA, (const char *,const char *));
DECL(HWND, GetParent, (HWND));
DECL(HWND, SetParent, (HWND,HWND));
DECL(intptr_t, GetWindowLongPtrA, (HWND,int32_t));
DECL(BOOL, ClipCursor, (const RECT *));
DECL(LRESULT, SendMessageTimeoutA, (HWND,UINT,WPARAM,LPARAM,UINT,UINT,uintptr_t *));
DECL(int32_t, GetClassNameA, (HWND,char *,int32_t));
DECL(intptr_t, SetWindowLongPtrA, (HWND,int32_t,intptr_t));
DECL(LRESULT, CallWindowProcA, (WNDPROC,HWND,UINT,WPARAM,LPARAM));
DECL(uintptr_t, SetTimer, (HWND,uintptr_t,UINT,void *));
DECL(BOOL, KillTimer, (HWND,uintptr_t));
DECL(BOOL, PostMessageA, (HWND,UINT,WPARAM,LPARAM));
DECL(BOOL, PostThreadMessageA, (DWORD,UINT,WPARAM,LPARAM));
DECL(uint16_t, RegisterClassExA, (const WNDCLASSEXA *));
DECL(BOOL, UnregisterClassA, (const char *,HMODULE));
DECL(HWND, CreateWindowExA, (DWORD,const char *,const char *,DWORD,int32_t,int32_t,int32_t,int32_t,HWND,HANDLE,HMODULE,void *));
DECL(BOOL, DestroyWindow, (HWND));
DECL(LRESULT, DefWindowProcA, (HWND,UINT,WPARAM,LPARAM));
DECL(BOOL, ShowWindow, (HWND,int32_t));
DECL(BOOL, ShowWindowAsync, (HWND,int32_t));
DECL(BOOL, ValidateRect, (HWND,const RECT *));
DECL(BOOL, InvalidateRect, (HWND,const RECT *,BOOL));
DECL(HDC, BeginPaint, (HWND,PAINTSTRUCT *));
DECL(BOOL, EndPaint, (HWND,const PAINTSTRUCT *));
DECL(BOOL, GetMessageA, (MSG *,HWND,UINT,UINT));
DECL(void, PostQuitMessage, (int32_t));
DECL(HWND, SetCapture, (HWND));
DECL(BOOL, ReleaseCapture, (void));
DECL(BOOL, ScreenToClient, (HWND,POINT *));
DECL(HANDLE, LoadCursorA, (HMODULE,const char *));
DECL(BOOL, SetWindowPos, (HWND,HWND,int32_t,int32_t,int32_t,int32_t,UINT));
DECL(BOOL, SetLayeredWindowAttributes, (HWND,DWORD,unsigned char,DWORD));
DECL(BOOL, GetClientRect, (HWND,RECT *));
DECL(BOOL, GetWindowRect, (HWND,RECT *));
DECL(BOOL, ClientToScreen, (HWND,POINT *));
DECL(BOOL, PeekMessageA, (MSG *,HWND,UINT,UINT,UINT));
DECL(BOOL, TranslateMessage, (const MSG *));
DECL(LRESULT, DispatchMessageA, (const MSG *));
DECL(int16_t, GetAsyncKeyState, (int32_t));
DECL(UINT, MapVirtualKeyA, (UINT,UINT));
DECL(int32_t, GetKeyNameTextA, (int32_t,char *,int32_t));
DECL(HDC, GetDC, (HWND));
DECL(int32_t, ReleaseDC, (HWND,HDC));
DECL(int32_t, FillRect, (HDC,const RECT *,HBRUSH));
DECL(int32_t, MessageBoxA, (HWND,const char *,const char *,UINT));
DECL(HDC, CreateCompatibleDC, (HDC));
DECL(BOOL, DeleteDC, (HDC));
DECL(HBITMAP, CreateCompatibleBitmap, (HDC,int32_t,int32_t));
DECL(HGDIOBJ, SelectObject, (HDC,HGDIOBJ));
DECL(BOOL, DeleteObject, (HGDIOBJ));
DECL(HGDIOBJ, GetStockObject, (int32_t));
DECL(HBRUSH, CreateSolidBrush, (DWORD));
DECL(HPEN, CreatePen, (int32_t,int32_t,DWORD));
DECL(BOOL, Rectangle, (HDC,int32_t,int32_t,int32_t,int32_t));
DECL(BOOL, RoundRect, (HDC,int32_t,int32_t,int32_t,int32_t,int32_t,int32_t));
DECL(BOOL, Ellipse, (HDC,int32_t,int32_t,int32_t,int32_t));
DECL(BOOL, Polygon, (HDC,const POINT *,int32_t));
DECL(int32_t, SetDIBitsToDevice, (HDC,int32_t,int32_t,DWORD,DWORD,int32_t,int32_t,UINT,UINT,const void *,const void *,UINT));
DECL(int32_t, IntersectClipRect, (HDC,int32_t,int32_t,int32_t,int32_t));
DECL(int32_t, SaveDC, (HDC));
DECL(BOOL, RestoreDC, (HDC,int32_t));
DECL(HFONT, CreateFontA, (int32_t,int32_t,int32_t,int32_t,int32_t,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,const char *));
DECL(BOOL, MoveToEx, (HDC,int32_t,int32_t,POINT *));
DECL(BOOL, LineTo, (HDC,int32_t,int32_t));
DECL(int32_t, SetBkMode, (HDC,int32_t));
DECL(DWORD, SetTextColor, (HDC,DWORD));
DECL(BOOL, TextOutA, (HDC,int32_t,int32_t,const char *,int32_t));
DECL(BOOL, TextOutW, (HDC,int32_t,int32_t,const WCHAR *,int32_t));
DECL(BOOL, GetTextExtentPoint32A, (HDC,const char *,int32_t,SIZE *));
DECL(BOOL, GetTextExtentPoint32W, (HDC,const WCHAR *,int32_t,SIZE *));
DECL(BOOL, BitBlt, (HDC,int32_t,int32_t,int32_t,int32_t,HDC,int32_t,int32_t,DWORD));

static inline size_t slen(const char *s) { size_t n=0; while(s && s[n]) ++n; return n; }
static inline int equal(const char *a,const char *b) { if(!a||!b) return 0; while(*a&&*b&&*a==*b){++a;++b;} return *a==*b; }
static inline int iequal(const char *a,const char *b) { while(*a&&*b){char x=*a++,y=*b++;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return 0;}return *a==*b; }
static inline void copystr(char *out,const char *s,size_t n) { if(!n)return;size_t i=0;while(s[i]&&i+1<n){out[i]=s[i];++i;}out[i]=0; }
static inline void zeromem(void *p,size_t n) { unsigned char *a=(unsigned char *)p;while(n--)*a++=0; }
static inline size_t wlen(const WCHAR *s){size_t n=0;while(s&&s[n])++n;return n;}
static inline void wcopy(WCHAR *out,const WCHAR *s,size_t cap){if(!cap)return;size_t i=0;while(s[i]&&i+1<cap){out[i]=s[i];++i;}out[i]=0;}
static inline void wascii(WCHAR *out,const char *s,size_t cap){if(!cap)return;size_t i=0;while(s[i]&&i+1<cap){out[i]=(unsigned char)s[i];++i;}out[i]=0;}
