/* Search radius never becomes strike reach. One command per tool cooldown. */
#define FARM_MAGIC_FLAG 128u
static uint64_t magic_next_burst,magic_next_scan;
static unsigned magic_cursor;
static _Atomic unsigned magic_requests;
static void magic_farm_release(void){magic_next_burst=magic_next_scan=0;magic_cursor=0;}
#include "interaction_limits.h"
static void magic_farm_tick(Obj local,Obj camera,BOOL active){
 if(!active||!(farm_options&FARM_MAGIC_FLAG)||!farm_available){magic_farm_release();farm_release();farm_state_set("Magic farm paused: local player, focus or command unavailable");return;}
 navigation_release();if(!(farm_options&6u)){farm_state_set("Magic farm: select Trees or Ore");return;}
 uint64_t now=GetTickCount64();if(now<magic_next_burst)return;
 Obj weapon=0,item=0;field_get_value(local,weapon_field,&weapon);if(alive(weapon))field_get_value(weapon,item_field,&item);
 if(!alive(weapon)||!alive(item)||!farm_prepare_tool(local,item))return;
 unsigned char trees=0,ore=0;field_get_value(item,item_tree_field,&trees);field_get_value(item,item_ore_field,&ore);
 int32_t efficiency=0;Obj name=0;field_get_value(item,item_efficiency_field,&efficiency);field_get_value(item,item_name_field,&name);if(!name||efficiency<0||efficiency>10000)return;if(efficiency<1)efficiency=1;
 Vec3 origin,player_position;if(!world_position(camera,&origin)||!world_position(local,&player_position))return;
 float range=0,cooldown=0,swing=0;field_get_value(weapon,weapon_range_field,&range);field_get_value(item,item_cooldown_field,&cooldown);field_get_value(weapon,swing_field,&swing);
 float reach=interaction_reach(range,farm_range_cm);if(reach<=0){farm_state_set("Magic farm: invalid interaction distance");return;}
 if(!farm_array_root||now>=magic_next_scan){
  magic_next_scan=now+4000;int32_t inactive=0,sort=0;unsigned char no=0;void *args[]={farm_type,&no},*unsorted[]={farm_type,&inactive,&sort};Obj array=find_players_unsorted?invoke(find_players_unsorted,0,unsorted):invoke(find_players,0,args);GCHandle root=array?gchandle_new(array,0):0;if(root){if(farm_array_root)gchandle_free(farm_array_root);farm_array_root=root;}
 }
 Obj array=farm_array_root?gchandle_get_target(farm_array_root):0;if(!array)return;uint32_t count=array_length(array),header=array_object_header_size();farm_resources_seen=count;if(count>8192||header<24||header>128)return;
 unsigned sent=0;uint64_t deadline=clock_us()+1600;
 for(unsigned visited=0;visited<count&&visited<96&&clock_us()<deadline&&!native_faulted;++visited){
  if(magic_cursor>=count)magic_cursor=0;array=gchandle_get_target(farm_array_root);Obj resource=((Obj*)((unsigned char*)array+header))[magic_cursor++];if(!alive(resource)||!farm_matches(resource,trees,ore))continue;
  Vec3 center,hit;if(!world_position(resource,&center)||!farm_point(resource,&origin,&hit)||!interaction_in_reach(&player_position,&origin,&center,&hit,reach))continue;
  Obj can=invoke(farm_can,resource,0);if(!can||!*(unsigned char*)object_unbox(can))continue;
  /* Require the actual resource collider to be the first non-trigger hit. */
  Obj expected=0;field_get_value(resource,farm_collider_field,&expected);Vec3 direction={hit.x-origin.x,hit.y-origin.y,hit.z-origin.z};float length=__builtin_sqrtf(point_distance_sq(&hit,&origin));if(!finite_number(length)||length<0.01f||!alive(expected))continue;direction.x/=length;direction.y/=length;direction.z/=length;
  PhysicsHit trace;BOOL found=0;if(!trace_ray(&origin,&direction,length+0.1f,-1,1,&trace,&found)||!found||invoke(hit_collider,&trace,0)!=expected)continue;
  Obj identity=invoke(net_identity,resource,0);if(!alive(identity))continue;float resource_cooldown=0;field_get_value(resource,farm_cooldown_field,&resource_cooldown);
  uint32_t wait=interaction_cooldown(magic_cooldown_ms,cooldown,swing,resource_cooldown);if(!wait){farm_state_set("Magic farm: invalid cooldown");return;}magic_next_burst=now+wait;
  void *args[]={identity,&hit,&efficiency,name};Obj ignored=0;const char *previous=invoke_context;invoke_context="Magic farm: nearby CmdTryFarm";BOOL ok=invoke_checked(try_farm,weapon,args,&ignored);invoke_context=previous;
  if(ok){++sent;++farm_attempts;++magic_requests;}else farm_state_set("Magic farm: command failed; inspect esp.log");break;
 }
 if(sent)farm_state_set("Magic farm: nearby node strike sent");else {magic_next_burst=now+150;farm_state_set("Magic farm: waiting for a visible node within interaction reach");}
}
