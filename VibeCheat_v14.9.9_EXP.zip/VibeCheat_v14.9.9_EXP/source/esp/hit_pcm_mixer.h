#pragma once
#include <stdint.h>
#include <stddef.h>
#define VIBE_AUDIO_VOICES 16u
typedef struct {const unsigned char *pcm;size_t samples,position;uint32_t volume;uint64_t serial;} VibePcmVoice;
typedef struct {VibePcmVoice voices[VIBE_AUDIO_VOICES];uint64_t serial,evictions;} VibePcmMixer;
static inline void vibe_pcm_clear(VibePcmMixer *m){for(unsigned i=0;i<VIBE_AUDIO_VOICES;++i)m->voices[i].pcm=0;}
static inline int vibe_pcm_active(const VibePcmMixer *m){for(unsigned i=0;i<VIBE_AUDIO_VOICES;++i)if(m->voices[i].pcm)return 1;return 0;}
static inline void vibe_pcm_start(VibePcmMixer *m,const unsigned char *pcm,size_t samples,uint32_t volume){
 if(!pcm||!samples||!volume)return;if(volume>100)volume=100;
 unsigned slot=0;uint64_t oldest=UINT64_MAX;int found=0;
 for(unsigned i=0;i<VIBE_AUDIO_VOICES;++i){if(!m->voices[i].pcm){slot=i;found=1;break;}if(m->voices[i].serial<oldest){oldest=m->voices[i].serial;slot=i;}}
 if(!found)++m->evictions;
 VibePcmVoice v={pcm,samples,0,volume,++m->serial};m->voices[slot]=v;
}
static inline void vibe_pcm_render(VibePcmMixer *m,int16_t *out,size_t count){
 for(size_t n=0;n<count;++n){
  int64_t sum=0;
  for(unsigned i=0;i<VIBE_AUDIO_VOICES;++i){VibePcmVoice *v=&m->voices[i];if(!v->pcm)continue;
   size_t at=v->position*2;int16_t sample=(int16_t)((uint16_t)v->pcm[at]|((uint16_t)v->pcm[at+1]<<8));
   sum+=(int64_t)sample*v->volume/100;if(++v->position>=v->samples)v->pcm=0;
  }
  if(sum>32767)sum=32767;else if(sum<-32768)sum=-32768;out[n]=(int16_t)sum;
 }
}
