/* Only the metadata-checked Item.reloadTime is changed. Ammo and server
   reload completion still use the game's normal command and coroutine. */
static GCHandle reload_timing_root;
static float reload_timing_base,reload_timing_applied;
static _Atomic uint64_t reload_timing_changes;
static _Atomic(const char *) reload_timing_state="Fast reload disabled";
static void reload_timing_release(void){
 if(reload_timing_root){
  Obj item=gchandle_get_target(reload_timing_root);float current=0;
  if(alive(item)&&combat_reload_time){
   field_get_value(item,combat_reload_time,&current);
   if(finite_number(current)&&__builtin_fabsf(current-reload_timing_applied)<0.00001f)field_set_value(item,combat_reload_time,&reload_timing_base);
  }
  gchandle_free(reload_timing_root);reload_timing_root=0;
 }
 reload_timing_state="Fast reload paused or disabled";
}
static void reload_timing_tick(Obj item,BOOL enabled){
 if(!enabled||!alive(item)||!combat_reload_time||!rapid_ammo_field||!extra_mag_size||!field_set_value){reload_timing_release();return;}
 Obj ammo=0;int32_t size=0;field_get_value(item,rapid_ammo_field,&ammo);field_get_value(item,extra_mag_size,&size);
 if(!ammo||size<=0||size>10000){reload_timing_release();reload_timing_state="Fast reload: equip a firearm";return;}
 if(reload_timing_root&&gchandle_get_target(reload_timing_root)!=item)reload_timing_release();
 float current=0;field_get_value(item,combat_reload_time,&current);
 if(!finite_number(current)||current<0||current>30.f){reload_timing_release();reload_timing_state="Fast reload: invalid reload timer";return;}
 if(!reload_timing_root){reload_timing_root=gchandle_new(item,0);if(!reload_timing_root)return;reload_timing_base=reload_timing_applied=current;}
 else if(__builtin_fabsf(current-reload_timing_applied)>0.00001f)reload_timing_base=current;
 float desired=reload_timing_base<0.1f?reload_timing_base:0.1f;
 if(__builtin_fabsf(current-desired)>0.00001f){field_set_value(item,combat_reload_time,&desired);atomic_fetch_add(&reload_timing_changes,1);}
 reload_timing_applied=desired;reload_timing_state="Fast reload: local timer capped at 100ms; server completion unverified";
}
