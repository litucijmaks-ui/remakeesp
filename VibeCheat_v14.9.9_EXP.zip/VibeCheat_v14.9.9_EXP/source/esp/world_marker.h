/* Unity screen Y is bottom-up; marker pixels are top-down. */
static BOOL world_marker_project(const Vec3 *screen,int width,int height,VibeWorldMarker *out){
 if(!finite_number(screen->x)||!finite_number(screen->y)||!finite_number(screen->z)||width<40||height<40||__builtin_fabsf(screen->z)<.01f)return 0;
 float x=screen->x,y=(float)height-screen->y,cx=width*.5f,cy=height*.5f;
 if(screen->z<0){x=width-x;y=height-y;}
 out->edge=screen->z<0||x<18||x>width-18||y<18||y>height-18;
 if(out->edge){float dx=x-cx,dy=y-cy;if(__builtin_fabsf(dx)+__builtin_fabsf(dy)<.001f)dy=1;
  float ax=__builtin_fabsf(dx),ay=__builtin_fabsf(dy);if(ax<.001f)ax=.001f;if(ay<.001f)ay=.001f;
  float tx=(cx-18)/ax,ty=(cy-18)/ay,scale=tx<ty?tx:ty;x=cx+dx*scale;y=cy+dy*scale;}
 out->x=x;out->y=y;return 1;
}
