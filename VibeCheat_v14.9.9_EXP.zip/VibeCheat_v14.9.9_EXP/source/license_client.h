#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <stdint.h>
#include "license_crypto.h"

typedef struct {
 wchar_t directory[32768],server[512];char hwid[65],token[65],error[96],nonce[33],device_public[145];unsigned char device_private[104];DWORD ttl;uint64_t expires,request_started,request_stamp,lease_deadline;DWORD bind_pc;
} VibeLicenseClient;
static void license_error(VibeLicenseClient *c,const char *message){snprintf(c->error,sizeof(c->error),"%s",message);}
static BOOL license_hex(const char *s){if(strlen(s)!=64)return 0;for(unsigned i=0;i<64;i++)if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f')))return 0;return 1;}
static BOOL license_code(const char *s){if(strlen(s)!=6)return 0;for(unsigned i=0;i<6;i++)if(s[i]<'0'||s[i]>'9')return 0;return 1;}
static BOOL license_reply(VibeLicenseClient *c,const char *reply,DWORD status){
 unsigned ttl=0,bind=0;unsigned long long expires=0,issued=0,until=0;char token[65]={0},hwid[65]={0},nonce[33]={0},signature[129]={0},canonical[512];unsigned char sig[64];int prefix=0,used=0;uint64_t now=license_unix(),elapsed=GetTickCount64()-c->request_started;
 if(status==200&&sscanf(reply,"VIBE3 OK %u %64[0-9a-f] %llu %u %64[0-9a-f] %32[0-9a-f] %llu %llu%n %128[0-9a-f]%n",&ttl,token,&expires,&bind,hwid,nonce,&issued,&until,&prefix,signature,&used)==9&&reply[used]=='\n'&&!reply[used+1]){
  snprintf(canonical,sizeof(canonical),"VIBE3 OK %u %s %llu %u %s %s %llu %llu",ttl,token,expires,bind,hwid,nonce,issued,until);
  if(strlen(canonical)!=(size_t)prefix||memcmp(canonical,reply,prefix)||reply[prefix]!=' '||!license_fromhex(signature,64,sig)||!license_ecdsa(vibe_license_public,72,reply,(ULONG)prefix,sig,FALSE)){license_error(c,"invalid_signature");return 0;}
  if(!ttl||ttl>90||bind>1||!license_hex(token)||strcmp(hwid,c->hwid)||strlen(nonce)!=32||strcmp(nonce,c->nonce)||until<issued||until-issued!=ttl||(expires&&until>expires)||elapsed>=ttl*1000ULL){license_error(c,"invalid_lease");return 0;}
  if(issued>now+300||now>issued+300){license_error(c,"clock_error");return 0;}
  memcpy(c->token,token,65);c->ttl=ttl;c->expires=expires;c->bind_pc=bind;c->lease_deadline=c->request_started+ttl*1000ULL;c->error[0]=0;return 1;
 }
 char code[64]={0};if(sscanf(reply,"VIBE3 ERR %63[a-z_]",code)==1)license_error(c,code);else license_error(c,"invalid_server_response");return 0;
}
static BOOL license_ready_reply(VibeLicenseClient *c,const char *reply,DWORD status){
 char nonce[33]={0},signature[129]={0},canonical[96];unsigned char sig[64];int prefix=0,used=0;
 if(status!=200||sscanf(reply,"VIBE3 READY %32[0-9a-f]%n %128[0-9a-f]%n",nonce,&prefix,signature,&used)!=2||reply[used]!='\n'||reply[used+1]){license_error(c,"upgrade_required");return 0;}
 snprintf(canonical,sizeof(canonical),"VIBE3 READY %s",nonce);
 if(strlen(canonical)!=(size_t)prefix||memcmp(canonical,reply,prefix)||reply[prefix]!=' '||strlen(nonce)!=32||strcmp(nonce,c->nonce)||!license_fromhex(signature,64,sig)||!license_ecdsa(vibe_license_public,72,reply,(ULONG)prefix,sig,FALSE)){license_error(c,"invalid_signature");return 0;}return 1;
}
static BOOL license_paths(VibeLicenseClient *c,HMODULE module){
 ZeroMemory(c,sizeof(*c));DWORD n=GetModuleFileNameW(module,c->directory,32768);if(!n||n>=32768-32)return 0;
 wchar_t *slash=wcsrchr(c->directory,L'\\');if(!slash)return 0;slash[1]=0;
 wchar_t path[32768];wcscpy(path,c->directory);wcscat(path,L"client.ini");
 if(!GetPrivateProfileStringW(L"license",L"server",L"",c->server,512,path)){license_error(c,"configure_client_ini");return 0;}
 wchar_t guid[128]={0};DWORD size=sizeof(guid);
 /* Both binaries are x64, so the default registry view is already 64-bit. */
 if(RegGetValueW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Microsoft\\Cryptography",L"MachineGuid",RRF_RT_REG_SZ,NULL,guid,&size)!=ERROR_SUCCESS){license_error(c,"device_id_unavailable");return 0;}
 BCRYPT_ALG_HANDLE algorithm=NULL;BCRYPT_HASH_HANDLE hash=NULL;DWORD bytes=0,got=0;unsigned char digest[32];BOOL ok=0;unsigned char *object=NULL;
 if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
 if(BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,(PUCHAR)&bytes,sizeof(bytes),&got,0)<0)goto done;
 object=(unsigned char*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,bytes);if(!object)goto done;
 if(BCryptCreateHash(algorithm,&hash,object,bytes,NULL,0,0)<0)goto done;
 if(BCryptHashData(hash,(PUCHAR)"VIBE-PC-v1",10,0)<0||BCryptHashData(hash,(PUCHAR)guid,(ULONG)(wcslen(guid)*sizeof(wchar_t)),0)<0||BCryptFinishHash(hash,digest,32,0)<0)goto done;
 for(unsigned i=0;i<32;i++)snprintf(c->hwid+i*2,3,"%02x",digest[i]);ok=license_device(c->device_private,c->device_public);if(!ok)license_error(c,"device_key_failed");
 done:if(hash)BCryptDestroyHash(hash);if(object)HeapFree(GetProcessHeap(),0,object);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);SecureZeroMemory(guid,sizeof(guid));if(!ok)license_error(c,"device_hash_failed");return ok;
}
static BOOL license_post(VibeLicenseClient *c,const wchar_t *endpoint,const char *name,const char *value){
 c->error[0]=0;
 wchar_t host[256]={0},path[256]={0},extra[256]={0},user[128]={0},password[128]={0};URL_COMPONENTS url={0};url.dwStructSize=sizeof(url);url.lpszHostName=host;url.dwHostNameLength=256;url.lpszUrlPath=path;url.dwUrlPathLength=256;url.lpszExtraInfo=extra;url.dwExtraInfoLength=256;url.lpszUserName=user;url.dwUserNameLength=128;url.lpszPassword=password;url.dwPasswordLength=128;
 if(!WinHttpCrackUrl(c->server,0,0,&url)||url.dwUserNameLength||url.dwPasswordLength||url.dwExtraInfoLength||(url.dwUrlPathLength&&wcscmp(path,L"/"))){license_error(c,"invalid_server_url");return 0;}
 BOOL local=!_wcsicmp(host,L"127.0.0.1")||!_wcsicmp(host,L"localhost")||!_wcsicmp(host,L"::1");
 if(url.nScheme!=INTERNET_SCHEME_HTTPS&&!(local&&url.nScheme==INTERNET_SCHEME_HTTP)){license_error(c,"https_required");return 0;}
 /* Confirm the pinned server identity before sending activation credentials. */
 if(name&&!license_post(c,L"/v3/status",NULL,NULL))return 0;
 HINTERNET session=WinHttpOpen(L"VIBE-License/3",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0),connection=NULL,request=NULL;BOOL ok=0;
 char body[1024],reply[2048],proof_message[512],proof_hex[129];unsigned char nonce_bytes[16],proof[64];wchar_t route[96];DWORD used=0,status=0,status_size=sizeof(status);DWORD policy=WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
 if(!session)goto done;
 WinHttpSetTimeouts(session,3000,3000,3000,3000);
 connection=WinHttpConnect(session,host,url.nPort,0);if(!connection)goto done;
 if(BCryptGenRandom(NULL,nonce_bytes,16,BCRYPT_USE_SYSTEM_PREFERRED_RNG)<0){license_error(c,"random_failed");goto done;}
 license_tohex(nonce_bytes,16,c->nonce);c->request_started=GetTickCount64();c->request_stamp=license_unix();
 if(name)wcscpy(route,!strcmp(name,"key")?L"/v3/activate":L"/v3/check");
 else swprintf(route,96,L"/v3/status?nonce=%hs",c->nonce);
 request=WinHttpOpenRequest(connection,name?L"POST":L"GET",route,NULL,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,url.nScheme==INTERNET_SCHEME_HTTPS?WINHTTP_FLAG_SECURE:0);if(!request)goto done;
 if(!WinHttpSetOption(request,WINHTTP_OPTION_REDIRECT_POLICY,&policy,sizeof(policy)))goto done;
 if(name){
  snprintf(proof_message,sizeof(proof_message),"VIBE3REQ %s %s %s %s %llu %s",!strcmp(name,"key")?"activate":"check",value,c->hwid,c->nonce,(unsigned long long)c->request_stamp,c->device_public);
  if(!license_ecdsa(c->device_private,104,proof_message,(ULONG)strlen(proof_message),proof,TRUE)){license_error(c,"device_key_failed");goto done;}
  license_tohex(proof,64,proof_hex);
  snprintf(body,sizeof(body),"%s=%s&hwid=%s&nonce=%s&stamp=%llu&public=%s&proof=%s&protocol=3",name,value,c->hwid,c->nonce,(unsigned long long)c->request_stamp,c->device_public,proof_hex);
 }else body[0]=0;
 if(!WinHttpSendRequest(request,L"Content-Type: application/x-www-form-urlencoded\r\nX-Vibe-Protocol: 3\r\n",(DWORD)-1,body,(DWORD)strlen(body),(DWORD)strlen(body),0)||!WinHttpReceiveResponse(request,NULL)||!WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&status_size,WINHTTP_NO_HEADER_INDEX))goto done;
 for(;;){DWORD got=0;if(used>=sizeof(reply)-1){license_error(c,"response_too_large");goto done;}if(!WinHttpReadData(request,reply+used,(DWORD)sizeof(reply)-1-used,&got))goto done;if(!got)break;used+=got;}
 reply[used]=0;if(memchr(reply,0,used)){license_error(c,"invalid_server_response");goto done;}ok=name?license_reply(c,reply,status):license_ready_reply(c,reply,status);
 done:if(!ok&&!c->error[0])license_error(c,"server_unavailable");if(request)WinHttpCloseHandle(request);if(connection)WinHttpCloseHandle(connection);if(session)WinHttpCloseHandle(session);SecureZeroMemory(body,sizeof(body));SecureZeroMemory(proof_message,sizeof(proof_message));return ok;
}
static BOOL license_ticket(VibeLicenseClient *c,BOOL write){
 wchar_t path[32768];wcscpy(path,c->directory);wcscat(path,L"license-session.dat");BOOL ok=0;DATA_BLOB in={0},out={0};unsigned char encrypted[4096];
 if(write){
  in.pbData=(BYTE*)c->token;in.cbData=65;if(!CryptProtectData(&in,L"VIBE license session",NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&out))return 0;
  wchar_t temp[32768];wcscpy(temp,c->directory);wcscat(temp,L"license-session.tmp");HANDLE file=CreateFileW(temp,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
  if(file!=INVALID_HANDLE_VALUE){DWORD n=0;ok=WriteFile(file,out.pbData,out.cbData,&n,NULL)&&n==out.cbData&&FlushFileBuffers(file);CloseHandle(file);if(ok)ok=MoveFileExW(temp,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH);if(!ok)DeleteFileW(temp);}LocalFree(out.pbData);
 }else{
  HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(file==INVALID_HANDLE_VALUE)return 0;
  DWORD size=GetFileSize(file,NULL),n=0;if(size>0&&size<=sizeof(encrypted)&&ReadFile(file,encrypted,size,&n,NULL)&&n==size){in.pbData=encrypted;in.cbData=size;if(CryptUnprotectData(&in,NULL,NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&out)){if(out.cbData==65&&out.pbData[64]==0&&license_hex((char*)out.pbData)){memcpy(c->token,out.pbData,65);ok=1;}SecureZeroMemory(out.pbData,out.cbData);LocalFree(out.pbData);}}CloseHandle(file);
 }SecureZeroMemory(encrypted,sizeof(encrypted));return ok;
}
static BOOL license_check(VibeLicenseClient *c){c->error[0]=0;return license_hex(c->token)&&license_post(c,L"/v1/check","token",c->token);}
