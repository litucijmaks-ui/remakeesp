/* Ordinary LoadLibraryW launcher for this release's Remake DLL. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <wchar.h>
#include <stdint.h>
#include <shellapi.h>
static void launcher_note(const char *text);
static FILE *logfile;
static void note(const char *s){puts(s);launcher_note(s);if(logfile){fprintf(logfile,"%s\n",s);fflush(logfile);}}
static int fail(const char *s){char b[256];snprintf(b,sizeof(b),"%s (Windows error %lu)",s,(unsigned long)GetLastError());note(b);return 1;}
static const wchar_t *basename(const wchar_t *s){const wchar_t *p=wcsrchr(s,L'\\');return p?p+1:s;}
static int game_name(const wchar_t *s){return _wcsicmp(basename(s),L"Remake Survival.exe")==0;}
static int dll64(const wchar_t *path){
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return 0;
 unsigned char b[4096];DWORD got=0;int ok=ReadFile(f,b,sizeof(b),&got,NULL);CloseHandle(f);
 if(!ok||got<64||b[0]!='M'||b[1]!='Z')return 0;uint32_t pe;memcpy(&pe,b+60,4);
 return pe<=got-26&&memcmp(b+pe,"PE\0\0",4)==0&&b[pe+4]==0x64&&b[pe+5]==0x86&&b[pe+24]==0x0b&&b[pe+25]==2;
}
static DWORD game_pid(DWORD selected){
 HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snapshot==INVALID_HANDLE_VALUE)return 0;
 PROCESSENTRY32W p={0};p.dwSize=sizeof(p);DWORD found=0;unsigned count=0;
 if(Process32FirstW(snapshot,&p))do{if(game_name(p.szExeFile)&&(!selected||p.th32ProcessID==selected)){found=p.th32ProcessID;count++;}}while(Process32NextW(snapshot,&p));CloseHandle(snapshot);
 if(count>1){note("Several Remake processes found. Run StartVibe.exe with the desired numeric PID.");return (DWORD)-1;}return found;
}
static uintptr_t module_base(DWORD pid,const wchar_t *name){
 HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);if(snapshot==INVALID_HANDLE_VALUE)return 0;
 MODULEENTRY32W m={0};m.dwSize=sizeof(m);uintptr_t result=0;
 if(Module32FirstW(snapshot,&m))do{if(_wcsicmp(m.szModule,name)==0){result=(uintptr_t)m.modBaseAddr;break;}}while(Module32NextW(snapshot,&m));CloseHandle(snapshot);return result;
}
static int load_owner(wchar_t *owner,uintptr_t *offset){
 FARPROC load=GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW");HMODULE module=NULL;
 if(!load||!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCWSTR)(uintptr_t)load,&module))return 0;
 wchar_t path[MAX_PATH];if(!GetModuleFileNameW(module,path,MAX_PATH))return 0;wcscpy(owner,basename(path));*offset=(uintptr_t)load-(uintptr_t)module;return 1;
}
#include "launcher_direct.h"
int launcher_run(int argc,wchar_t **argv){
 SetConsoleOutputCP(CP_UTF8);wchar_t dll[32768];DWORD n=GetModuleFileNameW(NULL,dll,32768);if(!n||n>=32768)return fail("Cannot locate the launcher");
 wchar_t *slash=wcsrchr(dll,L'\\');if(!slash)return 1;slash[1]=0;
 wchar_t logpath[32768];wcscpy(logpath,dll);wcscat(logpath,L"launcher.log");logfile=_wfopen(logpath,L"w");wcscat(dll,L"RemakeESP.dll");
 note("VIBE 14.10.14 - Remake x64. All gameplay controls start disabled.");
 if(!dll64(dll)){note("Place the release's x64 RemakeESP.dll beside StartVibe.exe.");return 1;}
 wchar_t owner[MAX_PATH];uintptr_t offset=0;if(!load_owner(owner,&offset))return fail("Cannot resolve LoadLibraryW owner");
 if(argc==2&&wcscmp(argv[1],L"--self-test")==0){note("Self-test passed: x64 DLL and Windows loader owner resolved. No game process modified.");return 0;}
 DWORD selected=0;if(argc>2){note("Usage: StartVibe.exe [numeric Remake PID]");return 1;}
 if(argc==2){wchar_t *end=NULL;unsigned long v=wcstoul(argv[1],&end,10);if(!*argv[1]||*end||!v||v==(DWORD)-1){note("Invalid PID.");return 1;}selected=(DWORD)v;}
 note("Waiting up to 60 seconds for Remake Survival.exe and its Unity modules...");DWORD pid=0;ULONGLONG until=GetTickCount64()+60000;
 while(GetTickCount64()<until){pid=game_pid(selected);if(pid==(DWORD)-1)return 1;if(pid&&module_base(pid,L"GameAssembly.dll")&&module_base(pid,L"UnityPlayer.dll"))break;Sleep(100);}
 if(!pid||!module_base(pid,L"GameAssembly.dll")||!module_base(pid,L"UnityPlayer.dll")){note("Game modules were not ready. Start Remake and try again.");return 1;}
 if(module_base(pid,L"RemakeESP.dll")){note("A RemakeESP.dll is already loaded. INSERT opens the currently loaded menu. To change VIBE version, fully restart Remake and run this launcher again.");return 0;}
 HANDLE process=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,FALSE,pid);if(!process)return fail("Cannot open Remake; check matching elevation");
 wchar_t path[32768];DWORD chars=32768;BOOL wow=FALSE;
 if(!QueryFullProcessImageNameW(process,0,path,&chars)||!game_name(path)||!IsWow64Process(process,&wow)||wow){CloseHandle(process);note("Target is not the expected x64 Remake process.");return 1;}
 uintptr_t remote_owner=module_base(pid,owner);if(!remote_owner){CloseHandle(process);return fail("Windows loader module missing in target");}
 SIZE_T bytes=(wcslen(dll)+1)*sizeof(wchar_t),written=0;void *remote=VirtualAllocEx(process,NULL,bytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
 if(!remote){CloseHandle(process);return fail("Cannot allocate DLL path");}
 if(!WriteProcessMemory(process,remote,dll,bytes,&written)||written!=bytes){VirtualFreeEx(process,remote,0,MEM_RELEASE);CloseHandle(process);return fail("Cannot write DLL path");}
 HANDLE thread=CreateRemoteThread(process,NULL,0,(LPTHREAD_START_ROUTINE)(remote_owner+offset),remote,0,NULL);
 if(!thread){VirtualFreeEx(process,remote,0,MEM_RELEASE);CloseHandle(process);return fail("Cannot start Windows DLL loader");}
 DWORD wait=WaitForSingleObject(thread,15000);CloseHandle(thread);
 if(wait!=WAIT_OBJECT_0){CloseHandle(process);note("Loader has not completed. Do not retry while it is running; inspect launcher.log and esp.log. DLL path remains allocated until process exit.");return 1;}
 VirtualFreeEx(process,remote,0,MEM_RELEASE);CloseHandle(process);
 if(!module_base(pid,L"RemakeESP.dll")){note("DLL did not remain loaded. Check esp.log / compatibility.txt; a successful thread start does not prove compatibility.");return 1;}
 note("DLL loaded. Press INSERT for the menu, END to stop the functions.");return 0;
}
