#pragma once
#include "license_public.h"
static BOOL license_sha(const void *data,ULONG size,unsigned char out[32]){
 BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE hash=NULL;BOOL ok=0;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
 if(BCryptCreateHash(alg,&hash,NULL,0,NULL,0,0)<0)goto done;
 if(BCryptHashData(hash,(PUCHAR)data,size,0)<0||BCryptFinishHash(hash,out,32,0)<0)goto done;ok=1;
 done:if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);return ok;
}
static void license_tohex(const unsigned char *data,unsigned size,char *out){
 static const char digits[]="0123456789abcdef";for(unsigned i=0;i<size;i++){out[2*i]=digits[data[i]>>4];out[2*i+1]=digits[data[i]&15];}out[2*size]=0;
}
static BOOL license_fromhex(const char *text,unsigned size,unsigned char *out){
 if(strlen(text)!=size*2)return 0;for(unsigned i=0;i<size*2;i++){char c=text[i];int v=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1;if(v<0)return 0;if(!(i&1))out[i/2]=(unsigned char)(v<<4);else out[i/2]|=(unsigned char)v;}return 1;
}
static uint64_t license_unix(void){FILETIME f;ULARGE_INTEGER n;GetSystemTimeAsFileTime(&f);n.LowPart=f.dwLowDateTime;n.HighPart=f.dwHighDateTime;return n.QuadPart/10000000ULL-11644473600ULL;}
static BOOL license_ecdsa(const unsigned char *blob,ULONG size,const void *message,ULONG length,unsigned char sig[64],BOOL sign){
 BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_KEY_HANDLE key=NULL;unsigned char digest[32];DWORD used=0;BOOL ok=0;
 if(!license_sha(message,length,digest)||BCryptOpenAlgorithmProvider(&alg,BCRYPT_ECDSA_P256_ALGORITHM,NULL,0)<0)goto done;
 if(BCryptImportKeyPair(alg,NULL,sign?BCRYPT_ECCPRIVATE_BLOB:BCRYPT_ECCPUBLIC_BLOB,&key,(PUCHAR)blob,size,0)<0)goto done;
 if(sign)ok=BCryptSignHash(key,NULL,digest,32,sig,64,&used,0)>=0&&used==64;
 else ok=BCryptVerifySignature(key,NULL,digest,32,sig,64,0)>=0;
 done:if(key)BCryptDestroyKey(key);if(alg)BCryptCloseAlgorithmProvider(alg,0);SecureZeroMemory(digest,sizeof(digest));return ok;
}
static BOOL license_device(unsigned char private_key[104],char public_hex[145]){
 wchar_t path[32768];DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",path,32768),used=0;BOOL ok=0;HANDLE mutex=CreateMutexW(NULL,FALSE,L"Local\\VIBE_DeviceKey_v3");BOOL locked=0;
 HANDLE file=INVALID_HANDLE_VALUE;DATA_BLOB input={0},output={0};unsigned char encrypted[4096],pub[72];BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_KEY_HANDLE key=NULL;
 if(!mutex)goto done;used=WaitForSingleObject(mutex,5000);if(used!=WAIT_OBJECT_0&&used!=WAIT_ABANDONED)goto done;locked=1;
 if(!n||n>32600)goto done;wcscat(path,L"\\VIBE");if(!CreateDirectoryW(path,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)goto done;wcscat(path,L"\\device-key.dat");
 file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(file!=INVALID_HANDLE_VALUE){
  n=GetFileSize(file,NULL);if(!n||n>sizeof(encrypted)||!ReadFile(file,encrypted,n,&used,NULL)||used!=n)goto done;CloseHandle(file);file=INVALID_HANDLE_VALUE;
  input.pbData=encrypted;input.cbData=n;if(!CryptUnprotectData(&input,NULL,NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&output))goto done;
  if(output.cbData!=104)goto done;memcpy(private_key,output.pbData,104);SecureZeroMemory(output.pbData,output.cbData);LocalFree(output.pbData);output.pbData=NULL;
 }else{
  if(GetLastError()!=ERROR_FILE_NOT_FOUND)goto done;
  if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_ECDSA_P256_ALGORITHM,NULL,0)<0||BCryptGenerateKeyPair(alg,&key,256,0)<0||BCryptFinalizeKeyPair(key,0)<0)goto done;
  if(BCryptExportKey(key,NULL,BCRYPT_ECCPRIVATE_BLOB,private_key,104,&used,0)<0||used!=104)goto done;
  input.pbData=private_key;input.cbData=104;if(!CryptProtectData(&input,L"VIBE device signing key",NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&output))goto done;
  /* CREATE_NEW avoids concurrent first-start instances overwriting identity. */
  file=CreateFileW(path,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
  if(file==INVALID_HANDLE_VALUE)goto done;
  if(!WriteFile(file,output.pbData,output.cbData,&used,NULL)||used!=output.cbData||!FlushFileBuffers(file)){CloseHandle(file);file=INVALID_HANDLE_VALUE;DeleteFileW(path);goto done;}
  CloseHandle(file);file=INVALID_HANDLE_VALUE;
 }
 if(((BCRYPT_ECCKEY_BLOB*)private_key)->dwMagic!=BCRYPT_ECDSA_PRIVATE_P256_MAGIC||((BCRYPT_ECCKEY_BLOB*)private_key)->cbKey!=32)goto done;
 memcpy(pub,private_key,72);((BCRYPT_ECCKEY_BLOB*)pub)->dwMagic=BCRYPT_ECDSA_PUBLIC_P256_MAGIC;license_tohex(pub,72,public_hex);ok=1;
 done:if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);if(output.pbData){SecureZeroMemory(output.pbData,output.cbData);LocalFree(output.pbData);}if(key)BCryptDestroyKey(key);if(alg)BCryptCloseAlgorithmProvider(alg,0);if(!ok)SecureZeroMemory(private_key,104);SecureZeroMemory(encrypted,sizeof(encrypted));if(locked)ReleaseMutex(mutex);if(mutex)CloseHandle(mutex);return ok;
}
static BOOL license_filehash(const wchar_t *path,char hex[65]){
 HANDLE file=INVALID_HANDLE_VALUE;BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE hash=NULL;unsigned char block[65536],digest[32];DWORD got=0;BOOL ok=0;
 file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(file==INVALID_HANDLE_VALUE)goto done;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0||BCryptCreateHash(alg,&hash,NULL,0,NULL,0,0)<0)goto done;
 for(;;){if(!ReadFile(file,block,sizeof(block),&got,NULL))goto done;if(!got)break;if(BCryptHashData(hash,block,got,0)<0)goto done;}
 if(BCryptFinishHash(hash,digest,32,0)<0)goto done;license_tohex(digest,32,hex);ok=1;
 done:if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);return ok;
}
static BOOL license_release_integrity(const wchar_t *directory){
 wchar_t path[32768];FILE *file=NULL;char record[512]={0},dll[65]={0},exe[65]={0},signature[129]={0},canonical[192],actual[65];unsigned char sig[64];size_t size=0;int prefix=0,used=0;
 if(wcslen(directory)>32600)return 0;wcscpy(path,directory);wcscat(path,L"release.sig");file=_wfopen(path,L"rb");if(!file)return 0;size=fread(record,1,sizeof(record)-1,file);BOOL io_ok=!ferror(file)&&feof(file);fclose(file);
 if(!io_ok||!size||size>=sizeof(record)-1||memchr(record,0,size))return 0;
 if(sscanf(record,"VIBE3BIN 14.10.11 %64[0-9a-f] %64[0-9a-f]%n\n%128[0-9a-f]%n",dll,exe,&prefix,signature,&used)!=3||record[prefix]!='\n'||record[used]!='\n'||record[used+1])return 0;
 snprintf(canonical,sizeof(canonical),"VIBE3BIN 14.10.11 %s %s",dll,exe);
 if(strlen(dll)!=64||strlen(exe)!=64||strlen(canonical)!=(size_t)prefix||memcmp(canonical,record,prefix)||!license_fromhex(signature,64,sig)||!license_ecdsa(vibe_license_public,72,record,(ULONG)prefix,sig,FALSE))return 0;
 wcscpy(path,directory);wcscat(path,L"RemakeESP.dll");if(!license_filehash(path,actual)||strcmp(actual,dll))return 0;
 wcscpy(path,directory);wcscat(path,L"StartVibe.exe");return license_filehash(path,actual)&&!strcmp(actual,exe);
}
