/* Direct launcher UI. No activation, account, device binding or network worker. */
int launcher_run(int argc,wchar_t **argv);
#define LAUNCH_NOTE (WM_APP+41)
#define LAUNCH_DONE (WM_APP+42)
#define LAUNCH_START 1001
static struct {HWND window,start,status;HFONT font,title;HBRUSH background;DWORD selected;BOOL busy;} launch_ui;
static void launcher_note(const char *text){
 if(!launch_ui.window)return;
 int n=MultiByteToWideChar(CP_UTF8,0,text,-1,NULL,0);if(n<=0||n>4096)return;
 wchar_t *copy=(wchar_t*)HeapAlloc(GetProcessHeap(),0,(SIZE_T)n*sizeof(wchar_t));if(!copy)return;
 if(!MultiByteToWideChar(CP_UTF8,0,text,-1,copy,n)||!PostMessageW(launch_ui.window,LAUNCH_NOTE,0,(LPARAM)copy))HeapFree(GetProcessHeap(),0,copy);
}
static DWORD WINAPI launch_worker(void *unused){
 (void)unused;wchar_t path[MAX_PATH],pid[32];GetModuleFileNameW(NULL,path,MAX_PATH);wchar_t *args[]={path,pid};int argc=1;
 if(launch_ui.selected){swprintf(pid,32,L"%lu",(unsigned long)launch_ui.selected);argc=2;}
 int result=launcher_run(argc,args);if(logfile){fclose(logfile);logfile=NULL;}
 PostMessageW(launch_ui.window,LAUNCH_DONE,(WPARAM)result,0);return 0;
}
static HWND launch_control(const wchar_t *kind,const wchar_t *text,DWORD extra,int x,int y,int w,int h,int id){
 HWND control=CreateWindowExW(0,kind,text,WS_CHILD|WS_VISIBLE|extra,x,y,w,h,launch_ui.window,(HMENU)(INT_PTR)id,GetModuleHandleW(NULL),NULL);
 SendMessageW(control,WM_SETFONT,(WPARAM)launch_ui.font,TRUE);return control;
}
static LRESULT CALLBACK launch_window(HWND window,UINT message,WPARAM w,LPARAM l){
 switch(message){
 case WM_CREATE:
  launch_ui.window=window;
  {HWND title=launch_control(L"STATIC",L"VIBE",0,28,22,460,55,0);SendMessageW(title,WM_SETFONT,(WPARAM)launch_ui.title,TRUE);}
  launch_control(L"STATIC",L"PC 14.10.14 · прямой запуск",0,30,87,460,26,0);
  launch_control(L"STATIC",L"Открой Remake Survival, затем подключи VIBE.",0,30,128,460,38,0);
  launch_ui.start=launch_control(L"BUTTON",L"Подключить VIBE",BS_DEFPUSHBUTTON,30,184,460,46,LAUNCH_START);
  launch_ui.status=launch_control(L"STATIC",L"Готов к запуску.",SS_LEFT,30,252,460,96,0);
  launch_control(L"STATIC",L"INSERT — меню    ·    END — остановка",0,30,365,460,26,0);return 0;
 case WM_COMMAND:
  if(LOWORD(w)==LAUNCH_START&&!launch_ui.busy){
   launch_ui.busy=TRUE;EnableWindow(launch_ui.start,FALSE);SetWindowTextW(launch_ui.status,L"Подключение…");
   HANDLE thread=CreateThread(NULL,0,launch_worker,NULL,0,NULL);
   if(thread)CloseHandle(thread);else {launch_ui.busy=FALSE;EnableWindow(launch_ui.start,TRUE);SetWindowTextW(launch_ui.status,L"Не удалось запустить подключение.");}
  }return 0;
 case LAUNCH_NOTE:
  if(l){SetWindowTextW(launch_ui.status,(const wchar_t*)l);HeapFree(GetProcessHeap(),0,(void*)l);}return 0;
 case LAUNCH_DONE:
  launch_ui.busy=FALSE;EnableWindow(launch_ui.start,TRUE);
  SetWindowTextW(launch_ui.status,w?L"Не удалось подключить VIBE. Подробности в launcher.log рядом с программой.":L"VIBE подключён. INSERT — открыть меню, END — остановить функции.");return 0;
 case WM_CTLCOLORSTATIC:
  SetTextColor((HDC)w,RGB(238,241,246));SetBkColor((HDC)w,RGB(19,25,36));return(LRESULT)launch_ui.background;
 case WM_CLOSE:
  if(!launch_ui.busy)DestroyWindow(window);return 0;
 case WM_DESTROY:
  launch_ui.window=NULL;PostQuitMessage(0);return 0;
 }return DefWindowProcW(window,message,w,l);
}
static BOOL launch_preview(HWND window,const wchar_t *path){
 RECT r;GetWindowRect(window,&r);int width=r.right-r.left,height=r.bottom-r.top;
 HDC screen=GetDC(window),dc=CreateCompatibleDC(screen);BITMAPINFO bi={0};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=width;bi.bmiHeader.biHeight=-height;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
 void *pixels=NULL;HBITMAP bitmap=CreateDIBSection(screen,&bi,DIB_RGB_COLORS,&pixels,NULL,0);BOOL ok=FALSE;
 if(bitmap&&pixels){HGDIOBJ old=SelectObject(dc,bitmap);PrintWindow(window,dc,0);GdiFlush();FILE *file=_wfopen(path,L"wb");if(file){BITMAPFILEHEADER header={0};header.bfType=0x4d42;header.bfOffBits=sizeof(header)+sizeof(bi.bmiHeader);header.bfSize=header.bfOffBits+width*height*4;ok=fwrite(&header,sizeof(header),1,file)==1&&fwrite(&bi.bmiHeader,sizeof(bi.bmiHeader),1,file)==1&&fwrite(pixels,width*height*4,1,file)==1;fclose(file);}SelectObject(dc,old);DeleteObject(bitmap);}
 DeleteDC(dc);ReleaseDC(window,screen);return ok;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,wchar_t *command,int show){
 (void)previous;(void)command;(void)show;SetProcessDPIAware();int argc=0;wchar_t **argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(!argv)return 1;
 if(argc==2&&!wcscmp(argv[1],L"--self-test")){int result=launcher_run(argc,argv);if(logfile){fclose(logfile);logfile=NULL;}LocalFree(argv);return result;}
 BOOL test=argc>=2&&!wcscmp(argv[1],L"--gui-self-test");
 if(!test&&argc>1){wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(argc!=2||!*argv[1]||*end||!pid||pid==(DWORD)-1){LocalFree(argv);return 1;}launch_ui.selected=(DWORD)pid;}
 launch_ui.font=CreateFontW(-17,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,0,0,L"Segoe UI");launch_ui.title=CreateFontW(-40,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,0,0,L"Segoe UI");launch_ui.background=CreateSolidBrush(RGB(19,25,36));
 WNDCLASSW wc={0};wc.lpfnWndProc=launch_window;wc.hInstance=instance;wc.hCursor=LoadCursorW(NULL,MAKEINTRESOURCEW(32512));wc.hbrBackground=launch_ui.background;wc.lpszClassName=L"VibeDirectLaunch";RegisterClassW(&wc);
 RECT size={0,0,520,410};DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;AdjustWindowRectEx(&size,style,FALSE,0);
 HWND window=CreateWindowExW(0,wc.lpszClassName,L"VIBE — PC 14.10.14",style,CW_USEDEFAULT,CW_USEDEFAULT,size.right-size.left,size.bottom-size.top,NULL,NULL,instance,NULL);if(!window){LocalFree(argv);return 1;}
 if(test){
  BOOL ok=IsWindowEnabled(launch_ui.start)&&!launch_ui.busy;
  /* Exercise status delivery without starting the loader or touching a game. */
  wchar_t *text=(wchar_t*)HeapAlloc(GetProcessHeap(),0,64*sizeof(wchar_t));if(text){wcscpy(text,L"Offline UI check");SendMessageW(window,LAUNCH_NOTE,0,(LPARAM)text);wchar_t actual[64];GetWindowTextW(launch_ui.status,actual,64);ok=ok&&!wcscmp(actual,L"Offline UI check");}else ok=FALSE;
  SetWindowTextW(launch_ui.status,L"Готов к запуску.");
  if(argc==3){SetWindowPos(window,NULL,-20000,-20000,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);ShowWindow(window,SW_SHOWNOACTIVATE);UpdateWindow(window);ok=ok&&launch_preview(window,argv[2]);}
  DestroyWindow(window);LocalFree(argv);DeleteObject(launch_ui.font);DeleteObject(launch_ui.title);DeleteObject(launch_ui.background);puts(ok?"Direct launcher UI self-test passed; no game process modified.":"Direct launcher UI self-test failed.");return ok?0:1;
 }
 ShowWindow(window,SW_SHOW);UpdateWindow(window);LocalFree(argv);MSG message;
 while(GetMessageW(&message,NULL,0,0)>0){if(!IsDialogMessageW(window,&message)){TranslateMessage(&message);DispatchMessageW(&message);}}
 DeleteObject(launch_ui.font);DeleteObject(launch_ui.title);DeleteObject(launch_ui.background);return 0;
}
