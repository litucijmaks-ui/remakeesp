#pragma once
int launcher_run(int,wchar_t**);
enum {LOGIN_EDIT=101,LOGIN_ENTER=102,LOGIN_START=103,LOGIN_REFRESH=104,LOGIN_DONE=WM_APP+31};
typedef struct {
 HWND window,key,enter,start,refresh,server,expiry,pc,status;
 VibeLicenseClient client;char code[7];BOOL busy,authenticated,ok,self_test;unsigned operation;DWORD selected;
 HFONT font,title,code_font;HBRUSH background,edit_background;
} LoginUI;
static LoginUI login_ui;
static const wchar_t *login_error_text(const char *error){
 if(!strcmp(error,"invalid_signature"))return L"Подпись сервера не совпадает. Используй клиент от своего администратора.";
 if(!strcmp(error,"upgrade_required"))return L"Нужно обновить сервер и клиент до защищённого протокола VIBE3.";
 if(!strcmp(error,"clock_error"))return L"Проверь дату и время Windows на клиенте и сервере.";
 if(!strcmp(error,"device_key_failed"))return L"Не удалось открыть ключ устройства. Проверь доступ к профилю Windows.";
 if(!strcmp(error,"integrity_failed"))return L"Файлы сборки изменены. Распакуй исходный клиентский архив заново.";
 if(!strcmp(error,"invalid_proof")||!strcmp(error,"replay")||!strcmp(error,"invalid_lease"))return L"Сервер отклонил разрешение доступа. Проверь версии клиента и сервера.";
 if(!strcmp(error,"locked"))return L"Слишком много неверных попыток. Подожди 15 минут.";
 if(!strcmp(error,"invalid_key"))return L"Ключ не найден или отозван. Проверь 6 цифр.";
 if(!strcmp(error,"expired"))return L"Срок доступа закончился. Получи новый ключ у администратора.";
 if(!strcmp(error,"other_pc"))return L"Ключ уже привязан к другому ПК. Обратись к администратору.";
 if(!strcmp(error,"configure_client_ini"))return L"Укажи адрес сервера в client.ini рядом с программой.";
 if(!strcmp(error,"https_required"))return L"Для удалённого сервера нужен адрес HTTPS.";
 if(!strcmp(error,"invalid_server_url"))return L"Неверный адрес сервера в client.ini.";
 if(!strcmp(error,"invalid_session"))return L"Сеанс закончился или отозван. Введи ключ повторно.";
 if(!strcmp(error,"save_failed"))return L"Не удалось сохранить сеанс. Распакуй клиент в доступную папку.";
 return L"Сервер недоступен. Запусти сервер или проверь адрес в client.ini.";
}
static HWND login_control(const wchar_t *class_name,const wchar_t *text,DWORD style,int x,int y,int w,int h,int id){
 HWND control=CreateWindowExW(!wcscmp(class_name,L"EDIT")?WS_EX_CLIENTEDGE:0,class_name,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,login_ui.window,(HMENU)(uintptr_t)id,GetModuleHandleW(NULL),NULL);
 SendMessageW(control,WM_SETFONT,(WPARAM)login_ui.font,TRUE);return control;
}
static void login_information(void){
 wchar_t text[256];
 if(!login_ui.client.expires)wcscpy(text,L"Срок доступа: бессрочно");
 else {
  ULARGE_INTEGER value;value.QuadPart=(login_ui.client.expires+11644473600ULL)*10000000ULL;FILETIME utc={value.LowPart,value.HighPart},local;SYSTEMTIME st;
  if(FileTimeToLocalFileTime(&utc,&local)&&FileTimeToSystemTime(&local,&st))swprintf(text,256,L"Доступ до: %02u.%02u.%04u, %02u:%02u",st.wDay,st.wMonth,st.wYear,st.wHour,st.wMinute);
  else wcscpy(text,L"Срок доступа получен от сервера");
 }
 SetWindowTextW(login_ui.expiry,text);SetWindowTextW(login_ui.pc,login_ui.client.bind_pc?L"Привязка: этот ПК · установлена при первом входе":L"Привязка: без ограничения по ПК");
}
static DWORD WINAPI login_worker(void *unused){
 (void)unused;unsigned operation=login_ui.operation;login_ui.ok=0;
 if(operation==1)login_ui.ok=license_post(&login_ui.client,L"/v1/status",NULL,NULL);
 if(operation==2){
  if(!license_release_integrity(login_ui.client.directory))license_error(&login_ui.client,"integrity_failed");
  else login_ui.ok=license_post(&login_ui.client,L"/v3/activate","key",login_ui.code);
  if(login_ui.ok&&!license_ticket(&login_ui.client,TRUE)){license_error(&login_ui.client,"save_failed");login_ui.ok=0;}
  SecureZeroMemory(login_ui.code,sizeof(login_ui.code));
 }
 if(operation==3)login_ui.ok=license_ticket(&login_ui.client,FALSE)&&license_check(&login_ui.client);
 if(operation==4){
  if(license_check(&login_ui.client)){
   wchar_t selected[32];wchar_t *args[]={L"StartVibe.exe",selected};swprintf(selected,32,L"%lu",(unsigned long)login_ui.selected);
   login_ui.ok=launcher_run(login_ui.selected?2:1,args)==0;
   if(!login_ui.ok)license_error(&login_ui.client,"game_start_failed");
  }
 }
 PostMessageW(login_ui.window,LOGIN_DONE,operation,0);return 0;
}
static void login_begin(unsigned operation){
 if(login_ui.busy)return;login_ui.busy=1;login_ui.operation=operation;
 EnableWindow(login_ui.enter,FALSE);EnableWindow(login_ui.start,FALSE);EnableWindow(login_ui.refresh,FALSE);EnableWindow(login_ui.key,FALSE);
 SetWindowTextW(login_ui.status,operation==4?L"Ожидаю игру и запускаю VIBE…":L"Проверяю доступ…");
 HANDLE thread=CreateThread(NULL,0,login_worker,NULL,0,NULL);
 if(thread)CloseHandle(thread);else {license_error(&login_ui.client,"server_unavailable");login_ui.ok=0;PostMessageW(login_ui.window,LOGIN_DONE,operation,0);}
}
static LRESULT CALLBACK login_window_proc(HWND window,UINT message,WPARAM w,LPARAM l){
 if(message==WM_CREATE){
  login_ui.window=window;
  HWND title=login_control(L"STATIC",L"VIBE",0,32,25,400,49,0);SendMessageW(title,WM_SETFONT,(WPARAM)login_ui.title,TRUE);
  login_control(L"STATIC",L"Вход по ключу · PC 14.10.11",0,33,80,470,25,0);
  login_control(L"STATIC",L"Введи 6 цифр. Первый вход активирует ключ и начнёт срок доступа.",0,33,117,500,42,0);
  login_ui.key=login_control(L"EDIT",L"",ES_NUMBER|ES_CENTER|ES_AUTOHSCROLL|WS_TABSTOP,33,174,230,49,LOGIN_EDIT);
  SendMessageW(login_ui.key,WM_SETFONT,(WPARAM)login_ui.code_font,TRUE);SendMessageW(login_ui.key,EM_SETLIMITTEXT,6,0);
  login_ui.enter=login_control(L"BUTTON",L"Войти / активировать",BS_DEFPUSHBUTTON|WS_TABSTOP,282,174,236,49,LOGIN_ENTER);
  login_ui.server=login_control(L"STATIC",L"Сервер: проверка ещё не выполнена",0,33,249,490,25,0);
  login_ui.expiry=login_control(L"STATIC",L"Срок доступа: после входа",0,33,284,490,25,0);
  login_ui.pc=login_control(L"STATIC",L"Привязка к ПК: после входа",0,33,319,490,25,0);
  login_ui.status=login_control(L"STATIC",L"Запусти сервер и введи выданный ключ.",0,33,362,490,64,0);
  login_ui.refresh=login_control(L"BUTTON",L"Проверить сервер",WS_TABSTOP,33,445,216,43,LOGIN_REFRESH);
  login_ui.start=login_control(L"BUTTON",L"Запустить VIBE",WS_TABSTOP,282,445,236,43,LOGIN_START);EnableWindow(login_ui.start,FALSE);
  login_control(L"STATIC",L"Адрес берётся из client.ini. Сеанс проверяется сервером каждые 20 секунд.",0,33,510,490,40,0);
  SetFocus(login_ui.key);return 0;
 }
 if(message==WM_COMMAND){
  if((LOWORD(w)==LOGIN_ENTER||LOWORD(w)==IDOK)&&!login_ui.busy){
   wchar_t code[8]={0};GetWindowTextW(login_ui.key,code,8);BOOL valid=wcslen(code)==6;
   for(unsigned i=0;i<6&&valid;i++){if(code[i]<L'0'||code[i]>L'9')valid=0;else login_ui.code[i]=(char)code[i];}login_ui.code[6]=0;
   if(!valid){SetWindowTextW(login_ui.status,L"Ключ должен содержать ровно 6 цифр.");SetFocus(login_ui.key);return 0;}
   login_begin(2);
  }
  if(LOWORD(w)==LOGIN_REFRESH)login_begin(1);
  if(LOWORD(w)==LOGIN_START&&login_ui.authenticated)login_begin(4);
  return 0;
 }
 if(message==LOGIN_DONE){
  login_ui.busy=0;EnableWindow(login_ui.key,TRUE);EnableWindow(login_ui.enter,TRUE);EnableWindow(login_ui.refresh,TRUE);
  if(login_ui.ok){
   SetWindowTextW(login_ui.server,L"Сервер: доступен");
   if(w==2||w==3){login_ui.authenticated=TRUE;login_information();SetWindowTextW(login_ui.status,L"Доступ разрешён. Запусти игру, затем нажми «Запустить VIBE».");}
   else if(w==4)SetWindowTextW(login_ui.status,L"VIBE загружен. INSERT — меню, END — остановка функций.");
   else SetWindowTextW(login_ui.status,L"Сервер работает. Можно войти по ключу.");
  }else {
   if(w==2||w==3||w==4)login_ui.authenticated=FALSE;
   SetWindowTextW(login_ui.status,!strcmp(login_ui.client.error,"game_start_failed")?L"Не удалось загрузить VIBE. Проверь, что игра запущена, и прочитай launcher.log.":login_error_text(login_ui.client.error));
   if(w==1)SetWindowTextW(login_ui.server,L"Сервер: недоступен");
  }
  EnableWindow(login_ui.start,login_ui.authenticated);return 0;
 }
 if(message==WM_CTLCOLORSTATIC){SetTextColor((HDC)w,RGB(228,236,247));SetBkColor((HDC)w,RGB(19,25,36));return (LRESULT)login_ui.background;}
 if(message==WM_CTLCOLOREDIT){SetTextColor((HDC)w,RGB(240,245,255));SetBkColor((HDC)w,RGB(34,45,63));return (LRESULT)login_ui.edit_background;}
 if(message==WM_ERASEBKGND){RECT rect;GetClientRect(window,&rect);FillRect((HDC)w,&rect,login_ui.background);return 1;}
 if(message==WM_CLOSE){DestroyWindow(window);return 0;}
 if(message==WM_DESTROY){PostQuitMessage(0);return 0;}
 return DefWindowProcW(window,message,w,l);
}
static BOOL login_preview_bmp(HWND window,const wchar_t *path){
 RECT r;GetWindowRect(window,&r);int width=r.right-r.left,height=r.bottom-r.top;
 HDC screen=GetDC(window),dc=CreateCompatibleDC(screen);BITMAPINFO bi={0};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=width;bi.bmiHeader.biHeight=-height;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
 void *pixels=NULL;HBITMAP bitmap=CreateDIBSection(screen,&bi,DIB_RGB_COLORS,&pixels,NULL,0);BOOL ok=0;
 if(bitmap&&pixels){HGDIOBJ previous=SelectObject(dc,bitmap);PrintWindow(window,dc,0);GdiFlush();FILE *file=_wfopen(path,L"wb");if(file){BITMAPFILEHEADER header={0};header.bfType=0x4d42;header.bfOffBits=sizeof(header)+sizeof(bi.bmiHeader);header.bfSize=header.bfOffBits+width*height*4;ok=fwrite(&header,sizeof(header),1,file)==1&&fwrite(&bi.bmiHeader,sizeof(bi.bmiHeader),1,file)==1&&fwrite(pixels,width*height*4,1,file)==1;fclose(file);}SelectObject(dc,previous);DeleteObject(bitmap);}
 DeleteDC(dc);ReleaseDC(window,screen);return ok;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,wchar_t *command,int show){
 (void)previous;(void)command;(void)show;SetProcessDPIAware();int argc=0;wchar_t **argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(!argv)return 1;
 if(argc==2&&!wcscmp(argv[1],L"--self-test")){int result=launcher_run(argc,argv);LocalFree(argv);return result;}
 if(argc==2&&!wcscmp(argv[1],L"--license-check")){int result=authenticate()?0:1;LocalFree(argv);return result;}
 login_ui.self_test=argc>=2&&!wcscmp(argv[1],L"--gui-self-test");
 if(argc==2&&!login_ui.self_test){wchar_t *end=NULL;unsigned long selected=wcstoul(argv[1],&end,10);if(selected&&!*end)login_ui.selected=(DWORD)selected;}
 login_ui.font=CreateFontW(-16,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,0,0,L"Segoe UI");
 login_ui.title=CreateFontW(-42,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,0,0,L"Segoe UI");
 login_ui.code_font=CreateFontW(-28,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,0,0,L"Segoe UI");
 login_ui.background=CreateSolidBrush(RGB(19,25,36));login_ui.edit_background=CreateSolidBrush(RGB(34,45,63));
 WNDCLASSW wc={0};wc.lpfnWndProc=login_window_proc;wc.hInstance=instance;wc.hCursor=LoadCursorW(NULL,MAKEINTRESOURCEW(32512));wc.hbrBackground=login_ui.background;wc.lpszClassName=L"VibeLicenseLogin";RegisterClassW(&wc);
 RECT size={0,0,553,574};AdjustWindowRectEx(&size,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,FALSE,0);
 HWND window=CreateWindowExW(0,wc.lpszClassName,L"VIBE — вход по ключу",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,size.right-size.left,size.bottom-size.top,NULL,NULL,instance,NULL);
 if(!window){LocalFree(argv);return 1;}
 if(login_ui.self_test){
  BOOL ok=SendMessageW(login_ui.key,EM_GETLIMITTEXT,0,0)==6&&!IsWindowEnabled(login_ui.start);
  SetWindowTextW(login_ui.key,L"12345");SendMessageW(window,WM_COMMAND,IDOK,0);ok=ok&&!login_ui.busy&&!IsWindowEnabled(login_ui.start);
  login_ui.ok=TRUE;login_ui.client.expires=2000000000ULL;login_ui.client.bind_pc=1;SendMessageW(window,LOGIN_DONE,2,0);ok=ok&&login_ui.authenticated&&IsWindowEnabled(login_ui.start);
  login_ui.ok=FALSE;license_error(&login_ui.client,"expired");SendMessageW(window,LOGIN_DONE,2,0);ok=ok&&!login_ui.authenticated&&!IsWindowEnabled(login_ui.start);
  ZeroMemory(&login_ui.client,sizeof(login_ui.client));SetWindowTextW(login_ui.key,L"");SetWindowTextW(login_ui.status,L"Запусти сервер и введи выданный ключ.");SetWindowTextW(login_ui.expiry,L"Срок доступа: после входа");SetWindowTextW(login_ui.pc,L"Привязка к ПК: после входа");
  if(argc==3){SetWindowPos(window,NULL,-20000,-20000,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);ShowWindow(window,SW_SHOWNOACTIVATE);UpdateWindow(window);RedrawWindow(window,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN|RDW_UPDATENOW);ok=ok&&login_preview_bmp(window,argv[2]);}DestroyWindow(window);puts(ok?"GUI self-test passed: six-digit input and access gate; no game process modified.":"GUI self-test failed");LocalFree(argv);return ok?0:1;
 }
 ShowWindow(window,SW_SHOW);UpdateWindow(window);
 if(!license_paths(&login_ui.client,NULL)){SetWindowTextW(login_ui.status,login_error_text(login_ui.client.error));EnableWindow(login_ui.enter,FALSE);EnableWindow(login_ui.refresh,FALSE);}
 else if(license_ticket(&login_ui.client,FALSE))login_begin(3);else login_begin(1);
 LocalFree(argv);MSG msg;while(GetMessageW(&msg,NULL,0,0)>0){if(!IsDialogMessageW(window,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}
 return 0;
}
