#include "ui/egui.hxx"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "imgui_internal.h"
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <tlhelp32.h>
#include <shellapi.h>
#include <cstdio>
#include "ui/layout.hxx"
#include "ui/glass.hxx"
#include "ui/state.hxx"
#include "vibe/VibeRuntime.h"
#include "vibe/PlayerPreview.h"
#include "vibe/EspRenderer.h"
#include "vibe/GamePresent.h"

extern "C" DWORD VibeUiGetMenuOpen(void);
extern "C" void VibeUiSetMenuOpen(DWORD open);

static DWORD g_game_pid = 0;
static HANDLE g_game_process = nullptr;
static HANDLE g_single_instance = nullptr;
static HWND g_overlay_hwnd = nullptr;

static void enable_dpi_awareness()
{
    if (HMODULE user32 = ::GetModuleHandleW(L"user32.dll")) {
        using SetCtx = BOOL (WINAPI*)(HANDLE);
        auto fn = reinterpret_cast<SetCtx>(::GetProcAddress(user32, "SetProcessDpiAwarenessContext"));
        if (fn && fn(reinterpret_cast<HANDLE>(static_cast<INT_PTR>(-4))))
            return;
    }
    ::SetProcessDPIAware();
}

static RECT virtual_screen()
{
    RECT r;
    r.left = ::GetSystemMetrics(SM_XVIRTUALSCREEN);
    r.top = ::GetSystemMetrics(SM_YVIRTUALSCREEN);
    r.right = r.left + ::GetSystemMetrics(SM_CXVIRTUALSCREEN);
    r.bottom = r.top + ::GetSystemMetrics(SM_CYVIRTUALSCREEN);
    if (r.right <= r.left || r.bottom <= r.top) {
        r.left = 0;
        r.top = 0;
        r.right = ::GetSystemMetrics(SM_CXSCREEN);
        r.bottom = ::GetSystemMetrics(SM_CYSCREEN);
    }
    return r;
}

static DWORD parse_game_pid()
{
    int argc = 0;
    LPWSTR* argv = ::CommandLineToArgvW(::GetCommandLineW(), &argc);
    if (!argv) return 0;

    DWORD pid = 0;
    for (int i = 1; i + 1 < argc; ++i) {
        if (_wcsicmp(argv[i], L"--game-pid") != 0)
            continue;
        wchar_t* end = nullptr;
        unsigned long value = wcstoul(argv[i + 1], &end, 10);
        if (end && *end == 0)
            pid = static_cast<DWORD>(value);
        break;
    }
    ::LocalFree(argv);
    return pid;
}

static DWORD find_game_pid()
{
    HANDLE snap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;

    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    DWORD found = 0;
    unsigned matches = 0;

    if (::Process32FirstW(snap, &entry)) {
        do {
            if (_wcsicmp(entry.szExeFile, L"Remake Survival.exe") == 0 ||
                _wcsicmp(entry.szExeFile, L"RemakeSurvival.exe") == 0) {
                found = entry.th32ProcessID;
                ++matches;
            }
        } while (::Process32NextW(snap, &entry));
    }

    ::CloseHandle(snap);
    return matches == 1 ? found : 0;
}

struct GameWindowFindData { HWND hwnd; LONG area; };

static BOOL CALLBACK find_game_window_proc(HWND hwnd, LPARAM lParam)
{
    DWORD pid = 0;
    ::GetWindowThreadProcessId(hwnd, &pid);
    if (pid != g_game_pid || !::IsWindowVisible(hwnd))
        return TRUE;

    RECT client{};
    if (!::GetClientRect(hwnd, &client))
        return TRUE;
    const LONG w = client.right - client.left;
    const LONG h = client.bottom - client.top;
    if (w < 320 || h < 200)
        return TRUE;

    GameWindowFindData* data = reinterpret_cast<GameWindowFindData*>(lParam);
    const LONG area = w * h;
    if (!data->hwnd || area > data->area) {
        data->hwnd = hwnd;
        data->area = area;
    }
    return TRUE;
}

static bool game_client_screen_rect(RECT& out)
{
    GameWindowFindData data{ nullptr, 0 };
    ::EnumWindows(find_game_window_proc, reinterpret_cast<LPARAM>(&data));
    if (!data.hwnd)
        return false;

    RECT r{};
    POINT tl{ 0, 0 };
    if (!::GetClientRect(data.hwnd, &r) || !::ClientToScreen(data.hwnd, &tl))
        return false;

    const LONG w = r.right - r.left;
    const LONG h = r.bottom - r.top;
    if (w < 1 || h < 1)
        return false;

    out.left = tl.x;
    out.top = tl.y;
    out.right = tl.x + w;
    out.bottom = tl.y + h;
    return true;
}

static bool game_alive()
{
    return g_game_process && ::WaitForSingleObject(g_game_process, 0) == WAIT_TIMEOUT;
}

static bool game_focused()
{
    static ULONGLONG focus_grace_until = 0;
    const ULONGLONG now = ::GetTickCount64();

    bool active = false;
    HWND foreground = ::GetForegroundWindow();
    if (foreground) {
        // The overlay is intentionally non-activating, but treat it as an allowed
        // foreground window too. This avoids one-frame hide/show flicker if Windows
        // briefly reports the overlay while the user clicks it.
        if (g_overlay_hwnd && foreground == g_overlay_hwnd) {
            active = true;
        } else {
            DWORD pid = 0;
            ::GetWindowThreadProcessId(foreground, &pid);
            active = (pid == g_game_pid);
        }
    }

    // Some fullscreen-windowed transitions briefly report another foreground
    // window. Keep the overlay alive for a tiny grace period instead of hiding it.
    if (active)
        focus_grace_until = now + 350;

    return active || (now < focus_grace_until);
}

#ifndef WDA_EXCLUDEFROMCAPTURE
#define WDA_EXCLUDEFROMCAPTURE 0x00000011
#endif

static void apply_streamproof(HWND hwnd)
{
    static int applied = -1;
    const int want = vars.gui.streamproof ? 1 : 0;
    if (applied == want)
        return;
    const DWORD affinity = want ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE;
    if (::SetWindowDisplayAffinity(hwnd, affinity))
        applied = want;
}

static bool cursor_over_ui(HWND hwnd)
{
    ImGuiContext* ctx = ImGui::GetCurrentContext();
    if (!ctx || !game_focused())
        return false;

    POINT pt;
    if (!::GetCursorPos(&pt))
        return false;
    ::ScreenToClient(hwnd, &pt);
    const ImVec2 mouse((float)pt.x, (float)pt.y);

    if (!egui::settings.state.menu_open)
        return false;

    for (int i = 0; i < ctx->Windows.Size; ++i) {
        ImGuiWindow* w = ctx->Windows[i];
        if (!w->Active || w->Hidden || w->IsFallbackWindow)
            continue;
        if (w->Flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_NoInputs))
            continue;
        const ImRect& r = w->OuterRectClipped;
        if (r.GetWidth() > 1.0f && r.GetHeight() > 1.0f && r.Contains(mouse))
            return true;
    }
    return false;
}

bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static void set_clickthrough(HWND hwnd, bool through)
{
    LONG_PTR ex = ::GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
    const LONG_PTR want = through ? (ex | WS_EX_LAYERED | WS_EX_TRANSPARENT)
                                  : ((ex | WS_EX_LAYERED) & ~WS_EX_TRANSPARENT);
    if (want == ex)
        return;
    ::SetWindowLongPtrW(hwnd, GWL_EXSTYLE, want);
    ::SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                   SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_FRAMECHANGED);
    ::SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
}

static bool acquire_single_instance(DWORD pid)
{
    wchar_t name[96]{};
    _snwprintf_s(name, _countof(name), _TRUNCATE, L"Local\\VibeImGuiMenu.%lu", (unsigned long)pid);
    g_single_instance = ::CreateMutexW(nullptr, FALSE, name);
    if (!g_single_instance)
        return false;
    if (::GetLastError() == ERROR_ALREADY_EXISTS) {
        ::CloseHandle(g_single_instance);
        g_single_instance = nullptr;
        return false;
    }
    return true;
}

static int run_internal_ui(HMODULE module)
{
    enable_dpi_awareness();

    g_game_pid = ::GetCurrentProcessId();
    g_game_process = ::OpenProcess(SYNCHRONIZE, FALSE, g_game_pid);
    if (!g_game_process)
        return 1;

    if (!vibe_runtime::Initialize(g_game_pid, module)) {
        ::CloseHandle(g_game_process);
        g_game_process = nullptr;
        return 1;
    }

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr),
                       nullptr, nullptr, nullptr, nullptr, L"VibeImGuiOverlay16", nullptr };
    ::RegisterClassExW(&wc);

    RECT screen = virtual_screen();
    RECT game_rect{};
    if (game_client_screen_rect(game_rect))
        screen = game_rect;
    HWND hwnd = ::CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE,
        wc.lpszClassName, L"Vibe ImGui", WS_POPUP,
        screen.left, screen.top, screen.right - screen.left, screen.bottom - screen.top,
        nullptr, nullptr, wc.hInstance, nullptr);
    g_overlay_hwnd = hwnd;
    if (!hwnd || !::SetPropA(hwnd, vibe::SESSION_PID_PROPERTY,
                             reinterpret_cast<HANDLE>(static_cast<uintptr_t>(g_game_pid)))) {
        if (hwnd) ::DestroyWindow(hwnd);
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        vibe_runtime::Shutdown();
        ::CloseHandle(g_single_instance);
        ::CloseHandle(g_game_process);
        return 1;
    }
    ::SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
    // Recording-friendly by default. WDA_NONE makes the menu visible to OBS,
    // Windows screen recording and screenshots unless the user explicitly
    // enables "Hide menu from recording" in Settings.
    ::SetWindowDisplayAffinity(hwnd, WDA_NONE);
    const MARGINS margins = { -1, -1, -1, -1 };
    ::DwmExtendFrameIntoClientArea(hwnd, &margins);

    if (!CreateDeviceD3D(hwnd)) {
        ::MessageBoxW(nullptr, L"The DirectX 11 overlay could not be created.", L"Vibe Menu", MB_OK | MB_ICONERROR);
        CleanupDeviceD3D();
        ::DestroyWindow(hwnd);
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        vibe_runtime::Shutdown();
        ::CloseHandle(g_single_instance);
        ::CloseHandle(g_game_process);
        return 1;
    }

    vibe_present::Install(g_pSwapChain);
    ::ShowWindow(hwnd, SW_SHOW);
    ::UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    ImGui::StyleColorsDark();

    egui::settings.dpi_scale = egui::system_dpi_scale();
    egui::initialize();

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    const float clear_color[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
    bool done = false;

    while (!done) {
        if (!game_alive())
            break;

        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        if (g_ResizeWidth != 0 && g_ResizeHeight != 0) {
            CleanupRenderTarget();
            HRESULT resize_result = g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight, DXGI_FORMAT_UNKNOWN, 0);
            if (FAILED(resize_result)) { done = true; break; }
            g_ResizeWidth = g_ResizeHeight = 0;
            CreateRenderTarget();
            egui::glass_invalidate();
        }

        static ULONGLONG next_bounds_check = 0;
        const ULONGLONG bounds_now = ::GetTickCount64();
        if (bounds_now >= next_bounds_check) {
            next_bounds_check = bounds_now + 350;
            RECT target{};
            if (game_client_screen_rect(target)) {
                RECT current{};
                ::GetWindowRect(hwnd, &current);
                const int tw = target.right - target.left;
                const int th = target.bottom - target.top;
                const bool moved_or_resized =
                    current.left != target.left || current.top != target.top ||
                    current.right - current.left != tw || current.bottom - current.top != th;

                // Reassert TOPMOST even when the bounds did not change. Unity can
                // raise a borderless/fullscreen-windowed surface above the overlay
                // during presentation/focus transitions.
                if (moved_or_resized) {
                    ::SetWindowPos(hwnd, HWND_TOPMOST, target.left, target.top, tw, th,
                                   SWP_NOACTIVATE | SWP_SHOWWINDOW);
                } else {
                    ::SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                                   SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
                }
            }
        }

        vibe_runtime::Tick();
        apply_streamproof(hwnd);
        egui::update_dpi();

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        const bool focused = game_focused();
        const bool core_menu_open = VibeUiGetMenuOpen() != 0;
        egui::settings.state.menu_open = core_menu_open;
        if (focused) {
            if(!vibe_present::Active())vibe_esp::Draw(g_pd3dDevice);
            egui::menu();
            egui::watermark();
        }
        if (egui::settings.state.menu_open != core_menu_open)
            VibeUiSetMenuOpen(egui::settings.state.menu_open ? 1u : 0u);

        ImGui::Render();
        if (!g_mainRenderTargetView) { ::Sleep(16); continue; }
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        set_clickthrough(hwnd, !focused || !cursor_over_ui(hwnd));
        HRESULT present_result = g_pSwapChain->Present(1, 0);
        if (present_result == DXGI_ERROR_DEVICE_REMOVED || present_result == DXGI_ERROR_DEVICE_RESET) break;
        if (!focused)
            ::Sleep(80);
        else if(vibe_present::Active()&&!core_menu_open)
            ::Sleep(16);
        
    }

    vibe_present::Stop();
    vibe_esp::Shutdown();
    vibe_preview::Shutdown();
    vibe_runtime::Shutdown();
    egui::glass_shutdown();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::RemovePropA(hwnd, vibe::SESSION_PID_PROPERTY);
    ::DestroyWindow(hwnd);
    g_overlay_hwnd = nullptr;
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);

    if (g_single_instance) ::CloseHandle(g_single_instance);
    if (g_game_process) ::CloseHandle(g_game_process);
    return 0;
}


static volatile LONG g_internal_ui_started = 0;

static DWORD WINAPI vibe_internal_ui_thread(LPVOID module)
{
    run_internal_ui(reinterpret_cast<HMODULE>(module));
    return 0;
}

extern "C" void vibe_imgui_start(HMODULE module)
{
    if (::InterlockedCompareExchange(&g_internal_ui_started, 1, 0) != 0)
        return;

    HANDLE thread = ::CreateThread(nullptr, 0, vibe_internal_ui_thread, module, 0, nullptr);
    if (thread)
        ::CloseHandle(thread);
    else
        ::InterlockedExchange(&g_internal_ui_started, 0);
}

bool CreateDeviceD3D(HWND hWnd)
{
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = {
        D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0
    };
    const UINT device_flags = D3D11_CREATE_DEVICE_SINGLETHREADED;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, device_flags,
        featureLevelArray, 2, D3D11_SDK_VERSION, &sd,
        &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (hr == DXGI_ERROR_UNSUPPORTED)
        hr = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_WARP, nullptr, device_flags,
            featureLevelArray, 2, D3D11_SDK_VERSION, &sd,
            &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (FAILED(hr))
        return false;

    // Keep the independently presented overlay from queuing several old camera frames.
    IDXGIDevice1* latency_device = nullptr;
    if (SUCCEEDED(g_pd3dDevice->QueryInterface(IID_PPV_ARGS(&latency_device)))) {
        latency_device->SetMaximumFrameLatency(1);
        latency_device->Release();
    }

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer = nullptr;
    if (!g_pSwapChain || !g_pd3dDevice || FAILED(g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer))) || !pBackBuffer) return;
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) {
        g_mainRenderTargetView->Release();
        g_mainRenderTargetView = nullptr;
    }
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg) {
    case vibe::SESSION_QUIT_MESSAGE:
        if (wParam == vibe::SESSION_COOKIE) { VibeUiSetMenuOpen(0); return 0; }
        break;
    case 0x8355u:
        if (wParam == 0x56494255u) { egui::settings.state.menu_open = true; return 0; }
        break;
    case WM_MOUSEACTIVATE:
        // Keep Remake Survival focused while the overlay receives mouse input.
        return MA_NOACTIVATE;
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;
        g_ResizeWidth = (UINT)LOWORD(lParam);
        g_ResizeHeight = (UINT)HIWORD(lParam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;
    case WM_DISPLAYCHANGE: {
        RECT screen = virtual_screen();
        RECT target{};
        if (game_client_screen_rect(target))
            screen = target;
        ::SetWindowPos(hWnd, HWND_TOPMOST, screen.left, screen.top,
                       screen.right - screen.left, screen.bottom - screen.top,
                       SWP_NOACTIVATE);
        return 0;
    }
    case WM_CLOSE:
        VibeUiSetMenuOpen(0);
        egui::settings.state.menu_open = false;
        return 0;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}
