#include "HeadshotAudio.h"
#include <windows.h>
#include <mmsystem.h>
#include <atomic>
#include <array>
#include <cstring>
#include "../../../source/esp/headshot_asset.h"
#include "../../../source/esp/hit_assets.h"
#include "../../../source/esp/hit_pcm_mixer.h"
#ifdef VIBE_INTERNAL_DLL_UI
extern "C" std::uint64_t WINAPI VibeUiTakeHitAudio(void);
extern "C" DWORD WINAPI VibeUiHitAudioActive(void);
extern "C" void WINAPI VibeUiReportHitAudio(DWORD,DWORD);
#endif
namespace vibe_audio {
// One audio worker owns the device, mixer and persistent driver buffers.
// UI stalls and another PlaySound caller cannot cancel this playback.
constexpr std::size_t block_samples=320,block_count=3;
struct OutputBlock {WAVEHDR header{};std::array<int16_t,block_samples> pcm{};bool submitted=false;};
static std::array<OutputBlock,block_count> blocks{};
static HWAVEOUT output=nullptr;
static VibePcmMixer mixer{};
static std::size_t next_block=0;
static HANDLE worker=nullptr;
static std::atomic<bool> quit{false},stop{false};
static std::atomic<std::uint32_t> settings{1u|(2u<<2)|(70u<<4)},preview_packet{0},error_code{0},state{0};
static ULONGLONG retry_after=0;
static bool previous_active=false;
static void PublishStatus(){
#ifdef VIBE_INTERNAL_DLL_UI
 VibeUiReportHitAudio(state.load(),error_code.load());
#endif
}
static void StartVoice(std::uint32_t sound,std::uint32_t volume){
 const auto* wav=sound==1?vibe_punch_impact_wav:sound==2?vibe_hit_something_wav:vibe_headshot_wav;
 const std::size_t bytes=sound==1?sizeof(vibe_punch_impact_wav):sound==2?sizeof(vibe_hit_something_wav):sizeof(vibe_headshot_wav);
 vibe_pcm_start(&mixer,wav+44,(bytes-44)/2,volume);
}
static bool CloseOutput(){
 if(!output)return true;
 MMRESULT error=waveOutReset(output);if(error){error_code=error;state=2;return false;}
 for(auto& block:blocks)if(block.header.dwFlags&WHDR_PREPARED){
  error=waveOutUnprepareHeader(output,&block.header,sizeof(block.header));if(error){error_code=error;state=2;return false;}
 }
 error=waveOutClose(output);if(error){error_code=error;state=2;return false;}
 output=nullptr;next_block=0;for(auto& block:blocks)block=OutputBlock{};return true;
}
static bool OpenOutput(){
 WAVEFORMATEX format{};format.wFormatTag=WAVE_FORMAT_PCM;format.nChannels=1;format.nSamplesPerSec=32000;format.wBitsPerSample=16;format.nBlockAlign=2;format.nAvgBytesPerSec=64000;
 MMRESULT error=waveOutOpen(&output,WAVE_MAPPER,&format,0,0,CALLBACK_NULL);
 if(error){output=nullptr;error_code=error;state=2;return false;}
 for(auto& block:blocks){
  block=OutputBlock{};block.header.lpData=reinterpret_cast<LPSTR>(block.pcm.data());block.header.dwBufferLength=static_cast<DWORD>(block.pcm.size()*2);
  error=waveOutPrepareHeader(output,&block.header,sizeof(block.header));
  if(error){error_code=error;state=2;CloseOutput();return false;}
 }
 next_block=0;error_code=0;state=1;return true;
}
static void ResetPlayback(){
 vibe_pcm_clear(&mixer);
 if(output){MMRESULT error=waveOutReset(output);if(error){error_code=error;state=2;CloseOutput();}else {for(auto& block:blocks)block.submitted=false;next_block=0;}}
}
static void AudioStep(){
 bool active=false;std::uint64_t events=0;
#ifdef VIBE_INTERNAL_DLL_UI
 active=VibeUiHitAudioActive()!=0;
#endif
 const bool stopped=stop.exchange(false);
 if(stopped||(previous_active&&!active))ResetPlayback();
 if(stopped)preview_packet=0;
 previous_active=active;
#ifdef VIBE_INTERNAL_DLL_UI
 events=VibeUiTakeHitAudio();
#endif
 if(!stopped&&active){
  const auto config=settings.load();const auto volume=(config>>4)&127u;
  const auto body=static_cast<std::uint32_t>(events),head=static_cast<std::uint32_t>(events>>32);
  // Saturation only replaces an oldest tail; regular head/body cues never cancel one another.
  for(std::uint32_t n=0;n<body&&n<VIBE_AUDIO_VOICES;++n)StartVoice((config>>2)&3u,volume);
  for(std::uint32_t n=0;n<head&&n<VIBE_AUDIO_VOICES;++n)StartVoice(config&3u,volume);
 }
 const auto preview=preview_packet.exchange(0);
 if(preview)StartVoice((preview>>1)&3u,(preview>>3)&127u);
 const auto now=GetTickCount64();
 if(state.load()==2&&output){if(now<retry_after)return;if(!CloseOutput()){retry_after=now+1000;return;}}
 if(!output){if(!vibe_pcm_active(&mixer)||now<retry_after)return;if(!OpenOutput()){retry_after=now+1000;return;}}
 // Once opened, short silence blocks keep the device stable between hits.
 for(std::size_t n=0;n<block_count;++n){
  auto& block=blocks[next_block];
  if(block.submitted&&!(block.header.dwFlags&WHDR_DONE))break;
  const auto before=mixer;vibe_pcm_render(&mixer,block.pcm.data(),block.pcm.size());
  const MMRESULT error=waveOutWrite(output,&block.header,sizeof(block.header));
  if(error){mixer=before;error_code=error;state=2;CloseOutput();retry_after=now+1000;return;}
  block.submitted=true;next_block=(next_block+1)%block_count;
 }
}
static DWORD WINAPI AudioWorker(void*){
 while(!quit.load()){AudioStep();PublishStatus();Sleep(5);}
 vibe_pcm_clear(&mixer);CloseOutput();return 0;
}
static void EnsureWorker(){
 if(worker)return;quit=false;worker=CreateThread(nullptr,0,AudioWorker,nullptr,0,nullptr);
 if(!worker){error_code=GetLastError();state=3;PublishStatus();}
}
void Configure(std::uint32_t head,std::uint32_t body,std::uint32_t volume){
 if(head>2)head=0;if(body>2)body=0;if(volume>100)volume=100;
 settings=head|(body<<2)|(volume<<4);EnsureWorker();
}
void Play(std::uint32_t sound,std::uint32_t volume,bool headshot,bool preview){
 (void)headshot;(void)preview;if(sound>2)sound=0;if(volume>100)volume=100;EnsureWorker();
 preview_packet=1u|(sound<<1)|(volume<<3);
}
void Stop(){stop=true;preview_packet=0;}
void Shutdown(){
 if(!worker)return;quit=true;WaitForSingleObject(worker,INFINITE);CloseHandle(worker);worker=nullptr;stop=false;previous_active=false;
}
const char* Status(){switch(state.load()){case 1:return "Hit sound mixer ready";case 2:return "Audio device unavailable; retrying";case 3:return "Audio worker unavailable";default:return "Hit sound mixer waiting";}}
std::uint32_t ErrorCode(){return error_code.load();}
}
