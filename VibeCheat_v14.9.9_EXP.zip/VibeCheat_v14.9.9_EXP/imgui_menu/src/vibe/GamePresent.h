#pragma once
#include <dxgi.h>
namespace vibe_present {
void Install(IDXGISwapChain* overlay_chain);
bool Active();
void Stop();
}
