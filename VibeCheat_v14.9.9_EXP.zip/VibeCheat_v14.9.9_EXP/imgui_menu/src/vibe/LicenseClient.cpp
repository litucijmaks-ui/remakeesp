#include "../../../source/license_client.h"
static VibeLicenseClient client;
static volatile LONG licensed;
static volatile LONG64 leaseUntil;
static volatile LONG64 publicExpiry;
static volatile LONG publicBind;
static void PublishLicense(){
    InterlockedExchange64(&publicExpiry,(LONG64)client.expires);
    InterlockedExchange(&publicBind,(LONG)client.bind_pc);
    InterlockedExchange64(&leaseUntil,(LONG64)client.lease_deadline);
    InterlockedExchange(&licensed,1);
}
static DWORD WINAPI LicenseWorker(void*){
    ULONGLONG next=GetTickCount64()+20000;
    for(;;){
        Sleep(500);ULONGLONG now=GetTickCount64();
        if(now>=(ULONGLONG)InterlockedCompareExchange64(&leaseUntil,0,0))InterlockedExchange(&licensed,0);
        if(now<next)continue;
        next=now+20000;
        if(license_check(&client))PublishLicense();
        else if(strcmp(client.error,"server_unavailable"))InterlockedExchange(&licensed,0);
    }
}
extern "C" DWORD WINAPI VibeLicenseReady(){return InterlockedCompareExchange(&licensed,0,0)!=0&&GetTickCount64()<(ULONGLONG)InterlockedCompareExchange64(&leaseUntil,0,0);}
extern "C" DWORD WINAPI VibeLicenseInfo(uint64_t *expiry,DWORD *bind){
    if(expiry)*expiry=(uint64_t)InterlockedCompareExchange64(&publicExpiry,0,0);
    if(bind)*bind=(DWORD)InterlockedCompareExchange(&publicBind,0,0);
    return VibeLicenseReady();
}
extern "C" DWORD WINAPI VibeLicenseInitialize(HMODULE module){
    if(!license_paths(&client,module)||!license_release_integrity(client.directory)||!license_ticket(&client,FALSE)||!license_check(&client))return 0;
    PublishLicense();
    HANDLE thread=CreateThread(nullptr,0,LicenseWorker,nullptr,0,nullptr);
    if(!thread){InterlockedExchange(&licensed,0);return 0;}CloseHandle(thread);return 1;
}
