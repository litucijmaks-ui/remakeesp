#include "PlayerPreview.h"
#include "game_player_asset.h"
#include "../ui/egui.hxx"
#include "../ui/theme.hxx"
#include "../ui/layout.hxx"
#include <Windows.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace vibe_preview {

static ID3D11Texture2D* g_texture = nullptr;
static ID3D11ShaderResourceView* g_srv = nullptr;
static int g_view = -1;
static float g_angle = 0.28f;
static bool g_dragging = false;
static std::array<std::uint32_t, (size_t)GAME_PREVIEW_WIDTH * GAME_PREVIEW_HEIGHT> g_pixels{};

static constexpr float PI = 3.14159265358979323846f;
static constexpr float TAU = PI * 2.0f;

static ImU32 from_cfg(DWORD c, int alpha = 255)
{
    return IM_COL32(GetRValue(c), GetGValue(c), GetBValue(c), alpha);
}

static float wrap_angle(float a)
{
    while (a < 0.0f) a += TAU;
    while (a >= TAU) a -= TAU;
    return a;
}

static int current_view()
{
    // The baked sprite atlas is authored with a +90 degree facing offset.
    // Keep the overlay skeleton on that exact same heading.
    const float a = wrap_angle(g_angle + PI * 0.5f);
    return (int)(a * (float)GAME_PREVIEW_VIEWS / TAU + 0.5f) % GAME_PREVIEW_VIEWS;
}

static void decode_view(int view)
{
    const unsigned begin = game_preview_offsets[view];
    const unsigned end = game_preview_offsets[view + 1];
    std::fill(g_pixels.begin(), g_pixels.end(), 0xFF151212u);

    size_t out = 0;
    for (unsigned i = begin; i + 1 < end && out < g_pixels.size();) {
        unsigned run = game_preview_rle[i++];
        const unsigned index = game_preview_rle[i++];
        const DWORD packed = index < (sizeof(game_preview_palette) / sizeof(game_preview_palette[0]))
            ? game_preview_palette[index]
            : 0;

        const unsigned r = packed ? ((packed >> 16) & 0xFFu) : 1u;
        const unsigned g = packed ? ((packed >> 8) & 0xFFu) : 1u;
        const unsigned b = packed ? (packed & 0xFFu) : 1u;
        const std::uint32_t rgba = r | (g << 8) | (b << 16) | 0xFF000000u;

        while (run-- && out < g_pixels.size())
            g_pixels[out++] = rgba;
    }
}

static bool ensure_texture()
{
    if (!g_pd3dDevice || !g_pd3dDeviceContext)
        return false;

    const int view = current_view();
    if (view == g_view && g_srv)
        return true;

    decode_view(view);

    if (!g_texture) {
        D3D11_TEXTURE2D_DESC desc{};
        desc.Width = GAME_PREVIEW_WIDTH;
        desc.Height = GAME_PREVIEW_HEIGHT;
        desc.MipLevels = 1;
        desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_DEFAULT;
        desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA data{};
        data.pSysMem = g_pixels.data();
        data.SysMemPitch = GAME_PREVIEW_WIDTH * 4;

        if (FAILED(g_pd3dDevice->CreateTexture2D(&desc, &data, &g_texture)) || !g_texture)
            return false;

        D3D11_SHADER_RESOURCE_VIEW_DESC srv_desc{};
        srv_desc.Format = desc.Format;
        srv_desc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srv_desc.Texture2D.MipLevels = 1;

        if (FAILED(g_pd3dDevice->CreateShaderResourceView(g_texture, &srv_desc, &g_srv)) || !g_srv) {
            g_texture->Release();
            g_texture = nullptr;
            return false;
        }
    } else {
        g_pd3dDeviceContext->UpdateSubresource(
            g_texture, 0, nullptr, g_pixels.data(), GAME_PREVIEW_WIDTH * 4, 0);
    }

    g_view = view;
    return g_srv != nullptr;
}

static float fast_sin(float x)
{
    while (x > PI) x -= TAU;
    while (x < -PI) x += TAU;
    const float q = x * x;
    return x * (1.0f - q / 6.0f + q * q / 120.0f - q * q * q / 5040.0f + q * q * q * q / 362880.0f);
}

struct P3 { float x, y, z; };

static P3 rotate_to_sprite(P3 p)
{
    // IMPORTANT: use the same +90 deg orientation as current_view().
    const float a = (float)current_view() * TAU / (float)GAME_PREVIEW_VIEWS;
    const float s = fast_sin(a);
    const float c = fast_sin(a + PI * 0.5f);
    return { c * p.x + s * p.z, p.y, -s * p.x + c * p.z };
}

static ImVec2 project(P3 p, ImVec2 origin, float unit)
{
    p = rotate_to_sprite(p);
    const float scale = 108.0f; // Match the atlas orthographic projection.
    return ImVec2(origin.x + (99.0f + p.x * scale) * unit,
                  origin.y + (243.0f - p.y * scale) * unit);
}

static void bone(ImDrawList* dl, const P3& a, const P3& b, ImVec2 origin,
                 float unit, ImU32 color, float thickness)
{
    dl->AddLine(project(a, origin, unit), project(b, origin, unit), color, thickness);
}

static void draw_realistic_skeleton(ImDrawList* dl, ImVec2 origin, float unit,
                                    ImU32 color, float thickness)
{
    // A more human-like rig than the old straight stick figure.  The rig is
    // projected with the same angle as the baked player sprite, so it does not
    // turn sideways relative to the model anymore.
    const P3 head{0.00f, 1.76f, 0.01f};
    const P3 neck{0.00f, 1.54f, -0.015f};
    const P3 chest{0.00f, 1.28f, 0.01f};
    const P3 pelvis{0.00f, 0.88f, 0.0f};

    const ImVec2 hp = project(head, origin, unit);
    const ImVec2 np = project(neck, origin, unit);
    const float head_radius = ImMax(2.5f * unit, std::abs(hp.y - np.y) * 0.42f);
    dl->AddCircle(hp, head_radius, color, 18, thickness);

    bone(dl, neck, chest, origin, unit, color, thickness);
    bone(dl, chest, pelvis, origin, unit, color, thickness);

    for (int side : {-1, 1}) {
        const float s = (float)side;
        const P3 shoulder{s * 0.255f, 1.43f, -0.08f};
        const P3 elbow{s * 0.335f, 1.12f, -0.075f};
        const P3 wrist{s * 0.370f, 0.82f, -0.04f};
        const P3 hip{s * 0.125f, 0.86f, 0.0f};
        const P3 knee{s * 0.135f, 0.48f, -0.065f};
        const P3 ankle{s * 0.120f, 0.10f, -0.04f};
        const P3 toe{s * 0.120f, 0.04f, 0.10f};

        bone(dl, neck, shoulder, origin, unit, color, thickness);
        bone(dl, shoulder, elbow, origin, unit, color, thickness);
        bone(dl, elbow, wrist, origin, unit, color, thickness);
        bone(dl, pelvis, hip, origin, unit, color, thickness);
        bone(dl, hip, knee, origin, unit, color, thickness);
        bone(dl, knee, ankle, origin, unit, color, thickness);
        bone(dl, ankle, toe, origin, unit, color, thickness);

        // Tiny joints make the preview resemble a real ESP skeleton more closely.
        for (const P3& joint : { shoulder, elbow, wrist, hip, knee, ankle })
            dl->AddCircleFilled(project(joint, origin, unit), ImMax(1.4f, 1.7f * unit), color, 8);
    }
}

static void centered_text(ImDrawList* dl, ImVec2 origin, float unit, float y,
                          ImU32 color, const char* text)
{
    const ImVec2 ts = ImGui::CalcTextSize(text);
    const ImVec2 center(origin.x + 99.0f * unit, origin.y + y * unit);
    dl->AddText(ImVec2(center.x - ts.x * 0.5f, center.y), color, text);
}

void Draw(float width, vibe::ESPSettings& c)
{
    const float dpi = egui::dpi(1.0f);
    const float max_scale = 0.86f; // compact in-menu preview
    const float fit = ImMin(max_scale, width / (198.0f * dpi));
    const float unit = dpi * ImMax(0.55f, fit);
    const ImVec2 widget_size(198.0f * unit, 302.0f * unit);

    const float x_pad = ImMax(0.0f, (width - widget_size.x) * 0.5f);
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + x_pad);
    const ImVec2 origin = ImGui::GetCursorScreenPos();

    ImGui::InvisibleButton("##vibe_player_preview", widget_size);
    const bool hovered = ImGui::IsItemHovered();
    const ImGuiIO& io = ImGui::GetIO();

    if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left))
        g_dragging = true;
    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
        g_dragging = false;
    if (g_dragging) {
        g_angle += (io.MouseDelta.x / ImMax(dpi, 0.001f)) * 0.015f;
        while (g_angle > PI) g_angle -= TAU;
        while (g_angle < -PI) g_angle += TAU;
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 max(origin.x + widget_size.x, origin.y + widget_size.y);
    dl->AddRectFilled(origin, max, ImGui::ColorConvertFloat4ToU32(egui::colors.page), egui::dpi(8.0f));
    dl->AddRect(origin, max, ImGui::ColorConvertFloat4ToU32(egui::colors.card_border), egui::dpi(8.0f), 0, egui::dpi(1.0f));

    dl->AddText(ImVec2(origin.x + 14.0f * unit, origin.y + 9.0f * unit),
                ImGui::ColorConvertFloat4ToU32(egui::colors.text_sec), vibe_lang::T("Player Preview"));

    if (ensure_texture()) {
        const ImVec2 i0(origin.x + 35.0f * unit, origin.y + 35.0f * unit);
        const ImVec2 i1(i0.x + GAME_PREVIEW_WIDTH * unit, i0.y + GAME_PREVIEW_HEIGHT * unit);
        dl->AddImage((ImTextureID)g_srv, i0, i1);
    }

    dl->AddLine(ImVec2(origin.x + 23.0f * unit, origin.y + 245.0f * unit),
                ImVec2(origin.x + 176.0f * unit, origin.y + 245.0f * unit),
                ImGui::ColorConvertFloat4ToU32(egui::colors.divider), ImMax(1.0f, unit));

    if ((c.flags & 1u) != 0) {
        const float thickness = ImMax(1.0f, (float)c.esp_width * unit);

        if ((c.aim_flags & 3u) == 3u) {
            dl->AddCircle(ImVec2(origin.x + 99.0f * unit, origin.y + 139.0f * unit),
                          79.0f * unit, from_cfg(c.esp_colors[vibe::ESP_COLOR_FOV]), 64, thickness);
        }

        if ((c.flags & 2u) != 0) {
            dl->AddRect(ImVec2(origin.x + 55.0f * unit, origin.y + 41.0f * unit),
                        ImVec2(origin.x + 143.0f * unit, origin.y + 246.0f * unit),
                        from_cfg(c.esp_colors[vibe::ESP_COLOR_BOX]), 0.0f, 0, thickness);

            dl->AddLine(ImVec2(origin.x + 50.0f * unit, origin.y + 245.0f * unit),
                        ImVec2(origin.x + 50.0f * unit, origin.y + 91.0f * unit),
                        from_cfg(c.esp_colors[vibe::ESP_COLOR_HP]), thickness);
            centered_text(dl, origin, unit, 249.0f, from_cfg(c.esp_colors[vibe::ESP_COLOR_HP]), "75% hp");
        }

        if ((c.flags & 4u) != 0)
            centered_text(dl, origin, unit, 26.0f, from_cfg(c.esp_colors[vibe::ESP_COLOR_NAME]), vibe_lang::T("Player"));

        if ((c.flags & 8u) != 0)
            dl->AddLine(ImVec2(origin.x + 99.0f * unit, origin.y + 280.0f * unit),
                        ImVec2(origin.x + 99.0f * unit, origin.y + 246.0f * unit),
                        from_cfg(c.esp_colors[vibe::ESP_COLOR_LINE]), thickness);

        if ((c.flags & 16u) != 0)
            centered_text(dl, origin, unit, 266.0f, from_cfg(c.esp_colors[vibe::ESP_COLOR_DISTANCE]), "25 m");

        if ((c.flags & 32u) != 0)
            draw_realistic_skeleton(dl, origin, unit,
                                    from_cfg(c.esp_colors[vibe::ESP_COLOR_SKELETON]), thickness);
    }

    const char* hint = vibe_lang::T(g_dragging ? "Rotating..." : "Drag to rotate");
    const ImVec2 hs = ImGui::CalcTextSize(hint);
    dl->AddText(ImVec2(origin.x + (widget_size.x - hs.x) * 0.5f, origin.y + 283.0f * unit),
                ImGui::ColorConvertFloat4ToU32(hovered ? egui::colors.text : egui::colors.text_muted), hint);
}

void Shutdown()
{
    if (g_srv) {
        g_srv->Release();
        g_srv = nullptr;
    }
    if (g_texture) {
        g_texture->Release();
        g_texture = nullptr;
    }
    g_view = -1;
    g_dragging = false;
}

} // namespace vibe_preview
