#pragma once
// Streaming metadata export. No managed method is invoked and no game field is read.
#include <cstdio>
#include <cstdint>
#include <string>
#include <stdexcept>
#include <limits>
namespace vibe_dump {
using P = void*;
struct Api {
 P (*domain_get)(); P* (*domain_get_assemblies)(P,size_t*);
 P (*assembly_get_image)(P); const char* (*image_get_name)(P);
 size_t (*image_get_class_count)(P); P (*image_get_class)(P,size_t);
 const char* (*class_get_name)(P); const char* (*class_get_namespace)(P);
 P (*class_get_parent)(P); P (*class_get_declaring_type)(P); uint32_t (*class_get_flags)(P);
 P (*class_get_fields)(P,P*); const char* (*field_get_name)(P);
 P (*field_get_type)(P); size_t (*field_get_offset)(P); int (*field_get_flags)(P);
 P (*class_get_methods)(P,P*); const char* (*method_get_name)(P);
 P (*method_get_return_type)(P); uint32_t (*method_get_param_count)(P);
 P (*method_get_param)(P,uint32_t); const char* (*method_get_param_name)(P,uint32_t);
 uint32_t (*method_get_flags)(P,uint32_t*); uint32_t (*method_get_token)(P);
 char* (*type_get_name)(P); void (*free)(P);
 P (*class_get_properties)(P,P*); const char* (*property_get_name)(P);
 P (*property_get_get_method)(P); P (*property_get_set_method)(P);
 P (*class_get_interfaces)(P,P*);
 P (*thread_attach)(P); void (*thread_detach)(P);
};
struct Counts { uint64_t images=0,classes=0,fields=0,methods=0,properties=0,totalClasses=0; };
struct Sink {
 FILE *cs=nullptr,*json=nullptr;
 void (*progress)(const Counts&)=nullptr; bool (*cancelled)()=nullptr;
 uintptr_t moduleBase=0; size_t moduleSize=0;
};
inline const char* safe(const char* s){return s?s:"";}
inline void quoted(FILE* f,const char* text){
 std::fputc('"',f);
 for(const unsigned char* p=reinterpret_cast<const unsigned char*>(safe(text));*p;++p){
  switch(*p){case '"':std::fputs("\\\"",f);break;case '\\':std::fputs("\\\\",f);break;
   case '\n':std::fputs("\\n",f);break;case '\r':std::fputs("\\r",f);break;case '\t':std::fputs("\\t",f);break;
   default:if(*p<32)std::fprintf(f,"\\u%04x",*p);else std::fputc(*p,f);}
 }
 std::fputc('"',f);
}
inline std::string line(const char* text){
 std::string s=safe(text);for(char& c:s)if(static_cast<unsigned char>(c)<32)c=' ';
 return s;
}
inline std::string className(const Api& a,P c){
 if(!c)return {};
 std::string name=safe(a.class_get_namespace(c));if(!name.empty())name+='.';
 name+=safe(a.class_get_name(c));return name;
}
inline std::string typeName(const Api& a,P type){
 if(!type)return {};
 char* raw=a.type_get_name(type);std::string result;
 try{result=safe(raw);}catch(...){if(raw)a.free(raw);throw;}
 if(raw)a.free(raw);return result;
}
inline void checkpoint(const Sink& s){
 if(s.cancelled&&s.cancelled())throw std::runtime_error("cancelled");
 if(std::ferror(s.cs)||std::ferror(s.json))throw std::runtime_error("Output write failed");
}
inline void rva(FILE* f,const Sink& s,P method){
 uintptr_t entry=method?*reinterpret_cast<const uintptr_t*>(method):0;
 if(entry>=s.moduleBase&&entry-s.moduleBase<s.moduleSize)std::fprintf(f,"%llu",static_cast<unsigned long long>(entry-s.moduleBase));
 else std::fputs("null",f);
}
inline void write(const Api& a,P domain,const Sink& s,Counts& counts){
 if(!s.cs||!s.json)throw std::runtime_error("Output not open");
 size_t assemblyCount=0;P* assemblies=a.domain_get_assemblies(domain,&assemblyCount);
 if(!assemblies||!assemblyCount||assemblyCount>65536)throw std::runtime_error("Runtime assemblies unavailable");
 for(size_t i=0;i<assemblyCount;++i){P image=a.assembly_get_image(assemblies[i]);if(!image)throw std::runtime_error("Null assembly image");
  size_t n=a.image_get_class_count(image);if(n>10000000||counts.totalClasses>10000000-n)throw std::runtime_error("Invalid class count");counts.totalClasses+=n;}
 std::fputs("// VIBE IL2CPP runtime metadata export\n// RVA is relative to GameAssembly.dll; unavailable native pointers are null.\n// Names/signatures are preserved as metadata; this reference listing may not compile.\n",s.cs);
 std::fprintf(s.json,"{\"schemaVersion\":1,\"module\":\"GameAssembly.dll\",\"propertiesAvailable\":%s,\"interfacesAvailable\":%s,\"images\":[\n",a.class_get_properties?"true":"false",a.class_get_interfaces?"true":"false");
 for(size_t i=0;i<assemblyCount;++i){
  checkpoint(s);P image=a.assembly_get_image(assemblies[i]);size_t n=a.image_get_class_count(image);
  if(i)std::fputc(',',s.json);std::fputs("{\"name\":",s.json);quoted(s.json,a.image_get_name(image));std::fputs(",\"classes\":[\n",s.json);
  std::fprintf(s.cs,"\n// Image: %s\n",line(a.image_get_name(image)).c_str());
  for(size_t j=0;j<n;++j){
   checkpoint(s);P c=a.image_get_class(image,j);if(!c)throw std::runtime_error("Null runtime class; export incomplete");
   if(j)std::fputc(',',s.json);
   std::string parent=className(a,a.class_get_parent(c)),declaring=className(a,a.class_get_declaring_type(c));
   uint32_t flags=a.class_get_flags(c);
   std::fputs("{\"name\":",s.json);quoted(s.json,a.class_get_name(c));std::fputs(",\"namespace\":",s.json);quoted(s.json,a.class_get_namespace(c));
   std::fputs(",\"parent\":",s.json);quoted(s.json,parent.c_str());std::fputs(",\"declaringType\":",s.json);quoted(s.json,declaring.c_str());
   std::fprintf(s.json,",\"flags\":%u,\"interfaces\":[",flags);
   if(a.class_get_interfaces){P it=nullptr,p;bool comma=false;while((p=a.class_get_interfaces(c,&it))){checkpoint(s);if(comma)std::fputc(',',s.json);comma=true;quoted(s.json,className(a,p).c_str());}}
   std::fprintf(s.cs,"\n// Namespace: %s | Declaring type: %s | Flags: 0x%X\nclass %s%s%s\n{\n",line(a.class_get_namespace(c)).c_str(),line(declaring.c_str()).c_str(),flags,line(a.class_get_name(c)).c_str(),parent.empty()?"":" : ",line(parent.c_str()).c_str());
   std::fputs("],\"fields\":[",s.json);P it=nullptr,p;bool comma=false;
   while((p=a.class_get_fields(c,&it))){
    checkpoint(s);if(comma)std::fputc(',',s.json);comma=true;std::string type=typeName(a,a.field_get_type(p));size_t offset=a.field_get_offset(p);int ff=a.field_get_flags(p);
    std::fputs("{\"name\":",s.json);quoted(s.json,a.field_get_name(p));std::fputs(",\"type\":",s.json);quoted(s.json,type.c_str());
    std::fprintf(s.json,",\"offset\":%lld,\"flags\":%u}",static_cast<long long>(static_cast<intptr_t>(offset)),static_cast<unsigned>(ff));
    std::fprintf(s.cs,"    %s%s %s; // Offset: 0x%llX, Flags: 0x%X\n",(ff&16)?"static ":"",line(type.c_str()).c_str(),line(a.field_get_name(p)).c_str(),static_cast<unsigned long long>(offset),ff);++counts.fields;
   }
   std::fputs("],\"methods\":[",s.json);it=nullptr;comma=false;
   while((p=a.class_get_methods(c,&it))){
    checkpoint(s);if(comma)std::fputc(',',s.json);comma=true;std::string returns=typeName(a,a.method_get_return_type(p));uint32_t impl=0,mf=a.method_get_flags(p,&impl),params=a.method_get_param_count(p);
    if(params>65536)throw std::runtime_error("Invalid method parameter count");
    std::fputs("{\"name\":",s.json);quoted(s.json,a.method_get_name(p));std::fputs(",\"returnType\":",s.json);quoted(s.json,returns.c_str());
    std::fprintf(s.json,",\"flags\":%u,\"implementationFlags\":%u,\"token\":%u,\"rva\":",mf,impl,a.method_get_token(p));rva(s.json,s,p);std::fputs(",\"parameters\":[",s.json);
    uintptr_t entry=*reinterpret_cast<const uintptr_t*>(p);bool valid=entry>=s.moduleBase&&entry-s.moduleBase<s.moduleSize;
    if(valid)std::fprintf(s.cs,"    // RVA: 0x%llX",static_cast<unsigned long long>(entry-s.moduleBase));else std::fputs("    // RVA: unavailable",s.cs);
    std::fprintf(s.cs," | Token: 0x%X | Flags: 0x%X | Impl: 0x%X\n    %s%s %s(",a.method_get_token(p),mf,impl,(mf&16)?"static ":"",line(returns.c_str()).c_str(),line(a.method_get_name(p)).c_str());
    for(uint32_t k=0;k<params;++k){
     checkpoint(s);if(k){std::fputc(',',s.json);std::fputs(", ",s.cs);}std::string pt=typeName(a,a.method_get_param(p,k));
     std::fputs("{\"name\":",s.json);quoted(s.json,a.method_get_param_name(p,k));std::fputs(",\"type\":",s.json);quoted(s.json,pt.c_str());std::fputc('}',s.json);
     std::fprintf(s.cs,"%s %s",line(pt.c_str()).c_str(),line(a.method_get_param_name(p,k)).c_str());
    }
    std::fputs("]}",s.json);std::fputs(");\n",s.cs);++counts.methods;
   }
   std::fputs("],\"properties\":[",s.json);it=nullptr;comma=false;
   if(a.class_get_properties)while((p=a.class_get_properties(c,&it))){
    checkpoint(s);if(comma)std::fputc(',',s.json);comma=true;
    P get=a.property_get_get_method(p),set=a.property_get_set_method(p);
    std::fputs("{\"name\":",s.json);quoted(s.json,a.property_get_name(p));std::fputs(",\"getter\":",s.json);quoted(s.json,get?a.method_get_name(get):"");std::fputs(",\"setter\":",s.json);quoted(s.json,set?a.method_get_name(set):"");std::fputs(",\"getterRva\":",s.json);rva(s.json,s,get);std::fputs(",\"setterRva\":",s.json);rva(s.json,s,set);std::fputc('}',s.json);
    std::fprintf(s.cs,"    // Property: %s | Get: %s | Set: %s\n",line(a.property_get_name(p)).c_str(),line(get?a.method_get_name(get):"").c_str(),line(set?a.method_get_name(set):"").c_str());++counts.properties;
   }
   std::fputs("]}\n",s.json);std::fputs("}\n",s.cs);++counts.classes;if(s.progress)s.progress(counts);
  }
  std::fputs("]}\n",s.json);++counts.images;if(s.progress)s.progress(counts);
 }
 checkpoint(s);
 std::fprintf(s.json,"],\"complete\":true,\"counts\":{\"images\":%llu,\"classes\":%llu,\"fields\":%llu,\"methods\":%llu,\"properties\":%llu}}\n",static_cast<unsigned long long>(counts.images),static_cast<unsigned long long>(counts.classes),static_cast<unsigned long long>(counts.fields),static_cast<unsigned long long>(counts.methods),static_cast<unsigned long long>(counts.properties));
 checkpoint(s);
}
}
