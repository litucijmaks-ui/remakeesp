#include "VibeRuntime.h"
#include <string>
#include <cstdio>
#include "HeadshotAudio.h"
#ifdef VIBE_INTERNAL_DLL_UI
extern "C" void VibeUiSetMenuOpen(DWORD open);
extern "C" void VibeUiRequestCompatibilityCheck(void);
extern "C" DWORD WINAPI VibeUiReadCompatibilityStatus(char*,DWORD);
extern "C" DWORD WINAPI VibeUiWriteCustom(const VibeCustomSettings*,DWORD);
extern "C" DWORD WINAPI VibeUiReadSkinCatalog(VibeSkinCatalog*,DWORD);
extern "C" DWORD WINAPI VibeUiReadCombatFeedback(VibeCombatFeedback*,DWORD);
extern "C" DWORD WINAPI VibeUiRefreshSkinCatalog(void);
#endif

namespace vibe_runtime {
void StartMetadataDump(){
#ifdef VIBE_INTERNAL_DLL_UI
    vibe_dump::Start();
#endif
}
void CancelMetadataDump(){
#ifdef VIBE_INTERNAL_DLL_UI
    vibe_dump::Cancel();
#endif
}
vibe_dump::Status MetadataDumpStatus(){
#ifdef VIBE_INTERNAL_DLL_UI
    return vibe_dump::Read();
#else
    vibe_dump::Status s{};s.state=vibe_dump::Failed;std::snprintf(s.message,sizeof(s.message),"Requires the internal DLL menu");return s;
#endif
}

vibe::ESPSettings config{};
VibeCustomSettings custom{};
static std::wstring g_custom_path;
static bool g_custom_pending = false;

static std::wstring g_path;
static std::wstring g_ui_path;
static FILETIME g_last_write{};
static ULONGLONG g_next_reload = 0;
static bool g_dirty = false;
static ULONGLONG g_save_after = 0;
static char g_status[128] = "ready";
static DWORD g_game_pid = 0;

static bool PushCustom() {
    custom.checksum = vibe_custom_checksum(&custom);
#ifdef VIBE_INTERNAL_DLL_UI
    return VibeUiWriteCustom(&custom, sizeof(custom)) != 0;
#else
    return true;
#endif
}
static bool LoadCustom() {
    HANDLE file=CreateFileW(g_custom_path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE)return false;
    VibeCustomSettings value{};unsigned char data[sizeof(value)]{};DWORD got=0;
    const DWORD size=GetFileSize(file,nullptr);
    const bool ok=size<=sizeof(data)&&ReadFile(file,data,sizeof(data),&got,nullptr)&&got==size&&vibe_custom_decode(&value,data,size);
    CloseHandle(file);if(ok)custom=value;return ok;
}
static bool SaveCustom() {
    custom.checksum=vibe_custom_checksum(&custom);if(!vibe_custom_valid(&custom))return false;
    const std::wstring temporary=g_custom_path+L".tmp";
    HANDLE file=CreateFileW(temporary.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE)return false;
    DWORD wrote=0;const bool ok=WriteFile(file,&custom,sizeof(custom),&wrote,nullptr)&&wrote==sizeof(custom);CloseHandle(file);
    if(!ok||!MoveFileExW(temporary.c_str(),g_custom_path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(temporary.c_str());return false;}
    return true;
}
void MarkCustomDirty() {g_custom_pending=!PushCustom();vibe_audio::Configure(custom.head_sound,custom.body_sound,custom.sound_volume);MarkDirty();}
void PreviewHitSound(bool headshot) {vibe_audio::Play(headshot?custom.head_sound:custom.body_sound,custom.sound_volume,headshot,true);}
const char* HitAudioStatusText(){return vibe_audio::Status();}
DWORD HitAudioErrorCode(){return vibe_audio::ErrorCode();}
void RefreshSkinCatalog() {
#ifdef VIBE_INTERNAL_DLL_UI
    VibeUiRefreshSkinCatalog();
#endif
}
bool ReadSkinCatalog(VibeSkinCatalog& out) {
#ifdef VIBE_INTERNAL_DLL_UI
    return VibeUiReadSkinCatalog(&out,sizeof(out)) != 0;
#else
    (void)out;return false;
#endif
}
bool ReadCombatFeedback(VibeCombatFeedback& out) {
#ifdef VIBE_INTERNAL_DLL_UI
    return VibeUiReadCombatFeedback(&out,sizeof(out)) != 0;
#else
    (void)out;return false;
#endif
}

static bool GetLastWrite(const std::wstring& path, FILETIME& ft) {
    WIN32_FILE_ATTRIBUTE_DATA data{};
    if (!GetFileAttributesExW(path.c_str(), GetFileExInfoStandard, &data))
        return false;
    ft = data.ftLastWriteTime;
    return true;
}

bool Initialize(DWORD gamePid, HMODULE module) {
    g_game_pid = gamePid;
    if (module) {
        wchar_t path[MAX_PATH * 4]{};
        DWORD n = GetModuleFileNameW(module, path, static_cast<DWORD>(_countof(path)));
        std::wstring dir(path, path + n);
        const auto pos = dir.find_last_of(L"\\/");
        if (pos != std::wstring::npos) dir.resize(pos + 1); else dir.clear();
        g_path = dir + L"esp_menu.bin";
    } else {
        g_path = vibe::SiblingPath(L"esp_menu.bin");
    }
    const auto separator = g_path.find_last_of(L"\\/");
    g_ui_path = (separator == std::wstring::npos ? L"" : g_path.substr(0, separator + 1)) + L"esp_ui.ini";
    g_custom_path=(separator==std::wstring::npos?L"":g_path.substr(0,separator+1))+L"esp_custom.bin";
    vibe_custom_default(&custom);LoadCustom();custom.flags=0;SaveCustom();g_custom_pending=!PushCustom();
    vibe_audio::Configure(custom.head_sound,custom.body_sound,custom.sound_volume);
    const UINT language = GetPrivateProfileIntW(L"Interface", L"Language", 1, g_ui_path.c_str());
    vibe_lang::selected = language <= 1 ? static_cast<int>(language) : 1;
    vibe::DefaultSettings(config);

    if (!vibe::LoadSettings(g_path, config)) {
        if (!vibe::SaveSettings(g_path, config)) {
            std::snprintf(g_status, sizeof(g_status), "cannot create esp_menu.bin");
            return false;
        }
    }

    // Preserve preferences, but each process starts with gameplay controls off.
    config.flags &= ~(1u|1792u);
    config.aim_flags &= ~1u;
    config.farm_flags &= ~1u;
    config.move_flags = 0;
    config.rapid_flags = 0;
    config.combat_flags = 0;
    config.visual_flags = 0;
    config.speed_percent = 100;
    vibe::SaveSettings(g_path, config);
    GetLastWrite(g_path, g_last_write);
    std::snprintf(g_status, sizeof(g_status), "settings connected");
    return true;
}

void MarkDirty() {
    g_dirty = true;
    g_save_after = GetTickCount64() + 75;
}

void ForceSave() {
    if (!g_dirty)
        return;

    if (vibe::SaveSettings(g_path, config) && SaveCustom()) {
        GetLastWrite(g_path, g_last_write);
        g_dirty = false;
        std::snprintf(g_status, sizeof(g_status), "saved");
    } else {
        std::snprintf(g_status, sizeof(g_status), "save failed");
    }
}

void Tick() {
    if(g_custom_pending)g_custom_pending=!PushCustom();
    const ULONGLONG now = GetTickCount64();
    if (g_dirty) {
        if (now >= g_save_after)
            ForceSave();
        return;
    }

    if (now < g_next_reload)
        return;
    g_next_reload = now + 250;

    FILETIME current{};
    if (!GetLastWrite(g_path, current))
        return;

    if (CompareFileTime(&current, &g_last_write) == 0)
        return;

    vibe::ESPSettings fresh{};
    if (vibe::LoadSettings(g_path, fresh)) {
        config = fresh;
        g_last_write = current;
        std::snprintf(g_status, sizeof(g_status), "reloaded");
    }
}

void Shutdown() {
    CancelMetadataDump();
    ForceSave();vibe_audio::Shutdown();
}


static BOOL CALLBACK NotifyWindowProc(HWND hwnd, LPARAM lParam) {
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid == static_cast<DWORD>(lParam))
        PostMessageA(hwnd, vibe::MENU_CLOSE_MESSAGE, vibe::MENU_CLOSE_COOKIE, 0);
    return TRUE;
}

void NotifyMenuClosed() {
#ifdef VIBE_INTERNAL_DLL_UI
    VibeUiSetMenuOpen(0);
#else
    if (g_game_pid)
        EnumWindows(NotifyWindowProc, static_cast<LPARAM>(g_game_pid));
#endif
}


const wchar_t* SettingsPath() {
    return g_path.c_str();
}

const char* StatusText() {
    return g_status;
}

bool SetLanguage(int language) {
    if (language < 0 || language > 1) return false;
    vibe_lang::selected = language;
    const bool saved = WritePrivateProfileStringW(L"Interface", L"Language", language ? L"1" : L"0", g_ui_path.c_str()) != FALSE;
    std::snprintf(g_status, sizeof(g_status), "%s", saved ? "Language saved" : "Language save failed");
    return saved;
}

void RequestCompatibilityCheck() {
#ifdef VIBE_INTERNAL_DLL_UI
    VibeUiRequestCompatibilityCheck();
    std::snprintf(g_status, sizeof(g_status), "Compatibility recheck requested");
#endif
}

const char* CompatibilityStatusText() {
    static char text[128]{};
#ifdef VIBE_INTERNAL_DLL_UI
    VibeUiReadCompatibilityStatus(text, sizeof(text));
#endif
    return text;
}

} // namespace vibe_runtime
