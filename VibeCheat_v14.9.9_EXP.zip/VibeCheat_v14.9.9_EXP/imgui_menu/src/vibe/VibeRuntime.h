#pragma once
#include "SettingsCompat.h"
#include "Language.h"
#include "Il2CppDump.h"
#include "../../../source/esp/custom_bridge.h"
#include <windows.h>

namespace vibe_runtime {

extern vibe::ESPSettings config;
extern VibeCustomSettings custom;
void MarkCustomDirty();
void PreviewHitSound(bool headshot);
const char* HitAudioStatusText();
DWORD HitAudioErrorCode();
void RefreshSkinCatalog();
bool ReadSkinCatalog(VibeSkinCatalog& out);
bool ReadCombatFeedback(VibeCombatFeedback& out);

bool Initialize(DWORD gamePid, HMODULE module = nullptr);
void Tick();
void MarkDirty();
void ForceSave();
void Shutdown();
void NotifyMenuClosed();
const wchar_t* SettingsPath();
const char* StatusText();
bool SetLanguage(int language);
void RequestCompatibilityCheck();
void StartMetadataDump();
void CancelMetadataDump();
vibe_dump::Status MetadataDumpStatus();

const char* CompatibilityStatusText();

}
