#include "EspRenderer.h"
#include "../ui/egui.hxx"
#include "../../../source/esp/render_bridge.h"
#include "../../../source/esp/world_marker_kind.h"
#include "../../../source/game_item_assets.h"
#include "Language.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>
#include <new>
#include <cstring>
extern "C" DWORD WINAPI VibeUiReadESP(VibeRenderSnapshot*,DWORD);
namespace vibe_esp {
extern "C" DWORD WINAPI VibeUiReadGameESP(VibeRenderSnapshot*,DWORD);
struct State {
 VibeRenderSnapshot snapshot{};
 ID3D11ShaderResourceView* icons[GAME_ICON_COUNT]{};
 struct Name {uint16_t source[64]{};int length=-1;char text[256]{};} names[256];
};
static State menu_state;
State* CreateState(){return new(std::nothrow) State{};}
static ImU32 color(uint32_t value){return IM_COL32(value&255,(value>>8)&255,(value>>16)&255,255);}
static void text(ImDrawList* draw,ImVec2 pos,ImU32 tint,const char* value){
    ImVec2 size=ImGui::CalcTextSize(value),display=ImGui::GetIO().DisplaySize;
    pos.x=std::clamp(pos.x-size.x/2,2.f,std::max(2.f,display.x-size.x-2));
    pos.y=std::clamp(pos.y,2.f,std::max(2.f,display.y-size.y-2));
    draw->AddText(ImVec2(pos.x+1,pos.y+1),IM_COL32(0,0,0,220),value);draw->AddText(pos,tint,value);
}
static ID3D11ShaderResourceView* icon(ID3D11Device* device,int index,State& state){
    auto& icons=state.icons;
    if(index<0||index>=GAME_ICON_COUNT)return nullptr;if(icons[index])return icons[index];
    uint32_t pixels[GAME_ICON_SIZE*GAME_ICON_SIZE];
    for(unsigned i=0;i<_countof(pixels);++i){DWORD p=game_icon_pixels[index*_countof(pixels)+i];pixels[i]=p?((p&255)<<16)|(p&0xff00)|((p>>16)&255)|0xff000000u:0;}
    D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=GAME_ICON_SIZE;desc.MipLevels=desc.ArraySize=1;desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.Usage=D3D11_USAGE_IMMUTABLE;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA data{pixels,GAME_ICON_SIZE*4,0};ID3D11Texture2D* texture=nullptr;
    if(SUCCEEDED(device->CreateTexture2D(&desc,&data,&texture))){device->CreateShaderResourceView(texture,nullptr,&icons[index]);texture->Release();}return icons[index];
}
static void chain(ImDrawList* draw,const VibeRenderPlayer& p,const int* nodes,unsigned count,float sx,float sy,ImU32 tint,float width){
    int previous=-1;for(unsigned i=0;i<count;++i){int node=nodes[i];if(!(p.joint_mask&(1u<<node)))continue;
        if(previous>=0)draw->AddLine(ImVec2(p.joints[previous].x*sx,p.joints[previous].y*sy),ImVec2(p.joints[node].x*sx,p.joints[node].y*sy),tint,width);previous=node;}
}
bool Draw(ID3D11Device* device,ImFont* font,State* state,bool game_frame){
    State& current=state?*state:menu_state;auto& snapshot=current.snapshot;
    DWORD read=game_frame?VibeUiReadGameESP(&snapshot,sizeof(snapshot)):VibeUiReadESP(&snapshot,sizeof(snapshot));
    if(!read){snapshot={};return false;}
    if(!snapshot.width||!snapshot.height||GetTickCount64()-snapshot.age_ms>100)return false;
    ImGui::PushFont(font?font:egui::efonts.inter.Text12?egui::efonts.inter.Text12:ImGui::GetFont());
    ImDrawList* draw=ImGui::GetBackgroundDrawList();ImVec2 display=ImGui::GetIO().DisplaySize;
    float sx=display.x/snapshot.width,sy=display.y/snapshot.height,width=static_cast<float>(snapshot.line_width);
    uint32_t flags=snapshot.flags;
    if(flags&1984u)for(unsigned i=0;i<std::min(snapshot.marker_count,128u);++i){const auto& marker=snapshot.markers[i];
        if(!(flags&world_marker_flag(marker.edge)))continue;
        float x=marker.x*sx,y=marker.y*sy;if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(marker.distance))continue;
        ImU32 tint=IM_COL32(255,181,67,255);char label[96];std::snprintf(label,sizeof(label),"%s · %.0f m",vibe_lang::T(world_marker_name(marker.edge)),marker.distance);
        draw->AddCircle(ImVec2(x,y),(marker.edge&1u)?6.f:4.f,tint,12,width);
        text(draw,ImVec2(x,y-16),tint,label);
    }
    if(flags&1)for(unsigned i=0;i<std::min(snapshot.count,256u);++i){const auto& p=snapshot.players[i];
        float x=p.x*sx,y=p.y*sy,w=p.w*sx,h=p.h*sy;ImVec2 center(x+w/2,y+h);
        if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(w)||!std::isfinite(h))continue;
        if(flags&2){draw->AddRect(ImVec2(x,y),ImVec2(x+w,y+h),color(snapshot.colors[0]),0,0,width);
            if(std::isfinite(p.hp)){float hp=std::clamp(p.hp,0.f,100.f);draw->AddLine(ImVec2(x-5,y+h),ImVec2(x-5,y+h-h*hp/100),color(snapshot.colors[4]),width);}}
        if(flags&8)draw->AddLine(ImVec2(display.x/2,display.y),center,color(snapshot.colors[2]),width);
        if(flags&32){int anchor=(p.joint_mask&4)?2:(p.joint_mask&2)?1:3;int torso[]={0,1,2,3,4},left[]={anchor,17,5,6,7},right[]={anchor,18,8,9,10},leg_l[]={4,11,12,13},leg_r[]={4,14,15,16};
            chain(draw,p,torso,5,sx,sy,color(snapshot.colors[3]),width);chain(draw,p,left,5,sx,sy,color(snapshot.colors[3]),width);chain(draw,p,right,5,sx,sy,color(snapshot.colors[3]),width);chain(draw,p,leg_l,4,sx,sy,color(snapshot.colors[3]),width);chain(draw,p,leg_r,4,sx,sy,color(snapshot.colors[3]),width);}
        if((flags&4)&&p.name_len>0){auto& name=current.names[i];int length=std::clamp(p.name_len,0,63);
            if(name.length!=length||std::memcmp(name.source,p.name,length*sizeof(uint16_t))){std::memcpy(name.source,p.name,length*sizeof(uint16_t));name.length=length;name.text[0]=0;int n=WideCharToMultiByte(CP_UTF8,0,reinterpret_cast<const wchar_t*>(p.name),length,name.text,sizeof(name.text)-1,nullptr,nullptr);if(n>=0)name.text[n]=0;}
            if(name.text[0])text(draw,ImVec2(x+w/2,y-ImGui::GetFontSize()-3),color(snapshot.colors[1]),name.text);}

        const int label_rows=((flags&2)&&std::isfinite(p.hp)?1:0)+((flags&16)&&std::isfinite(p.distance)?1:0);
        float label_y=std::clamp(y+h+3,2.f,std::max(2.f,display.y-label_rows*(ImGui::GetFontSize()+2)-2));char label[32];
        if((flags&2)&&std::isfinite(p.hp)){std::snprintf(label,sizeof(label),"%.0f HP",p.hp);text(draw,ImVec2(x+w/2,label_y),color(snapshot.colors[4]),label);label_y+=ImGui::GetFontSize()+2;}
        if((flags&16)&&std::isfinite(p.distance)){std::snprintf(label,sizeof(label),"%.0f m",p.distance);text(draw,ImVec2(x+w/2,label_y),color(snapshot.colors[5]),label);}
        if(auto image=icon(device,p.icon,current)){float ix=x+w+6;if(ix+GAME_ICON_SIZE>display.x)ix=x-GAME_ICON_SIZE-6;float iy=y+h/2-GAME_ICON_SIZE/2;draw->AddImage(reinterpret_cast<ImTextureID>(image),ImVec2(ix,iy),ImVec2(ix+GAME_ICON_SIZE,iy+GAME_ICON_SIZE));}
    }
    if(snapshot.circle&&snapshot.radius>0){ImVec2 center(display.x/2,display.y/2);unsigned segments=snapshot.profile==2?48u:96u;for(unsigned i=0;i<segments;++i){float angle=6.2831853f*i/segments;draw->PathLineTo(ImVec2(center.x+std::cos(angle)*snapshot.radius*sx,center.y+std::sin(angle)*snapshot.radius*sy));}draw->PathStroke(color(snapshot.colors[6]),ImDrawFlags_Closed,width);
        if(snapshot.target){float x=snapshot.target_x*sx,y=snapshot.target_y*sy;draw->AddLine(ImVec2(x-5,y),ImVec2(x+5,y),color(snapshot.colors[6]),width);draw->AddLine(ImVec2(x,y-5),ImVec2(x,y+5),color(snapshot.colors[6]),width);}}
    ImGui::PopFont();return true;
}
void Shutdown(State* state){State& current=state?*state:menu_state;for(auto& image:current.icons){if(image)image->Release();image=nullptr;}current.snapshot={};}
void DeleteState(State* state){if(state){Shutdown(state);delete state;}}
}
