#pragma once
#include <d3d11.h>
struct ImFont;
namespace vibe_esp {
struct State;
State* CreateState();
bool Draw(ID3D11Device* device,ImFont* font=nullptr,State* state=nullptr,bool game_frame=false);
void Shutdown(State* state=nullptr);
void DeleteState(State* state);
}
