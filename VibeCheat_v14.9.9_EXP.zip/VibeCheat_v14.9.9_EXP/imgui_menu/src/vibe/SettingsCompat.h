#pragma once
#include <windows.h>
#include <cstdint>
#include <string>

namespace vibe {

constexpr DWORD SETTINGS_MAGIC = 0x48505345u;
constexpr DWORD SETTINGS_V14_8_MAGIC = 0x47505345u;
constexpr DWORD SETTINGS_V14_7_MAGIC = 0x46505345u;
constexpr DWORD SETTINGS_V14_4_MAGIC = 0x45505345u;
constexpr DWORD SETTINGS_V14_MAGIC = 0x44505345u;
constexpr DWORD SETTINGS_V12_MAGIC = 0x43505345u;
constexpr DWORD SETTINGS_V10_MAGIC = 0x41505345u;
constexpr DWORD SETTINGS_V9_MAGIC = 0x39505345u;
constexpr DWORD SETTINGS_LEGACY_MAGIC = 0x33505345u;

constexpr const char* MENU_WINDOW_CLASS = "VibeRemakeMenu12";
constexpr UINT MENU_CLOSE_MESSAGE = 0x8353u;
constexpr WPARAM MENU_CLOSE_COOKIE = 0x45535034u;
constexpr UINT SESSION_QUIT_MESSAGE = 0x8354u;
constexpr WPARAM SESSION_COOKIE = 0x56494231u;
constexpr const char* SESSION_PID_PROPERTY = "Vibe.GamePID.12";

constexpr DWORD RANGE_LIMIT_M = 1500u;
constexpr DWORD RANGE_DEFAULT_M = 500u;
constexpr DWORD FARM_SEARCH_LIMIT_M = 1000u;
constexpr DWORD PROFILE_AUTO = 0u;
constexpr DWORD PROFILE_SMOOTH = 1u;
constexpr DWORD PROFILE_ECO = 2u;
constexpr DWORD AIM_FOV_LIMIT = 600u;
constexpr DWORD AIM_FOV_DEFAULT = 160u;
constexpr DWORD AIM_BIND_DEFAULT = 2u;
constexpr DWORD AIM_POINT_HEAD = 0u;
constexpr DWORD AIM_POINT_BODY = 1u;
constexpr DWORD AIM_POINT_LEGS = 2u;
constexpr DWORD AIM_MODE_CAMERA = 0u;
constexpr DWORD AIM_MODE_SILENT = 1u;
constexpr DWORD AIM_MODE_AIMKILL = 2u;
constexpr DWORD SETTINGS_REMOVED_AIM_MODE = 3u;
constexpr DWORD FARM_MODE_AUTO = 0u;
constexpr DWORD VISUAL_TIME = 1u;
constexpr DWORD VISUAL_SKY_COLOR = 2u;
constexpr DWORD VISUAL_HANDS = 4u;
constexpr DWORD VISUAL_FOG = 8u;
constexpr DWORD HANDS_DISTANCE_LIMIT_CM = 100u;
constexpr DWORD ESP_COLOR_BOX = 0u;
constexpr DWORD ESP_COLOR_NAME = 1u;
constexpr DWORD ESP_COLOR_LINE = 2u;
constexpr DWORD ESP_COLOR_SKELETON = 3u;
constexpr DWORD ESP_COLOR_HP = 4u;
constexpr DWORD ESP_COLOR_DISTANCE = 5u;
constexpr DWORD ESP_COLOR_FOV = 6u;
constexpr DWORD ESP_COLOR_COUNT = 7u;

#pragma pack(push, 4)
struct ESPSettings {
    DWORD magic, flags, min_m, max_m, profile;
    DWORD aim_flags, aim_fov, aim_key, aim_point, aim_sharpness, aim_mode;
    DWORD farm_flags, farm_mode, farm_range_cm, farm_interval_ms;
    DWORD move_flags, speed_percent, farm_search_m, farm_reserve_percent;
    DWORD speed_key, noclip_key;
    DWORD rapid_flags, rapid_percent;
    DWORD visual_flags, sky_minutes, sky_color, hands_distance_cm;
    DWORD esp_colors[ESP_COLOR_COUNT];
    DWORD esp_width, fog_color, medkit_threshold, medkit_slots,medkit_delay_ms,magic_cooldown_ms,combat_flags,fastkill_damage,balloon_max_m, check;
};
#pragma pack(pop)

static_assert(sizeof(ESPSettings) == 176, "ESPSettings layout changed");

bool SettingsKeyValid(DWORD key);
DWORD SettingsChecksum(const ESPSettings& s);
void ResetColors(ESPSettings& s);
void DefaultSettings(ESPSettings& s);
void NormalizeSettings(ESPSettings& s);
bool DecodeSettings(ESPSettings& out, const void* data, DWORD count);
bool LoadSettings(const std::wstring& path, ESPSettings& out);
bool SaveSettings(const std::wstring& path, ESPSettings& s);
std::wstring SiblingPath(const std::wstring& fileName);
std::wstring ExeDirectory();

} // namespace vibe
