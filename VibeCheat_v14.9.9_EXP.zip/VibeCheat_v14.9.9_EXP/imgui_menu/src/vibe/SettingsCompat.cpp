#include "SettingsCompat.h"
#include <vector>
#include <cstring>

namespace vibe {

bool SettingsKeyValid(DWORD key) {
    return key > 0 && key < 255 && key != 27 && key != VK_END && key != VK_INSERT &&
           key != VK_MENU && key != VK_LMENU && key != VK_RMENU;
}

static DWORD OldChecksum(const ESPSettings& s) {
    return 0x56494245u ^ s.magic ^ s.flags ^ (s.min_m * 31u) ^ (s.max_m * 131u) ^
           (s.profile * 17u) ^ (s.aim_flags * 193u) ^ (s.aim_fov * 251u) ^
           (s.aim_key * 397u) ^ (s.aim_point * 503u) ^ (s.aim_sharpness * 719u) ^
           (s.aim_mode * 823u) ^ (s.farm_flags * 947u) ^ (s.farm_mode * 1031u) ^
           (s.farm_range_cm * 1151u) ^ (s.farm_interval_ms * 1223u) ^
           (s.move_flags * 1381u) ^ (s.speed_percent * 1459u) ^
           (s.farm_search_m * 1543u) ^ (s.farm_reserve_percent * 1657u);
}

static DWORD V144Checksum(const ESPSettings& s) {
    return OldChecksum(s) ^ (s.speed_key * 1783u) ^ (s.noclip_key * 1861u) ^
           (s.rapid_flags * 1973u) ^ (s.rapid_percent * 2081u);
}

static DWORD V148Checksum(const ESPSettings& s) {
    DWORD check = V144Checksum(s) ^ (s.visual_flags * 2203u) ^
                  (s.sky_minutes * 2333u) ^ (s.sky_color * 2441u) ^
                  (s.hands_distance_cm * 2557u) ^ (s.esp_width * 2683u) ^ (s.fog_color * 3691u) ^ (s.medkit_threshold * 3821u);
    for (unsigned i = 0; i < ESP_COLOR_COUNT; ++i)
        check ^= s.esp_colors[i] * (2801u + i * 122u);
    return check;
}

DWORD SettingsChecksum(const ESPSettings& s) { return V148Checksum(s)^(s.medkit_slots*3943u)^(s.medkit_delay_ms*4051u)^(s.magic_cooldown_ms*4177u)^(s.combat_flags*4297u)^(s.fastkill_damage*4409u)^(s.balloon_max_m*4507u); }

static DWORD DefaultColor(unsigned i) {
    static const DWORD colors[ESP_COLOR_COUNT] = {
        RGB(0,255,120), RGB(248,248,252), RGB(0,255,120), RGB(0,255,120),
        RGB(0,255,120), RGB(248,248,252), RGB(225,225,232)
    };
    return i < ESP_COLOR_COUNT ? colors[i] : 0;
}

void ResetColors(ESPSettings& s) {
    for (unsigned i = 0; i < ESP_COLOR_COUNT; ++i) s.esp_colors[i] = DefaultColor(i);
    s.esp_width = 2;
}

void NormalizeSettings(ESPSettings& s) {
    s.farm_mode = FARM_MODE_AUTO;
    s.farm_flags &= 223u; /* clear removed magic-farm bit 32 */
    s.combat_flags &= 13u; /* removed Fast kill */
    if (s.aim_mode == SETTINGS_REMOVED_AIM_MODE) {s.aim_mode = AIM_MODE_SILENT;s.aim_flags |= 4u;}
}

void DefaultSettings(ESPSettings& s) {
    std::memset(&s, 0, sizeof(s));
    s.magic = SETTINGS_MAGIC;
    s.flags = 31;
    s.max_m = RANGE_DEFAULT_M;
    s.profile = PROFILE_AUTO;
    s.aim_flags = 2;
    s.aim_fov = AIM_FOV_DEFAULT;
    s.aim_key = AIM_BIND_DEFAULT;
    s.aim_point = AIM_POINT_HEAD;
    s.aim_sharpness = 35;
    s.aim_mode = AIM_MODE_CAMERA;
    s.farm_flags = 30;
    s.farm_mode = FARM_MODE_AUTO;
    s.farm_range_cm = 300;
    s.farm_interval_ms = 500;
    s.speed_percent = 150;
    s.farm_search_m = 60;
    s.farm_reserve_percent = 15;
    s.rapid_percent = 200;
    s.sky_minutes = 720;
    s.sky_color = RGB(83,130,190);
    s.hands_distance_cm = 20;
    s.fog_color = RGB(160,170,180);
    s.medkit_threshold = 60;
    s.medkit_slots=255;s.medkit_delay_ms=1500;s.magic_cooldown_ms=500;s.fastkill_damage=250;s.balloon_max_m=RANGE_DEFAULT_M;
    ResetColors(s);
    s.check = SettingsChecksum(s);
}

static bool ValidateCurrent(const ESPSettings& s) {
    if (s.medkit_slots>255 || s.medkit_delay_ms<100 || s.medkit_delay_ms>10000 || s.magic_cooldown_ms<150 || s.magic_cooldown_ms>5000 || s.combat_flags>15 || s.fastkill_damage<1 || s.fastkill_damage>500 || s.visual_flags > 15 || s.fog_color > 0xffffffu || s.medkit_threshold < 1 || s.medkit_threshold > 99 || s.sky_minutes > 1440 || s.sky_color > 0xffffffu ||
        s.hands_distance_cm > HANDS_DISTANCE_LIMIT_CM || s.esp_width < 1 || s.esp_width > 4)
        return false;
    for (unsigned i = 0; i < ESP_COLOR_COUNT; ++i)
        if (s.esp_colors[i] > 0xffffffu) return false;

    return s.magic == SETTINGS_MAGIC && s.flags <= 2047 && s.min_m == 0 &&
           s.max_m <= RANGE_LIMIT_M && s.profile <= PROFILE_ECO && s.aim_flags <= 7 &&
           s.aim_fov <= AIM_FOV_LIMIT && SettingsKeyValid(s.aim_key) &&
           s.aim_point <= AIM_POINT_LEGS && s.aim_sharpness >= 1 && s.aim_sharpness <= 100 &&
           s.aim_mode <= SETTINGS_REMOVED_AIM_MODE && s.farm_flags <= 255 &&
           s.farm_mode == FARM_MODE_AUTO && s.farm_range_cm >= 50 && s.farm_range_cm <= 800 &&
           s.farm_interval_ms >= 20 && s.farm_interval_ms <= 2000 && s.move_flags <= 7 &&
           s.speed_percent >= 100 && s.speed_percent <= 300 && s.farm_search_m >= 5 &&
           s.farm_search_m <= FARM_SEARCH_LIMIT_M && s.farm_reserve_percent >= 5 && s.farm_reserve_percent <= 50 &&
           (!s.speed_key || SettingsKeyValid(s.speed_key)) && (!s.noclip_key || SettingsKeyValid(s.noclip_key)) &&
           (!s.speed_key || (s.speed_key != s.noclip_key && s.speed_key != s.aim_key)) &&
           (!s.noclip_key || s.noclip_key != s.aim_key) && s.rapid_flags <= 63 &&
           s.rapid_percent >= 100 && s.rapid_percent <= 300 &&
           s.balloon_max_m <= 2500u && s.check == SettingsChecksum(s);
}

bool DecodeSettings(ESPSettings& out, const void* data, DWORD count) {
    if (!data) return false;

    if (count == 8) {
        const DWORD* old = static_cast<const DWORD*>(data);
        if (old[0] != SETTINGS_LEGACY_MAGIC) return false;
        DefaultSettings(out);
        out.flags = old[1] & 63u;
        out.check = SettingsChecksum(out);
        return true;
    }

    if (count == 24) {
        const DWORD* old = static_cast<const DWORD*>(data);
        DWORD check = 0x56494245u ^ old[0] ^ old[1] ^ (old[2] * 31u) ^
                      (old[3] * 131u) ^ (old[4] * 17u);
        if (old[0] != SETTINGS_V9_MAGIC || old[1] > 63 || old[2] > old[3] ||
            old[3] > RANGE_LIMIT_M || old[4] > PROFILE_ECO || old[5] != check)
            return false;
        DefaultSettings(out);
        out.flags = old[1]; out.min_m = 0; out.max_m = old[3]; out.profile = old[4];
        out.check = SettingsChecksum(out);
        return true;
    }

    if (count == 44) {
        const DWORD* old = static_cast<const DWORD*>(data);
        DWORD check = 0x56494245u ^ old[0] ^ old[1] ^ (old[2] * 31u) ^
                      (old[3] * 131u) ^ (old[4] * 17u) ^ (old[5] * 193u) ^
                      (old[6] * 251u) ^ (old[7] * 397u) ^ (old[8] * 503u) ^
                      (old[9] * 719u);
        if (old[0] != SETTINGS_V10_MAGIC || old[1] > 63 || old[2] > old[3] ||
            old[3] > RANGE_LIMIT_M || old[4] > PROFILE_ECO || old[5] > 3 ||
            old[6] > AIM_FOV_LIMIT || !SettingsKeyValid(old[7]) ||
            old[8] > AIM_POINT_LEGS || old[9] < 1 || old[9] > 100 || old[10] != check)
            return false;
        DefaultSettings(out);
        out.flags = old[1]; out.min_m = 0; out.max_m = old[3]; out.profile = old[4];
        out.aim_flags = old[5]; out.aim_fov = old[6]; out.aim_key = old[7];
        out.aim_point = old[8]; out.aim_sharpness = old[9]; out.check = SettingsChecksum(out);
        return true;
    }

    if (count == 72 || count == 80 || count == 96) {
        const DWORD* old = static_cast<const DWORD*>(data);
        ESPSettings migrated{}; DefaultSettings(migrated);
        DWORD* dest = reinterpret_cast<DWORD*>(&migrated);
        int words = count == 72 ? 17 : count == 80 ? 19 : 23;
        for (int i = 0; i < words; ++i) dest[i] = old[i];

        DWORD oldCheck = OldChecksum(migrated);
        if (count == 72) {
            oldCheck ^= (migrated.farm_search_m * 1543u) ^ (migrated.farm_reserve_percent * 1657u);
            if (old[0] != SETTINGS_V12_MAGIC || old[17] != oldCheck || old[11] > 7 || old[15] > 3)
                return false;
            migrated.farm_flags = (migrated.farm_flags & 6u) | 24u;
        } else if (count == 80) {
            if (old[0] != SETTINGS_V14_MAGIC || old[19] != oldCheck || old[11] > 255 || old[12] > 1)
                return false;
        } else {
            if (old[0] != SETTINGS_V14_4_MAGIC || old[23] != V144Checksum(migrated)) return false;
        }
        migrated.magic = SETTINGS_MAGIC;
        migrated.min_m = 0;
        NormalizeSettings(migrated);
        migrated.check = SettingsChecksum(migrated);
        out = migrated;
        return ValidateCurrent(out);
    }

    if (count == 144) {
        const DWORD* old = static_cast<const DWORD*>(data);
        ESPSettings migrated; DefaultSettings(migrated);
        std::memcpy(&migrated, data, 140);
        DWORD legacy = V148Checksum(migrated) ^ (migrated.fog_color * 3691u) ^ (migrated.medkit_threshold * 3821u);
        if (old[0] != SETTINGS_V14_7_MAGIC || old[35] != legacy || migrated.visual_flags > 7 || migrated.rapid_flags > 1) return false;
        migrated.magic = SETTINGS_MAGIC; migrated.check = SettingsChecksum(migrated);
        out = migrated; return ValidateCurrent(out);
    }
    if(count==152) { const DWORD* old=static_cast<const DWORD*>(data); ESPSettings migrated;DefaultSettings(migrated);std::memcpy(&migrated,data,148);if(old[0]!=SETTINGS_V14_8_MAGIC || old[37]!=V148Checksum(migrated))return false;migrated.magic=SETTINGS_MAGIC;migrated.check=SettingsChecksum(migrated);return DecodeSettings(out,&migrated,sizeof(migrated)); }

    if(count==172){const DWORD* old=static_cast<const DWORD*>(data);ESPSettings migrated;DefaultSettings(migrated);std::memcpy(&migrated,data,168);if(old[0]!=SETTINGS_MAGIC||old[42]!=(SettingsChecksum(migrated)^(migrated.balloon_max_m*4507u)))return false;migrated.check=SettingsChecksum(migrated);return DecodeSettings(out,&migrated,sizeof(migrated));}
    if (count != sizeof(ESPSettings)) return false;
    ESPSettings temp = *static_cast<const ESPSettings*>(data);
    if (!ValidateCurrent(temp)) return false;
    NormalizeSettings(temp);
    temp.check = SettingsChecksum(temp);
    out = temp;
    return true;
}

bool LoadSettings(const std::wstring& path, ESPSettings& out) {
    HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    std::vector<std::uint8_t> data(sizeof(ESPSettings));
    DWORD got = 0;
    BOOL ok = ReadFile(f, data.data(), static_cast<DWORD>(data.size()), &got, nullptr);
    CloseHandle(f);
    return ok && DecodeSettings(out, data.data(), got);
}

bool SaveSettings(const std::wstring& path, ESPSettings& s) {
    std::wstring tmp = path + L".tmp";
    s.magic = SETTINGS_MAGIC;
    NormalizeSettings(s);
    s.check = SettingsChecksum(s);

    HANDLE f = CreateFileW(tmp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    DWORD wrote = 0;
    BOOL ok = WriteFile(f, &s, sizeof(s), &wrote, nullptr);
    CloseHandle(f);
    if (!ok || wrote != sizeof(s)) {
        DeleteFileW(tmp.c_str());
        return false;
    }
    if (!MoveFileExW(tmp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        DeleteFileW(tmp.c_str());
        return false;
    }
    return true;
}

std::wstring ExeDirectory() {
    wchar_t path[MAX_PATH * 4]{};
    DWORD n = GetModuleFileNameW(nullptr, path, static_cast<DWORD>(_countof(path)));
    std::wstring result(path, path + n);
    const auto pos = result.find_last_of(L"\\/");
    if (pos != std::wstring::npos) result.resize(pos + 1);
    else result.clear();
    return result;
}

std::wstring SiblingPath(const std::wstring& fileName) {
    return ExeDirectory() + fileName;
}

} // namespace vibe
