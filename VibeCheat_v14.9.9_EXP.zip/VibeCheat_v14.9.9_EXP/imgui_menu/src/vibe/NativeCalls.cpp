#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cwchar>
#include <dbghelp.h>
#pragma comment(lib,"dbghelp.lib")

static wchar_t dumpDirectory[1024],dumpPath[1200];
static char faultModule[1024];
static uintptr_t faultRva;
static volatile LONG dumpStarted,dumpStatus;
static EXCEPTION_RECORD savedRecord;
static CONTEXT savedContext;
static EXCEPTION_POINTERS savedPointers;
static DWORD faultThread;
#include "AutoFireInput.h"
extern "C" void WINAPI VibeInitializeCrashCapture(HMODULE module){
    wchar_t path[1024]{};
    DWORD length=GetModuleFileNameW(module,path,1024);
    if(!length||length>=1024)return;
    wchar_t* slash=wcsrchr(path,L'\\');if(!slash)return;*slash=0;
    if(swprintf_s(dumpDirectory,L"%s\\crash_reports",path)<0)dumpDirectory[0]=0;
    if(dumpDirectory[0]&&!CreateDirectoryW(dumpDirectory,nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS)dumpDirectory[0]=0;
}
extern "C" const wchar_t* WINAPI VibeCrashDumpPath(){return dumpPath;}
extern "C" DWORD WINAPI VibeCrashDumpStatus(){return static_cast<DWORD>(InterlockedCompareExchange(&dumpStatus,0,0));}
extern "C" const char* WINAPI VibeNativeFaultModule(){return faultModule;}
extern "C" uintptr_t WINAPI VibeNativeFaultRva(){return faultRva;}
static DWORD WINAPI WriteNativeDump(void*){
    HANDLE file=CreateFileW(dumpPath,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE){InterlockedExchange(&dumpStatus,2);return 0;}
    MINIDUMP_EXCEPTION_INFORMATION info{faultThread,&savedPointers,FALSE};
    auto flags=static_cast<MINIDUMP_TYPE>(MiniDumpWithIndirectlyReferencedMemory|MiniDumpWithUnloadedModules|MiniDumpWithThreadInfo);
    BOOL ok=MiniDumpWriteDump(GetCurrentProcess(),GetCurrentProcessId(),file,flags,&info,nullptr,nullptr);
    CloseHandle(file);InterlockedExchange(&dumpStatus,ok?1:2);return 0;
}
static void CaptureNativeDump(EXCEPTION_POINTERS* exception){
    HMODULE module=nullptr;
    if(GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
        reinterpret_cast<LPCWSTR>(exception->ExceptionRecord->ExceptionAddress),&module)){
        GetModuleFileNameA(module,faultModule,sizeof(faultModule));
        faultRva=reinterpret_cast<uintptr_t>(exception->ExceptionRecord->ExceptionAddress)-reinterpret_cast<uintptr_t>(module);
    }
    if(!dumpDirectory[0]||InterlockedCompareExchange(&dumpStarted,1,0)!=0)return;
    savedRecord=*exception->ExceptionRecord;savedRecord.ExceptionRecord=nullptr;
    savedContext=*exception->ContextRecord;savedPointers={&savedRecord,&savedContext};faultThread=GetCurrentThreadId();
    swprintf_s(dumpPath,L"%s\\native-fault-%lu-%llu.dmp",dumpDirectory,GetCurrentProcessId(),GetTickCount64());
    HANDLE thread=CreateThread(nullptr,0,WriteNativeDump,nullptr,0,nullptr);
    if(!thread){InterlockedExchange(&dumpStatus,2);return;}
    if(WaitForSingleObject(thread,10000)!=WAIT_OBJECT_0)InterlockedCompareExchange(&dumpStatus,3,0);
    CloseHandle(thread);
}

using ManagedInvoke = void* (WINAPI *)(const void*, void*, void**, void**);
static int CaptureAccessViolation(EXCEPTION_POINTERS* exception, DWORD* code, uintptr_t* address) {
    if (exception->ExceptionRecord->ExceptionCode != EXCEPTION_ACCESS_VIOLATION)
        return EXCEPTION_CONTINUE_SEARCH;
    *code = exception->ExceptionRecord->ExceptionCode;
    *address = reinterpret_cast<uintptr_t>(exception->ExceptionRecord->ExceptionAddress);
    CaptureNativeDump(exception);
    return EXCEPTION_EXECUTE_HANDLER;
}

extern "C" DWORD WINAPI VibeInvokeManaged(void* entry, const void* method, void* object,
    void** arguments, void** managedException, void** result, DWORD* code, uintptr_t* address) {
    *result = nullptr;
    *managedException = nullptr;
    *code = 0;
    *address = 0;
    __try {
        *result = reinterpret_cast<ManagedInvoke>(entry)(method, object, arguments, managedException);
        return 1;
    } __except (CaptureAccessViolation(GetExceptionInformation(), code, address)) {
        return 0;
    }
}

// Reviewed update constructors/readers take an unboxed 12-byte value pointer.
// Keep their direct Win64 ABI in a guarded native boundary.
extern "C" DWORD WINAPI VibeInvokeMovementValue(DWORD operation, void* entry,
    void* storage, void* input, const void* method, DWORD* code, uintptr_t* address) {
    *code=0;*address=0;
    if(!entry||!storage||!input||operation>2)return 0;
    __try {
        if(operation==0)reinterpret_cast<void (WINAPI *)(void*,float,const void*)>(entry)(storage,*static_cast<float*>(input),method);
        else if(operation==1)reinterpret_cast<void (WINAPI *)(void*,unsigned char,const void*)>(entry)(storage,*static_cast<unsigned char*>(input),method);
        else *static_cast<unsigned char*>(input)=reinterpret_cast<unsigned char (WINAPI *)(void*,const void*)>(entry)(storage,method);
        return 1;
    } __except (CaptureAccessViolation(GetExceptionInformation(),code,address)) {
        return 0;
    }
}
