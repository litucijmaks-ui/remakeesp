#pragma once
static SRWLOCK autoFireLock=SRWLOCK_INIT;
static bool autoFireMouseOwned;
static ULONGLONG autoFireReleaseAt;
struct AutoFireLockGuard{
    AutoFireLockGuard(){AcquireSRWLockExclusive(&autoFireLock);}
    ~AutoFireLockGuard(){ReleaseSRWLockExclusive(&autoFireLock);}
};
extern "C" DWORD WINAPI VibeAutoFireInput(){
    AutoFireLockGuard guard;DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    if(pid!=GetCurrentProcessId()||autoFireMouseOwned||GetAsyncKeyState(VK_LBUTTON)<0)return 0;
    INPUT input{};input.type=INPUT_MOUSE;input.mi.dwFlags=MOUSEEVENTF_LEFTDOWN;
    if(SendInput(1,&input,sizeof(input))!=1)return 0;
    autoFireMouseOwned=true;autoFireReleaseAt=GetTickCount64()+45;return 1;
}
extern "C" void WINAPI VibeAutoFirePoll(DWORD active){
    AutoFireLockGuard guard;if(!autoFireMouseOwned)return;
    DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    if(active&&pid==GetCurrentProcessId()&&GetTickCount64()<autoFireReleaseAt)return;
    INPUT input{};input.type=INPUT_MOUSE;input.mi.dwFlags=MOUSEEVENTF_LEFTUP;
    if(SendInput(1,&input,sizeof(input))==1)autoFireMouseOwned=false;
}
