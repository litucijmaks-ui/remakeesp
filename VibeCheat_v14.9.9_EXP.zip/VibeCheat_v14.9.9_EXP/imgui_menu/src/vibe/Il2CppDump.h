#pragma once
#include <cstdint>
namespace vibe_dump {
enum State : unsigned { Idle, Running, Complete, Failed, Cancelled };
struct Status {
 State state=Idle;
 uint64_t images=0,classes=0,fields=0,methods=0,properties=0,totalClasses=0;
 char message[256]{},directory[2048]{};
};
bool Start();
void Cancel();
Status Read();
}
