#include <windows.h>
#include "../../vendor/minhook/include/MinHook.h"
extern "C" DWORD WINAPI VibeCreateNativeHook(void* target,void* proxy,void** original) {
    MH_STATUS state=MH_Initialize();
    if(state!=MH_OK&&state!=MH_ERROR_ALREADY_INITIALIZED)return static_cast<DWORD>(state);
    state=MH_CreateHook(target,proxy,original);
    if(state!=MH_OK)return static_cast<DWORD>(state);
    state=MH_EnableHook(target);
    if(state!=MH_OK){MH_RemoveHook(target);return static_cast<DWORD>(state);}
    return 0;
}
