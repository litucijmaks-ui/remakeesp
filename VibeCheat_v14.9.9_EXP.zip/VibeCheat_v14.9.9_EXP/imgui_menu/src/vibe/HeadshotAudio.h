#pragma once
#include <cstdint>
namespace vibe_audio {
void Play(std::uint32_t sound, std::uint32_t volume, bool headshot = false, bool preview = false);
void Configure(std::uint32_t head, std::uint32_t body, std::uint32_t volume);
void Stop();
void Shutdown();
const char* Status();
std::uint32_t ErrorCode();
}
