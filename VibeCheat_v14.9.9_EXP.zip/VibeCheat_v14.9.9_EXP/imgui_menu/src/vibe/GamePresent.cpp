#include "GamePresent.h"
#include "EspRenderer.h"
#include "imgui.h"
#include "imgui_impl_dx11.h"
#include <dxgi1_2.h>
#include <atomic>
#include <algorithm>
thread_local ImGuiContext* VibeImGuiTLS = nullptr;
extern unsigned char inter_medium[343200];
extern "C" DWORD WINAPI VibeCreateNativeHook(void*,void*,void**);
extern "C" DWORD WINAPI VibeUiMatchesGameWindow(HWND);
extern "C" DWORD WINAPI VibeUiEnableRenderMarkers(DWORD);
extern "C" void WINAPI VibeUiReportGameRenderer(DWORD);
namespace vibe_present {
using PresentFunction=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT);
using Present1Function=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain1*,UINT,UINT,const DXGI_PRESENT_PARAMETERS*);
static PresentFunction original_present;
static Present1Function original_present1;
static IDXGISwapChain* excluded_chain;
static std::atomic<bool> enabled{false},cleanup_requested{false};
static std::atomic<ULONGLONG> last_draw{0};
static std::atomic_flag busy=ATOMIC_FLAG_INIT;
struct GameState {
 IDXGISwapChain* chain=nullptr; // weak; never keep a swap chain or back buffer alive
 ID3D11Device* device=nullptr;
 ID3D11DeviceContext* device_context=nullptr;
 ImGuiContext* context=nullptr;
 ImFont* font=nullptr;
 vibe_esp::State* esp=nullptr;
 bool backend=false,markers=false;
 ULONGLONG previous=0,next_marker_check=0;
};
static GameState game;
static void release_game(){
 ImGuiContext* previous=ImGui::GetCurrentContext();
 if(game.context){ImGui::SetCurrentContext(game.context);if(game.backend)ImGui_ImplDX11_Shutdown();vibe_esp::DeleteState(game.esp);ImGui::DestroyContext(game.context);}
 if(game.device_context)game.device_context->Release();if(game.device)game.device->Release();
 game={};ImGui::SetCurrentContext(previous);
}
static bool initialize(IDXGISwapChain* chain){
 if(game.chain==chain&&game.device&&game.context)return true;
 release_game();ID3D11Device* device=nullptr;
 if(FAILED(chain->GetDevice(IID_PPV_ARGS(&device))))return false;
 game.chain=chain;game.device=device;device->GetImmediateContext(&game.device_context);
 if(!game.device_context){release_game();return false;}
 ImGuiContext* previous=ImGui::GetCurrentContext();game.context=ImGui::CreateContext();ImGui::SetCurrentContext(game.context);
 ImGuiIO& io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;io.DisplaySize=ImVec2(1,1);
 ImFontConfig config;config.FontDataOwnedByAtlas=false;config.OversampleH=config.OversampleV=1;
 game.font=io.Fonts->AddFontFromMemoryTTF(inter_medium,sizeof(inter_medium),12.f,&config,io.Fonts->GetGlyphRangesCyrillic());
 game.esp=vibe_esp::CreateState();game.backend=ImGui_ImplDX11_Init(game.device,game.device_context);
 ImGui::SetCurrentContext(previous);
 if(!game.font||!game.esp||!game.backend){release_game();return false;}
 return true;
}
static void render(IDXGISwapChain* chain,UINT flags){
 if(chain==excluded_chain||(flags&DXGI_PRESENT_TEST))return;
 if(!enabled.load(std::memory_order_acquire)){
  if(cleanup_requested.load(std::memory_order_acquire)&&!busy.test_and_set(std::memory_order_acquire)){if(cleanup_requested.exchange(false,std::memory_order_acq_rel))release_game();busy.clear(std::memory_order_release);}return;
 }
 if(busy.test_and_set(std::memory_order_acquire))return;
 struct Unlock{~Unlock(){busy.clear(std::memory_order_release);}} unlock;
 if(!enabled.load(std::memory_order_acquire)){release_game();return;}
 DXGI_SWAP_CHAIN_DESC desc{};
 if(FAILED(chain->GetDesc(&desc))||!VibeUiMatchesGameWindow(desc.OutputWindow)||!initialize(chain))return;
 ULONGLONG now=GetTickCount64();
 if(now>=game.next_marker_check){game.next_marker_check=now+1000;game.markers=VibeUiEnableRenderMarkers(1)!=0;}
 ID3D11Texture2D* buffer=nullptr;ID3D11RenderTargetView* target=nullptr;
 if(FAILED(chain->GetBuffer(0,IID_PPV_ARGS(&buffer))))return;
 D3D11_TEXTURE2D_DESC texture_desc{};buffer->GetDesc(&texture_desc);
 HRESULT created=game.device->CreateRenderTargetView(buffer,nullptr,&target);buffer->Release();
 if(FAILED(created)||!target||!texture_desc.Width||!texture_desc.Height){if(target)target->Release();return;}
 ImGuiContext* previous=ImGui::GetCurrentContext();ImGui::SetCurrentContext(game.context);
 ImGuiIO& io=ImGui::GetIO();io.DisplaySize=ImVec2(static_cast<float>(texture_desc.Width),static_cast<float>(texture_desc.Height));io.DisplayFramebufferScale=ImVec2(1,1);
 io.DeltaTime=game.previous?std::clamp(static_cast<float>(now-game.previous)*.001f,.001f,.1f):1.f/60.f;game.previous=now;
 ImGui_ImplDX11_NewFrame();ImGui::NewFrame();bool drawn=vibe_esp::Draw(game.device,game.font,game.esp,game.markers);ImGui::Render();
 if(drawn){
  ID3D11RenderTargetView* previous_targets[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT]{};ID3D11DepthStencilView* previous_depth=nullptr;
  game.device_context->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT,previous_targets,&previous_depth);
  game.device_context->OMSetRenderTargets(1,&target,nullptr);
  ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
  game.device_context->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT,previous_targets,previous_depth);
  for(auto view:previous_targets)if(view)view->Release();if(previous_depth)previous_depth->Release();
  last_draw.store(now,std::memory_order_release);VibeUiReportGameRenderer(game.markers?3u:1u);
 }
 ImGui::SetCurrentContext(previous);target->Release(); // no retained buffer references: ResizeBuffers remains available
}
static HRESULT STDMETHODCALLTYPE present_proxy(IDXGISwapChain* chain,UINT interval,UINT flags){render(chain,flags);return original_present(chain,interval,flags);}
static HRESULT STDMETHODCALLTYPE present1_proxy(IDXGISwapChain1* chain,UINT interval,UINT flags,const DXGI_PRESENT_PARAMETERS* params){render(chain,flags);return original_present1(chain,interval,flags,params);}
void Install(IDXGISwapChain* chain){
 if(!chain||original_present)return;excluded_chain=chain;
 void** table=*reinterpret_cast<void***>(chain);
 DWORD error=VibeCreateNativeHook(table[8],reinterpret_cast<void*>(present_proxy),reinterpret_cast<void**>(&original_present));
 if(error){original_present=nullptr;VibeUiReportGameRenderer(8);return;}
 enabled.store(true,std::memory_order_release);
 IDXGISwapChain1* newer=nullptr;
 if(SUCCEEDED(chain->QueryInterface(IID_PPV_ARGS(&newer)))){
  void** next=*reinterpret_cast<void***>(newer);
  if(next[22]!=table[8]&&VibeCreateNativeHook(next[22],reinterpret_cast<void*>(present1_proxy),reinterpret_cast<void**>(&original_present1)))original_present1=nullptr;
  newer->Release();
 }
}
bool Active(){ULONGLONG stamp=last_draw.load(std::memory_order_acquire);return enabled.load(std::memory_order_acquire)&&stamp&&GetTickCount64()-stamp<150;}
void Stop(){
 enabled.store(false,std::memory_order_release);last_draw.store(0,std::memory_order_release);VibeUiEnableRenderMarkers(0);
 cleanup_requested.store(true,std::memory_order_release); // COM cleanup stays on a graphics callback
 // Installed proxies remain pass-through; their trampolines are resident until process exit.
}
}
