#include "Il2CppDump.h"
#include "Il2CppDumpModel.h"
#include <windows.h>
#include <atomic>
#include <mutex>
#include <cwchar>
#include <exception>
namespace vibe_dump {
static std::atomic<bool> busy{false},cancel{false};
static std::mutex lock;
static Status status;
struct Job {
 Api api{};Counts counts{};Sink sink{};P attached=nullptr;
 std::wstring directory;HMODULE own=nullptr,game=nullptr;
 bool success=false;DWORD fault=0;char error[256]{};
};
static void progress(const Counts& c){std::lock_guard<std::mutex> guard(lock);status.images=c.images;status.classes=c.classes;status.fields=c.fields;status.methods=c.methods;status.properties=c.properties;status.totalClasses=c.totalClasses;}
static bool cancelled(){return cancel.load(std::memory_order_relaxed);}
template<class T> static void required(HMODULE m,T& target,const char* name){
 target=reinterpret_cast<T>(GetProcAddress(m,name));if(!target)throw std::runtime_error(std::string("Missing runtime export: ")+name);
}
template<class T> static void optional(HMODULE m,T& target,const char* name){target=reinterpret_cast<T>(GetProcAddress(m,name));}
static void load(Job& j){
 if(!GetModuleHandleExW(0,L"GameAssembly.dll",&j.game))throw std::runtime_error("GameAssembly.dll is not loaded");
#define LOAD(name) required(j.game,j.api.name,"il2cpp_" #name)
 LOAD(domain_get);LOAD(domain_get_assemblies);LOAD(assembly_get_image);LOAD(image_get_name);LOAD(image_get_class_count);LOAD(image_get_class);
 LOAD(class_get_name);LOAD(class_get_namespace);LOAD(class_get_parent);LOAD(class_get_declaring_type);LOAD(class_get_flags);
 LOAD(class_get_fields);LOAD(field_get_name);LOAD(field_get_type);LOAD(field_get_offset);LOAD(field_get_flags);
 LOAD(class_get_methods);LOAD(method_get_name);LOAD(method_get_return_type);LOAD(method_get_param_count);LOAD(method_get_param);LOAD(method_get_param_name);LOAD(method_get_flags);LOAD(method_get_token);
 LOAD(type_get_name);LOAD(free);LOAD(thread_attach);LOAD(thread_detach);
#undef LOAD
#define OPT(name) optional(j.game,j.api.name,"il2cpp_" #name)
 OPT(class_get_properties);OPT(property_get_name);OPT(property_get_get_method);OPT(property_get_set_method);OPT(class_get_interfaces);
#undef OPT
 if(!j.api.property_get_name||!j.api.property_get_get_method||!j.api.property_get_set_method)j.api.class_get_properties=nullptr;
 auto dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(j.game);
 if(dos->e_magic!=IMAGE_DOS_SIGNATURE||dos->e_lfanew<0||dos->e_lfanew>4096)throw std::runtime_error("Invalid module header");
 auto pe=reinterpret_cast<const IMAGE_NT_HEADERS64*>(reinterpret_cast<const char*>(j.game)+dos->e_lfanew);
 if(pe->Signature!=IMAGE_NT_SIGNATURE||pe->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC)throw std::runtime_error("Expected x64 GameAssembly");
 j.sink.moduleBase=reinterpret_cast<uintptr_t>(j.game);j.sink.moduleSize=pe->OptionalHeader.SizeOfImage;
}
static void createDirectory(Job& j){
 wchar_t path[32768];DWORD n=GetModuleFileNameW(j.own,path,32768);if(!n||n>=32768)throw std::runtime_error("Cannot find DLL directory");
 std::wstring root(path,n);auto pos=root.find_last_of(L"\\/");if(pos==std::wstring::npos)throw std::runtime_error("Invalid DLL path");root.resize(pos+1);root+=L"dumps";
 if(!CreateDirectoryW(root.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS)throw std::runtime_error("Cannot create dumps directory");
 SYSTEMTIME t{};GetLocalTime(&t);wchar_t name[128];
 std::swprintf(name,128,L"\\%04u%02u%02u-%02u%02u%02u-%03u-%lu",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond,t.wMilliseconds,static_cast<unsigned long>(GetCurrentProcessId()));
 j.directory=root+name;
 if(!CreateDirectoryW(j.directory.c_str(),nullptr))throw std::runtime_error("Cannot create unique dump directory");
 {std::lock_guard<std::mutex> guard(lock);int bytes=WideCharToMultiByte(CP_UTF8,0,j.directory.c_str(),-1,nullptr,0,nullptr,nullptr);if(bytes>0&&bytes<=static_cast<int>(sizeof(status.directory)))WideCharToMultiByte(CP_UTF8,0,j.directory.c_str(),-1,status.directory,sizeof(status.directory),nullptr,nullptr);else std::snprintf(status.directory,sizeof(status.directory),"Output path exceeds menu display limit");}
 j.sink.cs=_wfopen((j.directory+L"\\dump.cs.partial").c_str(),L"wb");
 j.sink.json=_wfopen((j.directory+L"\\dump.json.partial").c_str(),L"wb");
 if(!j.sink.cs||!j.sink.json)throw std::runtime_error("Cannot open dump output");
 j.sink.progress=progress;j.sink.cancelled=cancelled;
}
static void work(Job& j){
 try{
  load(j);P domain=j.api.domain_get();if(!domain)throw std::runtime_error("IL2CPP domain is not ready");
  j.attached=j.api.thread_attach(domain);if(!j.attached)throw std::runtime_error("Cannot attach metadata worker");
  createDirectory(j);write(j.api,domain,j.sink,j.counts);j.success=true;
 }catch(const std::exception& e){std::snprintf(j.error,sizeof(j.error),"%s",e.what());}
 catch(...){std::snprintf(j.error,sizeof(j.error),"Metadata export failed");}
}
// Keep SEH wrappers separate from C++ stack objects (also builds with MSVC).
static void guardedWork(Job* j){__try{work(*j);}__except(EXCEPTION_EXECUTE_HANDLER){j->fault=GetExceptionCode();j->success=false;}}
static void guardedDetach(Job* j){__try{if(j->attached&&j->api.thread_detach)j->api.thread_detach(j->attached);}__except(EXCEPTION_EXECUTE_HANDLER){j->fault=GetExceptionCode();j->success=false;}}
static DWORD WINAPI worker(void* arg){
 Job* j=static_cast<Job*>(arg);guardedWork(j);guardedDetach(j);
 if(j->sink.cs){if(std::fflush(j->sink.cs)!=0)j->success=false;if(std::fclose(j->sink.cs)!=0)j->success=false;}
 if(j->sink.json){if(std::fflush(j->sink.json)!=0)j->success=false;if(std::fclose(j->sink.json)!=0)j->success=false;}
 if(j->success){
  bool first=MoveFileExW((j->directory+L"\\dump.cs.partial").c_str(),(j->directory+L"\\dump.cs").c_str(),MOVEFILE_WRITE_THROUGH)!=0;
  bool second=first&&MoveFileExW((j->directory+L"\\dump.json.partial").c_str(),(j->directory+L"\\dump.json").c_str(),MOVEFILE_WRITE_THROUGH)!=0;
  if(!second){if(first)MoveFileExW((j->directory+L"\\dump.cs").c_str(),(j->directory+L"\\dump.cs.partial").c_str(),MOVEFILE_WRITE_THROUGH);j->success=false;std::snprintf(j->error,sizeof(j->error),"Cannot finalize output files");}
 }
 progress(j->counts);
 {std::lock_guard<std::mutex> guard(lock);status.state=j->success?Complete:(j->fault?Failed:cancel.load()?Cancelled:Failed);
  if(j->fault)std::snprintf(status.message,sizeof(status.message),"Runtime metadata fault: 0x%08lX; partial files retained",static_cast<unsigned long>(j->fault));
  else std::snprintf(status.message,sizeof(status.message),"%s",j->success?"dump.cs + dump.json saved":j->error[0]?j->error:"Output write failed; partial files retained");}
 HMODULE own=j->own;if(j->game)FreeLibrary(j->game);delete j;busy.store(false,std::memory_order_release);
 FreeLibraryAndExitThread(own,0);return 0;
}
bool Start(){
 bool expected=false;if(!busy.compare_exchange_strong(expected,true))return false;
 cancel.store(false);
 {std::lock_guard<std::mutex> guard(lock);status={};status.state=Running;std::snprintf(status.message,sizeof(status.message),"Exporting IL2CPP metadata...");}
 Job* j=new(std::nothrow) Job;
 if(!j){busy.store(false);std::lock_guard<std::mutex> guard(lock);status.state=Failed;std::snprintf(status.message,sizeof(status.message),"Out of memory");return false;}
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,reinterpret_cast<LPCWSTR>(&Start),&j->own)){delete j;busy.store(false);std::lock_guard<std::mutex> guard(lock);status.state=Failed;std::snprintf(status.message,sizeof(status.message),"Cannot retain DLL for export");return false;}
 HANDLE thread=CreateThread(nullptr,0,worker,j,0,nullptr);
 if(!thread){FreeLibrary(j->own);delete j;busy.store(false);std::lock_guard<std::mutex> guard(lock);status.state=Failed;std::snprintf(status.message,sizeof(status.message),"Cannot start metadata worker");return false;}
 CloseHandle(thread);return true;
}
void Cancel(){cancel.store(true);}
Status Read(){std::lock_guard<std::mutex> guard(lock);return status;}
}
