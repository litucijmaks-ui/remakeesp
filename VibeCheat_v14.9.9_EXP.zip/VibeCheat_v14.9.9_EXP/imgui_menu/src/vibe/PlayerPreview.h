#pragma once

#include "SettingsCompat.h"

namespace vibe_preview {
    void Draw(float width, vibe::ESPSettings& config);
    void Shutdown();
}
