#include "egui.hxx"
#include "layout.hxx"
#include "theme.hxx"
#include "assets/font.hxx"
#include "glass.hxx"
#include "state.hxx"
#include "assets/icon.hxx"
#include "../vibe/VibeRuntime.h"
#include "../vibe/PlayerPreview.h"
#include "../../../source/esp/farm_rate.h"
#include <d3d11.h>
#include <imgui_freetype.h>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <vector>
#include <string>
#include <Windows.h>
#include <wincodec.h>
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
extern "C" DWORD WINAPI VibeUiReadScrapStatus(char *,DWORD);
namespace egui {

    static const ImWchar icomoon_ranges[] = { 0xe000, 0xf8ff, 0 };

    static float scaled_px(float v, float s) { return ImFloor(v * s + 0.5f); }

    static bool g_atlas_full = false;

    static ID3D11ShaderResourceView* g_font_srv = nullptr;

    static void upload_font_texture()
    {
        if (!g_pd3dDevice) return;

        unsigned char* pixels = nullptr;
        int width = 0, height = 0;
        ImGui::GetIO().Fonts->GetTexDataAsRGBA32(&pixels, &width, &height);
        if (!pixels || width <= 0 || height <= 0) return;

        D3D11_TEXTURE2D_DESC desc = {};
        desc.Width = width;
        desc.Height = height;
        desc.MipLevels = 1;
        desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_DEFAULT;
        desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA sub = {};
        sub.pSysMem = pixels;
        sub.SysMemPitch = (UINT)width * 4;

        ID3D11Texture2D* tex = nullptr;
        if (FAILED(g_pd3dDevice->CreateTexture2D(&desc, &sub, &tex)) || !tex)
            return;

        D3D11_SHADER_RESOURCE_VIEW_DESC srv_desc = {};
        srv_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        srv_desc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srv_desc.Texture2D.MipLevels = 1;

        ID3D11ShaderResourceView* srv = nullptr;
        g_pd3dDevice->CreateShaderResourceView(tex, &srv_desc, &srv);
        tex->Release();
        if (!srv) return;

        if (g_font_srv) g_font_srv->Release();
        g_font_srv = srv;

        ImGui::GetIO().Fonts->SetTexID((ImTextureID)srv);

        ImGui::GetIO().Fonts->ClearTexData();
    }

    bool create_texture_from_memory(ID3D11Device* dev, const void* data, size_t size,
                                    ID3D11ShaderResourceView** out_srv, int* out_w, int* out_h)
    {
        if (!dev || !data || size == 0 || !out_srv) return false;
        *out_srv = nullptr;
        if (out_w) *out_w = 0;
        if (out_h) *out_h = 0;

        const HRESULT co = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
        const bool co_owned = SUCCEEDED(co);

        IWICImagingFactory* factory = nullptr;
        IWICStream* stream = nullptr;
        IWICBitmapDecoder* decoder = nullptr;
        IWICBitmapFrameDecode* frame = nullptr;
        IWICFormatConverter* conv = nullptr;
        bool ok = false;

        if (SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                       IID_PPV_ARGS(&factory))) &&
            SUCCEEDED(factory->CreateStream(&stream)) &&
            SUCCEEDED(stream->InitializeFromMemory(static_cast<BYTE*>(const_cast<void*>(data)), (DWORD)size)) &&
            SUCCEEDED(factory->CreateDecoderFromStream(stream, nullptr, WICDecodeMetadataCacheOnDemand, &decoder)) &&
            SUCCEEDED(decoder->GetFrame(0, &frame)) &&
            SUCCEEDED(factory->CreateFormatConverter(&conv)) &&
            SUCCEEDED(conv->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone,
                                       nullptr, 0.0, WICBitmapPaletteTypeCustom)))
        {
            UINT w = 0, h = 0;
            if (SUCCEEDED(conv->GetSize(&w, &h)) && w > 0 && h > 0) {
                std::vector<unsigned char> pixels((size_t)w * h * 4);
                if (SUCCEEDED(conv->CopyPixels(nullptr, w * 4, (UINT)pixels.size(), pixels.data()))) {
                    D3D11_TEXTURE2D_DESC desc = {};
                    desc.Width = w;
                    desc.Height = h;
                    desc.MipLevels = 1;
                    desc.ArraySize = 1;
                    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                    desc.SampleDesc.Count = 1;
                    desc.Usage = D3D11_USAGE_DEFAULT;
                    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

                    D3D11_SUBRESOURCE_DATA sub = {};
                    sub.pSysMem = pixels.data();
                    sub.SysMemPitch = w * 4;

                    ID3D11Texture2D* tex = nullptr;
                    if (SUCCEEDED(dev->CreateTexture2D(&desc, &sub, &tex)) && tex) {
                        ok = SUCCEEDED(dev->CreateShaderResourceView(tex, nullptr, out_srv));
                        tex->Release();
                        if (ok) {
                            if (out_w) *out_w = (int)w;
                            if (out_h) *out_h = (int)h;
                        }
                    }
                }
            }
        }

        auto rel = [](auto*& p) { if (p) { p->Release(); p = nullptr; } };
        rel(conv); rel(frame); rel(decoder); rel(stream); rel(factory);
        if (co_owned) CoUninitialize();
        return ok;
    }

    static void load_fonts(float s, bool with_extras)
    {
        ImGuiIO& io = ImGui::GetIO();

        io.Fonts->Clear();
        io.FontDefault = nullptr;

        ImFontConfig inter_config;
        inter_config.FontBuilderFlags = ImGuiFreeTypeBuilderFlags_LoadColor;
        inter_config.FontDataOwnedByAtlas = false;
        inter_config.GlyphRanges = io.Fonts->GetGlyphRangesCyrillic();

        auto px = [s](float v) { return v * s; };

        efonts.inter.Text12        = io.Fonts->AddFontFromMemoryTTF(inter_medium,    sizeof(inter_medium),    px(12.f), &inter_config);
        efonts.inter.Text10        = io.Fonts->AddFontFromMemoryTTF(inter_medium,    sizeof(inter_medium),    px(10.f), &inter_config);
        efonts.inter.Text11        = io.Fonts->AddFontFromMemoryTTF(inter_medium,    sizeof(inter_medium),    px(11.f), &inter_config);
        efonts.inter.Text13        = io.Fonts->AddFontFromMemoryTTF(inter_medium,    sizeof(inter_medium),    px(13.f), &inter_config);
        efonts.inter.Bold10        = io.Fonts->AddFontFromMemoryTTF(inter_semibold,  sizeof(inter_semibold),  px(10.f), &inter_config);
        efonts.inter.Bold11        = io.Fonts->AddFontFromMemoryTTF(inter_semibold,  sizeof(inter_semibold),  px(11.f), &inter_config);
        efonts.inter.Bold12        = io.Fonts->AddFontFromMemoryTTF(inter_semibold,  sizeof(inter_semibold),  px(12.f), &inter_config);
        efonts.inter.Bold13        = io.Fonts->AddFontFromMemoryTTF(inter_bold,      sizeof(inter_bold),      px(13.f), &inter_config);

        if (with_extras) {
            efonts.inter.Regular       = io.Fonts->AddFontFromMemoryTTF(inter_regular,   sizeof(inter_regular),   px(18.f), &inter_config);
            efonts.inter.Medium        = io.Fonts->AddFontFromMemoryTTF(inter_medium,    sizeof(inter_medium),    px(18.f), &inter_config);
            efonts.inter.MediumSmall   = io.Fonts->AddFontFromMemoryTTF(inter_medium,    sizeof(inter_medium),    px(14.f), &inter_config);
            efonts.inter.SemiBold      = io.Fonts->AddFontFromMemoryTTF(inter_semibold,  sizeof(inter_semibold),  px(16.f), &inter_config);
            efonts.inter.SemiBoldSmall = io.Fonts->AddFontFromMemoryTTF(inter_semibold,  sizeof(inter_semibold),  px(11.f), &inter_config);
            efonts.inter.SemiBold13    = io.Fonts->AddFontFromMemoryTTF(inter_semibold,  sizeof(inter_semibold),  px(13.f), &inter_config);
            efonts.inter.Bold          = io.Fonts->AddFontFromMemoryTTF(inter_bold,      sizeof(inter_bold),      px(18.f), &inter_config);
            efonts.inter.Black         = io.Fonts->AddFontFromMemoryTTF(inter_black,     sizeof(inter_black),     px(18.f), &inter_config);
            efonts.inter.ExtraBold     = io.Fonts->AddFontFromMemoryTTF(inter_extrabold, sizeof(inter_extrabold), px(18.f), &inter_config);

            ImFontConfig icomoon_config;
            icomoon_config.OversampleH = icomoon_config.OversampleV = 1;
            icomoon_config.FontBuilderFlags |= ImGuiFreeTypeBuilderFlags_LoadColor;

            efonts.icomoon.regular       = io.Fonts->AddFontFromMemoryCompressedBase85TTF(icomoon_compressed_data_base85, px(20.f), &icomoon_config, icomoon_ranges);
            efonts.icomoon.regular_small = io.Fonts->AddFontFromMemoryCompressedBase85TTF(icomoon_compressed_data_base85, px(16.f), &icomoon_config, icomoon_ranges);
            efonts.icomoon.regular_large = io.Fonts->AddFontFromMemoryCompressedBase85TTF(icomoon_compressed_data_base85, px(28.f), &icomoon_config, icomoon_ranges);
        }
        else {
            efonts.inter.Regular = efonts.inter.Medium = efonts.inter.MediumSmall = nullptr;
            efonts.inter.SemiBold = efonts.inter.SemiBoldSmall = efonts.inter.SemiBold13 = nullptr;
            efonts.inter.Bold = efonts.inter.Black = efonts.inter.ExtraBold = nullptr;
            efonts.icomoon.regular = efonts.icomoon.regular_small = efonts.icomoon.regular_large = nullptr;
        }
        g_atlas_full = with_extras;

        settings.scale_current = s;
    }

    float system_dpi_scale()
    {
        HDC dc = ::GetDC(nullptr);
        if (!dc) return 1.0f;
        const int dpi_x = ::GetDeviceCaps(dc, LOGPIXELSX);
        ::ReleaseDC(nullptr, dc);
        return dpi_x > 0 ? (float)dpi_x / 96.0f : 1.0f;
    }

    static void apply_style_colors();

    void apply_scale(float scale)
    {
        scale = ImClamp(scale, 0.5f, 4.0f);

        const float* src = reinterpret_cast<const float*>(&layout_design);
        float* dst = reinterpret_cast<float*>(&layout);
        for (size_t i = 0; i < sizeof(Layout) / sizeof(float); i++)
            dst[i] = scaled_px(src[i], scale);

        layout.border = ImMax(1.0f, layout.border);

        settings.current_dpi_scale = scale;

        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowPadding      = ImVec2(0.f, 0.f);
        style.WindowBorderSize   = 0.f;
        style.WindowRounding     = 0.f;
        style.ChildBorderSize    = 0.f;
        style.ChildRounding      = 0.f;
        style.PopupRounding      = layout.control_rounding;
        style.PopupBorderSize    = layout.border;
        style.FrameBorderSize    = layout.border;
        style.FrameRounding      = layout.control_rounding;
        style.FramePadding       = ImVec2(dpi(11.f), (layout.control_h - dpi(12.f)) * 0.5f);
        style.ItemSpacing        = ImVec2(0.f, layout.row_gap);
        style.ItemInnerSpacing   = ImVec2(dpi(8.f), dpi(4.f));
        style.ScrollbarSize      = dpi(6.f);
        style.ScrollbarRounding  = dpi(3.f);
        style.GrabRounding       = dpi(3.f);
        style.WindowMenuButtonPosition = ImGuiDir_None;

        apply_style_colors();
    }

    static void apply_style_colors()
    {
        ImVec4* c = ImGui::GetStyle().Colors;
        c[ImGuiCol_Text]                  = colors.text;
        c[ImGuiCol_TextDisabled]          = colors.text_muted;
        c[ImGuiCol_WindowBg]              = colors.background;
        c[ImGuiCol_ChildBg]               = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_PopupBg]               = colors.surface_sec;
        c[ImGuiCol_Border]                = colors.control_border;
        c[ImGuiCol_BorderShadow]          = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_FrameBg]               = colors.control;
        c[ImGuiCol_FrameBgHovered]        = colors.control_hov;
        c[ImGuiCol_FrameBgActive]         = colors.control_hov;
        c[ImGuiCol_ScrollbarBg]           = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_ScrollbarGrab]         = colors.scroll;
        c[ImGuiCol_ScrollbarGrabHovered]  = colors.surface_sel;
        c[ImGuiCol_ScrollbarGrabActive]   = colors.accent;
        c[ImGuiCol_CheckMark]             = colors.accent;
        c[ImGuiCol_SliderGrab]            = colors.accent;
        c[ImGuiCol_SliderGrabActive]      = colors.accent;
        c[ImGuiCol_Button]                = colors.control;
        c[ImGuiCol_ButtonHovered]         = colors.control_hov;
        c[ImGuiCol_ButtonActive]          = colors.control_hov;
        c[ImGuiCol_Header]                = colors.surface_sel;
        c[ImGuiCol_HeaderHovered]         = colors.surface_hov;
        c[ImGuiCol_HeaderActive]          = colors.surface_sel;
        c[ImGuiCol_Separator]             = colors.divider;
        c[ImGuiCol_TextSelectedBg]        = ImVec4(colors.accent.x, colors.accent.y, colors.accent.z, 0.35f);
        c[ImGuiCol_NavHighlight]          = ImVec4(0, 0, 0, 0);
    }

    void set_theme(Theme t) { settings.theme = t; }

    void update_theme()
    {
        const DesignTokens target = theme_tokens(settings.theme);

        const float* dst = reinterpret_cast<const float*>(&target);
        float* cur = reinterpret_cast<float*>(&colors);
        const int n = (int)(sizeof(DesignTokens) / sizeof(float));

        const float k = anim_step(fade_speed);
        bool moving = false;
        for (int i = 0; i < n; i++) {
            if (ImFabs(cur[i] - dst[i]) < 0.001f) { cur[i] = dst[i]; continue; }
            cur[i] = ImLerp(cur[i], dst[i], k);
            moving = true;
        }

        static bool was_moving = true;
        if (moving || was_moving)
            apply_style_colors();
        was_moving = moving;
    }

    static int font_signature(float s)
    {
        static const float bases[] = { 10.f, 11.f, 12.f, 13.f };
        int sig = 0;
        for (int i = 0; i < IM_ARRAYSIZE(bases); i++)
            sig = sig * 131 + (int)scaled_px(bases[i], s);
        return sig;
    }

    void update_dpi()
    {
        IM_ASSERT((ImGui::GetCurrentContext() == nullptr || !ImGui::GetCurrentContext()->WithinFrameScope)
                  && "egui::update_dpi() debe llamarse fuera del frame, antes de NewFrame");

        ImGuiIO& io = ImGui::GetIO();
        settings.dpi_scale = system_dpi_scale();
        const float target = ImClamp(settings.dpi_scale, 0.5f, 4.0f);
        settings.dpi_scale = target;

        if (settings.current_dpi_scale != target) {
            float cur = ImLerp(settings.current_dpi_scale, target, anim_step(fade_speed));
            if (ImFabs(cur - target) < 0.002f) cur = target;
            apply_scale(cur);
        }
        const bool settled = (settings.current_dpi_scale == target);

        const bool sizes_changed = font_signature(settings.current_dpi_scale) != font_signature(settings.scale_current);
        const bool extras_missing = settled && !g_atlas_full;
        if (!sizes_changed && !extras_missing)
            return;

        load_fonts(settings.current_dpi_scale, settled);
        io.Fonts->Build();
        upload_font_texture();
    }

    void initialize()
    {
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = NULL;

        ImGui::StyleColorsDark();

        apply_scale(settings.dpi_scale);
        load_fonts(settings.current_dpi_scale, true);
    }

    static const char* header_tabs[] = { "Aim", "ESP", "Farm", "Movement", "Visuals", "Settings", "Skinchanger" };
    static constexpr int TAB_COUNT = IM_ARRAYSIZE(header_tabs);
    static_assert(TAB_COUNT == IM_ARRAYSIZE(vars.gui.active_subtab),
                  "header tab count must match active_subtab");

    static int shown_tab = 0;

    static bool g_scroll_reset_next = false;

    struct GroupCtx {
        ImDrawListSplitter splitter;
        ImVec2 start = ImVec2(0, 0);
        float  width = 0.f;
    };
    static GroupCtx g_groups[8];
    static int      g_group_depth = 0;

    void begin_group(const char* id, float width) {
        IM_ASSERT(g_group_depth < IM_ARRAYSIZE(g_groups));
        GroupCtx& g = g_groups[g_group_depth++];

        ImDrawList* dl = ImGui::GetWindowDrawList();
        g.start = ImGui::GetCursorScreenPos();
        g.width = (width > 0.f) ? width : ImGui::GetContentRegionAvail().x;

        g.splitter.Split(dl, 2);
        g.splitter.SetCurrentChannel(dl, 1);

        ImGui::PushID(id);
        ImGui::Indent(layout.card_pad_x);
        ImGui::BeginGroup();
        ImGui::PushItemWidth(g.width - layout.card_pad_x * 2.f);
        ImGui::Dummy(ImVec2(0.f, ImMax(0.f, layout.card_pad_t - ImGui::GetStyle().ItemSpacing.y)));
    }

    void end_group() {
        IM_ASSERT(g_group_depth > 0);
        GroupCtx& g = g_groups[--g_group_depth];

        ImGui::PopItemWidth();
        ImGui::EndGroup();
        ImGui::Unindent(layout.card_pad_x);
        ImGui::PopID();

        const ImVec2 p_min = g.start;
        const ImVec2 p_max(g.start.x + g.width, ImGui::GetItemRectMax().y + layout.card_pad_b);

        ImDrawList* dl = ImGui::GetWindowDrawList();
        g.splitter.SetCurrentChannel(dl, 0);
        // Opaque cards: never sample the game image through the menu.
        edraw.rect_filled(p_min, p_max, colors.card, layout.card_rounding);
        edraw.rect(p_min, p_max, colors.card_border, layout.card_rounding, 0, layout.border);
        g.splitter.Merge(dl);

        ImGuiWindow* window = ImGui::GetCurrentWindow();
        window->DC.CursorMaxPos.x = ImMax(window->DC.CursorMaxPos.x, p_max.x);
        window->DC.CursorMaxPos.y = ImMax(window->DC.CursorMaxPos.y, p_max.y);

        ImGui::SetCursorScreenPos(ImVec2(g.start.x, p_max.y + layout.card_gap));
    }

    void group_title(const char* text) {
        ImFont* f = fnt(efonts.inter.Bold11);
        const ImVec2 pos = ImGui::GetCursorScreenPos();
        draw_text(f, ImVec2(pos.x, pos.y - dpi(1.f)), colors.section_header, text);
        ImGui::Dummy(ImVec2(measure(f, text).x, fsize(f) + dpi(4.f)));
    }

    bool group_tabs(const char* id, const char* const* items, int count, int* current) {
        ImFont* f_on  = fnt(efonts.inter.Bold11);
        ImFont* f_off = fnt(efonts.inter.Text11);

        const ImVec2 pos = ImGui::GetCursorScreenPos();
        const float  h   = fsize(f_on);
        bool changed = false;
        float x = pos.x;

        ImGui::PushID(id);
        for (int i = 0; i < count; i++) {
            const ImVec2 ts_on  = measure(f_on,  items[i]);
            const ImVec2 ts_off = measure(f_off, items[i]);

            const float w = ts_on.x;

            ImGui::SetCursorScreenPos(ImVec2(x, pos.y));
            ImGui::InvisibleButton(items[i], ImVec2(w, h));
            const bool hovered = ImGui::IsItemHovered();
            if (ImGui::IsItemClicked()) { *current = i; changed = true; }

            const ImGuiID iid = ImGui::GetItemID();
            const float sel_t = anim(anim_value(iid), (*current == i) ? 1.f : 0.f, 14.f);
            const float hov_t = anim(anim_hover(iid), hovered ? 1.f : 0.f, 14.f);

            if (sel_t < 0.999f)
                draw_text(f_off, ImVec2(x, pos.y + (h - ts_off.y) * 0.5f - dpi(1.f)),
                          fade(ImLerp(colors.text_disabled, colors.text_sec, hov_t), 1.f - sel_t),
                          items[i]);
            if (sel_t > 0.001f)
                draw_text(f_on, ImVec2(x, pos.y + (h - ts_on.y) * 0.5f - dpi(1.f)),
                          fade(colors.accent, sel_t), items[i]);

            x += w + dpi(16.f);
        }
        ImGui::PopID();

        ImGui::SetCursorScreenPos(pos);
        ImGui::Dummy(ImVec2(ImMin(ImMax(0.f, x - pos.x - dpi(16.f)), ImGui::CalcItemWidth()), h + dpi(4.f)));
        return changed;
    }

    void section_label(const char* text, const char* text_end) {
        ImFont* f = fnt(efonts.inter.Text11);
        const ImVec2 pos = ImGui::GetCursorScreenPos();
        const auto span = vibe_lang::Span(text, text_end);
        const float wrap = ImMax(1.f, ImGui::CalcItemWidth());
        const ImVec2 size = f->CalcTextSizeA(fsize(f), FLT_MAX, wrap, span.text, span.end);
        ImVec4 tint = colors.section_header;tint.w *= ImGui::GetStyle().Alpha;
        ImGui::GetWindowDrawList()->AddText(f, fsize(f), pos, ImGui::ColorConvertFloat4ToU32(tint), span.text, span.end, wrap);
        ImGui::Dummy(ImVec2(ImMin(wrap, size.x), size.y));
    }

    void gap(float height) {
        const ImVec2 p = ImGui::GetCursorScreenPos();
        ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + height));
    }

    void same_line_right(float width) {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        const float row_w = ImGui::CalcItemWidth();
        const float row_l = window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x;
        const ImVec2 last_min = ImGui::GetItemRectMin();
        ImGui::SameLine();
        ImGui::SetCursorScreenPos(ImVec2(row_l + row_w - width, last_min.y));
    }

    static bool g_glass_frame = false;

    static void header_bar(ImVec2 p, float width) {
        ImFont* f_logo = fnt(efonts.inter.Bold13);
        ImFont* f_icon = fnt(efonts.icomoon.regular_small);

        const float pad = dpi(16.f);
        const float cy = p.y + layout.header_h * 0.5f;

        const ImVec2 logo_sz = measure(f_logo, settings.project_name);
        draw_text(f_logo, ImVec2(p.x + pad, cy - logo_sz.y * 0.5f - dpi(1.f)),
                  colors.accent, settings.project_name);

        const float btn = dpi(22.f);
        const ImVec2 bmin(p.x + width - pad - btn, cy - btn * 0.5f);
        ImGui::SetCursorScreenPos(bmin);
        ImGui::InvisibleButton("##close_menu", ImVec2(btn, btn));
        const bool hov = ImGui::IsItemHovered();
        if (ImGui::IsItemClicked()) {
            settings.state.menu_open = false;
            vibe_runtime::NotifyMenuClosed();
        }

        const char* mark = (f_icon ? ICON_CLOSE_LINE : "x");
        ImFont* fm = f_icon ? f_icon : fnt(efonts.inter.Text12);
        const ImVec2 ms = measure(fm, mark);
        draw_text(fm, ImVec2(bmin.x + (btn - ms.x) * 0.5f, bmin.y + (btn - ms.y) * 0.5f - dpi(1.f)),
                  hov ? colors.text_primary : colors.text_sec, mark);
    }

    static void nav_bar(ImVec2 p, float width) {
        (void)width;
        ImFont* f = fnt(efonts.inter.Text12);
        const float h = layout.tab_h;
        const float y = p.y + (layout.tabbar_h - h) * 0.5f;
        float x = p.x + layout.tab_pad_x;

        for (int i = 0; i < TAB_COUNT; i++) {
            const ImVec2 ts = measure(f, header_tabs[i]);
            const float w = ts.x + layout.tab_pad_x * 2.f;

            ImGui::SetCursorScreenPos(ImVec2(x, y));
            ImGui::InvisibleButton(header_tabs[i], ImVec2(w, h));
            const bool hovered = ImGui::IsItemHovered();
            if (ImGui::IsItemClicked()) vars.gui.active_tab = i;

            const ImGuiID id = ImGui::GetItemID();
            const float sel_t = anim(anim_value(id), (vars.gui.active_tab == i) ? 1.f : 0.f, 14.f);
            const float hov_t = anim(anim_hover(id), hovered ? 1.f : 0.f, 14.f);

            const float bg_a = ImMax(sel_t, hov_t * 0.6f);
            if (bg_a > 0.001f)
                edraw.rect_filled(ImVec2(x, y), ImVec2(x + w, y + h),
                                  fade(ImLerp(colors.surface_hov, colors.tab_sel, sel_t), bg_a),
                                  layout.control_rounding);

            const ImVec4 c_idle = g_glass_frame ? colors.text_sec     : colors.text_muted;
            const ImVec4 c_hov  = g_glass_frame ? colors.text_primary : colors.text_sec;
            const ImVec4 col = ImLerp(ImLerp(c_idle, c_hov, hov_t),
                                      colors.text_primary, sel_t);
            const ImVec2 tp(x + layout.tab_pad_x, y + (h - ts.y) * 0.5f - dpi(1.f));
            if (g_glass_frame)
                draw_text(f, ImVec2(tp.x + dpi(1.f), tp.y + dpi(1.f)),
                          ImVec4(0.f, 0.f, 0.f, 0.75f), header_tabs[i]);
            draw_text(f, tp, col, header_tabs[i]);
            x += w + layout.tab_gap;
        }
    }

    static const char* build_date() {
        static char buf[24] = {};
        if (!buf[0]) {
            const char* d = __DATE__;
            int j = 0;
            for (int i = 0; d[i] && j < (int)sizeof(buf) - 1; i++) {
                if (d[i] == ' ' && j > 0 && buf[j - 1] == ' ') continue;
                buf[j++] = d[i];
            }
            buf[j] = '\0';
        }
        return buf;
    }

    static void footer_bar(ImVec2 p, float width) {
        ImFont* f = fnt(efonts.inter.Text10);
        const float cy = p.y + layout.footer_h * 0.5f;
        const char* credit = "by Rufliy";
        const ImVec2 sz = measure(f, credit);
        const float x = p.x + width - layout.content_pad - sz.x;
        const float y = cy - sz.y * 0.5f - dpi(1.0f);
        draw_text(f, ImVec2(x, y), colors.text_muted, credit);
    }

    void template_shell() {

        update_theme();

        settings.overlay.watermark  = vars.gui.show_watermark;
        settings.overlay.keybinds   = vars.gui.show_active_hotkeys;
        settings.overlay.spectators = vars.gui.show_playerlist;

        ImGuiWindow* window = ImGui::GetCurrentWindow();
        const ImVec2 org(window->Pos.x + layout.shadow_pad, window->Pos.y + layout.shadow_pad);

        const float main_h = layout.header_h + layout.tabbar_h + layout.content_h + layout.footer_h;
        const ImVec2 m_min = org;
        const ImVec2 m_max(org.x + layout.main_w, org.y + main_h);

        edraw.shadow_rect(m_min, m_max, ImColor(0, 0, 0, 255), layout.shadow, layout.window_rounding);
        // Opaque menu background. The previous glass path intentionally mixed
        // the game framebuffer into the menu, which looked transparent in OBS.
        g_glass_frame = false;
        glass.enabled = false;
        edraw.rect_filled(m_min, m_max, colors.background, layout.window_rounding);
        edraw.rect(m_min, m_max, colors.window_border, layout.window_rounding, 0, layout.border);

        float y = m_min.y;

        const ImColor div = g_glass_frame ? fade(colors.divider, 0.55f)
                                          : ImColor(colors.divider);

        header_bar(ImVec2(m_min.x, y), layout.main_w);
        y += layout.header_h;
        edraw.line(ImVec2(m_min.x, y), ImVec2(m_max.x, y), div, layout.border);

        nav_bar(ImVec2(m_min.x, y), layout.main_w);
        y += layout.tabbar_h;
        edraw.line(ImVec2(m_min.x, y), ImVec2(m_max.x, y), div, layout.border);

        {
            float& tab_alpha = vars.gui.tab_transition_alpha;
            const bool swapping = (shown_tab != vars.gui.active_tab);
            ramp_to(tab_alpha, !swapping);
            if (swapping && tab_alpha <= 0.0f) {
                shown_tab = vars.gui.active_tab;
                g_scroll_reset_next = true;
            }
        }

        ImGui::SetCursorScreenPos(ImVec2(m_min.x, y));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(layout.content_pad, layout.content_pad));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * vars.gui.tab_transition_alpha);
        begin_child("##content", ImVec2(layout.main_w, layout.content_h));
        {
            const float avail = ImGui::GetContentRegionAvail().x;
            const float col_w = (avail - layout.col_gap) * 0.5f;

            ImGui::BeginGroup();
            panel_left(col_w, layout.content_h);
            ImGui::EndGroup();

            ImGui::SameLine(0.f, layout.col_gap);

            ImGui::BeginGroup();
            panel_right(col_w, layout.content_h, "Indicators");
            ImGui::EndGroup();
        }
        end_child();
        ImGui::PopStyleVar(2);

        const float footer_y = m_max.y - layout.footer_h;
        edraw.line(ImVec2(m_min.x, footer_y), ImVec2(m_max.x, footer_y), div, layout.border);
        footer_bar(ImVec2(m_min.x, footer_y), layout.main_w);
    }

    static int g_shown_subtab[TAB_COUNT] = {};

    static int subtab_begin() {
        int&   shown = g_shown_subtab[shown_tab];
        const int want = vars.gui.active_subtab[shown_tab];
        float& a = vars.gui.subtab_transition_alpha;

        const bool swapping = (shown != want);
        ramp_to(a, !swapping);
        if (swapping && a <= 0.0f) shown = want;

        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * a);
        return shown;
    }
    static void subtab_end() { ImGui::PopStyleVar(); }

    static bool cfg_bit(const char* label, DWORD& field, DWORD bit)
    {
        bool value = (field & bit) != 0;
        if (!checkbox(label, &value)) return false;
        if (value) field |= bit; else field &= ~bit;
        vibe_runtime::MarkDirty();
        return true;
    }

    static bool cfg_slider(const char* label, DWORD& field, float min_value, float max_value, const char* format)
    {
        float value = (float)field;
        if (!slider_float(label, &value, min_value, max_value, vibe_lang::T(format))) return false;
        value = ImClamp(value, min_value, max_value);
        field = (DWORD)(value + 0.5f);
        vibe_runtime::MarkDirty();
        return true;
    }

    static bool cfg_combo(const char* label, DWORD& field, const char* items)
    {
        int value = (int)field;
        if (!combo(label, &value, items)) return false;
        field = (DWORD)value;
        vibe_runtime::MarkDirty();
        return true;
    }

    static bool key_conflicts(DWORD key, const DWORD* self)
    {
        const vibe::ESPSettings& c = vibe_runtime::config;
        if (!key) return false;
        if (self != &c.aim_key && c.aim_key == key) return true;
        if (self != &c.speed_key && c.speed_key == key) return true;
        if (self != &c.noclip_key && c.noclip_key == key) return true;
        if (vibe_runtime::custom.zoom_key == key) return true;
        return false;
    }

    static bool cfg_key(const char* label, DWORD& field, bool allow_clear)
    {
        int value = (int)field;
        if (!keybind(label, &value)) return false;

        DWORD candidate = value > 0 ? (DWORD)value : 0u;
        if (!candidate && !allow_clear)
            return false;
        if (candidate && (!vibe::SettingsKeyValid(candidate) || key_conflicts(candidate, &field)))
            return false;

        field = candidate;
        vibe_runtime::MarkDirty();
        return true;
    }

    static void cfg_color(const char* label, DWORD& color)
    {
        float rgba[4] = {
            GetRValue(color) / 255.0f,
            GetGValue(color) / 255.0f,
            GetBValue(color) / 255.0f,
            1.0f
        };

        section_label(label);
        same_line_right(layout.swatch);
        ImGui::PushID(label);
        if (color_button("##value", rgba, false)) {
            const int r = (int)(ImClamp(rgba[0], 0.0f, 1.0f) * 255.0f + 0.5f);
            const int g = (int)(ImClamp(rgba[1], 0.0f, 1.0f) * 255.0f + 0.5f);
            const int b = (int)(ImClamp(rgba[2], 0.0f, 1.0f) * 255.0f + 0.5f);
            color = RGB(r, g, b);
            vibe_runtime::MarkDirty();
        }
        ImGui::PopID();
    }

    static void config_status_group(float width)
    {
        begin_group("##config_status", width);
        group_title("Connection");
        section_label(vibe_runtime::StatusText());
        end_group();
    }

    void panel_left(float width, float height)
    {
        (void)height;
        vibe::ESPSettings& c = vibe_runtime::config;

        if (shown_tab == 0) {
            begin_group("##aim_main", width);
            group_title("Aim");
            cfg_bit("Enable aim", c.aim_flags, 1u);
            cfg_bit("Show FOV", c.aim_flags, 2u);
            cfg_bit("Visible check", c.aim_flags, 4u);
            cfg_key("Hold key", c.aim_key, false);
            cfg_combo("Mode", c.aim_mode, "Camera\0Silent\0Aimkill\0\0");
            if(c.aim_mode==vibe::AIM_MODE_AIMKILL) section_label("Aimkill: native autofire + FOV");
            cfg_combo("Target", c.aim_point, "Head\0Body\0Legs\0\0");
            cfg_slider("FOV radius", c.aim_fov, 0.f, (float)vibe::AIM_FOV_LIMIT, "%.0f px");
            cfg_slider("Sharpness", c.aim_sharpness, 1.f, 100.f, "%.0f%%");
            end_group();
            return;
        }

        if (shown_tab == 1) {
            begin_group("##esp_main", width);
            group_title("Players");
            cfg_bit("Enable ESP", c.flags, 1u);
            cfg_bit("Boxes + HP", c.flags, 2u);
            cfg_bit("Player names", c.flags, 4u);
            cfg_bit("Snap lines", c.flags, 8u);
            cfg_bit("Distance", c.flags, 16u);
            cfg_bit("Skeleton", c.flags, 32u);
            cfg_bit("Loot balloon", c.flags, 64u);
            cfg_bit("Death backpack", c.flags, 128u);
            cfg_bit("Cupboard ESP",c.flags,256u);
            cfg_bit("Storage chest ESP",c.flags,512u);
            cfg_bit("Furnace ESP",c.flags,1024u);
            cfg_slider("Balloon distance", c.balloon_max_m, 0.f, 2500.f, "%.0f m");
            cfg_slider("ESP distance", c.max_m, 0.f, (float)vibe::RANGE_LIMIT_M, "%.0f m");
            cfg_slider("Line width", c.esp_width, 1.f, 4.f, "%.0f px");
            c.min_m = 0;
            end_group();
            gap(8.0f);
            begin_group("##esp_palette", width);
            group_title("ESP Palette");
            cfg_color("Box", c.esp_colors[vibe::ESP_COLOR_BOX]);
            cfg_color("Name", c.esp_colors[vibe::ESP_COLOR_NAME]);
            cfg_color("Line", c.esp_colors[vibe::ESP_COLOR_LINE]);
            cfg_color("Skeleton", c.esp_colors[vibe::ESP_COLOR_SKELETON]);
            cfg_color("HP", c.esp_colors[vibe::ESP_COLOR_HP]);
            cfg_color("Distance", c.esp_colors[vibe::ESP_COLOR_DISTANCE]);
            cfg_color("FOV", c.esp_colors[vibe::ESP_COLOR_FOV]);
            if (button("Reset colors")) {
                vibe::ResetColors(c);
                vibe_runtime::MarkDirty();
            }
            end_group();
            return;
        }

        if (shown_tab == 2) {
            begin_group("##farm_main", width);
            group_title("Auto Farm");
            cfg_bit("Enable farm", c.farm_flags, 1u);
            cfg_bit("Unbreakable tools", c.combat_flags, 8u);
            cfg_bit("Trees", c.farm_flags, 2u);
            cfg_bit("Ore", c.farm_flags, 4u);
            auto& extra=vibe_runtime::custom;
            bool scrap=(extra.flags&VIBE_CUSTOM_SCRAP)!=0;
            if(checkbox("Scrap",&scrap)){extra.flags=(extra.flags&~VIBE_CUSTOM_SCRAP)|(scrap?VIBE_CUSTOM_SCRAP:0u);if(scrap){c.farm_flags|=1u;vibe_runtime::MarkDirty();}vibe_runtime::MarkCustomDirty();}
            if(scrap){char state[160]={};VibeUiReadScrapStatus(state,sizeof(state));section_label("Last scrap activity");section_label(state);}
            cfg_bit("Walk to resources", c.farm_flags, 8u);
            cfg_bit("Auto select tool", c.farm_flags, 16u);
            cfg_bit("Free study", c.farm_flags, 64u);
            end_group();
            return;
        }

        if (shown_tab == 3) {
            begin_group("##movement_speed", width);
            group_title("Speed");
           
            cfg_bit("Enable speed", c.move_flags, 1u);
            cfg_bit("Auto sprint", c.move_flags, 2u);
            cfg_slider("Speed", c.speed_percent, 100.f, 300.f, "%.0f%%");
            cfg_key("Speed toggle", c.speed_key, true);
            cfg_bit("No fall damage", c.combat_flags, 4u);
            end_group();
            return;
        }

        if (shown_tab == 4) {
            begin_group("##visual_main", width);
            group_title("Sky / Hands");
            cfg_bit("Custom time", c.visual_flags, vibe::VISUAL_TIME);
            cfg_slider("Time", c.sky_minutes, 0.f, 1440.f, "%.0f min");
            char time_text[32];
            std::snprintf(time_text, sizeof(time_text), "%02lu:%02lu",
                          (unsigned long)(c.sky_minutes / 60u),
                          (unsigned long)(c.sky_minutes % 60u));
            section_label(time_text);
            cfg_bit("Custom sky color", c.visual_flags, vibe::VISUAL_SKY_COLOR);
            cfg_color("Sky color", c.sky_color);
            cfg_bit("Custom fog color", c.visual_flags, vibe::VISUAL_FOG);
            cfg_color("Fog color", c.fog_color);
            cfg_bit("Smaller hands", c.visual_flags, vibe::VISUAL_HANDS);
            cfg_slider("Hands reduction", c.hands_distance_cm, 0.f,
                       (float)vibe::HANDS_DISTANCE_LIMIT_CM, "%.0f%%");
            end_group();

            return;
        }

        if (shown_tab == 5) {
            begin_group("##interface", width);
            group_title("Interface");
            int language = vibe_lang::selected;
            if (combo("Language", &language, "English\0Русский\0\0"))
                vibe_runtime::SetLanguage(language);
            section_label("Menu key: Insert");
            checkbox("Watermark", &vars.gui.show_watermark);
            checkbox("Blur (heavier)", &glass.enabled);
            checkbox("Hide menu from recording", &vars.gui.streamproof);
            end_group();
            return;
        }
        if (shown_tab == 6) {
            static VibeSkinCatalog catalog{};
            static char filter[96]{};
            static bool profile_full=false;
            vibe_runtime::ReadSkinCatalog(catalog);
            auto& extra=vibe_runtime::custom;
            begin_group("##skin_main",width);group_title("Skinchanger");
            bool enabled=(extra.flags&VIBE_CUSTOM_SKINS)!=0;
            if(checkbox("Enable local skins",&enabled)){extra.flags=(extra.flags&~VIBE_CUSTOM_SKINS)|(enabled?VIBE_CUSTOM_SKINS:0u);vibe_runtime::MarkCustomDirty();}
            section_label("Hold the item to load its skin catalog.");
            char item_name[256]{};
            if(catalog.item_name[0])WideCharToMultiByte(CP_UTF8,0,reinterpret_cast<const wchar_t*>(catalog.item_name),-1,item_name,sizeof(item_name),nullptr,nullptr);
            if(item_name[0])section_label(item_name);
            input_text("Skin search","Name or ID",filter,sizeof(filter),0);
            wchar_t needle[96]{};MultiByteToWideChar(CP_UTF8,0,filter,-1,needle,96);
            const int needle_size=static_cast<int>(std::wcslen(needle));
            const DWORD choice=vibe_skin_choice(&extra,catalog.item_id);
            std::vector<DWORD> matches;
            std::string options=vibe_lang::T("Original skin");options.push_back('\0');
            int selected=0;
            const auto accept_choice=[&](DWORD id){
                if(!vibe_skin_set_choice(&extra,catalog.item_id,id)){profile_full=true;return;}
                profile_full=false;if(id)extra.flags|=VIBE_CUSTOM_SKINS;vibe_runtime::MarkCustomDirty();
            };
            for(DWORD i=0;i<catalog.count&&i<VIBE_SKIN_CATALOG_MAX;++i){
                const auto& entry=catalog.entries[i];const auto* name=reinterpret_cast<const wchar_t*>(entry.name);
                char identifier[24]{};std::snprintf(identifier,sizeof(identifier),"%lu",static_cast<unsigned long>(entry.id));
                bool match=!filter[0]||std::strstr(identifier,filter)!=nullptr;
                const int length=static_cast<int>(std::wcslen(name));
                for(int n=0;!match&&needle_size&&n+needle_size<=length;++n)
                    match=CompareStringOrdinal(name+n,needle_size,needle,needle_size,TRUE)==CSTR_EQUAL;
                if(!match&&entry.id!=choice)continue;
                char label[256]{},display[288]{};WideCharToMultiByte(CP_UTF8,0,name,-1,label,sizeof(label),nullptr,nullptr);
                std::snprintf(display,sizeof(display),"%s [%lu]",label[0]?label:"Skin",static_cast<unsigned long>(entry.id));
                options+=display;options.push_back('\0');matches.push_back(entry.id);
                if(entry.id==choice)selected=static_cast<int>(matches.size());
            }
            if(choice&&!selected){char label[64];std::snprintf(label,sizeof(label),"%s [%lu]",vibe_lang::T("Saved skin"),static_cast<unsigned long>(choice));options+=label;options.push_back('\0');matches.push_back(choice);selected=static_cast<int>(matches.size());}
            options.push_back('\0');
            if(catalog.item_id){
                if(combo("Weapon skin",&selected,options.c_str()))accept_choice(selected>0?matches[static_cast<std::size_t>(selected-1)]:0u);
                if(!matches.empty()){
                    if(button("Previous skin")){selected=(selected+static_cast<int>(matches.size()))%(static_cast<int>(matches.size())+1);accept_choice(selected?matches[static_cast<std::size_t>(selected-1)]:0u);}
                    if(button("Next skin")){selected=(selected+1)%(static_cast<int>(matches.size())+1);accept_choice(selected?matches[static_cast<std::size_t>(selected-1)]:0u);}
                }
                if(button("Restore held item"))accept_choice(0);
            }
            if(button("Refresh skin catalog"))vibe_runtime::RefreshSkinCatalog();
            if(profile_full)section_label("Skin profiles full; remove a saved profile.");
            end_group();gap(8.f);
            begin_group("##skin_profiles",width);group_title("Saved skin profiles");
            static int profile=0;
            if(extra.profile_count){
                if(profile>=static_cast<int>(extra.profile_count))profile=static_cast<int>(extra.profile_count)-1;
                std::string saved;
                for(DWORD i=0;i<extra.profile_count;++i){char label[96];std::snprintf(label,sizeof(label),"Item %lu : Skin %lu",static_cast<unsigned long>(extra.profiles[i].item_id),static_cast<unsigned long>(extra.profiles[i].skin_id));saved+=label;saved.push_back('\0');}
                saved.push_back('\0');combo("Saved profile",&profile,saved.c_str());
                if(button("Remove selected profile")){vibe_skin_set_choice(&extra,extra.profiles[profile].item_id,0);profile=0;profile_full=false;vibe_runtime::MarkCustomDirty();}
            }else section_label("No saved skins");
            if(button("Clear skin profiles")){extra.profile_count=0;std::memset(extra.profiles,0,sizeof(extra.profiles));profile=0;profile_full=false;vibe_runtime::MarkCustomDirty();}
            end_group();return;
        }
    }

    void panel_right(float width, float height, const char* title)
    {
        (void)height;
        (void)title;
        vibe::ESPSettings& c = vibe_runtime::config;

        if (shown_tab == 0) {
            begin_group("##rapid", width);
            group_title("Combat");
            const bool rapid_was_enabled=(c.rapid_flags&1u)!=0;
            cfg_bit("Enable rapid fire", c.rapid_flags, 1u);
            if(!rapid_was_enabled&&(c.rapid_flags&1u)&&c.rapid_percent==100u){
                c.rapid_percent=200u;vibe_runtime::MarkDirty();
            }
            auto& extra=vibe_runtime::custom;
            bool auto_melee=(extra.flags&VIBE_CUSTOM_AUTO_MELEE)!=0;
            if(checkbox("Silent melee auto strikes",&auto_melee)){extra.flags=(extra.flags&~VIBE_CUSTOM_AUTO_MELEE)|(auto_melee?(VIBE_CUSTOM_AUTO_MELEE|VIBE_CUSTOM_FAST_MELEE):0u);if(auto_melee&&extra.melee_percent<500u)extra.melee_percent=500u;vibe_runtime::MarkCustomDirty();}
            if(auto_melee)section_label("Hold Aim: melee strikes in FOV without starting a swing animation.");
            if(auto_melee){cfg_bit("Show FOV",c.aim_flags,2u);cfg_slider("FOV radius",c.aim_fov,0.f,(float)vibe::AIM_FOV_LIMIT,"%.0f px");}
            bool silent_melee=(extra.flags&VIBE_CUSTOM_SILENT_MELEE)!=0;
            if(checkbox("Silent Melee",&silent_melee)){extra.flags=(extra.flags&~VIBE_CUSTOM_SILENT_MELEE)|(silent_melee?VIBE_CUSTOM_SILENT_MELEE:0u);vibe_runtime::MarkCustomDirty();}
            bool fast_melee=(extra.flags&VIBE_CUSTOM_FAST_MELEE)!=0;
            if(checkbox("Fast Melee",&fast_melee)){extra.flags=(extra.flags&~VIBE_CUSTOM_FAST_MELEE)|(fast_melee?VIBE_CUSTOM_FAST_MELEE:0u);vibe_runtime::MarkCustomDirty();}
            float melee_percent=static_cast<float>(extra.melee_percent);
            if(slider_float("Melee speed",&melee_percent,100.f,1000.f,"%.0f%%")){extra.melee_percent=static_cast<DWORD>(melee_percent+.5f);vibe_runtime::MarkCustomDirty();}
            section_label("Silent melee range: 500 cm while Aim is held.");
            section_label("Melee uses Aim key + normal attack, FOV and weapon reach.");
            if(fast_melee)section_label("Client melee delays only; paused during Auto Farm.");
            int rapid_mode=static_cast<int>(extra.rapid_mode);
            if(combo("Rapid mode", &rapid_mode, "Client timer EXP\0Native HvH\0\0")) {extra.rapid_mode=static_cast<DWORD>(rapid_mode);vibe_runtime::MarkCustomDirty();}
            if(!extra.rapid_mode) {cfg_slider("Multiplier",c.rapid_percent,100.f,300.f,"%.0f%%");section_label("Server fire rate is unconfirmed.");}
            else section_label("Requires the game's native HvH permission.");
            cfg_bit("No recoil (camera shake)", c.rapid_flags, 16u);
            cfg_bit("Fast auto reload",c.combat_flags,1u);
            cfg_bit("Auto medkit", c.rapid_flags, 4u);
            cfg_slider("Heal below", c.medkit_threshold, 1.f, 99.f, "%.0f%% HP");
            cfg_slider("Medkit cooldown", c.medkit_delay_ms, 100.f, 10000.f, "%.0f ms");
            for(unsigned i=0;i<8;++i){char label[24];std::snprintf(label,sizeof(label),"Medkit slot %u",i+1);cfg_bit(label,c.medkit_slots,1u<<i);}
            end_group();
            gap(8.f);
            begin_group("##hit_feedback",width);
            group_title("Hit feedback");
            VibeCombatFeedback feedback{};
            if(vibe_runtime::ReadCombatFeedback(feedback)) {
                char text[96];
                section_label(feedback.feedback_ready?"Server hit feedback connected":"Server hit feedback unavailable");
                section_label(feedback.marker_ready?"Native hitmarker connected":"Native hitmarker unavailable");
                section_label(feedback.mute_ready?"Original hitmarker mute available":"Original hitmarker mute unavailable");
                std::snprintf(text,sizeof(text),"%s: %llu / %llu",vibe_lang::T("Game hitmarkers / headshots"),static_cast<unsigned long long>(feedback.marker_hits),static_cast<unsigned long long>(feedback.marker_heads));section_label(text);
                std::snprintf(text,sizeof(text),"%s: %llu / %llu",vibe_lang::T("Confirmed hits / headshots"),static_cast<unsigned long long>(feedback.confirmed_hits),static_cast<unsigned long long>(feedback.confirmed_heads));section_label(text);
                std::snprintf(text,sizeof(text),"%s: %llu / %llu",vibe_lang::T("Native audio / suppressed"),static_cast<unsigned long long>(feedback.native_audio_calls),static_cast<unsigned long long>(feedback.original_audio_suppressed));section_label(text);
                std::snprintf(text,sizeof(text),"%s: %llu / %llu",vibe_lang::T("Queued body / head sounds"),static_cast<unsigned long long>(feedback.queued_body),static_cast<unsigned long long>(feedback.queued_heads));section_label(text);
                section_label("Feedback totals include all weapon modes.");
            }
            end_group();
            config_status_group(width);
            return;
        }

        if (shown_tab == 1) {
            begin_group("##player_preview", width);
            group_title("Graphics and camera");
            static bool show_preview=false;
            checkbox("Show preview",&show_preview);
            if(show_preview)vibe_preview::Draw(ImGui::CalcItemWidth(), c);
            auto& extra=vibe_runtime::custom;
            bool potato=(extra.flags&VIBE_CUSTOM_POTATO)!=0;
            if(checkbox("Potato graphics",&potato)){extra.flags=(extra.flags&~VIBE_CUSTOM_POTATO)|(potato?VIBE_CUSTOM_POTATO:0u);vibe_runtime::MarkCustomDirty();}
            bool third=(extra.flags&VIBE_CUSTOM_THIRD)!=0;
            if(checkbox("Third person",&third)){extra.flags=(extra.flags&~VIBE_CUSTOM_THIRD)|(third?VIBE_CUSTOM_THIRD:0u);vibe_runtime::MarkCustomDirty();}
            float distance=(float)extra.third_distance_cm;
            if(slider_float("Camera distance",&distance,100.f,500.f,"%.0f cm")){extra.third_distance_cm=(uint32_t)distance;vibe_runtime::MarkCustomDirty();}
            bool camera_fov=(extra.flags&VIBE_CUSTOM_CAMERA_FOV)!=0;
            if(checkbox("Custom camera FOV",&camera_fov)){extra.flags=(extra.flags&~VIBE_CUSTOM_CAMERA_FOV)|(camera_fov?VIBE_CUSTOM_CAMERA_FOV:0u);vibe_runtime::MarkCustomDirty();}
            float camera_degrees=(float)extra.camera_fov_deg;
            if(slider_float("Camera FOV",&camera_degrees,40.f,120.f,"%.0f deg")){extra.camera_fov_deg=(uint32_t)camera_degrees;vibe_runtime::MarkCustomDirty();}
            bool zoom=(extra.flags&VIBE_CUSTOM_ZOOM)!=0;
            if(checkbox("Zoom while held",&zoom)){extra.flags=(extra.flags&~VIBE_CUSTOM_ZOOM)|(zoom?VIBE_CUSTOM_ZOOM:0u);vibe_runtime::MarkCustomDirty();}
            int zoom_key=(int)extra.zoom_key;
            if(keybind("Zoom key",&zoom_key)){
                DWORD candidate=zoom_key>0?(DWORD)zoom_key:0u;
                if((!candidate||vibe::SettingsKeyValid(candidate))&&(!candidate||(candidate!=c.aim_key&&candidate!=c.speed_key&&candidate!=c.noclip_key))){extra.zoom_key=candidate;vibe_runtime::MarkCustomDirty();}
            }
            float zoom_power=(float)extra.zoom_percent*.01f;
            if(slider_float("Zoom strength",&zoom_power,1.25f,8.f,"%.2f x")){extra.zoom_percent=(uint32_t)(zoom_power*100.f+.5f);vibe_runtime::MarkCustomDirty();}
            section_label("Hold the zoom key; release restores the view.");
            // ##global_graphics: preview is optional so the menu remains light.

            end_group();
            config_status_group(width);
            return;
        }

        if (shown_tab == 2) {
            begin_group("##farm_timing", width);
            group_title("Range / Timing");
            auto& extra=vibe_runtime::custom;
            if(extra.flags&VIBE_CUSTOM_CRAFT){extra.flags&=~VIBE_CUSTOM_CRAFT;vibe_runtime::MarkCustomDirty();}
            section_label("Fast crafting unavailable on this server queue.");
            section_label("The server controls craft completion.");

            cfg_slider("Farm range", c.farm_range_cm, 50.f, 800.f, "%.0f cm");
            cfg_slider("Search radius", c.farm_search_m, 5.f, (float)vibe::FARM_SEARCH_LIMIT_M, "%.0f m");
            float mining_rate = farm_rate_from_interval(c.farm_interval_ms);
            if (slider_float("Mining speed", &mining_rate, 0.5f, 50.f, vibe_lang::T("%.1f /s"))) {
                c.farm_interval_ms = farm_rate_interval(mining_rate);
                vibe_runtime::MarkDirty();
            }
            section_label("Client timing is accelerated; the server controls harvesting.");
            section_label("Free study also requests learning available recipes.");
            end_group();
            gap(8.0f);
            begin_group("##farm_run_speed", width);
            group_title("Run speed");
            cfg_bit("Speed hack", c.move_flags, 1u);
            cfg_slider("Run speed", c.speed_percent, 100.f, 300.f, "%.0f%%");
            section_label("Uses the Movement speed setting.");
            end_group();
            return;
        }

        if (shown_tab == 3) {
            begin_group("##movement_noclip", width);
            group_title("Noclip");
            cfg_bit("Enable noclip", c.move_flags, 4u);
            cfg_key("Noclip toggle", c.noclip_key, true);
            end_group();
            return;
        }

        if (shown_tab == 4) {
            begin_group("##performance", width);
            group_title("Performance");
            cfg_combo("Profile", c.profile, "Auto\0Smooth\0Eco 30\0\0");
            section_label("Auto: adapts update rate to load.");
            section_label("Smooth: prioritizes responsiveness.");
            section_label("Eco 30: reduces CPU work.");
            section_label("Blur stays off by default for a smoother menu.");
            end_group();
            return;
        }

        if (shown_tab == 5) {
            begin_group("##build_info",width);group_title("VIBE PC 14.10.14");section_label("Direct launch");end_group();gap(8.f);
            begin_group("##settings_file", width);
            group_title("Vibe Settings");
            if (button("Save now")) {
                vibe_runtime::MarkDirty();
                vibe_runtime::ForceSave();
            }
            if (button("Reset defaults")) {
                vibe::DefaultSettings(c);
                vibe_custom_default(&vibe_runtime::custom);vibe_runtime::MarkCustomDirty();
                vibe_runtime::MarkDirty();
            }
            section_label(vibe_runtime::StatusText());
            end_group();
            gap(8.0f);
            begin_group("##metadata_dump",width);group_title("IL2CPP dumper");
            auto dump=vibe_runtime::MetadataDumpStatus();
            if(dump.state==vibe_dump::Running){if(button("Cancel dump"))vibe_runtime::CancelMetadataDump();}
            else if(button("Export dump.cs + JSON"))vibe_runtime::StartMetadataDump();
            const char* dumpStates[]={"Ready to export","Exporting metadata","Dump complete","Dump failed","Dump cancelled"};
            section_label(dumpStates[dump.state<=vibe_dump::Cancelled?dump.state:vibe_dump::Failed]);
            char dumpCounts[192];std::snprintf(dumpCounts,sizeof(dumpCounts),"%s: %llu / %llu | %s: %llu | %s: %llu",vibe_lang::T("Classes"),static_cast<unsigned long long>(dump.classes),static_cast<unsigned long long>(dump.totalClasses),vibe_lang::T("Fields"),static_cast<unsigned long long>(dump.fields),vibe_lang::T("Methods"),static_cast<unsigned long long>(dump.methods));
            ImGui::TextWrapped("%s",dumpCounts);
            if(dump.message[0])ImGui::TextWrapped("%s",vibe_lang::T(dump.message));
            if(dump.directory[0])ImGui::TextWrapped("%s",dump.directory);
            section_label("Saved under dumps next to the DLL.");
            end_group();gap(8.f);
            begin_group("##headshot_audio",width);group_title("Hit sounds");
            auto& extra=vibe_runtime::custom;bool sound=(extra.flags&VIBE_CUSTOM_AUDIO)!=0;
            if(checkbox("Custom hit sounds",&sound)){extra.flags=(extra.flags&~VIBE_CUSTOM_AUDIO)|(sound?VIBE_CUSTOM_AUDIO:0u);vibe_runtime::MarkCustomDirty();}
            bool mute=(extra.flags&VIBE_CUSTOM_MUTE_HIT)!=0;
            if(checkbox("Mute original hit sound",&mute)){extra.flags=(extra.flags&~VIBE_CUSTOM_MUTE_HIT)|(mute?VIBE_CUSTOM_MUTE_HIT:0u);vibe_runtime::MarkCustomDirty();}
            int mode=static_cast<int>(extra.sound_mode);
            if(combo("Sound events",&mode,"All hits\0Headshots only\0\0")){extra.sound_mode=static_cast<DWORD>(mode);vibe_runtime::MarkCustomDirty();}
            int head=static_cast<int>(extra.head_sound),body=static_cast<int>(extra.body_sound);
            const char* sounds="VIBE\0Punch impact\0Hit something\0\0";
            if(combo("Headshot clip",&head,sounds)){extra.head_sound=static_cast<DWORD>(head);vibe_runtime::MarkCustomDirty();}
            if(combo("Body hit clip",&body,sounds)){extra.body_sound=static_cast<DWORD>(body);vibe_runtime::MarkCustomDirty();}
            float volume=static_cast<float>(extra.sound_volume);
            if(slider_float("Volume",&volume,0.f,100.f,"%.0f%%")){extra.sound_volume=static_cast<DWORD>(volume+.5f);vibe_runtime::MarkCustomDirty();}
            if(button("Preview headshot"))vibe_runtime::PreviewHitSound(true);
            if(button("Preview body hit"))vibe_runtime::PreviewHitSound(false);
            section_label("Plays from the native hit audio event.");
            section_label(vibe_runtime::HitAudioStatusText());
            if(vibe_runtime::HitAudioErrorCode()){char error[64];std::snprintf(error,sizeof(error),"%s: %lu",vibe_lang::T("Audio error"),static_cast<unsigned long>(vibe_runtime::HitAudioErrorCode()));section_label(error);}
            end_group();gap(8.f);
            begin_group("##compatibility", width);
            group_title("Compatibility");
            section_label("Automatic metadata rebinding is enabled.");
            section_label(vibe_runtime::CompatibilityStatusText());
            if (button("Check compatibility")) vibe_runtime::RequestCompatibilityCheck();
            section_label("Game updates may still need a new DLL.");
            end_group();
            return;
        }
        if (shown_tab == 6) {
            begin_group("##skin_info",width);group_title("Local appearance");
            VibeSkinCatalog catalog{};vibe_runtime::ReadSkinCatalog(catalog);
            const char* states[]={"Equip an item","Skinchanger unavailable for this build","Loading skin catalog","Choose a skin","Local skin applied","No compatible skins for this item","Original appearance restored","Waiting for held skin model","Skin operation failed","Waiting for skin materials"};
            section_label(states[catalog.status<10?catalog.status:8]);
            char text[128];std::snprintf(text,sizeof(text),"%s: %lu",vibe_lang::T("Item ID"),static_cast<unsigned long>(catalog.item_id));section_label(text);
            std::snprintf(text,sizeof(text),"%s: %lu",vibe_lang::T("Selected skin ID"),static_cast<unsigned long>(vibe_skin_choice(&vibe_runtime::custom,catalog.item_id)));section_label(text);
            std::snprintf(text,sizeof(text),"%s: %lu / 32",vibe_lang::T("Saved profiles"),static_cast<unsigned long>(vibe_runtime::custom.profile_count));section_label(text);
            std::snprintf(text,sizeof(text),"%s: %lu",vibe_lang::T("Held skin models"),static_cast<unsigned long>(catalog.models));section_label(text);
            std::snprintf(text,sizeof(text),"%s: %lu",vibe_lang::T("Available skins"),static_cast<unsigned long>(catalog.count));section_label(text);
            section_label("Visible on your local held model.");section_label("The game loads the skin materials.");
            end_group();return;
        }
    }

    void push_font_stretch() { ImGui::SetWindowFontScale(font_stretch()); }

    static void scroll_wheel_update() {
        ImGuiWindow* w = ImGui::GetCurrentWindow();
        ImGuiStorage* st = ImGui::GetStateStorage();
        const ImGuiID k_target = w->GetID("##egui_sc_target");
        const ImGuiID k_drag   = w->GetID("##egui_sc_drag");
        const ImGuiID k_snap   = w->GetID("##egui_sc_snap");

        const float max_y = ImMax(0.0f, w->ScrollMax.y);
        float target = st->GetFloat(k_target, w->Scroll.y);

        if (g_scroll_reset_next) {
            g_scroll_reset_next = false;
            target = 0.0f;
            st->SetBool(k_snap, true);
        }

        if (ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows | ImGuiHoveredFlags_AllowWhenBlockedByActiveItem)) {
            const float wheel = ImGui::GetIO().MouseWheel;
            if (wheel != 0.0f)
                target -= wheel * ImGui::GetFontSize() * 5.0f;
        }
        target = ImClamp(target, 0.0f, max_y);

        const bool dragging = st->GetBool(k_drag, false);
        const bool snap = st->GetBool(k_snap, false);
        st->SetBool(k_snap, false);
        const float speed = (dragging || snap) ? 1e9f : 16.0f;

        float cur = w->Scroll.y;
        if (ImFabs(cur - target) > 0.05f) {
            cur = ImLerp(cur, target, ImClamp(ImGui::GetIO().DeltaTime * speed, 0.0f, 1.0f));
            if (ImFabs(cur - target) < 0.5f) cur = target;
            ImGui::SetScrollY(cur);
        }
        st->SetFloat(k_target, target);
    }

    static void scroll_bar_draw() {
        ImGuiWindow* w = ImGui::GetCurrentWindow();
        ImGuiStorage* st = ImGui::GetStateStorage();
        const ImGuiID k_target = w->GetID("##egui_sc_target");
        const ImGuiID k_drag   = w->GetID("##egui_sc_drag");

        const float max_y = ImMax(0.0f, w->ScrollMax.y);
        st->SetBool(k_drag, false);
        if (max_y <= 0.0f) return;

        const float view_h = w->Size.y;
        const float track_x = w->Pos.x + w->Size.x - layout.scroll_margin - layout.scroll_w;
        const float track_y0 = w->Pos.y + layout.scroll_margin;
        const float track_y1 = w->Pos.y + view_h - layout.scroll_margin;
        const float track_h = ImMax(track_y1 - track_y0, 1.0f);

        const float thumb_h = ImClamp(track_h * (view_h / (view_h + max_y)), layout.scroll_min, track_h);
        const float thumb_y = track_y0 + (track_h - thumb_h) * ImClamp(w->Scroll.y / max_y, 0.0f, 1.0f);

        const ImVec2 backup_cursor = w->DC.CursorPos;
        const ImVec2 backup_max = w->DC.CursorMaxPos;

        const float grab_w = layout.scroll_w + dpi(6.0f);
        ImGui::SetCursorScreenPos(ImVec2(track_x - dpi(3.0f), track_y0));
        ImGui::InvisibleButton("##scrollbar", ImVec2(grab_w, track_h));

        const bool hovered = ImGui::IsItemHovered();
        const bool held = ImGui::IsItemActive();
        const ImGuiID id = ImGui::GetItemID();
        const ImGuiID k_grab = id ^ 0x5C0117B1u;

        if (ImGui::IsItemActivated()) {
            const float my = ImGui::GetIO().MousePos.y;
            const bool on_thumb = (my >= thumb_y && my <= thumb_y + thumb_h);
            st->SetFloat(k_grab, on_thumb ? (my - thumb_y) : thumb_h * 0.5f);
        }
        if (held) {
            const float grab = st->GetFloat(k_grab, thumb_h * 0.5f);
            const float ty = ImGui::GetIO().MousePos.y - grab;
            const float rel = ImClamp((ty - track_y0) / ImMax(track_h - thumb_h, 1.0f), 0.0f, 1.0f);
            st->SetFloat(k_target, rel * max_y);
            st->SetBool(k_drag, true);
        }

        w->DC.CursorPos = backup_cursor;
        w->DC.CursorMaxPos = backup_max;

        const float hv = anim(anim_hover(id), (hovered || held) ? 1.0f : 0.0f);
        const float r_track = layout.scroll_w * 0.5f;

        edraw.rect_filled(ImVec2(track_x, track_y0), ImVec2(track_x + layout.scroll_w, track_y1),
                          fade(colors.control, 0.35f + 0.45f * hv), r_track);
        edraw.rect_filled(ImVec2(track_x, thumb_y), ImVec2(track_x + layout.scroll_w, thumb_y + thumb_h),
                          ImLerp(colors.scroll, colors.text_muted, hv), r_track);
    }

    void begin_child(const char* name, const ImVec2& size) {
        ImGui::BeginChild(name, size, false,
                          ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_AlwaysUseWindowPadding |
                          ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
        push_font_stretch();
        scroll_wheel_update();
    }

    void end_child() {
        scroll_bar_draw();
        ImGui::EndChild();
    }

}
