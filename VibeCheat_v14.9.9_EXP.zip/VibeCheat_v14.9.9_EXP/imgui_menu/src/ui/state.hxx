#pragma once

class c_variables
{
public:
    struct
    {
        int menu_key = 0x2D; // Insert
        bool streamproof = false; // false = visible in OBS / screen recordings
        int active_tab = 0;
        int active_subtab[7] = {};
        float tab_transition_alpha = 1.0f;
        float subtab_transition_alpha = 1.0f;

        bool show_playerlist = false;
        bool show_active_hotkeys = false;
        bool show_watermark = true;
    } gui;
};

inline c_variables vars;
